#ifndef PROJECT__T3__H
#define PROJECT__T3__H
double watertank3079_t3_ode_1(double d, double watertank3079_x);
double watertank3079_t3_init_1(double x);
#endif
