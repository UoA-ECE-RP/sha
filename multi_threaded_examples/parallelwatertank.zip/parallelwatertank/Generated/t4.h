#ifndef PROJECT__T4__H
#define PROJECT__T4__H
double watertank3079_t4_ode_1(double watertank3079_x);
double watertank3079_t4_init_1(double x);
#endif
