#ifndef PROJECT__T2__H
#define PROJECT__T2__H
double controller_t2_ode_1(double controller_x);
double controller_t2_init_1(double x);
#endif
