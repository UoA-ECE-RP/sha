#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern void readInput();

extern void writeOutput();

//Continous variables

double watertank1157_x=20;

//Continous variable update

static double watertank1157_x_u;

//Continous variable init

static double watertank1157_x_init;

//External variables and events

unsigned char watertank1157_ON;

unsigned char watertank1157_OFF;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2 , t3 , t4};

//Previous state variable

#include "t1.h"
#include <math.h>
double watertank1157_t1_ode_1(double d, double watertank1157_x) {
   double watertank1157_t1_ode_1_result;
   watertank1157_t1_ode_1_result = d*(-0.075*watertank1157_x + 11.25) + watertank1157_x;
   return watertank1157_t1_ode_1_result;
}
double watertank1157_t1_init_1(double x) {
   double watertank1157_t1_init_1_result;
   watertank1157_t1_init_1_result = x;
   return watertank1157_t1_init_1_result;
}


#include "t2.h"
#include <math.h>
double watertank1157_t2_ode_1(double watertank1157_x) {
   double watertank1157_t2_ode_1_result;
   watertank1157_t2_ode_1_result = watertank1157_x;
   return watertank1157_t2_ode_1_result;
}
double watertank1157_t2_init_1(double x) {
   double watertank1157_t2_init_1_result;
   watertank1157_t2_init_1_result = x;
   return watertank1157_t2_init_1_result;
}


#include "t3.h"
#include <math.h>
double watertank1157_t3_ode_1(double d, double watertank1157_x) {
   double watertank1157_t3_ode_1_result;
   watertank1157_t3_ode_1_result = -0.075*d*watertank1157_x + watertank1157_x;
   return watertank1157_t3_ode_1_result;
}
double watertank1157_t3_init_1(double x) {
   double watertank1157_t3_init_1_result;
   watertank1157_t3_init_1_result = x;
   return watertank1157_t3_init_1_result;
}


#include "t4.h"
#include <math.h>
double watertank1157_t4_ode_1(double watertank1157_x) {
   double watertank1157_t4_ode_1_result;
   watertank1157_t4_ode_1_result = watertank1157_x;
   return watertank1157_t4_ode_1_result;
}
double watertank1157_t4_init_1(double x) {
   double watertank1157_t4_init_1_result;
   watertank1157_t4_init_1_result = x;
   return watertank1157_t4_init_1_result;
}


enum states watertank1157(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (t1):
    if(watertank1157_x >= 20 && watertank1157_x <= 100 && !watertank1157_ON && !watertank1157_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank1157_x = watertank1157_t1_init_1(watertank1157_x);
        watertank1157_x_init = watertank1157_x;
      }
      watertank1157_x_u = watertank1157_t1_ode_1(d, watertank1157_x);
      if(watertank1157_x_u > 100 && watertank1157_x_init <= 100)
        watertank1157_x_u = 100;
      ++k;
      cstate = t1;
      force_init_update = False;
    }
    else if(True && watertank1157_x >= 100 && watertank1157_x <= 100) {
      k=1;
      cstate=t2;
      watertank1157_x_u = watertank1157_x;
    }
    else if(watertank1157_OFF && True) {
      k=1;
      cstate=t3;
      watertank1157_x_u = watertank1157_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(watertank1157_x >= 100 && watertank1157_x <= 100 && !watertank1157_ON && !watertank1157_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank1157_x = watertank1157_t2_init_1(watertank1157_x);
        watertank1157_x_init = watertank1157_x;
      }
      watertank1157_x_u = watertank1157_t2_ode_1(watertank1157_x);
      ++k;
      cstate = t2;
      force_init_update = False;
    }
    else if(watertank1157_OFF && True) {
      k=1;
      cstate=t3;
      watertank1157_x_u = watertank1157_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t3):
    if(watertank1157_x >= 20 && watertank1157_x <= 100 && !watertank1157_ON && !watertank1157_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank1157_x = watertank1157_t3_init_1(watertank1157_x);
        watertank1157_x_init = watertank1157_x;
      }
      watertank1157_x_u = watertank1157_t3_ode_1(d, watertank1157_x);
      if(watertank1157_x_u < 20 && watertank1157_x_init >= 20)
        watertank1157_x_u = 20;
      ++k;
      cstate = t3;
      force_init_update = False;
    }
    else if(watertank1157_ON && True) {
      k=1;
      cstate=t1;
      watertank1157_x_u = watertank1157_x;
    }
    else if(True && watertank1157_x >= 20 && watertank1157_x <= 20) {
      k=1;
      cstate=t4;
      watertank1157_x_u = watertank1157_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t4):
    if(watertank1157_x >= 20 && watertank1157_x <= 20 && !watertank1157_ON && !watertank1157_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank1157_x = watertank1157_t4_init_1(watertank1157_x);
        watertank1157_x_init = watertank1157_x;
      }
      watertank1157_x_u = watertank1157_t4_ode_1(watertank1157_x);
      ++k;
      cstate = t4;
      force_init_update = False;
    }
    else if(watertank1157_ON && True) {
      k=1;
      cstate=t1;
      watertank1157_x_u = watertank1157_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  watertank1157_x = watertank1157_x_u;
  return cstate;
}