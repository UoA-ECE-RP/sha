#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern void readInput();

extern void writeOutput();

//External variables and events

double controller_x;

unsigned char controller_ON;

unsigned char controller_OFF;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2};

//Previous state variable


enum states controller(enum states cstate, enum states pstate) {
  static double fk;
    static unsigned char force_init_update;
    switch (cstate) {  
    case (t1):
        if(controller_x >= 20 && controller_x <= 100){
            ++k;
            cstate = t1;
            force_init_update = False;
        }
        else if(True && controller_x >= 100 && controller_x <= 100) {
          k=1;      
            cstate=t2;
            controller_ON = 0;
            controller_OFF = 1;
        }
        else {
          fprintf(stderr,"Unreachable state!");
          exit(1);
        }
        break;
    case (t2):
        if(controller_x >= 20 && controller_x <= 100){
          ++k;     
            cstate = t2;
            force_init_update = False;
        }
        else if(True && controller_x >= 20 && controller_x <= 20) {
            k=1;      
            cstate=t1;      
            controller_OFF = 0;      
            controller_ON = 1;   
        }
        else {    
            fprintf(stderr,"Unreachable state!");
            exit(1);    
        }    
        break;  
    default: exit(1); 
    }  
    return cstate;
}




