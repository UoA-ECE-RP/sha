#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern void readInput();

extern void writeOutput();

//Continous variables

double watertank11_x=20;

//Continous variable update

static double watertank11_x_u;

//Continous variable init

static double watertank11_x_init;

//External variables and events

unsigned char watertank11_ON;

unsigned char watertank11_OFF;

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2 , t3 , t4};

//Previous state variable

#include "t1.h"
#include <math.h>
double watertank11_t1_ode_1(double d, double watertank11_x) {
   double watertank11_t1_ode_1_result;
   watertank11_t1_ode_1_result = d*(-0.075*watertank11_x + 11.25) + watertank11_x;
   return watertank11_t1_ode_1_result;
}
double watertank11_t1_init_1(double x) {
   double watertank11_t1_init_1_result;
   watertank11_t1_init_1_result = x;
   return watertank11_t1_init_1_result;
}


#include "t2.h"
#include <math.h>
double watertank11_t2_ode_1(double watertank11_x) {
   double watertank11_t2_ode_1_result;
   watertank11_t2_ode_1_result = watertank11_x;
   return watertank11_t2_ode_1_result;
}
double watertank11_t2_init_1(double x) {
   double watertank11_t2_init_1_result;
   watertank11_t2_init_1_result = x;
   return watertank11_t2_init_1_result;
}


#include "t3.h"
#include <math.h>
double watertank11_t3_ode_1(double d, double watertank11_x) {
   double watertank11_t3_ode_1_result;
   watertank11_t3_ode_1_result = -0.075*d*watertank11_x + watertank11_x;
   return watertank11_t3_ode_1_result;
}
double watertank11_t3_init_1(double x) {
   double watertank11_t3_init_1_result;
   watertank11_t3_init_1_result = x;
   return watertank11_t3_init_1_result;
}


#include "t4.h"
#include <math.h>
double watertank11_t4_ode_1(double watertank11_x) {
   double watertank11_t4_ode_1_result;
   watertank11_t4_ode_1_result = watertank11_x;
   return watertank11_t4_ode_1_result;
}
double watertank11_t4_init_1(double x) {
   double watertank11_t4_init_1_result;
   watertank11_t4_init_1_result = x;
   return watertank11_t4_init_1_result;
}


enum states watertank11(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (t1):
    if(watertank11_x >= 20 && watertank11_x <= 100 && !watertank11_ON && !watertank11_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank11_x = watertank11_t1_init_1(watertank11_x);
        watertank11_x_init = watertank11_x;
      }
      watertank11_x_u = watertank11_t1_ode_1(d, watertank11_x);
      if(watertank11_x_u > 100 && watertank11_x_init <= 100)
        watertank11_x_u = 100;
      ++k;
      cstate = t1;
      force_init_update = False;
    }
    else if(True && watertank11_x >= 100 && watertank11_x <= 100) {
      k=1;
      cstate=t2;
      watertank11_x_u = watertank11_x;
    }
    else if(watertank11_OFF && True) {
      k=1;
      cstate=t3;
      watertank11_x_u = watertank11_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(watertank11_x >= 100 && watertank11_x <= 100 && !watertank11_ON && !watertank11_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank11_x = watertank11_t2_init_1(watertank11_x);
        watertank11_x_init = watertank11_x;
      }
      watertank11_x_u = watertank11_t2_ode_1(watertank11_x);
      ++k;
      cstate = t2;
      force_init_update = False;
    }
    else if(watertank11_OFF && True) {
      k=1;
      cstate=t3;
      watertank11_x_u = watertank11_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t3):
    if(watertank11_x >= 20 && watertank11_x <= 100 && !watertank11_ON && !watertank11_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank11_x = watertank11_t3_init_1(watertank11_x);
        watertank11_x_init = watertank11_x;
      }
      watertank11_x_u = watertank11_t3_ode_1(d, watertank11_x);
      if(watertank11_x_u < 20 && watertank11_x_init >= 20)
        watertank11_x_u = 20;
      ++k;
      cstate = t3;
      force_init_update = False;
    }
    else if(watertank11_ON && True) {
      k=1;
      cstate=t1;
      watertank11_x_u = watertank11_x;
    }
    else if(True && watertank11_x >= 20 && watertank11_x <= 20) {
      k=1;
      cstate=t4;
      watertank11_x_u = watertank11_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t4):
    if(watertank11_x >= 20 && watertank11_x <= 20 && !watertank11_ON && !watertank11_OFF){
      if ((pstate != cstate) || force_init_update){
        watertank11_x = watertank11_t4_init_1(watertank11_x);
        watertank11_x_init = watertank11_x;
      }
      watertank11_x_u = watertank11_t4_ode_1(watertank11_x);
      ++k;
      cstate = t4;
      force_init_update = False;
    }
    else if(watertank11_ON && True) {
      k=1;
      cstate=t1;
      watertank11_x_u = watertank11_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  watertank11_x = watertank11_x_u;
  return cstate;
}