#ifndef PROJECT__T1__H
#define PROJECT__T1__H
double controller_t1_ode_1(double controller_x, double d);
double controller_t1_init_1(double x);
#endif
