#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v100_v_i_0;
double v100_v_i_1;
double v100_v_i_2;
double v100_v_i_3;
double v100_voo = 0.0;
double v100_state = 0.0;


static double  v100_vx  =  0 ,  v100_vy  =  0 ,  v100_vz  =  0 ,  v100_g  =  0 ,  v100_v  =  0 ,  v100_ft  =  0 ,  v100_theta  =  0 ,  v100_v_O  =  0 ; //the continuous vars
static double  v100_vx_u , v100_vy_u , v100_vz_u , v100_g_u , v100_v_u , v100_ft_u , v100_theta_u , v100_v_O_u ; // and their updates
static double  v100_vx_init , v100_vy_init , v100_vz_init , v100_g_init , v100_v_init , v100_ft_init , v100_theta_init , v100_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v100_t1 , v100_t2 , v100_t3 , v100_t4 }; // state declarations

enum states v100 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v100_t1 ):
    if (True == False) {;}
    else if  (v100_g > (44.5)) {
      v100_vx_u = (0.3 * v100_v) ;
      v100_vy_u = 0 ;
      v100_vz_u = (0.7 * v100_v) ;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      v100_theta_u = (v100_v / 30.0) ;
      v100_v_O_u = (131.1 + (- (80.1 * pow ( ((v100_v / 30.0)) , (0.5) )))) ;
      v100_ft_u = f (v100_theta,4.0e-2) ;
      cstate =  v100_t2 ;
      force_init_update = False;
    }

    else if ( v100_v <= (44.5)
               && v100_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v100_vx_init = v100_vx ;
      slope =  (v100_vx * -8.7) ;
      v100_vx_u = (slope * d) + v100_vx ;
      if ((pstate != cstate) || force_init_update) v100_vy_init = v100_vy ;
      slope =  (v100_vy * -190.9) ;
      v100_vy_u = (slope * d) + v100_vy ;
      if ((pstate != cstate) || force_init_update) v100_vz_init = v100_vz ;
      slope =  (v100_vz * -190.4) ;
      v100_vz_u = (slope * d) + v100_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v100_t1 ;
      force_init_update = False;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      v100_v_u = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_voo = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v100!\n");
      exit(1);
    }
    break;
  case ( v100_t2 ):
    if (True == False) {;}
    else if  (v100_v >= (44.5)) {
      v100_vx_u = v100_vx ;
      v100_vy_u = v100_vy ;
      v100_vz_u = v100_vz ;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v100_t3 ;
      force_init_update = False;
    }
    else if  (v100_g <= (44.5)
               && v100_v < (44.5)) {
      v100_vx_u = v100_vx ;
      v100_vy_u = v100_vy ;
      v100_vz_u = v100_vz ;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v100_t1 ;
      force_init_update = False;
    }

    else if ( v100_v < (44.5)
               && v100_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v100_vx_init = v100_vx ;
      slope =  ((v100_vx * -23.6) + (777200.0 * v100_g)) ;
      v100_vx_u = (slope * d) + v100_vx ;
      if ((pstate != cstate) || force_init_update) v100_vy_init = v100_vy ;
      slope =  ((v100_vy * -45.5) + (58900.0 * v100_g)) ;
      v100_vy_u = (slope * d) + v100_vy ;
      if ((pstate != cstate) || force_init_update) v100_vz_init = v100_vz ;
      slope =  ((v100_vz * -12.9) + (276600.0 * v100_g)) ;
      v100_vz_u = (slope * d) + v100_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v100_t2 ;
      force_init_update = False;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      v100_v_u = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_voo = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v100!\n");
      exit(1);
    }
    break;
  case ( v100_t3 ):
    if (True == False) {;}
    else if  (v100_v >= (131.1)) {
      v100_vx_u = v100_vx ;
      v100_vy_u = v100_vy ;
      v100_vz_u = v100_vz ;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v100_t4 ;
      force_init_update = False;
    }

    else if ( v100_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v100_vx_init = v100_vx ;
      slope =  (v100_vx * -6.9) ;
      v100_vx_u = (slope * d) + v100_vx ;
      if ((pstate != cstate) || force_init_update) v100_vy_init = v100_vy ;
      slope =  (v100_vy * 75.9) ;
      v100_vy_u = (slope * d) + v100_vy ;
      if ((pstate != cstate) || force_init_update) v100_vz_init = v100_vz ;
      slope =  (v100_vz * 6826.5) ;
      v100_vz_u = (slope * d) + v100_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v100_t3 ;
      force_init_update = False;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      v100_v_u = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_voo = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v100!\n");
      exit(1);
    }
    break;
  case ( v100_t4 ):
    if (True == False) {;}
    else if  (v100_v <= (30.0)) {
      v100_vx_u = v100_vx ;
      v100_vy_u = v100_vy ;
      v100_vz_u = v100_vz ;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v100_t1 ;
      force_init_update = False;
    }

    else if ( v100_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v100_vx_init = v100_vx ;
      slope =  (v100_vx * -33.2) ;
      v100_vx_u = (slope * d) + v100_vx ;
      if ((pstate != cstate) || force_init_update) v100_vy_init = v100_vy ;
      slope =  ((v100_vy * 20.0) * v100_ft) ;
      v100_vy_u = (slope * d) + v100_vy ;
      if ((pstate != cstate) || force_init_update) v100_vz_init = v100_vz ;
      slope =  ((v100_vz * 2.0) * v100_ft) ;
      v100_vz_u = (slope * d) + v100_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v100_t4 ;
      force_init_update = False;
      v100_g_u = ((((((((((((v100_v_i_0 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v100_v_i_1 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.21633744931))) + ((((v100_v_i_2 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24764616044))) + ((((v100_v_i_3 + (- ((v100_vx + (- v100_vy)) + v100_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + 0) + 0) + 0) + 0) + 0) ;
      v100_v_u = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_voo = ((v100_vx + (- v100_vy)) + v100_vz) ;
      v100_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v100!\n");
      exit(1);
    }
    break;
  }
  v100_vx = v100_vx_u;
  v100_vy = v100_vy_u;
  v100_vz = v100_vz_u;
  v100_g = v100_g_u;
  v100_v = v100_v_u;
  v100_ft = v100_ft_u;
  v100_theta = v100_theta_u;
  v100_v_O = v100_v_O_u;
  return cstate;
}