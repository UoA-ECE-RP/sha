#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v124_v_i_0;
double v124_v_i_1;
double v124_v_i_2;
double v124_v_i_3;
double v124_voo = 0.0;
double v124_state = 0.0;


static double  v124_vx  =  0 ,  v124_vy  =  0 ,  v124_vz  =  0 ,  v124_g  =  0 ,  v124_v  =  0 ,  v124_ft  =  0 ,  v124_theta  =  0 ,  v124_v_O  =  0 ; //the continuous vars
static double  v124_vx_u , v124_vy_u , v124_vz_u , v124_g_u , v124_v_u , v124_ft_u , v124_theta_u , v124_v_O_u ; // and their updates
static double  v124_vx_init , v124_vy_init , v124_vz_init , v124_g_init , v124_v_init , v124_ft_init , v124_theta_init , v124_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v124_t1 , v124_t2 , v124_t3 , v124_t4 }; // state declarations

enum states v124 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v124_t1 ):
    if (True == False) {;}
    else if  (v124_g > (44.5)) {
      v124_vx_u = (0.3 * v124_v) ;
      v124_vy_u = 0 ;
      v124_vz_u = (0.7 * v124_v) ;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v124_theta_u = (v124_v / 30.0) ;
      v124_v_O_u = (131.1 + (- (80.1 * pow ( ((v124_v / 30.0)) , (0.5) )))) ;
      v124_ft_u = f (v124_theta,4.0e-2) ;
      cstate =  v124_t2 ;
      force_init_update = False;
    }

    else if ( v124_v <= (44.5)
               && v124_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v124_vx_init = v124_vx ;
      slope =  (v124_vx * -8.7) ;
      v124_vx_u = (slope * d) + v124_vx ;
      if ((pstate != cstate) || force_init_update) v124_vy_init = v124_vy ;
      slope =  (v124_vy * -190.9) ;
      v124_vy_u = (slope * d) + v124_vy ;
      if ((pstate != cstate) || force_init_update) v124_vz_init = v124_vz ;
      slope =  (v124_vz * -190.4) ;
      v124_vz_u = (slope * d) + v124_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v124_t1 ;
      force_init_update = False;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v124_v_u = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_voo = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v124!\n");
      exit(1);
    }
    break;
  case ( v124_t2 ):
    if (True == False) {;}
    else if  (v124_v >= (44.5)) {
      v124_vx_u = v124_vx ;
      v124_vy_u = v124_vy ;
      v124_vz_u = v124_vz ;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v124_t3 ;
      force_init_update = False;
    }
    else if  (v124_g <= (44.5)
               && v124_v < (44.5)) {
      v124_vx_u = v124_vx ;
      v124_vy_u = v124_vy ;
      v124_vz_u = v124_vz ;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v124_t1 ;
      force_init_update = False;
    }

    else if ( v124_v < (44.5)
               && v124_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v124_vx_init = v124_vx ;
      slope =  ((v124_vx * -23.6) + (777200.0 * v124_g)) ;
      v124_vx_u = (slope * d) + v124_vx ;
      if ((pstate != cstate) || force_init_update) v124_vy_init = v124_vy ;
      slope =  ((v124_vy * -45.5) + (58900.0 * v124_g)) ;
      v124_vy_u = (slope * d) + v124_vy ;
      if ((pstate != cstate) || force_init_update) v124_vz_init = v124_vz ;
      slope =  ((v124_vz * -12.9) + (276600.0 * v124_g)) ;
      v124_vz_u = (slope * d) + v124_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v124_t2 ;
      force_init_update = False;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v124_v_u = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_voo = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v124!\n");
      exit(1);
    }
    break;
  case ( v124_t3 ):
    if (True == False) {;}
    else if  (v124_v >= (131.1)) {
      v124_vx_u = v124_vx ;
      v124_vy_u = v124_vy ;
      v124_vz_u = v124_vz ;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v124_t4 ;
      force_init_update = False;
    }

    else if ( v124_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v124_vx_init = v124_vx ;
      slope =  (v124_vx * -6.9) ;
      v124_vx_u = (slope * d) + v124_vx ;
      if ((pstate != cstate) || force_init_update) v124_vy_init = v124_vy ;
      slope =  (v124_vy * 75.9) ;
      v124_vy_u = (slope * d) + v124_vy ;
      if ((pstate != cstate) || force_init_update) v124_vz_init = v124_vz ;
      slope =  (v124_vz * 6826.5) ;
      v124_vz_u = (slope * d) + v124_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v124_t3 ;
      force_init_update = False;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v124_v_u = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_voo = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v124!\n");
      exit(1);
    }
    break;
  case ( v124_t4 ):
    if (True == False) {;}
    else if  (v124_v <= (30.0)) {
      v124_vx_u = v124_vx ;
      v124_vy_u = v124_vy ;
      v124_vz_u = v124_vz ;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v124_t1 ;
      force_init_update = False;
    }

    else if ( v124_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v124_vx_init = v124_vx ;
      slope =  (v124_vx * -33.2) ;
      v124_vx_u = (slope * d) + v124_vx ;
      if ((pstate != cstate) || force_init_update) v124_vy_init = v124_vy ;
      slope =  ((v124_vy * 20.0) * v124_ft) ;
      v124_vy_u = (slope * d) + v124_vy ;
      if ((pstate != cstate) || force_init_update) v124_vz_init = v124_vz ;
      slope =  ((v124_vz * 2.0) * v124_ft) ;
      v124_vz_u = (slope * d) + v124_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v124_t4 ;
      force_init_update = False;
      v124_g_u = ((((((((((((v124_v_i_0 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617)) + ((((v124_v_i_1 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v124_v_i_2 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.49473814994))) + ((((v124_v_i_3 + (- ((v124_vx + (- v124_vy)) + v124_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v124_v_u = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_voo = ((v124_vx + (- v124_vy)) + v124_vz) ;
      v124_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v124!\n");
      exit(1);
    }
    break;
  }
  v124_vx = v124_vx_u;
  v124_vy = v124_vy_u;
  v124_vz = v124_vz_u;
  v124_g = v124_g_u;
  v124_v = v124_v_u;
  v124_ft = v124_ft_u;
  v124_theta = v124_theta_u;
  v124_v_O = v124_v_O_u;
  return cstate;
}