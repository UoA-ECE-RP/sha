#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v101_v_i_0;
double v101_v_i_1;
double v101_v_i_2;
double v101_voo = 0.0;
double v101_state = 0.0;


static double  v101_vx  =  0 ,  v101_vy  =  0 ,  v101_vz  =  0 ,  v101_g  =  0 ,  v101_v  =  0 ,  v101_ft  =  0 ,  v101_theta  =  0 ,  v101_v_O  =  0 ; //the continuous vars
static double  v101_vx_u , v101_vy_u , v101_vz_u , v101_g_u , v101_v_u , v101_ft_u , v101_theta_u , v101_v_O_u ; // and their updates
static double  v101_vx_init , v101_vy_init , v101_vz_init , v101_g_init , v101_v_init , v101_ft_init , v101_theta_init , v101_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v101_t1 , v101_t2 , v101_t3 , v101_t4 }; // state declarations

enum states v101 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v101_t1 ):
    if (True == False) {;}
    else if  (v101_g > (44.5)) {
      v101_vx_u = (0.3 * v101_v) ;
      v101_vy_u = 0 ;
      v101_vz_u = (0.7 * v101_v) ;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v101_theta_u = (v101_v / 30.0) ;
      v101_v_O_u = (131.1 + (- (80.1 * pow ( ((v101_v / 30.0)) , (0.5) )))) ;
      v101_ft_u = f (v101_theta,4.0e-2) ;
      cstate =  v101_t2 ;
      force_init_update = False;
    }

    else if ( v101_v <= (44.5)
               && v101_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v101_vx_init = v101_vx ;
      slope =  (v101_vx * -8.7) ;
      v101_vx_u = (slope * d) + v101_vx ;
      if ((pstate != cstate) || force_init_update) v101_vy_init = v101_vy ;
      slope =  (v101_vy * -190.9) ;
      v101_vy_u = (slope * d) + v101_vy ;
      if ((pstate != cstate) || force_init_update) v101_vz_init = v101_vz ;
      slope =  (v101_vz * -190.4) ;
      v101_vz_u = (slope * d) + v101_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v101_t1 ;
      force_init_update = False;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v101_v_u = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_voo = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101!\n");
      exit(1);
    }
    break;
  case ( v101_t2 ):
    if (True == False) {;}
    else if  (v101_v >= (44.5)) {
      v101_vx_u = v101_vx ;
      v101_vy_u = v101_vy ;
      v101_vz_u = v101_vz ;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v101_t3 ;
      force_init_update = False;
    }
    else if  (v101_g <= (44.5)
               && v101_v < (44.5)) {
      v101_vx_u = v101_vx ;
      v101_vy_u = v101_vy ;
      v101_vz_u = v101_vz ;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v101_t1 ;
      force_init_update = False;
    }

    else if ( v101_v < (44.5)
               && v101_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v101_vx_init = v101_vx ;
      slope =  ((v101_vx * -23.6) + (777200.0 * v101_g)) ;
      v101_vx_u = (slope * d) + v101_vx ;
      if ((pstate != cstate) || force_init_update) v101_vy_init = v101_vy ;
      slope =  ((v101_vy * -45.5) + (58900.0 * v101_g)) ;
      v101_vy_u = (slope * d) + v101_vy ;
      if ((pstate != cstate) || force_init_update) v101_vz_init = v101_vz ;
      slope =  ((v101_vz * -12.9) + (276600.0 * v101_g)) ;
      v101_vz_u = (slope * d) + v101_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v101_t2 ;
      force_init_update = False;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v101_v_u = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_voo = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101!\n");
      exit(1);
    }
    break;
  case ( v101_t3 ):
    if (True == False) {;}
    else if  (v101_v >= (131.1)) {
      v101_vx_u = v101_vx ;
      v101_vy_u = v101_vy ;
      v101_vz_u = v101_vz ;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v101_t4 ;
      force_init_update = False;
    }

    else if ( v101_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v101_vx_init = v101_vx ;
      slope =  (v101_vx * -6.9) ;
      v101_vx_u = (slope * d) + v101_vx ;
      if ((pstate != cstate) || force_init_update) v101_vy_init = v101_vy ;
      slope =  (v101_vy * 75.9) ;
      v101_vy_u = (slope * d) + v101_vy ;
      if ((pstate != cstate) || force_init_update) v101_vz_init = v101_vz ;
      slope =  (v101_vz * 6826.5) ;
      v101_vz_u = (slope * d) + v101_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v101_t3 ;
      force_init_update = False;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v101_v_u = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_voo = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101!\n");
      exit(1);
    }
    break;
  case ( v101_t4 ):
    if (True == False) {;}
    else if  (v101_v <= (30.0)) {
      v101_vx_u = v101_vx ;
      v101_vy_u = v101_vy ;
      v101_vz_u = v101_vz ;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v101_t1 ;
      force_init_update = False;
    }

    else if ( v101_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v101_vx_init = v101_vx ;
      slope =  (v101_vx * -33.2) ;
      v101_vx_u = (slope * d) + v101_vx ;
      if ((pstate != cstate) || force_init_update) v101_vy_init = v101_vy ;
      slope =  ((v101_vy * 20.0) * v101_ft) ;
      v101_vy_u = (slope * d) + v101_vy ;
      if ((pstate != cstate) || force_init_update) v101_vz_init = v101_vz ;
      slope =  ((v101_vz * 2.0) * v101_ft) ;
      v101_vz_u = (slope * d) + v101_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v101_t4 ;
      force_init_update = False;
      v101_g_u = ((((((((((((v101_v_i_0 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v101_v_i_1 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v101_v_i_2 + (- ((v101_vx + (- v101_vy)) + v101_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v101_v_u = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_voo = ((v101_vx + (- v101_vy)) + v101_vz) ;
      v101_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101!\n");
      exit(1);
    }
    break;
  }
  v101_vx = v101_vx_u;
  v101_vy = v101_vy_u;
  v101_vz = v101_vz_u;
  v101_g = v101_g_u;
  v101_v = v101_v_u;
  v101_ft = v101_ft_u;
  v101_theta = v101_theta_u;
  v101_v_O = v101_v_O_u;
  return cstate;
}