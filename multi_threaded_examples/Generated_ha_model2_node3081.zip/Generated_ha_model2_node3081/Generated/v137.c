#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v137_v_i_0;
double v137_v_i_1;
double v137_v_i_2;
double v137_v_i_3;
double v137_voo = 0.0;
double v137_state = 0.0;


static double  v137_vx  =  0 ,  v137_vy  =  0 ,  v137_vz  =  0 ,  v137_g  =  0 ,  v137_v  =  0 ,  v137_ft  =  0 ,  v137_theta  =  0 ,  v137_v_O  =  0 ; //the continuous vars
static double  v137_vx_u , v137_vy_u , v137_vz_u , v137_g_u , v137_v_u , v137_ft_u , v137_theta_u , v137_v_O_u ; // and their updates
static double  v137_vx_init , v137_vy_init , v137_vz_init , v137_g_init , v137_v_init , v137_ft_init , v137_theta_init , v137_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v137_t1 , v137_t2 , v137_t3 , v137_t4 }; // state declarations

enum states v137 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v137_t1 ):
    if (True == False) {;}
    else if  (v137_g > (44.5)) {
      v137_vx_u = (0.3 * v137_v) ;
      v137_vy_u = 0 ;
      v137_vz_u = (0.7 * v137_v) ;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      v137_theta_u = (v137_v / 30.0) ;
      v137_v_O_u = (131.1 + (- (80.1 * pow ( ((v137_v / 30.0)) , (0.5) )))) ;
      v137_ft_u = f (v137_theta,4.0e-2) ;
      cstate =  v137_t2 ;
      force_init_update = False;
    }

    else if ( v137_v <= (44.5)
               && v137_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v137_vx_init = v137_vx ;
      slope =  (v137_vx * -8.7) ;
      v137_vx_u = (slope * d) + v137_vx ;
      if ((pstate != cstate) || force_init_update) v137_vy_init = v137_vy ;
      slope =  (v137_vy * -190.9) ;
      v137_vy_u = (slope * d) + v137_vy ;
      if ((pstate != cstate) || force_init_update) v137_vz_init = v137_vz ;
      slope =  (v137_vz * -190.4) ;
      v137_vz_u = (slope * d) + v137_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v137_t1 ;
      force_init_update = False;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      v137_v_u = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_voo = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v137!\n");
      exit(1);
    }
    break;
  case ( v137_t2 ):
    if (True == False) {;}
    else if  (v137_v >= (44.5)) {
      v137_vx_u = v137_vx ;
      v137_vy_u = v137_vy ;
      v137_vz_u = v137_vz ;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v137_t3 ;
      force_init_update = False;
    }
    else if  (v137_g <= (44.5)
               && v137_v < (44.5)) {
      v137_vx_u = v137_vx ;
      v137_vy_u = v137_vy ;
      v137_vz_u = v137_vz ;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v137_t1 ;
      force_init_update = False;
    }

    else if ( v137_v < (44.5)
               && v137_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v137_vx_init = v137_vx ;
      slope =  ((v137_vx * -23.6) + (777200.0 * v137_g)) ;
      v137_vx_u = (slope * d) + v137_vx ;
      if ((pstate != cstate) || force_init_update) v137_vy_init = v137_vy ;
      slope =  ((v137_vy * -45.5) + (58900.0 * v137_g)) ;
      v137_vy_u = (slope * d) + v137_vy ;
      if ((pstate != cstate) || force_init_update) v137_vz_init = v137_vz ;
      slope =  ((v137_vz * -12.9) + (276600.0 * v137_g)) ;
      v137_vz_u = (slope * d) + v137_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v137_t2 ;
      force_init_update = False;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      v137_v_u = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_voo = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v137!\n");
      exit(1);
    }
    break;
  case ( v137_t3 ):
    if (True == False) {;}
    else if  (v137_v >= (131.1)) {
      v137_vx_u = v137_vx ;
      v137_vy_u = v137_vy ;
      v137_vz_u = v137_vz ;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v137_t4 ;
      force_init_update = False;
    }

    else if ( v137_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v137_vx_init = v137_vx ;
      slope =  (v137_vx * -6.9) ;
      v137_vx_u = (slope * d) + v137_vx ;
      if ((pstate != cstate) || force_init_update) v137_vy_init = v137_vy ;
      slope =  (v137_vy * 75.9) ;
      v137_vy_u = (slope * d) + v137_vy ;
      if ((pstate != cstate) || force_init_update) v137_vz_init = v137_vz ;
      slope =  (v137_vz * 6826.5) ;
      v137_vz_u = (slope * d) + v137_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v137_t3 ;
      force_init_update = False;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      v137_v_u = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_voo = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v137!\n");
      exit(1);
    }
    break;
  case ( v137_t4 ):
    if (True == False) {;}
    else if  (v137_v <= (30.0)) {
      v137_vx_u = v137_vx ;
      v137_vy_u = v137_vy ;
      v137_vz_u = v137_vz ;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v137_t1 ;
      force_init_update = False;
    }

    else if ( v137_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v137_vx_init = v137_vx ;
      slope =  (v137_vx * -33.2) ;
      v137_vx_u = (slope * d) + v137_vx ;
      if ((pstate != cstate) || force_init_update) v137_vy_init = v137_vy ;
      slope =  ((v137_vy * 20.0) * v137_ft) ;
      v137_vy_u = (slope * d) + v137_vy ;
      if ((pstate != cstate) || force_init_update) v137_vz_init = v137_vz ;
      slope =  ((v137_vz * 2.0) * v137_ft) ;
      v137_vz_u = (slope * d) + v137_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v137_t4 ;
      force_init_update = False;
      v137_g_u = ((((((((((((v137_v_i_0 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v137_v_i_1 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v137_v_i_2 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v137_v_i_3 + (- ((v137_vx + (- v137_vy)) + v137_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11079528828))) + 0) + 0) + 0) + 0) + 0) ;
      v137_v_u = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_voo = ((v137_vx + (- v137_vy)) + v137_vz) ;
      v137_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v137!\n");
      exit(1);
    }
    break;
  }
  v137_vx = v137_vx_u;
  v137_vy = v137_vy_u;
  v137_vz = v137_vz_u;
  v137_g = v137_g_u;
  v137_v = v137_v_u;
  v137_ft = v137_ft_u;
  v137_theta = v137_theta_u;
  v137_v_O = v137_v_O_u;
  return cstate;
}