#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v119_v118_update_c1vd();
extern double v119_v118_update_c2vd();
extern double v119_v118_update_c1md();
extern double v119_v118_update_c2md();
extern double v119_v118_update_buffer_index(double,double,double,double);
extern double v119_v118_update_latch1(double,double);
extern double v119_v118_update_latch2(double,double);
extern double v119_v118_update_ocell1(double,double);
extern double v119_v118_update_ocell2(double,double);
double v119_v118_cell1_v;
double v119_v118_cell1_mode;
double v119_v118_cell2_v;
double v119_v118_cell2_mode;
double v119_v118_cell1_v_replay = 0.0;
double v119_v118_cell2_v_replay = 0.0;


static double  v119_v118_k  =  0.0 ,  v119_v118_cell1_mode_delayed  =  0.0 ,  v119_v118_cell2_mode_delayed  =  0.0 ,  v119_v118_from_cell  =  0.0 ,  v119_v118_cell1_replay_latch  =  0.0 ,  v119_v118_cell2_replay_latch  =  0.0 ,  v119_v118_cell1_v_delayed  =  0.0 ,  v119_v118_cell2_v_delayed  =  0.0 ,  v119_v118_wasted  =  0.0 ; //the continuous vars
static double  v119_v118_k_u , v119_v118_cell1_mode_delayed_u , v119_v118_cell2_mode_delayed_u , v119_v118_from_cell_u , v119_v118_cell1_replay_latch_u , v119_v118_cell2_replay_latch_u , v119_v118_cell1_v_delayed_u , v119_v118_cell2_v_delayed_u , v119_v118_wasted_u ; // and their updates
static double  v119_v118_k_init , v119_v118_cell1_mode_delayed_init , v119_v118_cell2_mode_delayed_init , v119_v118_from_cell_init , v119_v118_cell1_replay_latch_init , v119_v118_cell2_replay_latch_init , v119_v118_cell1_v_delayed_init , v119_v118_cell2_v_delayed_init , v119_v118_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v119_v118_idle , v119_v118_annhilate , v119_v118_previous_drection1 , v119_v118_previous_direction2 , v119_v118_wait_cell1 , v119_v118_replay_cell1 , v119_v118_replay_cell2 , v119_v118_wait_cell2 }; // state declarations

enum states v119_v118 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v119_v118_idle ):
    if (True == False) {;}
    else if  (v119_v118_cell2_mode == (2.0) && (v119_v118_cell1_mode != (2.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v119_v118_cell1_mode == (2.0) && (v119_v118_cell2_mode != (2.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v119_v118_cell1_mode == (2.0) && (v119_v118_cell2_mode == (2.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_idle ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_annhilate ):
    if (True == False) {;}
    else if  (v119_v118_cell1_mode != (2.0) && (v119_v118_cell2_mode != (2.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_from_cell_u = 0 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_previous_drection1 ):
    if (True == False) {;}
    else if  (v119_v118_from_cell == (1.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (0.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (2.0) && (v119_v118_cell2_mode_delayed == (0.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (2.0) && (v119_v118_cell2_mode_delayed != (0.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_previous_drection1 ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_previous_direction2 ):
    if (True == False) {;}
    else if  (v119_v118_from_cell == (1.0) && (v119_v118_cell1_mode_delayed != (0.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (2.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (0.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v119_v118_from_cell == (1.0) && (v119_v118_cell1_mode_delayed == (0.0))) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_previous_direction2 ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_wait_cell1 ):
    if (True == False) {;}
    else if  (v119_v118_cell2_mode == (2.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
    }
    else if  (v119_v118_k >= (50.1405397651)) {
      v119_v118_from_cell_u = 1 ;
      v119_v118_cell1_replay_latch_u = 1 ;
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_wait_cell1 ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_replay_cell1 ):
    if (True == False) {;}
    else if  (v119_v118_cell1_mode == (2.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_annhilate ;
      force_init_update = False;
    }
    else if  (v119_v118_k >= (50.1405397651)) {
      v119_v118_from_cell_u = 2 ;
      v119_v118_cell2_replay_latch_u = 1 ;
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_replay_cell1 ;
      force_init_update = False;
      v119_v118_cell1_replay_latch_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_replay_cell2 ):
    if (True == False) {;}
    else if  (v119_v118_k >= (10.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_replay_cell2 ;
      force_init_update = False;
      v119_v118_cell2_replay_latch_u = 1 ;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  case ( v119_v118_wait_cell2 ):
    if (True == False) {;}
    else if  (v119_v118_k >= (10.0)) {
      v119_v118_k_u = 1 ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
      cstate =  v119_v118_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v119_v118_k_init = v119_v118_k ;
      slope =  1 ;
      v119_v118_k_u = (slope * d) + v119_v118_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v119_v118_wait_cell2 ;
      force_init_update = False;
      v119_v118_cell1_v_delayed_u = v119_v118_update_c1vd () ;
      v119_v118_cell2_v_delayed_u = v119_v118_update_c2vd () ;
      v119_v118_cell1_mode_delayed_u = v119_v118_update_c1md () ;
      v119_v118_cell2_mode_delayed_u = v119_v118_update_c2md () ;
      v119_v118_wasted_u = v119_v118_update_buffer_index (v119_v118_cell1_v,v119_v118_cell2_v,v119_v118_cell1_mode,v119_v118_cell2_mode) ;
      v119_v118_cell1_replay_latch_u = v119_v118_update_latch1 (v119_v118_cell1_mode_delayed,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_replay_latch_u = v119_v118_update_latch2 (v119_v118_cell2_mode_delayed,v119_v118_cell2_replay_latch_u) ;
      v119_v118_cell1_v_replay = v119_v118_update_ocell1 (v119_v118_cell1_v_delayed_u,v119_v118_cell1_replay_latch_u) ;
      v119_v118_cell2_v_replay = v119_v118_update_ocell2 (v119_v118_cell2_v_delayed_u,v119_v118_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119_v118!\n");
      exit(1);
    }
    break;
  }
  v119_v118_k = v119_v118_k_u;
  v119_v118_cell1_mode_delayed = v119_v118_cell1_mode_delayed_u;
  v119_v118_cell2_mode_delayed = v119_v118_cell2_mode_delayed_u;
  v119_v118_from_cell = v119_v118_from_cell_u;
  v119_v118_cell1_replay_latch = v119_v118_cell1_replay_latch_u;
  v119_v118_cell2_replay_latch = v119_v118_cell2_replay_latch_u;
  v119_v118_cell1_v_delayed = v119_v118_cell1_v_delayed_u;
  v119_v118_cell2_v_delayed = v119_v118_cell2_v_delayed_u;
  v119_v118_wasted = v119_v118_wasted_u;
  return cstate;
}