#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v136_v135_update_c1vd();
extern double v136_v135_update_c2vd();
extern double v136_v135_update_c1md();
extern double v136_v135_update_c2md();
extern double v136_v135_update_buffer_index(double,double,double,double);
extern double v136_v135_update_latch1(double,double);
extern double v136_v135_update_latch2(double,double);
extern double v136_v135_update_ocell1(double,double);
extern double v136_v135_update_ocell2(double,double);
double v136_v135_cell1_v;
double v136_v135_cell1_mode;
double v136_v135_cell2_v;
double v136_v135_cell2_mode;
double v136_v135_cell1_v_replay = 0.0;
double v136_v135_cell2_v_replay = 0.0;


static double  v136_v135_k  =  0.0 ,  v136_v135_cell1_mode_delayed  =  0.0 ,  v136_v135_cell2_mode_delayed  =  0.0 ,  v136_v135_from_cell  =  0.0 ,  v136_v135_cell1_replay_latch  =  0.0 ,  v136_v135_cell2_replay_latch  =  0.0 ,  v136_v135_cell1_v_delayed  =  0.0 ,  v136_v135_cell2_v_delayed  =  0.0 ,  v136_v135_wasted  =  0.0 ; //the continuous vars
static double  v136_v135_k_u , v136_v135_cell1_mode_delayed_u , v136_v135_cell2_mode_delayed_u , v136_v135_from_cell_u , v136_v135_cell1_replay_latch_u , v136_v135_cell2_replay_latch_u , v136_v135_cell1_v_delayed_u , v136_v135_cell2_v_delayed_u , v136_v135_wasted_u ; // and their updates
static double  v136_v135_k_init , v136_v135_cell1_mode_delayed_init , v136_v135_cell2_mode_delayed_init , v136_v135_from_cell_init , v136_v135_cell1_replay_latch_init , v136_v135_cell2_replay_latch_init , v136_v135_cell1_v_delayed_init , v136_v135_cell2_v_delayed_init , v136_v135_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v136_v135_idle , v136_v135_annhilate , v136_v135_previous_drection1 , v136_v135_previous_direction2 , v136_v135_wait_cell1 , v136_v135_replay_cell1 , v136_v135_replay_cell2 , v136_v135_wait_cell2 }; // state declarations

enum states v136_v135 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v136_v135_idle ):
    if (True == False) {;}
    else if  (v136_v135_cell2_mode == (2.0) && (v136_v135_cell1_mode != (2.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v136_v135_cell1_mode == (2.0) && (v136_v135_cell2_mode != (2.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v136_v135_cell1_mode == (2.0) && (v136_v135_cell2_mode == (2.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_idle ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_annhilate ):
    if (True == False) {;}
    else if  (v136_v135_cell1_mode != (2.0) && (v136_v135_cell2_mode != (2.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_from_cell_u = 0 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_previous_drection1 ):
    if (True == False) {;}
    else if  (v136_v135_from_cell == (1.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (0.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (2.0) && (v136_v135_cell2_mode_delayed == (0.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (2.0) && (v136_v135_cell2_mode_delayed != (0.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_previous_drection1 ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_previous_direction2 ):
    if (True == False) {;}
    else if  (v136_v135_from_cell == (1.0) && (v136_v135_cell1_mode_delayed != (0.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (2.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (0.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v136_v135_from_cell == (1.0) && (v136_v135_cell1_mode_delayed == (0.0))) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_previous_direction2 ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_wait_cell1 ):
    if (True == False) {;}
    else if  (v136_v135_cell2_mode == (2.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
    }
    else if  (v136_v135_k >= (80.0644554297)) {
      v136_v135_from_cell_u = 1 ;
      v136_v135_cell1_replay_latch_u = 1 ;
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_wait_cell1 ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_replay_cell1 ):
    if (True == False) {;}
    else if  (v136_v135_cell1_mode == (2.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_annhilate ;
      force_init_update = False;
    }
    else if  (v136_v135_k >= (80.0644554297)) {
      v136_v135_from_cell_u = 2 ;
      v136_v135_cell2_replay_latch_u = 1 ;
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_replay_cell1 ;
      force_init_update = False;
      v136_v135_cell1_replay_latch_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_replay_cell2 ):
    if (True == False) {;}
    else if  (v136_v135_k >= (10.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_replay_cell2 ;
      force_init_update = False;
      v136_v135_cell2_replay_latch_u = 1 ;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  case ( v136_v135_wait_cell2 ):
    if (True == False) {;}
    else if  (v136_v135_k >= (10.0)) {
      v136_v135_k_u = 1 ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
      cstate =  v136_v135_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v136_v135_k_init = v136_v135_k ;
      slope =  1 ;
      v136_v135_k_u = (slope * d) + v136_v135_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v136_v135_wait_cell2 ;
      force_init_update = False;
      v136_v135_cell1_v_delayed_u = v136_v135_update_c1vd () ;
      v136_v135_cell2_v_delayed_u = v136_v135_update_c2vd () ;
      v136_v135_cell1_mode_delayed_u = v136_v135_update_c1md () ;
      v136_v135_cell2_mode_delayed_u = v136_v135_update_c2md () ;
      v136_v135_wasted_u = v136_v135_update_buffer_index (v136_v135_cell1_v,v136_v135_cell2_v,v136_v135_cell1_mode,v136_v135_cell2_mode) ;
      v136_v135_cell1_replay_latch_u = v136_v135_update_latch1 (v136_v135_cell1_mode_delayed,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_replay_latch_u = v136_v135_update_latch2 (v136_v135_cell2_mode_delayed,v136_v135_cell2_replay_latch_u) ;
      v136_v135_cell1_v_replay = v136_v135_update_ocell1 (v136_v135_cell1_v_delayed_u,v136_v135_cell1_replay_latch_u) ;
      v136_v135_cell2_v_replay = v136_v135_update_ocell2 (v136_v135_cell2_v_delayed_u,v136_v135_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136_v135!\n");
      exit(1);
    }
    break;
  }
  v136_v135_k = v136_v135_k_u;
  v136_v135_cell1_mode_delayed = v136_v135_cell1_mode_delayed_u;
  v136_v135_cell2_mode_delayed = v136_v135_cell2_mode_delayed_u;
  v136_v135_from_cell = v136_v135_from_cell_u;
  v136_v135_cell1_replay_latch = v136_v135_cell1_replay_latch_u;
  v136_v135_cell2_replay_latch = v136_v135_cell2_replay_latch_u;
  v136_v135_cell1_v_delayed = v136_v135_cell1_v_delayed_u;
  v136_v135_cell2_v_delayed = v136_v135_cell2_v_delayed_u;
  v136_v135_wasted = v136_v135_wasted_u;
  return cstate;
}