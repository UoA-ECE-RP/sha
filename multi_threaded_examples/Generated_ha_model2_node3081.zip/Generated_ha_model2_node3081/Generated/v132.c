#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v132_v_i_0;
double v132_v_i_1;
double v132_v_i_2;
double v132_voo = 0.0;
double v132_state = 0.0;


static double  v132_vx  =  0 ,  v132_vy  =  0 ,  v132_vz  =  0 ,  v132_g  =  0 ,  v132_v  =  0 ,  v132_ft  =  0 ,  v132_theta  =  0 ,  v132_v_O  =  0 ; //the continuous vars
static double  v132_vx_u , v132_vy_u , v132_vz_u , v132_g_u , v132_v_u , v132_ft_u , v132_theta_u , v132_v_O_u ; // and their updates
static double  v132_vx_init , v132_vy_init , v132_vz_init , v132_g_init , v132_v_init , v132_ft_init , v132_theta_init , v132_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v132_t1 , v132_t2 , v132_t3 , v132_t4 }; // state declarations

enum states v132 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v132_t1 ):
    if (True == False) {;}
    else if  (v132_g > (44.5)) {
      v132_vx_u = (0.3 * v132_v) ;
      v132_vy_u = 0 ;
      v132_vz_u = (0.7 * v132_v) ;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v132_theta_u = (v132_v / 30.0) ;
      v132_v_O_u = (131.1 + (- (80.1 * pow ( ((v132_v / 30.0)) , (0.5) )))) ;
      v132_ft_u = f (v132_theta,4.0e-2) ;
      cstate =  v132_t2 ;
      force_init_update = False;
    }

    else if ( v132_v <= (44.5)
               && v132_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v132_vx_init = v132_vx ;
      slope =  (v132_vx * -8.7) ;
      v132_vx_u = (slope * d) + v132_vx ;
      if ((pstate != cstate) || force_init_update) v132_vy_init = v132_vy ;
      slope =  (v132_vy * -190.9) ;
      v132_vy_u = (slope * d) + v132_vy ;
      if ((pstate != cstate) || force_init_update) v132_vz_init = v132_vz ;
      slope =  (v132_vz * -190.4) ;
      v132_vz_u = (slope * d) + v132_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v132_t1 ;
      force_init_update = False;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v132_v_u = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_voo = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v132!\n");
      exit(1);
    }
    break;
  case ( v132_t2 ):
    if (True == False) {;}
    else if  (v132_v >= (44.5)) {
      v132_vx_u = v132_vx ;
      v132_vy_u = v132_vy ;
      v132_vz_u = v132_vz ;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v132_t3 ;
      force_init_update = False;
    }
    else if  (v132_g <= (44.5)
               && v132_v < (44.5)) {
      v132_vx_u = v132_vx ;
      v132_vy_u = v132_vy ;
      v132_vz_u = v132_vz ;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v132_t1 ;
      force_init_update = False;
    }

    else if ( v132_v < (44.5)
               && v132_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v132_vx_init = v132_vx ;
      slope =  ((v132_vx * -23.6) + (777200.0 * v132_g)) ;
      v132_vx_u = (slope * d) + v132_vx ;
      if ((pstate != cstate) || force_init_update) v132_vy_init = v132_vy ;
      slope =  ((v132_vy * -45.5) + (58900.0 * v132_g)) ;
      v132_vy_u = (slope * d) + v132_vy ;
      if ((pstate != cstate) || force_init_update) v132_vz_init = v132_vz ;
      slope =  ((v132_vz * -12.9) + (276600.0 * v132_g)) ;
      v132_vz_u = (slope * d) + v132_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v132_t2 ;
      force_init_update = False;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v132_v_u = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_voo = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v132!\n");
      exit(1);
    }
    break;
  case ( v132_t3 ):
    if (True == False) {;}
    else if  (v132_v >= (131.1)) {
      v132_vx_u = v132_vx ;
      v132_vy_u = v132_vy ;
      v132_vz_u = v132_vz ;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v132_t4 ;
      force_init_update = False;
    }

    else if ( v132_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v132_vx_init = v132_vx ;
      slope =  (v132_vx * -6.9) ;
      v132_vx_u = (slope * d) + v132_vx ;
      if ((pstate != cstate) || force_init_update) v132_vy_init = v132_vy ;
      slope =  (v132_vy * 75.9) ;
      v132_vy_u = (slope * d) + v132_vy ;
      if ((pstate != cstate) || force_init_update) v132_vz_init = v132_vz ;
      slope =  (v132_vz * 6826.5) ;
      v132_vz_u = (slope * d) + v132_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v132_t3 ;
      force_init_update = False;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v132_v_u = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_voo = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v132!\n");
      exit(1);
    }
    break;
  case ( v132_t4 ):
    if (True == False) {;}
    else if  (v132_v <= (30.0)) {
      v132_vx_u = v132_vx ;
      v132_vy_u = v132_vy ;
      v132_vz_u = v132_vz ;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v132_t1 ;
      force_init_update = False;
    }

    else if ( v132_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v132_vx_init = v132_vx ;
      slope =  (v132_vx * -33.2) ;
      v132_vx_u = (slope * d) + v132_vx ;
      if ((pstate != cstate) || force_init_update) v132_vy_init = v132_vy ;
      slope =  ((v132_vy * 20.0) * v132_ft) ;
      v132_vy_u = (slope * d) + v132_vy ;
      if ((pstate != cstate) || force_init_update) v132_vz_init = v132_vz ;
      slope =  ((v132_vz * 2.0) * v132_ft) ;
      v132_vz_u = (slope * d) + v132_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v132_t4 ;
      force_init_update = False;
      v132_g_u = ((((((((((((v132_v_i_0 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v132_v_i_1 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v132_v_i_2 + (- ((v132_vx + (- v132_vy)) + v132_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v132_v_u = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_voo = ((v132_vx + (- v132_vy)) + v132_vz) ;
      v132_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v132!\n");
      exit(1);
    }
    break;
  }
  v132_vx = v132_vx_u;
  v132_vy = v132_vy_u;
  v132_vz = v132_vz_u;
  v132_g = v132_g_u;
  v132_v = v132_v_u;
  v132_ft = v132_ft_u;
  v132_theta = v132_theta_u;
  v132_v_O = v132_v_O_u;
  return cstate;
}