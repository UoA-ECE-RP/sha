#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v112_v_i_0;
double v112_v_i_1;
double v112_voo = 0.0;
double v112_state = 0.0;


static double  v112_vx  =  0 ,  v112_vy  =  0 ,  v112_vz  =  0 ,  v112_g  =  0 ,  v112_v  =  0 ,  v112_ft  =  0 ,  v112_theta  =  0 ,  v112_v_O  =  0 ; //the continuous vars
static double  v112_vx_u , v112_vy_u , v112_vz_u , v112_g_u , v112_v_u , v112_ft_u , v112_theta_u , v112_v_O_u ; // and their updates
static double  v112_vx_init , v112_vy_init , v112_vz_init , v112_g_init , v112_v_init , v112_ft_init , v112_theta_init , v112_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v112_t1 , v112_t2 , v112_t3 , v112_t4 }; // state declarations

enum states v112 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v112_t1 ):
    if (True == False) {;}
    else if  (v112_g > (44.5)) {
      v112_vx_u = (0.3 * v112_v) ;
      v112_vy_u = 0 ;
      v112_vz_u = (0.7 * v112_v) ;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v112_theta_u = (v112_v / 30.0) ;
      v112_v_O_u = (131.1 + (- (80.1 * pow ( ((v112_v / 30.0)) , (0.5) )))) ;
      v112_ft_u = f (v112_theta,4.0e-2) ;
      cstate =  v112_t2 ;
      force_init_update = False;
    }

    else if ( v112_v <= (44.5)
               && v112_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v112_vx_init = v112_vx ;
      slope =  (v112_vx * -8.7) ;
      v112_vx_u = (slope * d) + v112_vx ;
      if ((pstate != cstate) || force_init_update) v112_vy_init = v112_vy ;
      slope =  (v112_vy * -190.9) ;
      v112_vy_u = (slope * d) + v112_vy ;
      if ((pstate != cstate) || force_init_update) v112_vz_init = v112_vz ;
      slope =  (v112_vz * -190.4) ;
      v112_vz_u = (slope * d) + v112_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v112_t1 ;
      force_init_update = False;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v112_v_u = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_voo = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112!\n");
      exit(1);
    }
    break;
  case ( v112_t2 ):
    if (True == False) {;}
    else if  (v112_v >= (44.5)) {
      v112_vx_u = v112_vx ;
      v112_vy_u = v112_vy ;
      v112_vz_u = v112_vz ;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v112_t3 ;
      force_init_update = False;
    }
    else if  (v112_g <= (44.5)
               && v112_v < (44.5)) {
      v112_vx_u = v112_vx ;
      v112_vy_u = v112_vy ;
      v112_vz_u = v112_vz ;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v112_t1 ;
      force_init_update = False;
    }

    else if ( v112_v < (44.5)
               && v112_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v112_vx_init = v112_vx ;
      slope =  ((v112_vx * -23.6) + (777200.0 * v112_g)) ;
      v112_vx_u = (slope * d) + v112_vx ;
      if ((pstate != cstate) || force_init_update) v112_vy_init = v112_vy ;
      slope =  ((v112_vy * -45.5) + (58900.0 * v112_g)) ;
      v112_vy_u = (slope * d) + v112_vy ;
      if ((pstate != cstate) || force_init_update) v112_vz_init = v112_vz ;
      slope =  ((v112_vz * -12.9) + (276600.0 * v112_g)) ;
      v112_vz_u = (slope * d) + v112_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v112_t2 ;
      force_init_update = False;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v112_v_u = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_voo = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112!\n");
      exit(1);
    }
    break;
  case ( v112_t3 ):
    if (True == False) {;}
    else if  (v112_v >= (131.1)) {
      v112_vx_u = v112_vx ;
      v112_vy_u = v112_vy ;
      v112_vz_u = v112_vz ;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v112_t4 ;
      force_init_update = False;
    }

    else if ( v112_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v112_vx_init = v112_vx ;
      slope =  (v112_vx * -6.9) ;
      v112_vx_u = (slope * d) + v112_vx ;
      if ((pstate != cstate) || force_init_update) v112_vy_init = v112_vy ;
      slope =  (v112_vy * 75.9) ;
      v112_vy_u = (slope * d) + v112_vy ;
      if ((pstate != cstate) || force_init_update) v112_vz_init = v112_vz ;
      slope =  (v112_vz * 6826.5) ;
      v112_vz_u = (slope * d) + v112_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v112_t3 ;
      force_init_update = False;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v112_v_u = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_voo = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112!\n");
      exit(1);
    }
    break;
  case ( v112_t4 ):
    if (True == False) {;}
    else if  (v112_v <= (30.0)) {
      v112_vx_u = v112_vx ;
      v112_vy_u = v112_vy ;
      v112_vz_u = v112_vz ;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v112_t1 ;
      force_init_update = False;
    }

    else if ( v112_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v112_vx_init = v112_vx ;
      slope =  (v112_vx * -33.2) ;
      v112_vx_u = (slope * d) + v112_vx ;
      if ((pstate != cstate) || force_init_update) v112_vy_init = v112_vy ;
      slope =  ((v112_vy * 20.0) * v112_ft) ;
      v112_vy_u = (slope * d) + v112_vy ;
      if ((pstate != cstate) || force_init_update) v112_vz_init = v112_vz ;
      slope =  ((v112_vz * 2.0) * v112_ft) ;
      v112_vz_u = (slope * d) + v112_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v112_t4 ;
      force_init_update = False;
      v112_g_u = ((((((((((((v112_v_i_0 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522)) + ((((v112_v_i_1 + (- ((v112_vx + (- v112_vy)) + v112_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v112_v_u = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_voo = ((v112_vx + (- v112_vy)) + v112_vz) ;
      v112_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112!\n");
      exit(1);
    }
    break;
  }
  v112_vx = v112_vx_u;
  v112_vy = v112_vy_u;
  v112_vz = v112_vz_u;
  v112_g = v112_g_u;
  v112_v = v112_v_u;
  v112_ft = v112_ft_u;
  v112_theta = v112_theta_u;
  v112_v_O = v112_v_O_u;
  return cstate;
}