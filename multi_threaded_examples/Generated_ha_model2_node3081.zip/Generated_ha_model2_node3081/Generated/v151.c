#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v151_v_i_0;
double v151_v_i_1;
double v151_v_i_2;
double v151_v_i_3;
double v151_v_i_4;
double v151_voo = 0.0;
double v151_state = 0.0;


static double  v151_vx  =  0 ,  v151_vy  =  0 ,  v151_vz  =  0 ,  v151_g  =  0 ,  v151_v  =  0 ,  v151_ft  =  0 ,  v151_theta  =  0 ,  v151_v_O  =  0 ; //the continuous vars
static double  v151_vx_u , v151_vy_u , v151_vz_u , v151_g_u , v151_v_u , v151_ft_u , v151_theta_u , v151_v_O_u ; // and their updates
static double  v151_vx_init , v151_vy_init , v151_vz_init , v151_g_init , v151_v_init , v151_ft_init , v151_theta_init , v151_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v151_t1 , v151_t2 , v151_t3 , v151_t4 }; // state declarations

enum states v151 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v151_t1 ):
    if (True == False) {;}
    else if  (v151_g > (44.5)) {
      v151_vx_u = (0.3 * v151_v) ;
      v151_vy_u = 0 ;
      v151_vz_u = (0.7 * v151_v) ;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      v151_theta_u = (v151_v / 30.0) ;
      v151_v_O_u = (131.1 + (- (80.1 * pow ( ((v151_v / 30.0)) , (0.5) )))) ;
      v151_ft_u = f (v151_theta,4.0e-2) ;
      cstate =  v151_t2 ;
      force_init_update = False;
    }

    else if ( v151_v <= (44.5)
               && v151_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v151_vx_init = v151_vx ;
      slope =  (v151_vx * -8.7) ;
      v151_vx_u = (slope * d) + v151_vx ;
      if ((pstate != cstate) || force_init_update) v151_vy_init = v151_vy ;
      slope =  (v151_vy * -190.9) ;
      v151_vy_u = (slope * d) + v151_vy ;
      if ((pstate != cstate) || force_init_update) v151_vz_init = v151_vz ;
      slope =  (v151_vz * -190.4) ;
      v151_vz_u = (slope * d) + v151_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v151_t1 ;
      force_init_update = False;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      v151_v_u = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_voo = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v151!\n");
      exit(1);
    }
    break;
  case ( v151_t2 ):
    if (True == False) {;}
    else if  (v151_v >= (44.5)) {
      v151_vx_u = v151_vx ;
      v151_vy_u = v151_vy ;
      v151_vz_u = v151_vz ;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      cstate =  v151_t3 ;
      force_init_update = False;
    }
    else if  (v151_g <= (44.5)
               && v151_v < (44.5)) {
      v151_vx_u = v151_vx ;
      v151_vy_u = v151_vy ;
      v151_vz_u = v151_vz ;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      cstate =  v151_t1 ;
      force_init_update = False;
    }

    else if ( v151_v < (44.5)
               && v151_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v151_vx_init = v151_vx ;
      slope =  ((v151_vx * -23.6) + (777200.0 * v151_g)) ;
      v151_vx_u = (slope * d) + v151_vx ;
      if ((pstate != cstate) || force_init_update) v151_vy_init = v151_vy ;
      slope =  ((v151_vy * -45.5) + (58900.0 * v151_g)) ;
      v151_vy_u = (slope * d) + v151_vy ;
      if ((pstate != cstate) || force_init_update) v151_vz_init = v151_vz ;
      slope =  ((v151_vz * -12.9) + (276600.0 * v151_g)) ;
      v151_vz_u = (slope * d) + v151_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v151_t2 ;
      force_init_update = False;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      v151_v_u = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_voo = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v151!\n");
      exit(1);
    }
    break;
  case ( v151_t3 ):
    if (True == False) {;}
    else if  (v151_v >= (131.1)) {
      v151_vx_u = v151_vx ;
      v151_vy_u = v151_vy ;
      v151_vz_u = v151_vz ;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      cstate =  v151_t4 ;
      force_init_update = False;
    }

    else if ( v151_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v151_vx_init = v151_vx ;
      slope =  (v151_vx * -6.9) ;
      v151_vx_u = (slope * d) + v151_vx ;
      if ((pstate != cstate) || force_init_update) v151_vy_init = v151_vy ;
      slope =  (v151_vy * 75.9) ;
      v151_vy_u = (slope * d) + v151_vy ;
      if ((pstate != cstate) || force_init_update) v151_vz_init = v151_vz ;
      slope =  (v151_vz * 6826.5) ;
      v151_vz_u = (slope * d) + v151_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v151_t3 ;
      force_init_update = False;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      v151_v_u = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_voo = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v151!\n");
      exit(1);
    }
    break;
  case ( v151_t4 ):
    if (True == False) {;}
    else if  (v151_v <= (30.0)) {
      v151_vx_u = v151_vx ;
      v151_vy_u = v151_vy ;
      v151_vz_u = v151_vz ;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      cstate =  v151_t1 ;
      force_init_update = False;
    }

    else if ( v151_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v151_vx_init = v151_vx ;
      slope =  (v151_vx * -33.2) ;
      v151_vx_u = (slope * d) + v151_vx ;
      if ((pstate != cstate) || force_init_update) v151_vy_init = v151_vy ;
      slope =  ((v151_vy * 20.0) * v151_ft) ;
      v151_vy_u = (slope * d) + v151_vy ;
      if ((pstate != cstate) || force_init_update) v151_vz_init = v151_vz ;
      slope =  ((v151_vz * 2.0) * v151_ft) ;
      v151_vz_u = (slope * d) + v151_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v151_t4 ;
      force_init_update = False;
      v151_g_u = ((((((((((((v151_v_i_0 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v151_v_i_1 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v151_v_i_2 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v151_v_i_3 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41212193924))) + ((((v151_v_i_4 + (- ((v151_vx + (- v151_vy)) + v151_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.59577794684))) + 0) + 0) + 0) + 0) ;
      v151_v_u = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_voo = ((v151_vx + (- v151_vy)) + v151_vz) ;
      v151_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v151!\n");
      exit(1);
    }
    break;
  }
  v151_vx = v151_vx_u;
  v151_vy = v151_vy_u;
  v151_vz = v151_vz_u;
  v151_g = v151_g_u;
  v151_v = v151_v_u;
  v151_ft = v151_ft_u;
  v151_theta = v151_theta_u;
  v151_v_O = v151_v_O_u;
  return cstate;
}