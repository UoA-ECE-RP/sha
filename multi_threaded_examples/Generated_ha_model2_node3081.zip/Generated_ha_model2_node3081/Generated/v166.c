#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v166_v_i_0;
double v166_v_i_1;
double v166_v_i_2;
double v166_voo = 0.0;
double v166_state = 0.0;


static double  v166_vx  =  0 ,  v166_vy  =  0 ,  v166_vz  =  0 ,  v166_g  =  0 ,  v166_v  =  0 ,  v166_ft  =  0 ,  v166_theta  =  0 ,  v166_v_O  =  0 ; //the continuous vars
static double  v166_vx_u , v166_vy_u , v166_vz_u , v166_g_u , v166_v_u , v166_ft_u , v166_theta_u , v166_v_O_u ; // and their updates
static double  v166_vx_init , v166_vy_init , v166_vz_init , v166_g_init , v166_v_init , v166_ft_init , v166_theta_init , v166_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v166_t1 , v166_t2 , v166_t3 , v166_t4 }; // state declarations

enum states v166 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v166_t1 ):
    if (True == False) {;}
    else if  (v166_g > (44.5)) {
      v166_vx_u = (0.3 * v166_v) ;
      v166_vy_u = 0 ;
      v166_vz_u = (0.7 * v166_v) ;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v166_theta_u = (v166_v / 30.0) ;
      v166_v_O_u = (131.1 + (- (80.1 * pow ( ((v166_v / 30.0)) , (0.5) )))) ;
      v166_ft_u = f (v166_theta,4.0e-2) ;
      cstate =  v166_t2 ;
      force_init_update = False;
    }

    else if ( v166_v <= (44.5)
               && v166_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v166_vx_init = v166_vx ;
      slope =  (v166_vx * -8.7) ;
      v166_vx_u = (slope * d) + v166_vx ;
      if ((pstate != cstate) || force_init_update) v166_vy_init = v166_vy ;
      slope =  (v166_vy * -190.9) ;
      v166_vy_u = (slope * d) + v166_vy ;
      if ((pstate != cstate) || force_init_update) v166_vz_init = v166_vz ;
      slope =  (v166_vz * -190.4) ;
      v166_vz_u = (slope * d) + v166_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v166_t1 ;
      force_init_update = False;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v166_v_u = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_voo = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v166!\n");
      exit(1);
    }
    break;
  case ( v166_t2 ):
    if (True == False) {;}
    else if  (v166_v >= (44.5)) {
      v166_vx_u = v166_vx ;
      v166_vy_u = v166_vy ;
      v166_vz_u = v166_vz ;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v166_t3 ;
      force_init_update = False;
    }
    else if  (v166_g <= (44.5)
               && v166_v < (44.5)) {
      v166_vx_u = v166_vx ;
      v166_vy_u = v166_vy ;
      v166_vz_u = v166_vz ;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v166_t1 ;
      force_init_update = False;
    }

    else if ( v166_v < (44.5)
               && v166_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v166_vx_init = v166_vx ;
      slope =  ((v166_vx * -23.6) + (777200.0 * v166_g)) ;
      v166_vx_u = (slope * d) + v166_vx ;
      if ((pstate != cstate) || force_init_update) v166_vy_init = v166_vy ;
      slope =  ((v166_vy * -45.5) + (58900.0 * v166_g)) ;
      v166_vy_u = (slope * d) + v166_vy ;
      if ((pstate != cstate) || force_init_update) v166_vz_init = v166_vz ;
      slope =  ((v166_vz * -12.9) + (276600.0 * v166_g)) ;
      v166_vz_u = (slope * d) + v166_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v166_t2 ;
      force_init_update = False;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v166_v_u = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_voo = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v166!\n");
      exit(1);
    }
    break;
  case ( v166_t3 ):
    if (True == False) {;}
    else if  (v166_v >= (131.1)) {
      v166_vx_u = v166_vx ;
      v166_vy_u = v166_vy ;
      v166_vz_u = v166_vz ;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v166_t4 ;
      force_init_update = False;
    }

    else if ( v166_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v166_vx_init = v166_vx ;
      slope =  (v166_vx * -6.9) ;
      v166_vx_u = (slope * d) + v166_vx ;
      if ((pstate != cstate) || force_init_update) v166_vy_init = v166_vy ;
      slope =  (v166_vy * 75.9) ;
      v166_vy_u = (slope * d) + v166_vy ;
      if ((pstate != cstate) || force_init_update) v166_vz_init = v166_vz ;
      slope =  (v166_vz * 6826.5) ;
      v166_vz_u = (slope * d) + v166_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v166_t3 ;
      force_init_update = False;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v166_v_u = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_voo = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v166!\n");
      exit(1);
    }
    break;
  case ( v166_t4 ):
    if (True == False) {;}
    else if  (v166_v <= (30.0)) {
      v166_vx_u = v166_vx ;
      v166_vy_u = v166_vy ;
      v166_vz_u = v166_vz ;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v166_t1 ;
      force_init_update = False;
    }

    else if ( v166_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v166_vx_init = v166_vx ;
      slope =  (v166_vx * -33.2) ;
      v166_vx_u = (slope * d) + v166_vx ;
      if ((pstate != cstate) || force_init_update) v166_vy_init = v166_vy ;
      slope =  ((v166_vy * 20.0) * v166_ft) ;
      v166_vy_u = (slope * d) + v166_vy ;
      if ((pstate != cstate) || force_init_update) v166_vz_init = v166_vz ;
      slope =  ((v166_vz * 2.0) * v166_ft) ;
      v166_vz_u = (slope * d) + v166_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v166_t4 ;
      force_init_update = False;
      v166_g_u = ((((((((((((v166_v_i_0 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v166_v_i_1 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v166_v_i_2 + (- ((v166_vx + (- v166_vy)) + v166_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v166_v_u = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_voo = ((v166_vx + (- v166_vy)) + v166_vz) ;
      v166_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v166!\n");
      exit(1);
    }
    break;
  }
  v166_vx = v166_vx_u;
  v166_vy = v166_vy_u;
  v166_vz = v166_vz_u;
  v166_g = v166_g_u;
  v166_v = v166_v_u;
  v166_ft = v166_ft_u;
  v166_theta = v166_theta_u;
  v166_v_O = v166_v_O_u;
  return cstate;
}