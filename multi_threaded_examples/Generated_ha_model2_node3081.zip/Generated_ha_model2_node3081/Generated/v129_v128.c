#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v129_v128_update_c1vd();
extern double v129_v128_update_c2vd();
extern double v129_v128_update_c1md();
extern double v129_v128_update_c2md();
extern double v129_v128_update_buffer_index(double,double,double,double);
extern double v129_v128_update_latch1(double,double);
extern double v129_v128_update_latch2(double,double);
extern double v129_v128_update_ocell1(double,double);
extern double v129_v128_update_ocell2(double,double);
double v129_v128_cell1_v;
double v129_v128_cell1_mode;
double v129_v128_cell2_v;
double v129_v128_cell2_mode;
double v129_v128_cell1_v_replay = 0.0;
double v129_v128_cell2_v_replay = 0.0;


static double  v129_v128_k  =  0.0 ,  v129_v128_cell1_mode_delayed  =  0.0 ,  v129_v128_cell2_mode_delayed  =  0.0 ,  v129_v128_from_cell  =  0.0 ,  v129_v128_cell1_replay_latch  =  0.0 ,  v129_v128_cell2_replay_latch  =  0.0 ,  v129_v128_cell1_v_delayed  =  0.0 ,  v129_v128_cell2_v_delayed  =  0.0 ,  v129_v128_wasted  =  0.0 ; //the continuous vars
static double  v129_v128_k_u , v129_v128_cell1_mode_delayed_u , v129_v128_cell2_mode_delayed_u , v129_v128_from_cell_u , v129_v128_cell1_replay_latch_u , v129_v128_cell2_replay_latch_u , v129_v128_cell1_v_delayed_u , v129_v128_cell2_v_delayed_u , v129_v128_wasted_u ; // and their updates
static double  v129_v128_k_init , v129_v128_cell1_mode_delayed_init , v129_v128_cell2_mode_delayed_init , v129_v128_from_cell_init , v129_v128_cell1_replay_latch_init , v129_v128_cell2_replay_latch_init , v129_v128_cell1_v_delayed_init , v129_v128_cell2_v_delayed_init , v129_v128_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v129_v128_idle , v129_v128_annhilate , v129_v128_previous_drection1 , v129_v128_previous_direction2 , v129_v128_wait_cell1 , v129_v128_replay_cell1 , v129_v128_replay_cell2 , v129_v128_wait_cell2 }; // state declarations

enum states v129_v128 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v129_v128_idle ):
    if (True == False) {;}
    else if  (v129_v128_cell2_mode == (2.0) && (v129_v128_cell1_mode != (2.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v129_v128_cell1_mode == (2.0) && (v129_v128_cell2_mode != (2.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v129_v128_cell1_mode == (2.0) && (v129_v128_cell2_mode == (2.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_idle ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_annhilate ):
    if (True == False) {;}
    else if  (v129_v128_cell1_mode != (2.0) && (v129_v128_cell2_mode != (2.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_from_cell_u = 0 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_previous_drection1 ):
    if (True == False) {;}
    else if  (v129_v128_from_cell == (1.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (0.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (2.0) && (v129_v128_cell2_mode_delayed == (0.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (2.0) && (v129_v128_cell2_mode_delayed != (0.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_previous_drection1 ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_previous_direction2 ):
    if (True == False) {;}
    else if  (v129_v128_from_cell == (1.0) && (v129_v128_cell1_mode_delayed != (0.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (2.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (0.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v129_v128_from_cell == (1.0) && (v129_v128_cell1_mode_delayed == (0.0))) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_previous_direction2 ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_wait_cell1 ):
    if (True == False) {;}
    else if  (v129_v128_cell2_mode == (2.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
    }
    else if  (v129_v128_k >= (68.2518027897)) {
      v129_v128_from_cell_u = 1 ;
      v129_v128_cell1_replay_latch_u = 1 ;
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_wait_cell1 ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_replay_cell1 ):
    if (True == False) {;}
    else if  (v129_v128_cell1_mode == (2.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_annhilate ;
      force_init_update = False;
    }
    else if  (v129_v128_k >= (68.2518027897)) {
      v129_v128_from_cell_u = 2 ;
      v129_v128_cell2_replay_latch_u = 1 ;
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_replay_cell1 ;
      force_init_update = False;
      v129_v128_cell1_replay_latch_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_replay_cell2 ):
    if (True == False) {;}
    else if  (v129_v128_k >= (10.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_replay_cell2 ;
      force_init_update = False;
      v129_v128_cell2_replay_latch_u = 1 ;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  case ( v129_v128_wait_cell2 ):
    if (True == False) {;}
    else if  (v129_v128_k >= (10.0)) {
      v129_v128_k_u = 1 ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
      cstate =  v129_v128_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v129_v128_k_init = v129_v128_k ;
      slope =  1 ;
      v129_v128_k_u = (slope * d) + v129_v128_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v129_v128_wait_cell2 ;
      force_init_update = False;
      v129_v128_cell1_v_delayed_u = v129_v128_update_c1vd () ;
      v129_v128_cell2_v_delayed_u = v129_v128_update_c2vd () ;
      v129_v128_cell1_mode_delayed_u = v129_v128_update_c1md () ;
      v129_v128_cell2_mode_delayed_u = v129_v128_update_c2md () ;
      v129_v128_wasted_u = v129_v128_update_buffer_index (v129_v128_cell1_v,v129_v128_cell2_v,v129_v128_cell1_mode,v129_v128_cell2_mode) ;
      v129_v128_cell1_replay_latch_u = v129_v128_update_latch1 (v129_v128_cell1_mode_delayed,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_replay_latch_u = v129_v128_update_latch2 (v129_v128_cell2_mode_delayed,v129_v128_cell2_replay_latch_u) ;
      v129_v128_cell1_v_replay = v129_v128_update_ocell1 (v129_v128_cell1_v_delayed_u,v129_v128_cell1_replay_latch_u) ;
      v129_v128_cell2_v_replay = v129_v128_update_ocell2 (v129_v128_cell2_v_delayed_u,v129_v128_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129_v128!\n");
      exit(1);
    }
    break;
  }
  v129_v128_k = v129_v128_k_u;
  v129_v128_cell1_mode_delayed = v129_v128_cell1_mode_delayed_u;
  v129_v128_cell2_mode_delayed = v129_v128_cell2_mode_delayed_u;
  v129_v128_from_cell = v129_v128_from_cell_u;
  v129_v128_cell1_replay_latch = v129_v128_cell1_replay_latch_u;
  v129_v128_cell2_replay_latch = v129_v128_cell2_replay_latch_u;
  v129_v128_cell1_v_delayed = v129_v128_cell1_v_delayed_u;
  v129_v128_cell2_v_delayed = v129_v128_cell2_v_delayed_u;
  v129_v128_wasted = v129_v128_wasted_u;
  return cstate;
}