#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v118_v_i_0;
double v118_v_i_1;
double v118_v_i_2;
double v118_v_i_3;
double v118_voo = 0.0;
double v118_state = 0.0;


static double  v118_vx  =  0 ,  v118_vy  =  0 ,  v118_vz  =  0 ,  v118_g  =  0 ,  v118_v  =  0 ,  v118_ft  =  0 ,  v118_theta  =  0 ,  v118_v_O  =  0 ; //the continuous vars
static double  v118_vx_u , v118_vy_u , v118_vz_u , v118_g_u , v118_v_u , v118_ft_u , v118_theta_u , v118_v_O_u ; // and their updates
static double  v118_vx_init , v118_vy_init , v118_vz_init , v118_g_init , v118_v_init , v118_ft_init , v118_theta_init , v118_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v118_t1 , v118_t2 , v118_t3 , v118_t4 }; // state declarations

enum states v118 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v118_t1 ):
    if (True == False) {;}
    else if  (v118_g > (44.5)) {
      v118_vx_u = (0.3 * v118_v) ;
      v118_vy_u = 0 ;
      v118_vz_u = (0.7 * v118_v) ;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      v118_theta_u = (v118_v / 30.0) ;
      v118_v_O_u = (131.1 + (- (80.1 * pow ( ((v118_v / 30.0)) , (0.5) )))) ;
      v118_ft_u = f (v118_theta,4.0e-2) ;
      cstate =  v118_t2 ;
      force_init_update = False;
    }

    else if ( v118_v <= (44.5)
               && v118_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v118_vx_init = v118_vx ;
      slope =  (v118_vx * -8.7) ;
      v118_vx_u = (slope * d) + v118_vx ;
      if ((pstate != cstate) || force_init_update) v118_vy_init = v118_vy ;
      slope =  (v118_vy * -190.9) ;
      v118_vy_u = (slope * d) + v118_vy ;
      if ((pstate != cstate) || force_init_update) v118_vz_init = v118_vz ;
      slope =  (v118_vz * -190.4) ;
      v118_vz_u = (slope * d) + v118_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v118_t1 ;
      force_init_update = False;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      v118_v_u = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_voo = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118!\n");
      exit(1);
    }
    break;
  case ( v118_t2 ):
    if (True == False) {;}
    else if  (v118_v >= (44.5)) {
      v118_vx_u = v118_vx ;
      v118_vy_u = v118_vy ;
      v118_vz_u = v118_vz ;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v118_t3 ;
      force_init_update = False;
    }
    else if  (v118_g <= (44.5)
               && v118_v < (44.5)) {
      v118_vx_u = v118_vx ;
      v118_vy_u = v118_vy ;
      v118_vz_u = v118_vz ;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v118_t1 ;
      force_init_update = False;
    }

    else if ( v118_v < (44.5)
               && v118_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v118_vx_init = v118_vx ;
      slope =  ((v118_vx * -23.6) + (777200.0 * v118_g)) ;
      v118_vx_u = (slope * d) + v118_vx ;
      if ((pstate != cstate) || force_init_update) v118_vy_init = v118_vy ;
      slope =  ((v118_vy * -45.5) + (58900.0 * v118_g)) ;
      v118_vy_u = (slope * d) + v118_vy ;
      if ((pstate != cstate) || force_init_update) v118_vz_init = v118_vz ;
      slope =  ((v118_vz * -12.9) + (276600.0 * v118_g)) ;
      v118_vz_u = (slope * d) + v118_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v118_t2 ;
      force_init_update = False;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      v118_v_u = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_voo = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118!\n");
      exit(1);
    }
    break;
  case ( v118_t3 ):
    if (True == False) {;}
    else if  (v118_v >= (131.1)) {
      v118_vx_u = v118_vx ;
      v118_vy_u = v118_vy ;
      v118_vz_u = v118_vz ;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v118_t4 ;
      force_init_update = False;
    }

    else if ( v118_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v118_vx_init = v118_vx ;
      slope =  (v118_vx * -6.9) ;
      v118_vx_u = (slope * d) + v118_vx ;
      if ((pstate != cstate) || force_init_update) v118_vy_init = v118_vy ;
      slope =  (v118_vy * 75.9) ;
      v118_vy_u = (slope * d) + v118_vy ;
      if ((pstate != cstate) || force_init_update) v118_vz_init = v118_vz ;
      slope =  (v118_vz * 6826.5) ;
      v118_vz_u = (slope * d) + v118_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v118_t3 ;
      force_init_update = False;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      v118_v_u = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_voo = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118!\n");
      exit(1);
    }
    break;
  case ( v118_t4 ):
    if (True == False) {;}
    else if  (v118_v <= (30.0)) {
      v118_vx_u = v118_vx ;
      v118_vy_u = v118_vy ;
      v118_vz_u = v118_vz ;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v118_t1 ;
      force_init_update = False;
    }

    else if ( v118_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v118_vx_init = v118_vx ;
      slope =  (v118_vx * -33.2) ;
      v118_vx_u = (slope * d) + v118_vx ;
      if ((pstate != cstate) || force_init_update) v118_vy_init = v118_vy ;
      slope =  ((v118_vy * 20.0) * v118_ft) ;
      v118_vy_u = (slope * d) + v118_vy ;
      if ((pstate != cstate) || force_init_update) v118_vz_init = v118_vz ;
      slope =  ((v118_vz * 2.0) * v118_ft) ;
      v118_vz_u = (slope * d) + v118_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v118_t4 ;
      force_init_update = False;
      v118_g_u = ((((((((((((v118_v_i_0 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v118_v_i_1 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636))) + ((((v118_v_i_2 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.33580070943))) + ((((v118_v_i_3 + (- ((v118_vx + (- v118_vy)) + v118_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + 0) + 0) + 0) + 0) + 0) ;
      v118_v_u = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_voo = ((v118_vx + (- v118_vy)) + v118_vz) ;
      v118_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118!\n");
      exit(1);
    }
    break;
  }
  v118_vx = v118_vx_u;
  v118_vy = v118_vy_u;
  v118_vz = v118_vz_u;
  v118_g = v118_g_u;
  v118_v = v118_v_u;
  v118_ft = v118_ft_u;
  v118_theta = v118_theta_u;
  v118_v_O = v118_v_O_u;
  return cstate;
}