#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v16_v255_update_c1vd();
extern double v16_v255_update_c2vd();
extern double v16_v255_update_c1md();
extern double v16_v255_update_c2md();
extern double v16_v255_update_buffer_index(double,double,double,double);
extern double v16_v255_update_latch1(double,double);
extern double v16_v255_update_latch2(double,double);
extern double v16_v255_update_ocell1(double,double);
extern double v16_v255_update_ocell2(double,double);
double v16_v255_cell1_v;
double v16_v255_cell1_mode;
double v16_v255_cell2_v;
double v16_v255_cell2_mode;
double v16_v255_cell1_v_replay = 0.0;
double v16_v255_cell2_v_replay = 0.0;


static double  v16_v255_k  =  0.0 ,  v16_v255_cell1_mode_delayed  =  0.0 ,  v16_v255_cell2_mode_delayed  =  0.0 ,  v16_v255_from_cell  =  0.0 ,  v16_v255_cell1_replay_latch  =  0.0 ,  v16_v255_cell2_replay_latch  =  0.0 ,  v16_v255_cell1_v_delayed  =  0.0 ,  v16_v255_cell2_v_delayed  =  0.0 ,  v16_v255_wasted  =  0.0 ; //the continuous vars
static double  v16_v255_k_u , v16_v255_cell1_mode_delayed_u , v16_v255_cell2_mode_delayed_u , v16_v255_from_cell_u , v16_v255_cell1_replay_latch_u , v16_v255_cell2_replay_latch_u , v16_v255_cell1_v_delayed_u , v16_v255_cell2_v_delayed_u , v16_v255_wasted_u ; // and their updates
static double  v16_v255_k_init , v16_v255_cell1_mode_delayed_init , v16_v255_cell2_mode_delayed_init , v16_v255_from_cell_init , v16_v255_cell1_replay_latch_init , v16_v255_cell2_replay_latch_init , v16_v255_cell1_v_delayed_init , v16_v255_cell2_v_delayed_init , v16_v255_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v16_v255_idle , v16_v255_annhilate , v16_v255_previous_drection1 , v16_v255_previous_direction2 , v16_v255_wait_cell1 , v16_v255_replay_cell1 , v16_v255_replay_cell2 , v16_v255_wait_cell2 }; // state declarations

enum states v16_v255 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v16_v255_idle ):
    if (True == False) {;}
    else if  (v16_v255_cell2_mode == (2.0) && (v16_v255_cell1_mode != (2.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v16_v255_cell1_mode == (2.0) && (v16_v255_cell2_mode != (2.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v16_v255_cell1_mode == (2.0) && (v16_v255_cell2_mode == (2.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_idle ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_annhilate ):
    if (True == False) {;}
    else if  (v16_v255_cell1_mode != (2.0) && (v16_v255_cell2_mode != (2.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_from_cell_u = 0 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_previous_drection1 ):
    if (True == False) {;}
    else if  (v16_v255_from_cell == (1.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (0.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (2.0) && (v16_v255_cell2_mode_delayed == (0.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (2.0) && (v16_v255_cell2_mode_delayed != (0.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_previous_drection1 ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_previous_direction2 ):
    if (True == False) {;}
    else if  (v16_v255_from_cell == (1.0) && (v16_v255_cell1_mode_delayed != (0.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (2.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (0.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v16_v255_from_cell == (1.0) && (v16_v255_cell1_mode_delayed == (0.0))) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_previous_direction2 ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_wait_cell1 ):
    if (True == False) {;}
    else if  (v16_v255_cell2_mode == (2.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
    }
    else if  (v16_v255_k >= (46.0423062262)) {
      v16_v255_from_cell_u = 1 ;
      v16_v255_cell1_replay_latch_u = 1 ;
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_wait_cell1 ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_replay_cell1 ):
    if (True == False) {;}
    else if  (v16_v255_cell1_mode == (2.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_annhilate ;
      force_init_update = False;
    }
    else if  (v16_v255_k >= (46.0423062262)) {
      v16_v255_from_cell_u = 2 ;
      v16_v255_cell2_replay_latch_u = 1 ;
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_replay_cell1 ;
      force_init_update = False;
      v16_v255_cell1_replay_latch_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_replay_cell2 ):
    if (True == False) {;}
    else if  (v16_v255_k >= (10.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_replay_cell2 ;
      force_init_update = False;
      v16_v255_cell2_replay_latch_u = 1 ;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  case ( v16_v255_wait_cell2 ):
    if (True == False) {;}
    else if  (v16_v255_k >= (10.0)) {
      v16_v255_k_u = 1 ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
      cstate =  v16_v255_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v16_v255_k_init = v16_v255_k ;
      slope =  1 ;
      v16_v255_k_u = (slope * d) + v16_v255_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v16_v255_wait_cell2 ;
      force_init_update = False;
      v16_v255_cell1_v_delayed_u = v16_v255_update_c1vd () ;
      v16_v255_cell2_v_delayed_u = v16_v255_update_c2vd () ;
      v16_v255_cell1_mode_delayed_u = v16_v255_update_c1md () ;
      v16_v255_cell2_mode_delayed_u = v16_v255_update_c2md () ;
      v16_v255_wasted_u = v16_v255_update_buffer_index (v16_v255_cell1_v,v16_v255_cell2_v,v16_v255_cell1_mode,v16_v255_cell2_mode) ;
      v16_v255_cell1_replay_latch_u = v16_v255_update_latch1 (v16_v255_cell1_mode_delayed,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_replay_latch_u = v16_v255_update_latch2 (v16_v255_cell2_mode_delayed,v16_v255_cell2_replay_latch_u) ;
      v16_v255_cell1_v_replay = v16_v255_update_ocell1 (v16_v255_cell1_v_delayed_u,v16_v255_cell1_replay_latch_u) ;
      v16_v255_cell2_v_replay = v16_v255_update_ocell2 (v16_v255_cell2_v_delayed_u,v16_v255_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16_v255!\n");
      exit(1);
    }
    break;
  }
  v16_v255_k = v16_v255_k_u;
  v16_v255_cell1_mode_delayed = v16_v255_cell1_mode_delayed_u;
  v16_v255_cell2_mode_delayed = v16_v255_cell2_mode_delayed_u;
  v16_v255_from_cell = v16_v255_from_cell_u;
  v16_v255_cell1_replay_latch = v16_v255_cell1_replay_latch_u;
  v16_v255_cell2_replay_latch = v16_v255_cell2_replay_latch_u;
  v16_v255_cell1_v_delayed = v16_v255_cell1_v_delayed_u;
  v16_v255_cell2_v_delayed = v16_v255_cell2_v_delayed_u;
  v16_v255_wasted = v16_v255_wasted_u;
  return cstate;
}