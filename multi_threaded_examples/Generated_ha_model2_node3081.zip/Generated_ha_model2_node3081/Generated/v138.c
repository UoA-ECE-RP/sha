#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v138_v_i_0;
double v138_v_i_1;
double v138_v_i_2;
double v138_v_i_3;
double v138_v_i_4;
double v138_voo = 0.0;
double v138_state = 0.0;


static double  v138_vx  =  0 ,  v138_vy  =  0 ,  v138_vz  =  0 ,  v138_g  =  0 ,  v138_v  =  0 ,  v138_ft  =  0 ,  v138_theta  =  0 ,  v138_v_O  =  0 ; //the continuous vars
static double  v138_vx_u , v138_vy_u , v138_vz_u , v138_g_u , v138_v_u , v138_ft_u , v138_theta_u , v138_v_O_u ; // and their updates
static double  v138_vx_init , v138_vy_init , v138_vz_init , v138_g_init , v138_v_init , v138_ft_init , v138_theta_init , v138_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v138_t1 , v138_t2 , v138_t3 , v138_t4 }; // state declarations

enum states v138 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v138_t1 ):
    if (True == False) {;}
    else if  (v138_g > (44.5)) {
      v138_vx_u = (0.3 * v138_v) ;
      v138_vy_u = 0 ;
      v138_vz_u = (0.7 * v138_v) ;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      v138_theta_u = (v138_v / 30.0) ;
      v138_v_O_u = (131.1 + (- (80.1 * pow ( ((v138_v / 30.0)) , (0.5) )))) ;
      v138_ft_u = f (v138_theta,4.0e-2) ;
      cstate =  v138_t2 ;
      force_init_update = False;
    }

    else if ( v138_v <= (44.5)
               && v138_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v138_vx_init = v138_vx ;
      slope =  (v138_vx * -8.7) ;
      v138_vx_u = (slope * d) + v138_vx ;
      if ((pstate != cstate) || force_init_update) v138_vy_init = v138_vy ;
      slope =  (v138_vy * -190.9) ;
      v138_vy_u = (slope * d) + v138_vy ;
      if ((pstate != cstate) || force_init_update) v138_vz_init = v138_vz ;
      slope =  (v138_vz * -190.4) ;
      v138_vz_u = (slope * d) + v138_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v138_t1 ;
      force_init_update = False;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      v138_v_u = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_voo = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138!\n");
      exit(1);
    }
    break;
  case ( v138_t2 ):
    if (True == False) {;}
    else if  (v138_v >= (44.5)) {
      v138_vx_u = v138_vx ;
      v138_vy_u = v138_vy ;
      v138_vz_u = v138_vz ;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      cstate =  v138_t3 ;
      force_init_update = False;
    }
    else if  (v138_g <= (44.5)
               && v138_v < (44.5)) {
      v138_vx_u = v138_vx ;
      v138_vy_u = v138_vy ;
      v138_vz_u = v138_vz ;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      cstate =  v138_t1 ;
      force_init_update = False;
    }

    else if ( v138_v < (44.5)
               && v138_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v138_vx_init = v138_vx ;
      slope =  ((v138_vx * -23.6) + (777200.0 * v138_g)) ;
      v138_vx_u = (slope * d) + v138_vx ;
      if ((pstate != cstate) || force_init_update) v138_vy_init = v138_vy ;
      slope =  ((v138_vy * -45.5) + (58900.0 * v138_g)) ;
      v138_vy_u = (slope * d) + v138_vy ;
      if ((pstate != cstate) || force_init_update) v138_vz_init = v138_vz ;
      slope =  ((v138_vz * -12.9) + (276600.0 * v138_g)) ;
      v138_vz_u = (slope * d) + v138_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v138_t2 ;
      force_init_update = False;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      v138_v_u = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_voo = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138!\n");
      exit(1);
    }
    break;
  case ( v138_t3 ):
    if (True == False) {;}
    else if  (v138_v >= (131.1)) {
      v138_vx_u = v138_vx ;
      v138_vy_u = v138_vy ;
      v138_vz_u = v138_vz ;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      cstate =  v138_t4 ;
      force_init_update = False;
    }

    else if ( v138_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v138_vx_init = v138_vx ;
      slope =  (v138_vx * -6.9) ;
      v138_vx_u = (slope * d) + v138_vx ;
      if ((pstate != cstate) || force_init_update) v138_vy_init = v138_vy ;
      slope =  (v138_vy * 75.9) ;
      v138_vy_u = (slope * d) + v138_vy ;
      if ((pstate != cstate) || force_init_update) v138_vz_init = v138_vz ;
      slope =  (v138_vz * 6826.5) ;
      v138_vz_u = (slope * d) + v138_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v138_t3 ;
      force_init_update = False;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      v138_v_u = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_voo = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138!\n");
      exit(1);
    }
    break;
  case ( v138_t4 ):
    if (True == False) {;}
    else if  (v138_v <= (30.0)) {
      v138_vx_u = v138_vx ;
      v138_vy_u = v138_vy ;
      v138_vz_u = v138_vz ;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      cstate =  v138_t1 ;
      force_init_update = False;
    }

    else if ( v138_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v138_vx_init = v138_vx ;
      slope =  (v138_vx * -33.2) ;
      v138_vx_u = (slope * d) + v138_vx ;
      if ((pstate != cstate) || force_init_update) v138_vy_init = v138_vy ;
      slope =  ((v138_vy * 20.0) * v138_ft) ;
      v138_vy_u = (slope * d) + v138_vy ;
      if ((pstate != cstate) || force_init_update) v138_vz_init = v138_vz ;
      slope =  ((v138_vz * 2.0) * v138_ft) ;
      v138_vz_u = (slope * d) + v138_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v138_t4 ;
      force_init_update = False;
      v138_g_u = ((((((((((((v138_v_i_0 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v138_v_i_1 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v138_v_i_2 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.2186144276))) + ((((v138_v_i_3 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.31658320566))) + ((((v138_v_i_4 + (- ((v138_vx + (- v138_vy)) + v138_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.26859009956))) + 0) + 0) + 0) + 0) ;
      v138_v_u = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_voo = ((v138_vx + (- v138_vy)) + v138_vz) ;
      v138_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138!\n");
      exit(1);
    }
    break;
  }
  v138_vx = v138_vx_u;
  v138_vy = v138_vy_u;
  v138_vz = v138_vz_u;
  v138_g = v138_g_u;
  v138_v = v138_v_u;
  v138_ft = v138_ft_u;
  v138_theta = v138_theta_u;
  v138_v_O = v138_v_O_u;
  return cstate;
}