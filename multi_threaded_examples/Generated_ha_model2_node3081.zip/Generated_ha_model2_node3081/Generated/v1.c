#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v1_v_i_0;
double v1_v_i_1;
double v1_v_i_2;
double v1_voo = 0.0;
double v1_state = 0.0;


static double  v1_vx  =  0 ,  v1_vy  =  0 ,  v1_vz  =  0 ,  v1_g  =  0 ,  v1_v  =  0 ,  v1_ft  =  0 ,  v1_theta  =  0 ,  v1_v_O  =  0 ; //the continuous vars
static double  v1_vx_u , v1_vy_u , v1_vz_u , v1_g_u , v1_v_u , v1_ft_u , v1_theta_u , v1_v_O_u ; // and their updates
static double  v1_vx_init , v1_vy_init , v1_vz_init , v1_g_init , v1_v_init , v1_ft_init , v1_theta_init , v1_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v1_t1 , v1_t2 , v1_t3 , v1_t4 }; // state declarations

enum states v1 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v1_t1 ):
    if (True == False) {;}
    else if  (v1_g > (44.5)) {
      v1_vx_u = (0.3 * v1_v) ;
      v1_vy_u = 0 ;
      v1_vz_u = (0.7 * v1_v) ;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v1_theta_u = (v1_v / 30.0) ;
      v1_v_O_u = (131.1 + (- (80.1 * pow ( ((v1_v / 30.0)) , (0.5) )))) ;
      v1_ft_u = f (v1_theta,4.0e-2) ;
      cstate =  v1_t2 ;
      force_init_update = False;
    }

    else if ( v1_v <= (44.5) && 
              v1_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v1_vx_init = v1_vx ;
      slope =  (v1_vx * -8.7) ;
      v1_vx_u = (slope * d) + v1_vx ;
      if ((pstate != cstate) || force_init_update) v1_vy_init = v1_vy ;
      slope =  (v1_vy * -190.9) ;
      v1_vy_u = (slope * d) + v1_vy ;
      if ((pstate != cstate) || force_init_update) v1_vz_init = v1_vz ;
      slope =  (v1_vz * -190.4) ;
      v1_vz_u = (slope * d) + v1_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v1_t1 ;
      force_init_update = False;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v1_v_u = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_voo = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v1!\n");
      exit(1);
    }
    break;
  case ( v1_t2 ):
    if (True == False) {;}
    else if  (v1_v >= (44.5)) {
      v1_vx_u = v1_vx ;
      v1_vy_u = v1_vy ;
      v1_vz_u = v1_vz ;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v1_t3 ;
      force_init_update = False;
    }
    else if  (v1_g <= (44.5) && 
              v1_v < (44.5)) {
      v1_vx_u = v1_vx ;
      v1_vy_u = v1_vy ;
      v1_vz_u = v1_vz ;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v1_t1 ;
      force_init_update = False;
    }

    else if ( v1_v < (44.5) && 
              v1_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v1_vx_init = v1_vx ;
      slope =  ((v1_vx * -23.6) + (777200.0 * v1_g)) ;
      v1_vx_u = (slope * d) + v1_vx ;
      if ((pstate != cstate) || force_init_update) v1_vy_init = v1_vy ;
      slope =  ((v1_vy * -45.5) + (58900.0 * v1_g)) ;
      v1_vy_u = (slope * d) + v1_vy ;
      if ((pstate != cstate) || force_init_update) v1_vz_init = v1_vz ;
      slope =  ((v1_vz * -12.9) + (276600.0 * v1_g)) ;
      v1_vz_u = (slope * d) + v1_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v1_t2 ;
      force_init_update = False;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v1_v_u = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_voo = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v1!\n");
      exit(1);
    }
    break;
  case ( v1_t3 ):
    if (True == False) {;}
    else if  (v1_v >= (131.1)) {
      v1_vx_u = v1_vx ;
      v1_vy_u = v1_vy ;
      v1_vz_u = v1_vz ;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v1_t4 ;
      force_init_update = False;
    }

    else if ( v1_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v1_vx_init = v1_vx ;
      slope =  (v1_vx * -6.9) ;
      v1_vx_u = (slope * d) + v1_vx ;
      if ((pstate != cstate) || force_init_update) v1_vy_init = v1_vy ;
      slope =  (v1_vy * 75.9) ;
      v1_vy_u = (slope * d) + v1_vy ;
      if ((pstate != cstate) || force_init_update) v1_vz_init = v1_vz ;
      slope =  (v1_vz * 6826.5) ;
      v1_vz_u = (slope * d) + v1_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v1_t3 ;
      force_init_update = False;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v1_v_u = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_voo = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v1!\n");
      exit(1);
    }
    break;
  case ( v1_t4 ):
    if (True == False) {;}
    else if  (v1_v <= (30.0)) {
      v1_vx_u = v1_vx ;
      v1_vy_u = v1_vy ;
      v1_vz_u = v1_vz ;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v1_t1 ;
      force_init_update = False;
    }

    else if ( v1_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v1_vx_init = v1_vx ;
      slope =  (v1_vx * -33.2) ;
      v1_vx_u = (slope * d) + v1_vx ;
      if ((pstate != cstate) || force_init_update) v1_vy_init = v1_vy ;
      slope =  ((v1_vy * 20.0) * v1_ft) ;
      v1_vy_u = (slope * d) + v1_vy ;
      if ((pstate != cstate) || force_init_update) v1_vz_init = v1_vz ;
      slope =  ((v1_vz * 2.0) * v1_ft) ;
      v1_vz_u = (slope * d) + v1_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v1_t4 ;
      force_init_update = False;
      v1_g_u = ((((((((((((v1_v_i_0 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.76496084381)) + ((((v1_v_i_1 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.2219179093))) + ((((v1_v_i_2 + (- ((v1_vx + (- v1_vy)) + v1_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09589158692))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v1_v_u = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_voo = ((v1_vx + (- v1_vy)) + v1_vz) ;
      v1_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v1!\n");
      exit(1);
    }
    break;
  }
  v1_vx = v1_vx_u;
  v1_vy = v1_vy_u;
  v1_vz = v1_vz_u;
  v1_g = v1_g_u;
  v1_v = v1_v_u;
  v1_ft = v1_ft_u;
  v1_theta = v1_theta_u;
  v1_v_O = v1_v_O_u;
  return cstate;
}