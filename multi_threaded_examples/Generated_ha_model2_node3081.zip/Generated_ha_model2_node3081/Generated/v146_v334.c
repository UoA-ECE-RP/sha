#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v146_v334_update_c1vd();
extern double v146_v334_update_c2vd();
extern double v146_v334_update_c1md();
extern double v146_v334_update_c2md();
extern double v146_v334_update_buffer_index(double,double,double,double);
extern double v146_v334_update_latch1(double,double);
extern double v146_v334_update_latch2(double,double);
extern double v146_v334_update_ocell1(double,double);
extern double v146_v334_update_ocell2(double,double);
double v146_v334_cell1_v;
double v146_v334_cell1_mode;
double v146_v334_cell2_v;
double v146_v334_cell2_mode;
double v146_v334_cell1_v_replay = 0.0;
double v146_v334_cell2_v_replay = 0.0;


static double  v146_v334_k  =  0.0 ,  v146_v334_cell1_mode_delayed  =  0.0 ,  v146_v334_cell2_mode_delayed  =  0.0 ,  v146_v334_from_cell  =  0.0 ,  v146_v334_cell1_replay_latch  =  0.0 ,  v146_v334_cell2_replay_latch  =  0.0 ,  v146_v334_cell1_v_delayed  =  0.0 ,  v146_v334_cell2_v_delayed  =  0.0 ,  v146_v334_wasted  =  0.0 ; //the continuous vars
static double  v146_v334_k_u , v146_v334_cell1_mode_delayed_u , v146_v334_cell2_mode_delayed_u , v146_v334_from_cell_u , v146_v334_cell1_replay_latch_u , v146_v334_cell2_replay_latch_u , v146_v334_cell1_v_delayed_u , v146_v334_cell2_v_delayed_u , v146_v334_wasted_u ; // and their updates
static double  v146_v334_k_init , v146_v334_cell1_mode_delayed_init , v146_v334_cell2_mode_delayed_init , v146_v334_from_cell_init , v146_v334_cell1_replay_latch_init , v146_v334_cell2_replay_latch_init , v146_v334_cell1_v_delayed_init , v146_v334_cell2_v_delayed_init , v146_v334_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v146_v334_idle , v146_v334_annhilate , v146_v334_previous_drection1 , v146_v334_previous_direction2 , v146_v334_wait_cell1 , v146_v334_replay_cell1 , v146_v334_replay_cell2 , v146_v334_wait_cell2 }; // state declarations

enum states v146_v334 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v146_v334_idle ):
    if (True == False) {;}
    else if  (v146_v334_cell2_mode == (2.0) && (v146_v334_cell1_mode != (2.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v146_v334_cell1_mode == (2.0) && (v146_v334_cell2_mode != (2.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v146_v334_cell1_mode == (2.0) && (v146_v334_cell2_mode == (2.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_idle ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_annhilate ):
    if (True == False) {;}
    else if  (v146_v334_cell1_mode != (2.0) && (v146_v334_cell2_mode != (2.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_from_cell_u = 0 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_previous_drection1 ):
    if (True == False) {;}
    else if  (v146_v334_from_cell == (1.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (0.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (2.0) && (v146_v334_cell2_mode_delayed == (0.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (2.0) && (v146_v334_cell2_mode_delayed != (0.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_previous_drection1 ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_previous_direction2 ):
    if (True == False) {;}
    else if  (v146_v334_from_cell == (1.0) && (v146_v334_cell1_mode_delayed != (0.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (2.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (0.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v146_v334_from_cell == (1.0) && (v146_v334_cell1_mode_delayed == (0.0))) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_previous_direction2 ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_wait_cell1 ):
    if (True == False) {;}
    else if  (v146_v334_cell2_mode == (2.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
    }
    else if  (v146_v334_k >= (134.3578811)) {
      v146_v334_from_cell_u = 1 ;
      v146_v334_cell1_replay_latch_u = 1 ;
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_wait_cell1 ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_replay_cell1 ):
    if (True == False) {;}
    else if  (v146_v334_cell1_mode == (2.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_annhilate ;
      force_init_update = False;
    }
    else if  (v146_v334_k >= (134.3578811)) {
      v146_v334_from_cell_u = 2 ;
      v146_v334_cell2_replay_latch_u = 1 ;
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_replay_cell1 ;
      force_init_update = False;
      v146_v334_cell1_replay_latch_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_replay_cell2 ):
    if (True == False) {;}
    else if  (v146_v334_k >= (10.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_replay_cell2 ;
      force_init_update = False;
      v146_v334_cell2_replay_latch_u = 1 ;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  case ( v146_v334_wait_cell2 ):
    if (True == False) {;}
    else if  (v146_v334_k >= (10.0)) {
      v146_v334_k_u = 1 ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
      cstate =  v146_v334_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v146_v334_k_init = v146_v334_k ;
      slope =  1 ;
      v146_v334_k_u = (slope * d) + v146_v334_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v146_v334_wait_cell2 ;
      force_init_update = False;
      v146_v334_cell1_v_delayed_u = v146_v334_update_c1vd () ;
      v146_v334_cell2_v_delayed_u = v146_v334_update_c2vd () ;
      v146_v334_cell1_mode_delayed_u = v146_v334_update_c1md () ;
      v146_v334_cell2_mode_delayed_u = v146_v334_update_c2md () ;
      v146_v334_wasted_u = v146_v334_update_buffer_index (v146_v334_cell1_v,v146_v334_cell2_v,v146_v334_cell1_mode,v146_v334_cell2_mode) ;
      v146_v334_cell1_replay_latch_u = v146_v334_update_latch1 (v146_v334_cell1_mode_delayed,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_replay_latch_u = v146_v334_update_latch2 (v146_v334_cell2_mode_delayed,v146_v334_cell2_replay_latch_u) ;
      v146_v334_cell1_v_replay = v146_v334_update_ocell1 (v146_v334_cell1_v_delayed_u,v146_v334_cell1_replay_latch_u) ;
      v146_v334_cell2_v_replay = v146_v334_update_ocell2 (v146_v334_cell2_v_delayed_u,v146_v334_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146_v334!\n");
      exit(1);
    }
    break;
  }
  v146_v334_k = v146_v334_k_u;
  v146_v334_cell1_mode_delayed = v146_v334_cell1_mode_delayed_u;
  v146_v334_cell2_mode_delayed = v146_v334_cell2_mode_delayed_u;
  v146_v334_from_cell = v146_v334_from_cell_u;
  v146_v334_cell1_replay_latch = v146_v334_cell1_replay_latch_u;
  v146_v334_cell2_replay_latch = v146_v334_cell2_replay_latch_u;
  v146_v334_cell1_v_delayed = v146_v334_cell1_v_delayed_u;
  v146_v334_cell2_v_delayed = v146_v334_cell2_v_delayed_u;
  v146_v334_wasted = v146_v334_wasted_u;
  return cstate;
}