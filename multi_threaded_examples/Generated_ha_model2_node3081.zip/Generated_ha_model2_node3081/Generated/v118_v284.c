#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v118_v284_update_c1vd();
extern double v118_v284_update_c2vd();
extern double v118_v284_update_c1md();
extern double v118_v284_update_c2md();
extern double v118_v284_update_buffer_index(double,double,double,double);
extern double v118_v284_update_latch1(double,double);
extern double v118_v284_update_latch2(double,double);
extern double v118_v284_update_ocell1(double,double);
extern double v118_v284_update_ocell2(double,double);
double v118_v284_cell1_v;
double v118_v284_cell1_mode;
double v118_v284_cell2_v;
double v118_v284_cell2_mode;
double v118_v284_cell1_v_replay = 0.0;
double v118_v284_cell2_v_replay = 0.0;


static double  v118_v284_k  =  0.0 ,  v118_v284_cell1_mode_delayed  =  0.0 ,  v118_v284_cell2_mode_delayed  =  0.0 ,  v118_v284_from_cell  =  0.0 ,  v118_v284_cell1_replay_latch  =  0.0 ,  v118_v284_cell2_replay_latch  =  0.0 ,  v118_v284_cell1_v_delayed  =  0.0 ,  v118_v284_cell2_v_delayed  =  0.0 ,  v118_v284_wasted  =  0.0 ; //the continuous vars
static double  v118_v284_k_u , v118_v284_cell1_mode_delayed_u , v118_v284_cell2_mode_delayed_u , v118_v284_from_cell_u , v118_v284_cell1_replay_latch_u , v118_v284_cell2_replay_latch_u , v118_v284_cell1_v_delayed_u , v118_v284_cell2_v_delayed_u , v118_v284_wasted_u ; // and their updates
static double  v118_v284_k_init , v118_v284_cell1_mode_delayed_init , v118_v284_cell2_mode_delayed_init , v118_v284_from_cell_init , v118_v284_cell1_replay_latch_init , v118_v284_cell2_replay_latch_init , v118_v284_cell1_v_delayed_init , v118_v284_cell2_v_delayed_init , v118_v284_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v118_v284_idle , v118_v284_annhilate , v118_v284_previous_drection1 , v118_v284_previous_direction2 , v118_v284_wait_cell1 , v118_v284_replay_cell1 , v118_v284_replay_cell2 , v118_v284_wait_cell2 }; // state declarations

enum states v118_v284 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v118_v284_idle ):
    if (True == False) {;}
    else if  (v118_v284_cell2_mode == (2.0) && (v118_v284_cell1_mode != (2.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v118_v284_cell1_mode == (2.0) && (v118_v284_cell2_mode != (2.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v118_v284_cell1_mode == (2.0) && (v118_v284_cell2_mode == (2.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_idle ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_annhilate ):
    if (True == False) {;}
    else if  (v118_v284_cell1_mode != (2.0) && (v118_v284_cell2_mode != (2.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_from_cell_u = 0 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_previous_drection1 ):
    if (True == False) {;}
    else if  (v118_v284_from_cell == (1.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (0.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (2.0) && (v118_v284_cell2_mode_delayed == (0.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (2.0) && (v118_v284_cell2_mode_delayed != (0.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_previous_drection1 ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_previous_direction2 ):
    if (True == False) {;}
    else if  (v118_v284_from_cell == (1.0) && (v118_v284_cell1_mode_delayed != (0.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (2.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (0.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v118_v284_from_cell == (1.0) && (v118_v284_cell1_mode_delayed == (0.0))) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_previous_direction2 ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_wait_cell1 ):
    if (True == False) {;}
    else if  (v118_v284_cell2_mode == (2.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
    }
    else if  (v118_v284_k >= (127.083885836)) {
      v118_v284_from_cell_u = 1 ;
      v118_v284_cell1_replay_latch_u = 1 ;
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_wait_cell1 ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_replay_cell1 ):
    if (True == False) {;}
    else if  (v118_v284_cell1_mode == (2.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_annhilate ;
      force_init_update = False;
    }
    else if  (v118_v284_k >= (127.083885836)) {
      v118_v284_from_cell_u = 2 ;
      v118_v284_cell2_replay_latch_u = 1 ;
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_replay_cell1 ;
      force_init_update = False;
      v118_v284_cell1_replay_latch_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_replay_cell2 ):
    if (True == False) {;}
    else if  (v118_v284_k >= (10.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_replay_cell2 ;
      force_init_update = False;
      v118_v284_cell2_replay_latch_u = 1 ;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  case ( v118_v284_wait_cell2 ):
    if (True == False) {;}
    else if  (v118_v284_k >= (10.0)) {
      v118_v284_k_u = 1 ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
      cstate =  v118_v284_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v118_v284_k_init = v118_v284_k ;
      slope =  1 ;
      v118_v284_k_u = (slope * d) + v118_v284_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v118_v284_wait_cell2 ;
      force_init_update = False;
      v118_v284_cell1_v_delayed_u = v118_v284_update_c1vd () ;
      v118_v284_cell2_v_delayed_u = v118_v284_update_c2vd () ;
      v118_v284_cell1_mode_delayed_u = v118_v284_update_c1md () ;
      v118_v284_cell2_mode_delayed_u = v118_v284_update_c2md () ;
      v118_v284_wasted_u = v118_v284_update_buffer_index (v118_v284_cell1_v,v118_v284_cell2_v,v118_v284_cell1_mode,v118_v284_cell2_mode) ;
      v118_v284_cell1_replay_latch_u = v118_v284_update_latch1 (v118_v284_cell1_mode_delayed,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_replay_latch_u = v118_v284_update_latch2 (v118_v284_cell2_mode_delayed,v118_v284_cell2_replay_latch_u) ;
      v118_v284_cell1_v_replay = v118_v284_update_ocell1 (v118_v284_cell1_v_delayed_u,v118_v284_cell1_replay_latch_u) ;
      v118_v284_cell2_v_replay = v118_v284_update_ocell2 (v118_v284_cell2_v_delayed_u,v118_v284_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v118_v284!\n");
      exit(1);
    }
    break;
  }
  v118_v284_k = v118_v284_k_u;
  v118_v284_cell1_mode_delayed = v118_v284_cell1_mode_delayed_u;
  v118_v284_cell2_mode_delayed = v118_v284_cell2_mode_delayed_u;
  v118_v284_from_cell = v118_v284_from_cell_u;
  v118_v284_cell1_replay_latch = v118_v284_cell1_replay_latch_u;
  v118_v284_cell2_replay_latch = v118_v284_cell2_replay_latch_u;
  v118_v284_cell1_v_delayed = v118_v284_cell1_v_delayed_u;
  v118_v284_cell2_v_delayed = v118_v284_cell2_v_delayed_u;
  v118_v284_wasted = v118_v284_wasted_u;
  return cstate;
}