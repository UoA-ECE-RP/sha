#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v133_v_i_0;
double v133_v_i_1;
double v133_v_i_2;
double v133_v_i_3;
double v133_voo = 0.0;
double v133_state = 0.0;


static double  v133_vx  =  0 ,  v133_vy  =  0 ,  v133_vz  =  0 ,  v133_g  =  0 ,  v133_v  =  0 ,  v133_ft  =  0 ,  v133_theta  =  0 ,  v133_v_O  =  0 ; //the continuous vars
static double  v133_vx_u , v133_vy_u , v133_vz_u , v133_g_u , v133_v_u , v133_ft_u , v133_theta_u , v133_v_O_u ; // and their updates
static double  v133_vx_init , v133_vy_init , v133_vz_init , v133_g_init , v133_v_init , v133_ft_init , v133_theta_init , v133_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v133_t1 , v133_t2 , v133_t3 , v133_t4 }; // state declarations

enum states v133 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v133_t1 ):
    if (True == False) {;}
    else if  (v133_g > (44.5)) {
      v133_vx_u = (0.3 * v133_v) ;
      v133_vy_u = 0 ;
      v133_vz_u = (0.7 * v133_v) ;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      v133_theta_u = (v133_v / 30.0) ;
      v133_v_O_u = (131.1 + (- (80.1 * pow ( ((v133_v / 30.0)) , (0.5) )))) ;
      v133_ft_u = f (v133_theta,4.0e-2) ;
      cstate =  v133_t2 ;
      force_init_update = False;
    }

    else if ( v133_v <= (44.5)
               && v133_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v133_vx_init = v133_vx ;
      slope =  (v133_vx * -8.7) ;
      v133_vx_u = (slope * d) + v133_vx ;
      if ((pstate != cstate) || force_init_update) v133_vy_init = v133_vy ;
      slope =  (v133_vy * -190.9) ;
      v133_vy_u = (slope * d) + v133_vy ;
      if ((pstate != cstate) || force_init_update) v133_vz_init = v133_vz ;
      slope =  (v133_vz * -190.4) ;
      v133_vz_u = (slope * d) + v133_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v133_t1 ;
      force_init_update = False;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      v133_v_u = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_voo = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v133!\n");
      exit(1);
    }
    break;
  case ( v133_t2 ):
    if (True == False) {;}
    else if  (v133_v >= (44.5)) {
      v133_vx_u = v133_vx ;
      v133_vy_u = v133_vy ;
      v133_vz_u = v133_vz ;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v133_t3 ;
      force_init_update = False;
    }
    else if  (v133_g <= (44.5)
               && v133_v < (44.5)) {
      v133_vx_u = v133_vx ;
      v133_vy_u = v133_vy ;
      v133_vz_u = v133_vz ;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v133_t1 ;
      force_init_update = False;
    }

    else if ( v133_v < (44.5)
               && v133_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v133_vx_init = v133_vx ;
      slope =  ((v133_vx * -23.6) + (777200.0 * v133_g)) ;
      v133_vx_u = (slope * d) + v133_vx ;
      if ((pstate != cstate) || force_init_update) v133_vy_init = v133_vy ;
      slope =  ((v133_vy * -45.5) + (58900.0 * v133_g)) ;
      v133_vy_u = (slope * d) + v133_vy ;
      if ((pstate != cstate) || force_init_update) v133_vz_init = v133_vz ;
      slope =  ((v133_vz * -12.9) + (276600.0 * v133_g)) ;
      v133_vz_u = (slope * d) + v133_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v133_t2 ;
      force_init_update = False;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      v133_v_u = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_voo = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v133!\n");
      exit(1);
    }
    break;
  case ( v133_t3 ):
    if (True == False) {;}
    else if  (v133_v >= (131.1)) {
      v133_vx_u = v133_vx ;
      v133_vy_u = v133_vy ;
      v133_vz_u = v133_vz ;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v133_t4 ;
      force_init_update = False;
    }

    else if ( v133_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v133_vx_init = v133_vx ;
      slope =  (v133_vx * -6.9) ;
      v133_vx_u = (slope * d) + v133_vx ;
      if ((pstate != cstate) || force_init_update) v133_vy_init = v133_vy ;
      slope =  (v133_vy * 75.9) ;
      v133_vy_u = (slope * d) + v133_vy ;
      if ((pstate != cstate) || force_init_update) v133_vz_init = v133_vz ;
      slope =  (v133_vz * 6826.5) ;
      v133_vz_u = (slope * d) + v133_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v133_t3 ;
      force_init_update = False;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      v133_v_u = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_voo = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v133!\n");
      exit(1);
    }
    break;
  case ( v133_t4 ):
    if (True == False) {;}
    else if  (v133_v <= (30.0)) {
      v133_vx_u = v133_vx ;
      v133_vy_u = v133_vy ;
      v133_vz_u = v133_vz ;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v133_t1 ;
      force_init_update = False;
    }

    else if ( v133_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v133_vx_init = v133_vx ;
      slope =  (v133_vx * -33.2) ;
      v133_vx_u = (slope * d) + v133_vx ;
      if ((pstate != cstate) || force_init_update) v133_vy_init = v133_vy ;
      slope =  ((v133_vy * 20.0) * v133_ft) ;
      v133_vy_u = (slope * d) + v133_vy ;
      if ((pstate != cstate) || force_init_update) v133_vz_init = v133_vz ;
      slope =  ((v133_vz * 2.0) * v133_ft) ;
      v133_vz_u = (slope * d) + v133_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v133_t4 ;
      force_init_update = False;
      v133_g_u = ((((((((((((v133_v_i_0 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v133_v_i_1 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487))) + ((((v133_v_i_2 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v133_v_i_3 + (- ((v133_vx + (- v133_vy)) + v133_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.2544546154))) + 0) + 0) + 0) + 0) + 0) ;
      v133_v_u = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_voo = ((v133_vx + (- v133_vy)) + v133_vz) ;
      v133_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v133!\n");
      exit(1);
    }
    break;
  }
  v133_vx = v133_vx_u;
  v133_vy = v133_vy_u;
  v133_vz = v133_vz_u;
  v133_g = v133_g_u;
  v133_v = v133_v_u;
  v133_ft = v133_ft_u;
  v133_theta = v133_theta_u;
  v133_v_O = v133_v_O_u;
  return cstate;
}