#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v123_v271_update_c1vd();
extern double v123_v271_update_c2vd();
extern double v123_v271_update_c1md();
extern double v123_v271_update_c2md();
extern double v123_v271_update_buffer_index(double,double,double,double);
extern double v123_v271_update_latch1(double,double);
extern double v123_v271_update_latch2(double,double);
extern double v123_v271_update_ocell1(double,double);
extern double v123_v271_update_ocell2(double,double);
double v123_v271_cell1_v;
double v123_v271_cell1_mode;
double v123_v271_cell2_v;
double v123_v271_cell2_mode;
double v123_v271_cell1_v_replay = 0.0;
double v123_v271_cell2_v_replay = 0.0;


static double  v123_v271_k  =  0.0 ,  v123_v271_cell1_mode_delayed  =  0.0 ,  v123_v271_cell2_mode_delayed  =  0.0 ,  v123_v271_from_cell  =  0.0 ,  v123_v271_cell1_replay_latch  =  0.0 ,  v123_v271_cell2_replay_latch  =  0.0 ,  v123_v271_cell1_v_delayed  =  0.0 ,  v123_v271_cell2_v_delayed  =  0.0 ,  v123_v271_wasted  =  0.0 ; //the continuous vars
static double  v123_v271_k_u , v123_v271_cell1_mode_delayed_u , v123_v271_cell2_mode_delayed_u , v123_v271_from_cell_u , v123_v271_cell1_replay_latch_u , v123_v271_cell2_replay_latch_u , v123_v271_cell1_v_delayed_u , v123_v271_cell2_v_delayed_u , v123_v271_wasted_u ; // and their updates
static double  v123_v271_k_init , v123_v271_cell1_mode_delayed_init , v123_v271_cell2_mode_delayed_init , v123_v271_from_cell_init , v123_v271_cell1_replay_latch_init , v123_v271_cell2_replay_latch_init , v123_v271_cell1_v_delayed_init , v123_v271_cell2_v_delayed_init , v123_v271_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v123_v271_idle , v123_v271_annhilate , v123_v271_previous_drection1 , v123_v271_previous_direction2 , v123_v271_wait_cell1 , v123_v271_replay_cell1 , v123_v271_replay_cell2 , v123_v271_wait_cell2 }; // state declarations

enum states v123_v271 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v123_v271_idle ):
    if (True == False) {;}
    else if  (v123_v271_cell2_mode == (2.0) && (v123_v271_cell1_mode != (2.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v123_v271_cell1_mode == (2.0) && (v123_v271_cell2_mode != (2.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v123_v271_cell1_mode == (2.0) && (v123_v271_cell2_mode == (2.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_idle ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_annhilate ):
    if (True == False) {;}
    else if  (v123_v271_cell1_mode != (2.0) && (v123_v271_cell2_mode != (2.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_from_cell_u = 0 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_previous_drection1 ):
    if (True == False) {;}
    else if  (v123_v271_from_cell == (1.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (0.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (2.0) && (v123_v271_cell2_mode_delayed == (0.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (2.0) && (v123_v271_cell2_mode_delayed != (0.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_previous_drection1 ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_previous_direction2 ):
    if (True == False) {;}
    else if  (v123_v271_from_cell == (1.0) && (v123_v271_cell1_mode_delayed != (0.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (2.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (0.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v123_v271_from_cell == (1.0) && (v123_v271_cell1_mode_delayed == (0.0))) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_previous_direction2 ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_wait_cell1 ):
    if (True == False) {;}
    else if  (v123_v271_cell2_mode == (2.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
    }
    else if  (v123_v271_k >= (102.86820356999999)) {
      v123_v271_from_cell_u = 1 ;
      v123_v271_cell1_replay_latch_u = 1 ;
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_wait_cell1 ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_replay_cell1 ):
    if (True == False) {;}
    else if  (v123_v271_cell1_mode == (2.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_annhilate ;
      force_init_update = False;
    }
    else if  (v123_v271_k >= (102.86820356999999)) {
      v123_v271_from_cell_u = 2 ;
      v123_v271_cell2_replay_latch_u = 1 ;
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_replay_cell1 ;
      force_init_update = False;
      v123_v271_cell1_replay_latch_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_replay_cell2 ):
    if (True == False) {;}
    else if  (v123_v271_k >= (10.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_replay_cell2 ;
      force_init_update = False;
      v123_v271_cell2_replay_latch_u = 1 ;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  case ( v123_v271_wait_cell2 ):
    if (True == False) {;}
    else if  (v123_v271_k >= (10.0)) {
      v123_v271_k_u = 1 ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
      cstate =  v123_v271_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v123_v271_k_init = v123_v271_k ;
      slope =  1 ;
      v123_v271_k_u = (slope * d) + v123_v271_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v123_v271_wait_cell2 ;
      force_init_update = False;
      v123_v271_cell1_v_delayed_u = v123_v271_update_c1vd () ;
      v123_v271_cell2_v_delayed_u = v123_v271_update_c2vd () ;
      v123_v271_cell1_mode_delayed_u = v123_v271_update_c1md () ;
      v123_v271_cell2_mode_delayed_u = v123_v271_update_c2md () ;
      v123_v271_wasted_u = v123_v271_update_buffer_index (v123_v271_cell1_v,v123_v271_cell2_v,v123_v271_cell1_mode,v123_v271_cell2_mode) ;
      v123_v271_cell1_replay_latch_u = v123_v271_update_latch1 (v123_v271_cell1_mode_delayed,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_replay_latch_u = v123_v271_update_latch2 (v123_v271_cell2_mode_delayed,v123_v271_cell2_replay_latch_u) ;
      v123_v271_cell1_v_replay = v123_v271_update_ocell1 (v123_v271_cell1_v_delayed_u,v123_v271_cell1_replay_latch_u) ;
      v123_v271_cell2_v_replay = v123_v271_update_ocell2 (v123_v271_cell2_v_delayed_u,v123_v271_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123_v271!\n");
      exit(1);
    }
    break;
  }
  v123_v271_k = v123_v271_k_u;
  v123_v271_cell1_mode_delayed = v123_v271_cell1_mode_delayed_u;
  v123_v271_cell2_mode_delayed = v123_v271_cell2_mode_delayed_u;
  v123_v271_from_cell = v123_v271_from_cell_u;
  v123_v271_cell1_replay_latch = v123_v271_cell1_replay_latch_u;
  v123_v271_cell2_replay_latch = v123_v271_cell2_replay_latch_u;
  v123_v271_cell1_v_delayed = v123_v271_cell1_v_delayed_u;
  v123_v271_cell2_v_delayed = v123_v271_cell2_v_delayed_u;
  v123_v271_wasted = v123_v271_wasted_u;
  return cstate;
}