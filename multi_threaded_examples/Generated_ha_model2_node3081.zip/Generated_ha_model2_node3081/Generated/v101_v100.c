#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v101_v100_update_c1vd();
extern double v101_v100_update_c2vd();
extern double v101_v100_update_c1md();
extern double v101_v100_update_c2md();
extern double v101_v100_update_buffer_index(double,double,double,double);
extern double v101_v100_update_latch1(double,double);
extern double v101_v100_update_latch2(double,double);
extern double v101_v100_update_ocell1(double,double);
extern double v101_v100_update_ocell2(double,double);
double v101_v100_cell1_v;
double v101_v100_cell1_mode;
double v101_v100_cell2_v;
double v101_v100_cell2_mode;
double v101_v100_cell1_v_replay = 0.0;
double v101_v100_cell2_v_replay = 0.0;


static double  v101_v100_k  =  0.0 ,  v101_v100_cell1_mode_delayed  =  0.0 ,  v101_v100_cell2_mode_delayed  =  0.0 ,  v101_v100_from_cell  =  0.0 ,  v101_v100_cell1_replay_latch  =  0.0 ,  v101_v100_cell2_replay_latch  =  0.0 ,  v101_v100_cell1_v_delayed  =  0.0 ,  v101_v100_cell2_v_delayed  =  0.0 ,  v101_v100_wasted  =  0.0 ; //the continuous vars
static double  v101_v100_k_u , v101_v100_cell1_mode_delayed_u , v101_v100_cell2_mode_delayed_u , v101_v100_from_cell_u , v101_v100_cell1_replay_latch_u , v101_v100_cell2_replay_latch_u , v101_v100_cell1_v_delayed_u , v101_v100_cell2_v_delayed_u , v101_v100_wasted_u ; // and their updates
static double  v101_v100_k_init , v101_v100_cell1_mode_delayed_init , v101_v100_cell2_mode_delayed_init , v101_v100_from_cell_init , v101_v100_cell1_replay_latch_init , v101_v100_cell2_replay_latch_init , v101_v100_cell1_v_delayed_init , v101_v100_cell2_v_delayed_init , v101_v100_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v101_v100_idle , v101_v100_annhilate , v101_v100_previous_drection1 , v101_v100_previous_direction2 , v101_v100_wait_cell1 , v101_v100_replay_cell1 , v101_v100_replay_cell2 , v101_v100_wait_cell2 }; // state declarations

enum states v101_v100 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v101_v100_idle ):
    if (True == False) {;}
    else if  (v101_v100_cell2_mode == (2.0) && (v101_v100_cell1_mode != (2.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v101_v100_cell1_mode == (2.0) && (v101_v100_cell2_mode != (2.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v101_v100_cell1_mode == (2.0) && (v101_v100_cell2_mode == (2.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_idle ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_annhilate ):
    if (True == False) {;}
    else if  (v101_v100_cell1_mode != (2.0) && (v101_v100_cell2_mode != (2.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_from_cell_u = 0 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_previous_drection1 ):
    if (True == False) {;}
    else if  (v101_v100_from_cell == (1.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (0.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (2.0) && (v101_v100_cell2_mode_delayed == (0.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (2.0) && (v101_v100_cell2_mode_delayed != (0.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_previous_drection1 ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_previous_direction2 ):
    if (True == False) {;}
    else if  (v101_v100_from_cell == (1.0) && (v101_v100_cell1_mode_delayed != (0.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (2.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (0.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v101_v100_from_cell == (1.0) && (v101_v100_cell1_mode_delayed == (0.0))) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_previous_direction2 ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_wait_cell1 ):
    if (True == False) {;}
    else if  (v101_v100_cell2_mode == (2.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
    }
    else if  (v101_v100_k >= (68.25177585109999)) {
      v101_v100_from_cell_u = 1 ;
      v101_v100_cell1_replay_latch_u = 1 ;
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_wait_cell1 ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_replay_cell1 ):
    if (True == False) {;}
    else if  (v101_v100_cell1_mode == (2.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_annhilate ;
      force_init_update = False;
    }
    else if  (v101_v100_k >= (68.25177585109999)) {
      v101_v100_from_cell_u = 2 ;
      v101_v100_cell2_replay_latch_u = 1 ;
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_replay_cell1 ;
      force_init_update = False;
      v101_v100_cell1_replay_latch_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_replay_cell2 ):
    if (True == False) {;}
    else if  (v101_v100_k >= (10.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_replay_cell2 ;
      force_init_update = False;
      v101_v100_cell2_replay_latch_u = 1 ;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  case ( v101_v100_wait_cell2 ):
    if (True == False) {;}
    else if  (v101_v100_k >= (10.0)) {
      v101_v100_k_u = 1 ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
      cstate =  v101_v100_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v101_v100_k_init = v101_v100_k ;
      slope =  1 ;
      v101_v100_k_u = (slope * d) + v101_v100_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v101_v100_wait_cell2 ;
      force_init_update = False;
      v101_v100_cell1_v_delayed_u = v101_v100_update_c1vd () ;
      v101_v100_cell2_v_delayed_u = v101_v100_update_c2vd () ;
      v101_v100_cell1_mode_delayed_u = v101_v100_update_c1md () ;
      v101_v100_cell2_mode_delayed_u = v101_v100_update_c2md () ;
      v101_v100_wasted_u = v101_v100_update_buffer_index (v101_v100_cell1_v,v101_v100_cell2_v,v101_v100_cell1_mode,v101_v100_cell2_mode) ;
      v101_v100_cell1_replay_latch_u = v101_v100_update_latch1 (v101_v100_cell1_mode_delayed,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_replay_latch_u = v101_v100_update_latch2 (v101_v100_cell2_mode_delayed,v101_v100_cell2_replay_latch_u) ;
      v101_v100_cell1_v_replay = v101_v100_update_ocell1 (v101_v100_cell1_v_delayed_u,v101_v100_cell1_replay_latch_u) ;
      v101_v100_cell2_v_replay = v101_v100_update_ocell2 (v101_v100_cell2_v_delayed_u,v101_v100_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v101_v100!\n");
      exit(1);
    }
    break;
  }
  v101_v100_k = v101_v100_k_u;
  v101_v100_cell1_mode_delayed = v101_v100_cell1_mode_delayed_u;
  v101_v100_cell2_mode_delayed = v101_v100_cell2_mode_delayed_u;
  v101_v100_from_cell = v101_v100_from_cell_u;
  v101_v100_cell1_replay_latch = v101_v100_cell1_replay_latch_u;
  v101_v100_cell2_replay_latch = v101_v100_cell2_replay_latch_u;
  v101_v100_cell1_v_delayed = v101_v100_cell1_v_delayed_u;
  v101_v100_cell2_v_delayed = v101_v100_cell2_v_delayed_u;
  v101_v100_wasted = v101_v100_wasted_u;
  return cstate;
}