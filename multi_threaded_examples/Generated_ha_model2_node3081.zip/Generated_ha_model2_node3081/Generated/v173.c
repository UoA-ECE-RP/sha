#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v173_v_i_0;
double v173_v_i_1;
double v173_v_i_2;
double v173_v_i_3;
double v173_voo = 0.0;
double v173_state = 0.0;


static double  v173_vx  =  0 ,  v173_vy  =  0 ,  v173_vz  =  0 ,  v173_g  =  0 ,  v173_v  =  0 ,  v173_ft  =  0 ,  v173_theta  =  0 ,  v173_v_O  =  0 ; //the continuous vars
static double  v173_vx_u , v173_vy_u , v173_vz_u , v173_g_u , v173_v_u , v173_ft_u , v173_theta_u , v173_v_O_u ; // and their updates
static double  v173_vx_init , v173_vy_init , v173_vz_init , v173_g_init , v173_v_init , v173_ft_init , v173_theta_init , v173_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v173_t1 , v173_t2 , v173_t3 , v173_t4 }; // state declarations

enum states v173 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v173_t1 ):
    if (True == False) {;}
    else if  (v173_g > (44.5)) {
      v173_vx_u = (0.3 * v173_v) ;
      v173_vy_u = 0 ;
      v173_vz_u = (0.7 * v173_v) ;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      v173_theta_u = (v173_v / 30.0) ;
      v173_v_O_u = (131.1 + (- (80.1 * pow ( ((v173_v / 30.0)) , (0.5) )))) ;
      v173_ft_u = f (v173_theta,4.0e-2) ;
      cstate =  v173_t2 ;
      force_init_update = False;
    }

    else if ( v173_v <= (44.5)
               && v173_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v173_vx_init = v173_vx ;
      slope =  (v173_vx * -8.7) ;
      v173_vx_u = (slope * d) + v173_vx ;
      if ((pstate != cstate) || force_init_update) v173_vy_init = v173_vy ;
      slope =  (v173_vy * -190.9) ;
      v173_vy_u = (slope * d) + v173_vy ;
      if ((pstate != cstate) || force_init_update) v173_vz_init = v173_vz ;
      slope =  (v173_vz * -190.4) ;
      v173_vz_u = (slope * d) + v173_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v173_t1 ;
      force_init_update = False;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      v173_v_u = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_voo = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173!\n");
      exit(1);
    }
    break;
  case ( v173_t2 ):
    if (True == False) {;}
    else if  (v173_v >= (44.5)) {
      v173_vx_u = v173_vx ;
      v173_vy_u = v173_vy ;
      v173_vz_u = v173_vz ;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v173_t3 ;
      force_init_update = False;
    }
    else if  (v173_g <= (44.5)
               && v173_v < (44.5)) {
      v173_vx_u = v173_vx ;
      v173_vy_u = v173_vy ;
      v173_vz_u = v173_vz ;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v173_t1 ;
      force_init_update = False;
    }

    else if ( v173_v < (44.5)
               && v173_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v173_vx_init = v173_vx ;
      slope =  ((v173_vx * -23.6) + (777200.0 * v173_g)) ;
      v173_vx_u = (slope * d) + v173_vx ;
      if ((pstate != cstate) || force_init_update) v173_vy_init = v173_vy ;
      slope =  ((v173_vy * -45.5) + (58900.0 * v173_g)) ;
      v173_vy_u = (slope * d) + v173_vy ;
      if ((pstate != cstate) || force_init_update) v173_vz_init = v173_vz ;
      slope =  ((v173_vz * -12.9) + (276600.0 * v173_g)) ;
      v173_vz_u = (slope * d) + v173_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v173_t2 ;
      force_init_update = False;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      v173_v_u = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_voo = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173!\n");
      exit(1);
    }
    break;
  case ( v173_t3 ):
    if (True == False) {;}
    else if  (v173_v >= (131.1)) {
      v173_vx_u = v173_vx ;
      v173_vy_u = v173_vy ;
      v173_vz_u = v173_vz ;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v173_t4 ;
      force_init_update = False;
    }

    else if ( v173_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v173_vx_init = v173_vx ;
      slope =  (v173_vx * -6.9) ;
      v173_vx_u = (slope * d) + v173_vx ;
      if ((pstate != cstate) || force_init_update) v173_vy_init = v173_vy ;
      slope =  (v173_vy * 75.9) ;
      v173_vy_u = (slope * d) + v173_vy ;
      if ((pstate != cstate) || force_init_update) v173_vz_init = v173_vz ;
      slope =  (v173_vz * 6826.5) ;
      v173_vz_u = (slope * d) + v173_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v173_t3 ;
      force_init_update = False;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      v173_v_u = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_voo = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173!\n");
      exit(1);
    }
    break;
  case ( v173_t4 ):
    if (True == False) {;}
    else if  (v173_v <= (30.0)) {
      v173_vx_u = v173_vx ;
      v173_vy_u = v173_vy ;
      v173_vz_u = v173_vz ;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v173_t1 ;
      force_init_update = False;
    }

    else if ( v173_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v173_vx_init = v173_vx ;
      slope =  (v173_vx * -33.2) ;
      v173_vx_u = (slope * d) + v173_vx ;
      if ((pstate != cstate) || force_init_update) v173_vy_init = v173_vy ;
      slope =  ((v173_vy * 20.0) * v173_ft) ;
      v173_vy_u = (slope * d) + v173_vy ;
      if ((pstate != cstate) || force_init_update) v173_vz_init = v173_vz ;
      slope =  ((v173_vz * 2.0) * v173_ft) ;
      v173_vz_u = (slope * d) + v173_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v173_t4 ;
      force_init_update = False;
      v173_g_u = ((((((((((((v173_v_i_0 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v173_v_i_1 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v173_v_i_2 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v173_v_i_3 + (- ((v173_vx + (- v173_vy)) + v173_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07520799382))) + 0) + 0) + 0) + 0) + 0) ;
      v173_v_u = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_voo = ((v173_vx + (- v173_vy)) + v173_vz) ;
      v173_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173!\n");
      exit(1);
    }
    break;
  }
  v173_vx = v173_vx_u;
  v173_vy = v173_vy_u;
  v173_vz = v173_vz_u;
  v173_g = v173_g_u;
  v173_v = v173_v_u;
  v173_ft = v173_ft_u;
  v173_theta = v173_theta_u;
  v173_v_O = v173_v_O_u;
  return cstate;
}