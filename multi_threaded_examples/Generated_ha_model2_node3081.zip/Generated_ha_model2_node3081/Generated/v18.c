#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v18_v_i_0;
double v18_v_i_1;
double v18_v_i_2;
double v18_v_i_3;
double v18_voo = 0.0;
double v18_state = 0.0;


static double  v18_vx  =  0 ,  v18_vy  =  0 ,  v18_vz  =  0 ,  v18_g  =  0 ,  v18_v  =  0 ,  v18_ft  =  0 ,  v18_theta  =  0 ,  v18_v_O  =  0 ; //the continuous vars
static double  v18_vx_u , v18_vy_u , v18_vz_u , v18_g_u , v18_v_u , v18_ft_u , v18_theta_u , v18_v_O_u ; // and their updates
static double  v18_vx_init , v18_vy_init , v18_vz_init , v18_g_init , v18_v_init , v18_ft_init , v18_theta_init , v18_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v18_t1 , v18_t2 , v18_t3 , v18_t4 }; // state declarations

enum states v18 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v18_t1 ):
    if (True == False) {;}
    else if  (v18_g > (44.5)) {
      v18_vx_u = (0.3 * v18_v) ;
      v18_vy_u = 0 ;
      v18_vz_u = (0.7 * v18_v) ;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      v18_theta_u = (v18_v / 30.0) ;
      v18_v_O_u = (131.1 + (- (80.1 * pow ( ((v18_v / 30.0)) , (0.5) )))) ;
      v18_ft_u = f (v18_theta,4.0e-2) ;
      cstate =  v18_t2 ;
      force_init_update = False;
    }

    else if ( v18_v <= (44.5)
               && v18_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v18_vx_init = v18_vx ;
      slope =  (v18_vx * -8.7) ;
      v18_vx_u = (slope * d) + v18_vx ;
      if ((pstate != cstate) || force_init_update) v18_vy_init = v18_vy ;
      slope =  (v18_vy * -190.9) ;
      v18_vy_u = (slope * d) + v18_vy ;
      if ((pstate != cstate) || force_init_update) v18_vz_init = v18_vz ;
      slope =  (v18_vz * -190.4) ;
      v18_vz_u = (slope * d) + v18_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v18_t1 ;
      force_init_update = False;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      v18_v_u = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_voo = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v18!\n");
      exit(1);
    }
    break;
  case ( v18_t2 ):
    if (True == False) {;}
    else if  (v18_v >= (44.5)) {
      v18_vx_u = v18_vx ;
      v18_vy_u = v18_vy ;
      v18_vz_u = v18_vz ;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v18_t3 ;
      force_init_update = False;
    }
    else if  (v18_g <= (44.5)
               && v18_v < (44.5)) {
      v18_vx_u = v18_vx ;
      v18_vy_u = v18_vy ;
      v18_vz_u = v18_vz ;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v18_t1 ;
      force_init_update = False;
    }

    else if ( v18_v < (44.5) && 
              v18_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v18_vx_init = v18_vx ;
      slope =  ((v18_vx * -23.6) + (777200.0 * v18_g)) ;
      v18_vx_u = (slope * d) + v18_vx ;
      if ((pstate != cstate) || force_init_update) v18_vy_init = v18_vy ;
      slope =  ((v18_vy * -45.5) + (58900.0 * v18_g)) ;
      v18_vy_u = (slope * d) + v18_vy ;
      if ((pstate != cstate) || force_init_update) v18_vz_init = v18_vz ;
      slope =  ((v18_vz * -12.9) + (276600.0 * v18_g)) ;
      v18_vz_u = (slope * d) + v18_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v18_t2 ;
      force_init_update = False;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      v18_v_u = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_voo = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v18!\n");
      exit(1);
    }
    break;
  case ( v18_t3 ):
    if (True == False) {;}
    else if  (v18_v >= (131.1)) {
      v18_vx_u = v18_vx ;
      v18_vy_u = v18_vy ;
      v18_vz_u = v18_vz ;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v18_t4 ;
      force_init_update = False;
    }

    else if ( v18_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v18_vx_init = v18_vx ;
      slope =  (v18_vx * -6.9) ;
      v18_vx_u = (slope * d) + v18_vx ;
      if ((pstate != cstate) || force_init_update) v18_vy_init = v18_vy ;
      slope =  (v18_vy * 75.9) ;
      v18_vy_u = (slope * d) + v18_vy ;
      if ((pstate != cstate) || force_init_update) v18_vz_init = v18_vz ;
      slope =  (v18_vz * 6826.5) ;
      v18_vz_u = (slope * d) + v18_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v18_t3 ;
      force_init_update = False;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      v18_v_u = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_voo = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v18!\n");
      exit(1);
    }
    break;
  case ( v18_t4 ):
    if (True == False) {;}
    else if  (v18_v <= (30.0)) {
      v18_vx_u = v18_vx ;
      v18_vy_u = v18_vy ;
      v18_vz_u = v18_vz ;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v18_t1 ;
      force_init_update = False;
    }

    else if ( v18_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v18_vx_init = v18_vx ;
      slope =  (v18_vx * -33.2) ;
      v18_vx_u = (slope * d) + v18_vx ;
      if ((pstate != cstate) || force_init_update) v18_vy_init = v18_vy ;
      slope =  ((v18_vy * 20.0) * v18_ft) ;
      v18_vy_u = (slope * d) + v18_vy ;
      if ((pstate != cstate) || force_init_update) v18_vz_init = v18_vz ;
      slope =  ((v18_vz * 2.0) * v18_ft) ;
      v18_vz_u = (slope * d) + v18_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v18_t4 ;
      force_init_update = False;
      v18_g_u = ((((((((((((v18_v_i_0 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v18_v_i_1 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v18_v_i_2 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v18_v_i_3 + (- ((v18_vx + (- v18_vy)) + v18_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.11362585588))) + 0) + 0) + 0) + 0) + 0) ;
      v18_v_u = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_voo = ((v18_vx + (- v18_vy)) + v18_vz) ;
      v18_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v18!\n");
      exit(1);
    }
    break;
  }
  v18_vx = v18_vx_u;
  v18_vy = v18_vy_u;
  v18_vz = v18_vz_u;
  v18_g = v18_g_u;
  v18_v = v18_v_u;
  v18_ft = v18_ft_u;
  v18_theta = v18_theta_u;
  v18_v_O = v18_v_O_u;
  return cstate;
}