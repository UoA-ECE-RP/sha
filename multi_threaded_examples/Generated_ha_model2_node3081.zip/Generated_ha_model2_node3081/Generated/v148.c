#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v148_v_i_0;
double v148_v_i_1;
double v148_v_i_2;
double v148_v_i_3;
double v148_voo = 0.0;
double v148_state = 0.0;


static double  v148_vx  =  0 ,  v148_vy  =  0 ,  v148_vz  =  0 ,  v148_g  =  0 ,  v148_v  =  0 ,  v148_ft  =  0 ,  v148_theta  =  0 ,  v148_v_O  =  0 ; //the continuous vars
static double  v148_vx_u , v148_vy_u , v148_vz_u , v148_g_u , v148_v_u , v148_ft_u , v148_theta_u , v148_v_O_u ; // and their updates
static double  v148_vx_init , v148_vy_init , v148_vz_init , v148_g_init , v148_v_init , v148_ft_init , v148_theta_init , v148_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v148_t1 , v148_t2 , v148_t3 , v148_t4 }; // state declarations

enum states v148 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v148_t1 ):
    if (True == False) {;}
    else if  (v148_g > (44.5)) {
      v148_vx_u = (0.3 * v148_v) ;
      v148_vy_u = 0 ;
      v148_vz_u = (0.7 * v148_v) ;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      v148_theta_u = (v148_v / 30.0) ;
      v148_v_O_u = (131.1 + (- (80.1 * pow ( ((v148_v / 30.0)) , (0.5) )))) ;
      v148_ft_u = f (v148_theta,4.0e-2) ;
      cstate =  v148_t2 ;
      force_init_update = False;
    }

    else if ( v148_v <= (44.5)
               && v148_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v148_vx_init = v148_vx ;
      slope =  (v148_vx * -8.7) ;
      v148_vx_u = (slope * d) + v148_vx ;
      if ((pstate != cstate) || force_init_update) v148_vy_init = v148_vy ;
      slope =  (v148_vy * -190.9) ;
      v148_vy_u = (slope * d) + v148_vy ;
      if ((pstate != cstate) || force_init_update) v148_vz_init = v148_vz ;
      slope =  (v148_vz * -190.4) ;
      v148_vz_u = (slope * d) + v148_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v148_t1 ;
      force_init_update = False;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      v148_v_u = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_voo = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v148!\n");
      exit(1);
    }
    break;
  case ( v148_t2 ):
    if (True == False) {;}
    else if  (v148_v >= (44.5)) {
      v148_vx_u = v148_vx ;
      v148_vy_u = v148_vy ;
      v148_vz_u = v148_vz ;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v148_t3 ;
      force_init_update = False;
    }
    else if  (v148_g <= (44.5)
               && v148_v < (44.5)) {
      v148_vx_u = v148_vx ;
      v148_vy_u = v148_vy ;
      v148_vz_u = v148_vz ;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v148_t1 ;
      force_init_update = False;
    }

    else if ( v148_v < (44.5)
               && v148_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v148_vx_init = v148_vx ;
      slope =  ((v148_vx * -23.6) + (777200.0 * v148_g)) ;
      v148_vx_u = (slope * d) + v148_vx ;
      if ((pstate != cstate) || force_init_update) v148_vy_init = v148_vy ;
      slope =  ((v148_vy * -45.5) + (58900.0 * v148_g)) ;
      v148_vy_u = (slope * d) + v148_vy ;
      if ((pstate != cstate) || force_init_update) v148_vz_init = v148_vz ;
      slope =  ((v148_vz * -12.9) + (276600.0 * v148_g)) ;
      v148_vz_u = (slope * d) + v148_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v148_t2 ;
      force_init_update = False;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      v148_v_u = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_voo = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v148!\n");
      exit(1);
    }
    break;
  case ( v148_t3 ):
    if (True == False) {;}
    else if  (v148_v >= (131.1)) {
      v148_vx_u = v148_vx ;
      v148_vy_u = v148_vy ;
      v148_vz_u = v148_vz ;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v148_t4 ;
      force_init_update = False;
    }

    else if ( v148_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v148_vx_init = v148_vx ;
      slope =  (v148_vx * -6.9) ;
      v148_vx_u = (slope * d) + v148_vx ;
      if ((pstate != cstate) || force_init_update) v148_vy_init = v148_vy ;
      slope =  (v148_vy * 75.9) ;
      v148_vy_u = (slope * d) + v148_vy ;
      if ((pstate != cstate) || force_init_update) v148_vz_init = v148_vz ;
      slope =  (v148_vz * 6826.5) ;
      v148_vz_u = (slope * d) + v148_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v148_t3 ;
      force_init_update = False;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      v148_v_u = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_voo = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v148!\n");
      exit(1);
    }
    break;
  case ( v148_t4 ):
    if (True == False) {;}
    else if  (v148_v <= (30.0)) {
      v148_vx_u = v148_vx ;
      v148_vy_u = v148_vy ;
      v148_vz_u = v148_vz ;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v148_t1 ;
      force_init_update = False;
    }

    else if ( v148_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v148_vx_init = v148_vx ;
      slope =  (v148_vx * -33.2) ;
      v148_vx_u = (slope * d) + v148_vx ;
      if ((pstate != cstate) || force_init_update) v148_vy_init = v148_vy ;
      slope =  ((v148_vy * 20.0) * v148_ft) ;
      v148_vy_u = (slope * d) + v148_vy ;
      if ((pstate != cstate) || force_init_update) v148_vz_init = v148_vz ;
      slope =  ((v148_vz * 2.0) * v148_ft) ;
      v148_vz_u = (slope * d) + v148_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v148_t4 ;
      force_init_update = False;
      v148_g_u = ((((((((((((v148_v_i_0 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v148_v_i_1 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v148_v_i_2 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.39734479176))) + ((((v148_v_i_3 + (- ((v148_vx + (- v148_vy)) + v148_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.56403499979))) + 0) + 0) + 0) + 0) + 0) ;
      v148_v_u = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_voo = ((v148_vx + (- v148_vy)) + v148_vz) ;
      v148_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v148!\n");
      exit(1);
    }
    break;
  }
  v148_vx = v148_vx_u;
  v148_vy = v148_vy_u;
  v148_vz = v148_vz_u;
  v148_g = v148_g_u;
  v148_v = v148_v_u;
  v148_ft = v148_ft_u;
  v148_theta = v148_theta_u;
  v148_v_O = v148_v_O_u;
  return cstate;
}