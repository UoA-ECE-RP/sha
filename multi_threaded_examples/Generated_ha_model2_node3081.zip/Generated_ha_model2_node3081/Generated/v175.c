#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v175_v_i_0;
double v175_v_i_1;
double v175_v_i_2;
double v175_v_i_3;
double v175_voo = 0.0;
double v175_state = 0.0;


static double  v175_vx  =  0 ,  v175_vy  =  0 ,  v175_vz  =  0 ,  v175_g  =  0 ,  v175_v  =  0 ,  v175_ft  =  0 ,  v175_theta  =  0 ,  v175_v_O  =  0 ; //the continuous vars
static double  v175_vx_u , v175_vy_u , v175_vz_u , v175_g_u , v175_v_u , v175_ft_u , v175_theta_u , v175_v_O_u ; // and their updates
static double  v175_vx_init , v175_vy_init , v175_vz_init , v175_g_init , v175_v_init , v175_ft_init , v175_theta_init , v175_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v175_t1 , v175_t2 , v175_t3 , v175_t4 }; // state declarations

enum states v175 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v175_t1 ):
    if (True == False) {;}
    else if  (v175_g > (44.5)) {
      v175_vx_u = (0.3 * v175_v) ;
      v175_vy_u = 0 ;
      v175_vz_u = (0.7 * v175_v) ;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      v175_theta_u = (v175_v / 30.0) ;
      v175_v_O_u = (131.1 + (- (80.1 * pow ( ((v175_v / 30.0)) , (0.5) )))) ;
      v175_ft_u = f (v175_theta,4.0e-2) ;
      cstate =  v175_t2 ;
      force_init_update = False;
    }

    else if ( v175_v <= (44.5)
               && v175_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v175_vx_init = v175_vx ;
      slope =  (v175_vx * -8.7) ;
      v175_vx_u = (slope * d) + v175_vx ;
      if ((pstate != cstate) || force_init_update) v175_vy_init = v175_vy ;
      slope =  (v175_vy * -190.9) ;
      v175_vy_u = (slope * d) + v175_vy ;
      if ((pstate != cstate) || force_init_update) v175_vz_init = v175_vz ;
      slope =  (v175_vz * -190.4) ;
      v175_vz_u = (slope * d) + v175_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v175_t1 ;
      force_init_update = False;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      v175_v_u = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_voo = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v175!\n");
      exit(1);
    }
    break;
  case ( v175_t2 ):
    if (True == False) {;}
    else if  (v175_v >= (44.5)) {
      v175_vx_u = v175_vx ;
      v175_vy_u = v175_vy ;
      v175_vz_u = v175_vz ;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v175_t3 ;
      force_init_update = False;
    }
    else if  (v175_g <= (44.5)
               && v175_v < (44.5)) {
      v175_vx_u = v175_vx ;
      v175_vy_u = v175_vy ;
      v175_vz_u = v175_vz ;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v175_t1 ;
      force_init_update = False;
    }

    else if ( v175_v < (44.5)
               && v175_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v175_vx_init = v175_vx ;
      slope =  ((v175_vx * -23.6) + (777200.0 * v175_g)) ;
      v175_vx_u = (slope * d) + v175_vx ;
      if ((pstate != cstate) || force_init_update) v175_vy_init = v175_vy ;
      slope =  ((v175_vy * -45.5) + (58900.0 * v175_g)) ;
      v175_vy_u = (slope * d) + v175_vy ;
      if ((pstate != cstate) || force_init_update) v175_vz_init = v175_vz ;
      slope =  ((v175_vz * -12.9) + (276600.0 * v175_g)) ;
      v175_vz_u = (slope * d) + v175_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v175_t2 ;
      force_init_update = False;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      v175_v_u = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_voo = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v175!\n");
      exit(1);
    }
    break;
  case ( v175_t3 ):
    if (True == False) {;}
    else if  (v175_v >= (131.1)) {
      v175_vx_u = v175_vx ;
      v175_vy_u = v175_vy ;
      v175_vz_u = v175_vz ;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v175_t4 ;
      force_init_update = False;
    }

    else if ( v175_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v175_vx_init = v175_vx ;
      slope =  (v175_vx * -6.9) ;
      v175_vx_u = (slope * d) + v175_vx ;
      if ((pstate != cstate) || force_init_update) v175_vy_init = v175_vy ;
      slope =  (v175_vy * 75.9) ;
      v175_vy_u = (slope * d) + v175_vy ;
      if ((pstate != cstate) || force_init_update) v175_vz_init = v175_vz ;
      slope =  (v175_vz * 6826.5) ;
      v175_vz_u = (slope * d) + v175_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v175_t3 ;
      force_init_update = False;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      v175_v_u = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_voo = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v175!\n");
      exit(1);
    }
    break;
  case ( v175_t4 ):
    if (True == False) {;}
    else if  (v175_v <= (30.0)) {
      v175_vx_u = v175_vx ;
      v175_vy_u = v175_vy ;
      v175_vz_u = v175_vz ;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v175_t1 ;
      force_init_update = False;
    }

    else if ( v175_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v175_vx_init = v175_vx ;
      slope =  (v175_vx * -33.2) ;
      v175_vx_u = (slope * d) + v175_vx ;
      if ((pstate != cstate) || force_init_update) v175_vy_init = v175_vy ;
      slope =  ((v175_vy * 20.0) * v175_ft) ;
      v175_vy_u = (slope * d) + v175_vy ;
      if ((pstate != cstate) || force_init_update) v175_vz_init = v175_vz ;
      slope =  ((v175_vz * 2.0) * v175_ft) ;
      v175_vz_u = (slope * d) + v175_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v175_t4 ;
      force_init_update = False;
      v175_g_u = ((((((((((((v175_v_i_0 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v175_v_i_1 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v175_v_i_2 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.42606494748))) + ((((v175_v_i_3 + (- ((v175_vx + (- v175_vy)) + v175_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49136170377))) + 0) + 0) + 0) + 0) + 0) ;
      v175_v_u = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_voo = ((v175_vx + (- v175_vy)) + v175_vz) ;
      v175_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v175!\n");
      exit(1);
    }
    break;
  }
  v175_vx = v175_vx_u;
  v175_vy = v175_vy_u;
  v175_vz = v175_vz_u;
  v175_g = v175_g_u;
  v175_v = v175_v_u;
  v175_ft = v175_ft_u;
  v175_theta = v175_theta_u;
  v175_v_O = v175_v_O_u;
  return cstate;
}