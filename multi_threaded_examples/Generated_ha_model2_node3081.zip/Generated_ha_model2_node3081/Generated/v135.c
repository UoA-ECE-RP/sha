#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v135_v_i_0;
double v135_v_i_1;
double v135_v_i_2;
double v135_v_i_3;
double v135_voo = 0.0;
double v135_state = 0.0;


static double  v135_vx  =  0 ,  v135_vy  =  0 ,  v135_vz  =  0 ,  v135_g  =  0 ,  v135_v  =  0 ,  v135_ft  =  0 ,  v135_theta  =  0 ,  v135_v_O  =  0 ; //the continuous vars
static double  v135_vx_u , v135_vy_u , v135_vz_u , v135_g_u , v135_v_u , v135_ft_u , v135_theta_u , v135_v_O_u ; // and their updates
static double  v135_vx_init , v135_vy_init , v135_vz_init , v135_g_init , v135_v_init , v135_ft_init , v135_theta_init , v135_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v135_t1 , v135_t2 , v135_t3 , v135_t4 }; // state declarations

enum states v135 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v135_t1 ):
    if (True == False) {;}
    else if  (v135_g > (44.5)) {
      v135_vx_u = (0.3 * v135_v) ;
      v135_vy_u = 0 ;
      v135_vz_u = (0.7 * v135_v) ;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      v135_theta_u = (v135_v / 30.0) ;
      v135_v_O_u = (131.1 + (- (80.1 * pow ( ((v135_v / 30.0)) , (0.5) )))) ;
      v135_ft_u = f (v135_theta,4.0e-2) ;
      cstate =  v135_t2 ;
      force_init_update = False;
    }

    else if ( v135_v <= (44.5)
               && v135_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v135_vx_init = v135_vx ;
      slope =  (v135_vx * -8.7) ;
      v135_vx_u = (slope * d) + v135_vx ;
      if ((pstate != cstate) || force_init_update) v135_vy_init = v135_vy ;
      slope =  (v135_vy * -190.9) ;
      v135_vy_u = (slope * d) + v135_vy ;
      if ((pstate != cstate) || force_init_update) v135_vz_init = v135_vz ;
      slope =  (v135_vz * -190.4) ;
      v135_vz_u = (slope * d) + v135_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v135_t1 ;
      force_init_update = False;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      v135_v_u = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_voo = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135!\n");
      exit(1);
    }
    break;
  case ( v135_t2 ):
    if (True == False) {;}
    else if  (v135_v >= (44.5)) {
      v135_vx_u = v135_vx ;
      v135_vy_u = v135_vy ;
      v135_vz_u = v135_vz ;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v135_t3 ;
      force_init_update = False;
    }
    else if  (v135_g <= (44.5)
               && v135_v < (44.5)) {
      v135_vx_u = v135_vx ;
      v135_vy_u = v135_vy ;
      v135_vz_u = v135_vz ;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v135_t1 ;
      force_init_update = False;
    }

    else if ( v135_v < (44.5)
               && v135_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v135_vx_init = v135_vx ;
      slope =  ((v135_vx * -23.6) + (777200.0 * v135_g)) ;
      v135_vx_u = (slope * d) + v135_vx ;
      if ((pstate != cstate) || force_init_update) v135_vy_init = v135_vy ;
      slope =  ((v135_vy * -45.5) + (58900.0 * v135_g)) ;
      v135_vy_u = (slope * d) + v135_vy ;
      if ((pstate != cstate) || force_init_update) v135_vz_init = v135_vz ;
      slope =  ((v135_vz * -12.9) + (276600.0 * v135_g)) ;
      v135_vz_u = (slope * d) + v135_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v135_t2 ;
      force_init_update = False;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      v135_v_u = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_voo = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135!\n");
      exit(1);
    }
    break;
  case ( v135_t3 ):
    if (True == False) {;}
    else if  (v135_v >= (131.1)) {
      v135_vx_u = v135_vx ;
      v135_vy_u = v135_vy ;
      v135_vz_u = v135_vz ;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v135_t4 ;
      force_init_update = False;
    }

    else if ( v135_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v135_vx_init = v135_vx ;
      slope =  (v135_vx * -6.9) ;
      v135_vx_u = (slope * d) + v135_vx ;
      if ((pstate != cstate) || force_init_update) v135_vy_init = v135_vy ;
      slope =  (v135_vy * 75.9) ;
      v135_vy_u = (slope * d) + v135_vy ;
      if ((pstate != cstate) || force_init_update) v135_vz_init = v135_vz ;
      slope =  (v135_vz * 6826.5) ;
      v135_vz_u = (slope * d) + v135_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v135_t3 ;
      force_init_update = False;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      v135_v_u = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_voo = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135!\n");
      exit(1);
    }
    break;
  case ( v135_t4 ):
    if (True == False) {;}
    else if  (v135_v <= (30.0)) {
      v135_vx_u = v135_vx ;
      v135_vy_u = v135_vy ;
      v135_vz_u = v135_vz ;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v135_t1 ;
      force_init_update = False;
    }

    else if ( v135_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v135_vx_init = v135_vx ;
      slope =  (v135_vx * -33.2) ;
      v135_vx_u = (slope * d) + v135_vx ;
      if ((pstate != cstate) || force_init_update) v135_vy_init = v135_vy ;
      slope =  ((v135_vy * 20.0) * v135_ft) ;
      v135_vy_u = (slope * d) + v135_vy ;
      if ((pstate != cstate) || force_init_update) v135_vz_init = v135_vz ;
      slope =  ((v135_vz * 2.0) * v135_ft) ;
      v135_vz_u = (slope * d) + v135_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v135_t4 ;
      force_init_update = False;
      v135_g_u = ((((((((((((v135_v_i_0 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992)) + ((((v135_v_i_1 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804))) + ((((v135_v_i_2 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + ((((v135_v_i_3 + (- ((v135_vx + (- v135_vy)) + v135_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.18860387176))) + 0) + 0) + 0) + 0) + 0) ;
      v135_v_u = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_voo = ((v135_vx + (- v135_vy)) + v135_vz) ;
      v135_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135!\n");
      exit(1);
    }
    break;
  }
  v135_vx = v135_vx_u;
  v135_vy = v135_vy_u;
  v135_vz = v135_vz_u;
  v135_g = v135_g_u;
  v135_v = v135_v_u;
  v135_ft = v135_ft_u;
  v135_theta = v135_theta_u;
  v135_v_O = v135_v_O_u;
  return cstate;
}