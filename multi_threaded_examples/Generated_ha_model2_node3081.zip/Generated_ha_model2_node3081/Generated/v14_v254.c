#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v14_v254_update_c1vd();
extern double v14_v254_update_c2vd();
extern double v14_v254_update_c1md();
extern double v14_v254_update_c2md();
extern double v14_v254_update_buffer_index(double,double,double,double);
extern double v14_v254_update_latch1(double,double);
extern double v14_v254_update_latch2(double,double);
extern double v14_v254_update_ocell1(double,double);
extern double v14_v254_update_ocell2(double,double);
double v14_v254_cell1_v;
double v14_v254_cell1_mode;
double v14_v254_cell2_v;
double v14_v254_cell2_mode;
double v14_v254_cell1_v_replay = 0.0;
double v14_v254_cell2_v_replay = 0.0;


static double  v14_v254_k  =  0.0 ,  v14_v254_cell1_mode_delayed  =  0.0 ,  v14_v254_cell2_mode_delayed  =  0.0 ,  v14_v254_from_cell  =  0.0 ,  v14_v254_cell1_replay_latch  =  0.0 ,  v14_v254_cell2_replay_latch  =  0.0 ,  v14_v254_cell1_v_delayed  =  0.0 ,  v14_v254_cell2_v_delayed  =  0.0 ,  v14_v254_wasted  =  0.0 ; //the continuous vars
static double  v14_v254_k_u , v14_v254_cell1_mode_delayed_u , v14_v254_cell2_mode_delayed_u , v14_v254_from_cell_u , v14_v254_cell1_replay_latch_u , v14_v254_cell2_replay_latch_u , v14_v254_cell1_v_delayed_u , v14_v254_cell2_v_delayed_u , v14_v254_wasted_u ; // and their updates
static double  v14_v254_k_init , v14_v254_cell1_mode_delayed_init , v14_v254_cell2_mode_delayed_init , v14_v254_from_cell_init , v14_v254_cell1_replay_latch_init , v14_v254_cell2_replay_latch_init , v14_v254_cell1_v_delayed_init , v14_v254_cell2_v_delayed_init , v14_v254_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v14_v254_idle , v14_v254_annhilate , v14_v254_previous_drection1 , v14_v254_previous_direction2 , v14_v254_wait_cell1 , v14_v254_replay_cell1 , v14_v254_replay_cell2 , v14_v254_wait_cell2 }; // state declarations

enum states v14_v254 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v14_v254_idle ):
    if (True == False) {;}
    else if  (v14_v254_cell2_mode == (2.0) && (v14_v254_cell1_mode != (2.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v14_v254_cell1_mode == (2.0) && (v14_v254_cell2_mode != (2.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v14_v254_cell1_mode == (2.0) && (v14_v254_cell2_mode == (2.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_idle ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_annhilate ):
    if (True == False) {;}
    else if  (v14_v254_cell1_mode != (2.0) && (v14_v254_cell2_mode != (2.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_from_cell_u = 0 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_previous_drection1 ):
    if (True == False) {;}
    else if  (v14_v254_from_cell == (1.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (0.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (2.0) && (v14_v254_cell2_mode_delayed == (0.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (2.0) && (v14_v254_cell2_mode_delayed != (0.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_previous_drection1 ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_previous_direction2 ):
    if (True == False) {;}
    else if  (v14_v254_from_cell == (1.0) && (v14_v254_cell1_mode_delayed != (0.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (2.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (0.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v254_from_cell == (1.0) && (v14_v254_cell1_mode_delayed == (0.0))) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_previous_direction2 ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_wait_cell1 ):
    if (True == False) {;}
    else if  (v14_v254_cell2_mode == (2.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v254_k >= (42.750455764499996)) {
      v14_v254_from_cell_u = 1 ;
      v14_v254_cell1_replay_latch_u = 1 ;
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_wait_cell1 ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_replay_cell1 ):
    if (True == False) {;}
    else if  (v14_v254_cell1_mode == (2.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v254_k >= (42.750455764499996)) {
      v14_v254_from_cell_u = 2 ;
      v14_v254_cell2_replay_latch_u = 1 ;
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_replay_cell1 ;
      force_init_update = False;
      v14_v254_cell1_replay_latch_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_replay_cell2 ):
    if (True == False) {;}
    else if  (v14_v254_k >= (10.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_replay_cell2 ;
      force_init_update = False;
      v14_v254_cell2_replay_latch_u = 1 ;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  case ( v14_v254_wait_cell2 ):
    if (True == False) {;}
    else if  (v14_v254_k >= (10.0)) {
      v14_v254_k_u = 1 ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
      cstate =  v14_v254_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v254_k_init = v14_v254_k ;
      slope =  1 ;
      v14_v254_k_u = (slope * d) + v14_v254_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v254_wait_cell2 ;
      force_init_update = False;
      v14_v254_cell1_v_delayed_u = v14_v254_update_c1vd () ;
      v14_v254_cell2_v_delayed_u = v14_v254_update_c2vd () ;
      v14_v254_cell1_mode_delayed_u = v14_v254_update_c1md () ;
      v14_v254_cell2_mode_delayed_u = v14_v254_update_c2md () ;
      v14_v254_wasted_u = v14_v254_update_buffer_index (v14_v254_cell1_v,v14_v254_cell2_v,v14_v254_cell1_mode,v14_v254_cell2_mode) ;
      v14_v254_cell1_replay_latch_u = v14_v254_update_latch1 (v14_v254_cell1_mode_delayed,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_replay_latch_u = v14_v254_update_latch2 (v14_v254_cell2_mode_delayed,v14_v254_cell2_replay_latch_u) ;
      v14_v254_cell1_v_replay = v14_v254_update_ocell1 (v14_v254_cell1_v_delayed_u,v14_v254_cell1_replay_latch_u) ;
      v14_v254_cell2_v_replay = v14_v254_update_ocell2 (v14_v254_cell2_v_delayed_u,v14_v254_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v254!\n");
      exit(1);
    }
    break;
  }
  v14_v254_k = v14_v254_k_u;
  v14_v254_cell1_mode_delayed = v14_v254_cell1_mode_delayed_u;
  v14_v254_cell2_mode_delayed = v14_v254_cell2_mode_delayed_u;
  v14_v254_from_cell = v14_v254_from_cell_u;
  v14_v254_cell1_replay_latch = v14_v254_cell1_replay_latch_u;
  v14_v254_cell2_replay_latch = v14_v254_cell2_replay_latch_u;
  v14_v254_cell1_v_delayed = v14_v254_cell1_v_delayed_u;
  v14_v254_cell2_v_delayed = v14_v254_cell2_v_delayed_u;
  v14_v254_wasted = v14_v254_wasted_u;
  return cstate;
}