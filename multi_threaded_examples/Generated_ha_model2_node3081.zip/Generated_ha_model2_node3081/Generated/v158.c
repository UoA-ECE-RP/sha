#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v158_v_i_0;
double v158_v_i_1;
double v158_v_i_2;
double v158_voo = 0.0;
double v158_state = 0.0;


static double  v158_vx  =  0 ,  v158_vy  =  0 ,  v158_vz  =  0 ,  v158_g  =  0 ,  v158_v  =  0 ,  v158_ft  =  0 ,  v158_theta  =  0 ,  v158_v_O  =  0 ; //the continuous vars
static double  v158_vx_u , v158_vy_u , v158_vz_u , v158_g_u , v158_v_u , v158_ft_u , v158_theta_u , v158_v_O_u ; // and their updates
static double  v158_vx_init , v158_vy_init , v158_vz_init , v158_g_init , v158_v_init , v158_ft_init , v158_theta_init , v158_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v158_t1 , v158_t2 , v158_t3 , v158_t4 }; // state declarations

enum states v158 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v158_t1 ):
    if (True == False) {;}
    else if  (v158_g > (44.5)) {
      v158_vx_u = (0.3 * v158_v) ;
      v158_vy_u = 0 ;
      v158_vz_u = (0.7 * v158_v) ;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v158_theta_u = (v158_v / 30.0) ;
      v158_v_O_u = (131.1 + (- (80.1 * pow ( ((v158_v / 30.0)) , (0.5) )))) ;
      v158_ft_u = f (v158_theta,4.0e-2) ;
      cstate =  v158_t2 ;
      force_init_update = False;
    }

    else if ( v158_v <= (44.5)
               && v158_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v158_vx_init = v158_vx ;
      slope =  (v158_vx * -8.7) ;
      v158_vx_u = (slope * d) + v158_vx ;
      if ((pstate != cstate) || force_init_update) v158_vy_init = v158_vy ;
      slope =  (v158_vy * -190.9) ;
      v158_vy_u = (slope * d) + v158_vy ;
      if ((pstate != cstate) || force_init_update) v158_vz_init = v158_vz ;
      slope =  (v158_vz * -190.4) ;
      v158_vz_u = (slope * d) + v158_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v158_t1 ;
      force_init_update = False;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v158_v_u = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_voo = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158!\n");
      exit(1);
    }
    break;
  case ( v158_t2 ):
    if (True == False) {;}
    else if  (v158_v >= (44.5)) {
      v158_vx_u = v158_vx ;
      v158_vy_u = v158_vy ;
      v158_vz_u = v158_vz ;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v158_t3 ;
      force_init_update = False;
    }
    else if  (v158_g <= (44.5)
               && v158_v < (44.5)) {
      v158_vx_u = v158_vx ;
      v158_vy_u = v158_vy ;
      v158_vz_u = v158_vz ;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v158_t1 ;
      force_init_update = False;
    }

    else if ( v158_v < (44.5)
               && v158_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v158_vx_init = v158_vx ;
      slope =  ((v158_vx * -23.6) + (777200.0 * v158_g)) ;
      v158_vx_u = (slope * d) + v158_vx ;
      if ((pstate != cstate) || force_init_update) v158_vy_init = v158_vy ;
      slope =  ((v158_vy * -45.5) + (58900.0 * v158_g)) ;
      v158_vy_u = (slope * d) + v158_vy ;
      if ((pstate != cstate) || force_init_update) v158_vz_init = v158_vz ;
      slope =  ((v158_vz * -12.9) + (276600.0 * v158_g)) ;
      v158_vz_u = (slope * d) + v158_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v158_t2 ;
      force_init_update = False;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v158_v_u = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_voo = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158!\n");
      exit(1);
    }
    break;
  case ( v158_t3 ):
    if (True == False) {;}
    else if  (v158_v >= (131.1)) {
      v158_vx_u = v158_vx ;
      v158_vy_u = v158_vy ;
      v158_vz_u = v158_vz ;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v158_t4 ;
      force_init_update = False;
    }

    else if ( v158_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v158_vx_init = v158_vx ;
      slope =  (v158_vx * -6.9) ;
      v158_vx_u = (slope * d) + v158_vx ;
      if ((pstate != cstate) || force_init_update) v158_vy_init = v158_vy ;
      slope =  (v158_vy * 75.9) ;
      v158_vy_u = (slope * d) + v158_vy ;
      if ((pstate != cstate) || force_init_update) v158_vz_init = v158_vz ;
      slope =  (v158_vz * 6826.5) ;
      v158_vz_u = (slope * d) + v158_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v158_t3 ;
      force_init_update = False;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v158_v_u = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_voo = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158!\n");
      exit(1);
    }
    break;
  case ( v158_t4 ):
    if (True == False) {;}
    else if  (v158_v <= (30.0)) {
      v158_vx_u = v158_vx ;
      v158_vy_u = v158_vy ;
      v158_vz_u = v158_vz ;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v158_t1 ;
      force_init_update = False;
    }

    else if ( v158_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v158_vx_init = v158_vx ;
      slope =  (v158_vx * -33.2) ;
      v158_vx_u = (slope * d) + v158_vx ;
      if ((pstate != cstate) || force_init_update) v158_vy_init = v158_vy ;
      slope =  ((v158_vy * 20.0) * v158_ft) ;
      v158_vy_u = (slope * d) + v158_vy ;
      if ((pstate != cstate) || force_init_update) v158_vz_init = v158_vz ;
      slope =  ((v158_vz * 2.0) * v158_ft) ;
      v158_vz_u = (slope * d) + v158_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v158_t4 ;
      force_init_update = False;
      v158_g_u = ((((((((((((v158_v_i_0 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v158_v_i_1 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499))) + ((((v158_v_i_2 + (- ((v158_vx + (- v158_vy)) + v158_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v158_v_u = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_voo = ((v158_vx + (- v158_vy)) + v158_vz) ;
      v158_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158!\n");
      exit(1);
    }
    break;
  }
  v158_vx = v158_vx_u;
  v158_vy = v158_vy_u;
  v158_vz = v158_vz_u;
  v158_g = v158_g_u;
  v158_v = v158_v_u;
  v158_ft = v158_ft_u;
  v158_theta = v158_theta_u;
  v158_v_O = v158_v_O_u;
  return cstate;
}