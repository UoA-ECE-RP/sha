#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v163_v_i_0;
double v163_v_i_1;
double v163_v_i_2;
double v163_voo = 0.0;
double v163_state = 0.0;


static double  v163_vx  =  0 ,  v163_vy  =  0 ,  v163_vz  =  0 ,  v163_g  =  0 ,  v163_v  =  0 ,  v163_ft  =  0 ,  v163_theta  =  0 ,  v163_v_O  =  0 ; //the continuous vars
static double  v163_vx_u , v163_vy_u , v163_vz_u , v163_g_u , v163_v_u , v163_ft_u , v163_theta_u , v163_v_O_u ; // and their updates
static double  v163_vx_init , v163_vy_init , v163_vz_init , v163_g_init , v163_v_init , v163_ft_init , v163_theta_init , v163_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v163_t1 , v163_t2 , v163_t3 , v163_t4 }; // state declarations

enum states v163 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v163_t1 ):
    if (True == False) {;}
    else if  (v163_g > (44.5)) {
      v163_vx_u = (0.3 * v163_v) ;
      v163_vy_u = 0 ;
      v163_vz_u = (0.7 * v163_v) ;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v163_theta_u = (v163_v / 30.0) ;
      v163_v_O_u = (131.1 + (- (80.1 * pow ( ((v163_v / 30.0)) , (0.5) )))) ;
      v163_ft_u = f (v163_theta,4.0e-2) ;
      cstate =  v163_t2 ;
      force_init_update = False;
    }

    else if ( v163_v <= (44.5)
               && v163_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v163_vx_init = v163_vx ;
      slope =  (v163_vx * -8.7) ;
      v163_vx_u = (slope * d) + v163_vx ;
      if ((pstate != cstate) || force_init_update) v163_vy_init = v163_vy ;
      slope =  (v163_vy * -190.9) ;
      v163_vy_u = (slope * d) + v163_vy ;
      if ((pstate != cstate) || force_init_update) v163_vz_init = v163_vz ;
      slope =  (v163_vz * -190.4) ;
      v163_vz_u = (slope * d) + v163_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v163_t1 ;
      force_init_update = False;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v163_v_u = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_voo = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v163!\n");
      exit(1);
    }
    break;
  case ( v163_t2 ):
    if (True == False) {;}
    else if  (v163_v >= (44.5)) {
      v163_vx_u = v163_vx ;
      v163_vy_u = v163_vy ;
      v163_vz_u = v163_vz ;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v163_t3 ;
      force_init_update = False;
    }
    else if  (v163_g <= (44.5)
               && v163_v < (44.5)) {
      v163_vx_u = v163_vx ;
      v163_vy_u = v163_vy ;
      v163_vz_u = v163_vz ;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v163_t1 ;
      force_init_update = False;
    }

    else if ( v163_v < (44.5)
               && v163_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v163_vx_init = v163_vx ;
      slope =  ((v163_vx * -23.6) + (777200.0 * v163_g)) ;
      v163_vx_u = (slope * d) + v163_vx ;
      if ((pstate != cstate) || force_init_update) v163_vy_init = v163_vy ;
      slope =  ((v163_vy * -45.5) + (58900.0 * v163_g)) ;
      v163_vy_u = (slope * d) + v163_vy ;
      if ((pstate != cstate) || force_init_update) v163_vz_init = v163_vz ;
      slope =  ((v163_vz * -12.9) + (276600.0 * v163_g)) ;
      v163_vz_u = (slope * d) + v163_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v163_t2 ;
      force_init_update = False;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v163_v_u = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_voo = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v163!\n");
      exit(1);
    }
    break;
  case ( v163_t3 ):
    if (True == False) {;}
    else if  (v163_v >= (131.1)) {
      v163_vx_u = v163_vx ;
      v163_vy_u = v163_vy ;
      v163_vz_u = v163_vz ;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v163_t4 ;
      force_init_update = False;
    }

    else if ( v163_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v163_vx_init = v163_vx ;
      slope =  (v163_vx * -6.9) ;
      v163_vx_u = (slope * d) + v163_vx ;
      if ((pstate != cstate) || force_init_update) v163_vy_init = v163_vy ;
      slope =  (v163_vy * 75.9) ;
      v163_vy_u = (slope * d) + v163_vy ;
      if ((pstate != cstate) || force_init_update) v163_vz_init = v163_vz ;
      slope =  (v163_vz * 6826.5) ;
      v163_vz_u = (slope * d) + v163_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v163_t3 ;
      force_init_update = False;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v163_v_u = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_voo = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v163!\n");
      exit(1);
    }
    break;
  case ( v163_t4 ):
    if (True == False) {;}
    else if  (v163_v <= (30.0)) {
      v163_vx_u = v163_vx ;
      v163_vy_u = v163_vy ;
      v163_vz_u = v163_vz ;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v163_t1 ;
      force_init_update = False;
    }

    else if ( v163_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v163_vx_init = v163_vx ;
      slope =  (v163_vx * -33.2) ;
      v163_vx_u = (slope * d) + v163_vx ;
      if ((pstate != cstate) || force_init_update) v163_vy_init = v163_vy ;
      slope =  ((v163_vy * 20.0) * v163_ft) ;
      v163_vy_u = (slope * d) + v163_vy ;
      if ((pstate != cstate) || force_init_update) v163_vz_init = v163_vz ;
      slope =  ((v163_vz * 2.0) * v163_ft) ;
      v163_vz_u = (slope * d) + v163_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v163_t4 ;
      force_init_update = False;
      v163_g_u = ((((((((((((v163_v_i_0 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v163_v_i_1 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v163_v_i_2 + (- ((v163_vx + (- v163_vy)) + v163_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v163_v_u = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_voo = ((v163_vx + (- v163_vy)) + v163_vz) ;
      v163_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v163!\n");
      exit(1);
    }
    break;
  }
  v163_vx = v163_vx_u;
  v163_vy = v163_vy_u;
  v163_vz = v163_vz_u;
  v163_g = v163_g_u;
  v163_v = v163_v_u;
  v163_ft = v163_ft_u;
  v163_theta = v163_theta_u;
  v163_v_O = v163_v_O_u;
  return cstate;
}