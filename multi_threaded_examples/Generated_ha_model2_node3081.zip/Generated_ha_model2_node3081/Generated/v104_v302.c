#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v104_v302_update_c1vd();
extern double v104_v302_update_c2vd();
extern double v104_v302_update_c1md();
extern double v104_v302_update_c2md();
extern double v104_v302_update_buffer_index(double,double,double,double);
extern double v104_v302_update_latch1(double,double);
extern double v104_v302_update_latch2(double,double);
extern double v104_v302_update_ocell1(double,double);
extern double v104_v302_update_ocell2(double,double);
double v104_v302_cell1_v;
double v104_v302_cell1_mode;
double v104_v302_cell2_v;
double v104_v302_cell2_mode;
double v104_v302_cell1_v_replay = 0.0;
double v104_v302_cell2_v_replay = 0.0;


static double  v104_v302_k  =  0.0 ,  v104_v302_cell1_mode_delayed  =  0.0 ,  v104_v302_cell2_mode_delayed  =  0.0 ,  v104_v302_from_cell  =  0.0 ,  v104_v302_cell1_replay_latch  =  0.0 ,  v104_v302_cell2_replay_latch  =  0.0 ,  v104_v302_cell1_v_delayed  =  0.0 ,  v104_v302_cell2_v_delayed  =  0.0 ,  v104_v302_wasted  =  0.0 ; //the continuous vars
static double  v104_v302_k_u , v104_v302_cell1_mode_delayed_u , v104_v302_cell2_mode_delayed_u , v104_v302_from_cell_u , v104_v302_cell1_replay_latch_u , v104_v302_cell2_replay_latch_u , v104_v302_cell1_v_delayed_u , v104_v302_cell2_v_delayed_u , v104_v302_wasted_u ; // and their updates
static double  v104_v302_k_init , v104_v302_cell1_mode_delayed_init , v104_v302_cell2_mode_delayed_init , v104_v302_from_cell_init , v104_v302_cell1_replay_latch_init , v104_v302_cell2_replay_latch_init , v104_v302_cell1_v_delayed_init , v104_v302_cell2_v_delayed_init , v104_v302_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v104_v302_idle , v104_v302_annhilate , v104_v302_previous_drection1 , v104_v302_previous_direction2 , v104_v302_wait_cell1 , v104_v302_replay_cell1 , v104_v302_replay_cell2 , v104_v302_wait_cell2 }; // state declarations

enum states v104_v302 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v104_v302_idle ):
    if (True == False) {;}
    else if  (v104_v302_cell2_mode == (2.0) && (v104_v302_cell1_mode != (2.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v104_v302_cell1_mode == (2.0) && (v104_v302_cell2_mode != (2.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v104_v302_cell1_mode == (2.0) && (v104_v302_cell2_mode == (2.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_idle ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_annhilate ):
    if (True == False) {;}
    else if  (v104_v302_cell1_mode != (2.0) && (v104_v302_cell2_mode != (2.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_from_cell_u = 0 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_previous_drection1 ):
    if (True == False) {;}
    else if  (v104_v302_from_cell == (1.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (0.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (2.0) && (v104_v302_cell2_mode_delayed == (0.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (2.0) && (v104_v302_cell2_mode_delayed != (0.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_previous_drection1 ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_previous_direction2 ):
    if (True == False) {;}
    else if  (v104_v302_from_cell == (1.0) && (v104_v302_cell1_mode_delayed != (0.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (2.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (0.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v104_v302_from_cell == (1.0) && (v104_v302_cell1_mode_delayed == (0.0))) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_previous_direction2 ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_wait_cell1 ):
    if (True == False) {;}
    else if  (v104_v302_cell2_mode == (2.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
    }
    else if  (v104_v302_k >= (82.9396205262)) {
      v104_v302_from_cell_u = 1 ;
      v104_v302_cell1_replay_latch_u = 1 ;
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_wait_cell1 ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_replay_cell1 ):
    if (True == False) {;}
    else if  (v104_v302_cell1_mode == (2.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_annhilate ;
      force_init_update = False;
    }
    else if  (v104_v302_k >= (82.9396205262)) {
      v104_v302_from_cell_u = 2 ;
      v104_v302_cell2_replay_latch_u = 1 ;
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_replay_cell1 ;
      force_init_update = False;
      v104_v302_cell1_replay_latch_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_replay_cell2 ):
    if (True == False) {;}
    else if  (v104_v302_k >= (10.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_replay_cell2 ;
      force_init_update = False;
      v104_v302_cell2_replay_latch_u = 1 ;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  case ( v104_v302_wait_cell2 ):
    if (True == False) {;}
    else if  (v104_v302_k >= (10.0)) {
      v104_v302_k_u = 1 ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
      cstate =  v104_v302_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v104_v302_k_init = v104_v302_k ;
      slope =  1 ;
      v104_v302_k_u = (slope * d) + v104_v302_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v104_v302_wait_cell2 ;
      force_init_update = False;
      v104_v302_cell1_v_delayed_u = v104_v302_update_c1vd () ;
      v104_v302_cell2_v_delayed_u = v104_v302_update_c2vd () ;
      v104_v302_cell1_mode_delayed_u = v104_v302_update_c1md () ;
      v104_v302_cell2_mode_delayed_u = v104_v302_update_c2md () ;
      v104_v302_wasted_u = v104_v302_update_buffer_index (v104_v302_cell1_v,v104_v302_cell2_v,v104_v302_cell1_mode,v104_v302_cell2_mode) ;
      v104_v302_cell1_replay_latch_u = v104_v302_update_latch1 (v104_v302_cell1_mode_delayed,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_replay_latch_u = v104_v302_update_latch2 (v104_v302_cell2_mode_delayed,v104_v302_cell2_replay_latch_u) ;
      v104_v302_cell1_v_replay = v104_v302_update_ocell1 (v104_v302_cell1_v_delayed_u,v104_v302_cell1_replay_latch_u) ;
      v104_v302_cell2_v_replay = v104_v302_update_ocell2 (v104_v302_cell2_v_delayed_u,v104_v302_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104_v302!\n");
      exit(1);
    }
    break;
  }
  v104_v302_k = v104_v302_k_u;
  v104_v302_cell1_mode_delayed = v104_v302_cell1_mode_delayed_u;
  v104_v302_cell2_mode_delayed = v104_v302_cell2_mode_delayed_u;
  v104_v302_from_cell = v104_v302_from_cell_u;
  v104_v302_cell1_replay_latch = v104_v302_cell1_replay_latch_u;
  v104_v302_cell2_replay_latch = v104_v302_cell2_replay_latch_u;
  v104_v302_cell1_v_delayed = v104_v302_cell1_v_delayed_u;
  v104_v302_cell2_v_delayed = v104_v302_cell2_v_delayed_u;
  v104_v302_wasted = v104_v302_wasted_u;
  return cstate;
}