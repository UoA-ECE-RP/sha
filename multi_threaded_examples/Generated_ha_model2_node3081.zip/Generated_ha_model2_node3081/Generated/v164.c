#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v164_v_i_0;
double v164_v_i_1;
double v164_v_i_2;
double v164_v_i_3;
double v164_voo = 0.0;
double v164_state = 0.0;


static double  v164_vx  =  0 ,  v164_vy  =  0 ,  v164_vz  =  0 ,  v164_g  =  0 ,  v164_v  =  0 ,  v164_ft  =  0 ,  v164_theta  =  0 ,  v164_v_O  =  0 ; //the continuous vars
static double  v164_vx_u , v164_vy_u , v164_vz_u , v164_g_u , v164_v_u , v164_ft_u , v164_theta_u , v164_v_O_u ; // and their updates
static double  v164_vx_init , v164_vy_init , v164_vz_init , v164_g_init , v164_v_init , v164_ft_init , v164_theta_init , v164_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v164_t1 , v164_t2 , v164_t3 , v164_t4 }; // state declarations

enum states v164 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v164_t1 ):
    if (True == False) {;}
    else if  (v164_g > (44.5)) {
      v164_vx_u = (0.3 * v164_v) ;
      v164_vy_u = 0 ;
      v164_vz_u = (0.7 * v164_v) ;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v164_theta_u = (v164_v / 30.0) ;
      v164_v_O_u = (131.1 + (- (80.1 * pow ( ((v164_v / 30.0)) , (0.5) )))) ;
      v164_ft_u = f (v164_theta,4.0e-2) ;
      cstate =  v164_t2 ;
      force_init_update = False;
    }

    else if ( v164_v <= (44.5)
               && v164_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v164_vx_init = v164_vx ;
      slope =  (v164_vx * -8.7) ;
      v164_vx_u = (slope * d) + v164_vx ;
      if ((pstate != cstate) || force_init_update) v164_vy_init = v164_vy ;
      slope =  (v164_vy * -190.9) ;
      v164_vy_u = (slope * d) + v164_vy ;
      if ((pstate != cstate) || force_init_update) v164_vz_init = v164_vz ;
      slope =  (v164_vz * -190.4) ;
      v164_vz_u = (slope * d) + v164_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v164_t1 ;
      force_init_update = False;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v164_v_u = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_voo = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164!\n");
      exit(1);
    }
    break;
  case ( v164_t2 ):
    if (True == False) {;}
    else if  (v164_v >= (44.5)) {
      v164_vx_u = v164_vx ;
      v164_vy_u = v164_vy ;
      v164_vz_u = v164_vz ;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v164_t3 ;
      force_init_update = False;
    }
    else if  (v164_g <= (44.5)
               && v164_v < (44.5)) {
      v164_vx_u = v164_vx ;
      v164_vy_u = v164_vy ;
      v164_vz_u = v164_vz ;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v164_t1 ;
      force_init_update = False;
    }

    else if ( v164_v < (44.5)
               && v164_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v164_vx_init = v164_vx ;
      slope =  ((v164_vx * -23.6) + (777200.0 * v164_g)) ;
      v164_vx_u = (slope * d) + v164_vx ;
      if ((pstate != cstate) || force_init_update) v164_vy_init = v164_vy ;
      slope =  ((v164_vy * -45.5) + (58900.0 * v164_g)) ;
      v164_vy_u = (slope * d) + v164_vy ;
      if ((pstate != cstate) || force_init_update) v164_vz_init = v164_vz ;
      slope =  ((v164_vz * -12.9) + (276600.0 * v164_g)) ;
      v164_vz_u = (slope * d) + v164_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v164_t2 ;
      force_init_update = False;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v164_v_u = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_voo = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164!\n");
      exit(1);
    }
    break;
  case ( v164_t3 ):
    if (True == False) {;}
    else if  (v164_v >= (131.1)) {
      v164_vx_u = v164_vx ;
      v164_vy_u = v164_vy ;
      v164_vz_u = v164_vz ;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v164_t4 ;
      force_init_update = False;
    }

    else if ( v164_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v164_vx_init = v164_vx ;
      slope =  (v164_vx * -6.9) ;
      v164_vx_u = (slope * d) + v164_vx ;
      if ((pstate != cstate) || force_init_update) v164_vy_init = v164_vy ;
      slope =  (v164_vy * 75.9) ;
      v164_vy_u = (slope * d) + v164_vy ;
      if ((pstate != cstate) || force_init_update) v164_vz_init = v164_vz ;
      slope =  (v164_vz * 6826.5) ;
      v164_vz_u = (slope * d) + v164_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v164_t3 ;
      force_init_update = False;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v164_v_u = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_voo = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164!\n");
      exit(1);
    }
    break;
  case ( v164_t4 ):
    if (True == False) {;}
    else if  (v164_v <= (30.0)) {
      v164_vx_u = v164_vx ;
      v164_vy_u = v164_vy ;
      v164_vz_u = v164_vz ;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v164_t1 ;
      force_init_update = False;
    }

    else if ( v164_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v164_vx_init = v164_vx ;
      slope =  (v164_vx * -33.2) ;
      v164_vx_u = (slope * d) + v164_vx ;
      if ((pstate != cstate) || force_init_update) v164_vy_init = v164_vy ;
      slope =  ((v164_vy * 20.0) * v164_ft) ;
      v164_vy_u = (slope * d) + v164_vy ;
      if ((pstate != cstate) || force_init_update) v164_vz_init = v164_vz ;
      slope =  ((v164_vz * 2.0) * v164_ft) ;
      v164_vz_u = (slope * d) + v164_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v164_t4 ;
      force_init_update = False;
      v164_g_u = ((((((((((((v164_v_i_0 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v164_v_i_1 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v164_v_i_2 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v164_v_i_3 + (- ((v164_vx + (- v164_vy)) + v164_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v164_v_u = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_voo = ((v164_vx + (- v164_vy)) + v164_vz) ;
      v164_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164!\n");
      exit(1);
    }
    break;
  }
  v164_vx = v164_vx_u;
  v164_vy = v164_vy_u;
  v164_vz = v164_vz_u;
  v164_g = v164_g_u;
  v164_v = v164_v_u;
  v164_ft = v164_ft_u;
  v164_theta = v164_theta_u;
  v164_v_O = v164_v_O_u;
  return cstate;
}