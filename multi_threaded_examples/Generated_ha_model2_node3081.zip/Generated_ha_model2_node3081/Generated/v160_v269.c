#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v160_v269_update_c1vd();
extern double v160_v269_update_c2vd();
extern double v160_v269_update_c1md();
extern double v160_v269_update_c2md();
extern double v160_v269_update_buffer_index(double,double,double,double);
extern double v160_v269_update_latch1(double,double);
extern double v160_v269_update_latch2(double,double);
extern double v160_v269_update_ocell1(double,double);
extern double v160_v269_update_ocell2(double,double);
double v160_v269_cell1_v;
double v160_v269_cell1_mode;
double v160_v269_cell2_v;
double v160_v269_cell2_mode;
double v160_v269_cell1_v_replay = 0.0;
double v160_v269_cell2_v_replay = 0.0;


static double  v160_v269_k  =  0.0 ,  v160_v269_cell1_mode_delayed  =  0.0 ,  v160_v269_cell2_mode_delayed  =  0.0 ,  v160_v269_from_cell  =  0.0 ,  v160_v269_cell1_replay_latch  =  0.0 ,  v160_v269_cell2_replay_latch  =  0.0 ,  v160_v269_cell1_v_delayed  =  0.0 ,  v160_v269_cell2_v_delayed  =  0.0 ,  v160_v269_wasted  =  0.0 ; //the continuous vars
static double  v160_v269_k_u , v160_v269_cell1_mode_delayed_u , v160_v269_cell2_mode_delayed_u , v160_v269_from_cell_u , v160_v269_cell1_replay_latch_u , v160_v269_cell2_replay_latch_u , v160_v269_cell1_v_delayed_u , v160_v269_cell2_v_delayed_u , v160_v269_wasted_u ; // and their updates
static double  v160_v269_k_init , v160_v269_cell1_mode_delayed_init , v160_v269_cell2_mode_delayed_init , v160_v269_from_cell_init , v160_v269_cell1_replay_latch_init , v160_v269_cell2_replay_latch_init , v160_v269_cell1_v_delayed_init , v160_v269_cell2_v_delayed_init , v160_v269_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v160_v269_idle , v160_v269_annhilate , v160_v269_previous_drection1 , v160_v269_previous_direction2 , v160_v269_wait_cell1 , v160_v269_replay_cell1 , v160_v269_replay_cell2 , v160_v269_wait_cell2 }; // state declarations

enum states v160_v269 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v160_v269_idle ):
    if (True == False) {;}
    else if  (v160_v269_cell2_mode == (2.0) && (v160_v269_cell1_mode != (2.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v160_v269_cell1_mode == (2.0) && (v160_v269_cell2_mode != (2.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v160_v269_cell1_mode == (2.0) && (v160_v269_cell2_mode == (2.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_idle ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_annhilate ):
    if (True == False) {;}
    else if  (v160_v269_cell1_mode != (2.0) && (v160_v269_cell2_mode != (2.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_from_cell_u = 0 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_previous_drection1 ):
    if (True == False) {;}
    else if  (v160_v269_from_cell == (1.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (0.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (2.0) && (v160_v269_cell2_mode_delayed == (0.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (2.0) && (v160_v269_cell2_mode_delayed != (0.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_previous_drection1 ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_previous_direction2 ):
    if (True == False) {;}
    else if  (v160_v269_from_cell == (1.0) && (v160_v269_cell1_mode_delayed != (0.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (2.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (0.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v269_from_cell == (1.0) && (v160_v269_cell1_mode_delayed == (0.0))) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_previous_direction2 ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_wait_cell1 ):
    if (True == False) {;}
    else if  (v160_v269_cell2_mode == (2.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v269_k >= (44.915456525799996)) {
      v160_v269_from_cell_u = 1 ;
      v160_v269_cell1_replay_latch_u = 1 ;
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_wait_cell1 ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_replay_cell1 ):
    if (True == False) {;}
    else if  (v160_v269_cell1_mode == (2.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v269_k >= (44.915456525799996)) {
      v160_v269_from_cell_u = 2 ;
      v160_v269_cell2_replay_latch_u = 1 ;
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_replay_cell1 ;
      force_init_update = False;
      v160_v269_cell1_replay_latch_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_replay_cell2 ):
    if (True == False) {;}
    else if  (v160_v269_k >= (10.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_replay_cell2 ;
      force_init_update = False;
      v160_v269_cell2_replay_latch_u = 1 ;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  case ( v160_v269_wait_cell2 ):
    if (True == False) {;}
    else if  (v160_v269_k >= (10.0)) {
      v160_v269_k_u = 1 ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
      cstate =  v160_v269_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v269_k_init = v160_v269_k ;
      slope =  1 ;
      v160_v269_k_u = (slope * d) + v160_v269_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v269_wait_cell2 ;
      force_init_update = False;
      v160_v269_cell1_v_delayed_u = v160_v269_update_c1vd () ;
      v160_v269_cell2_v_delayed_u = v160_v269_update_c2vd () ;
      v160_v269_cell1_mode_delayed_u = v160_v269_update_c1md () ;
      v160_v269_cell2_mode_delayed_u = v160_v269_update_c2md () ;
      v160_v269_wasted_u = v160_v269_update_buffer_index (v160_v269_cell1_v,v160_v269_cell2_v,v160_v269_cell1_mode,v160_v269_cell2_mode) ;
      v160_v269_cell1_replay_latch_u = v160_v269_update_latch1 (v160_v269_cell1_mode_delayed,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_replay_latch_u = v160_v269_update_latch2 (v160_v269_cell2_mode_delayed,v160_v269_cell2_replay_latch_u) ;
      v160_v269_cell1_v_replay = v160_v269_update_ocell1 (v160_v269_cell1_v_delayed_u,v160_v269_cell1_replay_latch_u) ;
      v160_v269_cell2_v_replay = v160_v269_update_ocell2 (v160_v269_cell2_v_delayed_u,v160_v269_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v269!\n");
      exit(1);
    }
    break;
  }
  v160_v269_k = v160_v269_k_u;
  v160_v269_cell1_mode_delayed = v160_v269_cell1_mode_delayed_u;
  v160_v269_cell2_mode_delayed = v160_v269_cell2_mode_delayed_u;
  v160_v269_from_cell = v160_v269_from_cell_u;
  v160_v269_cell1_replay_latch = v160_v269_cell1_replay_latch_u;
  v160_v269_cell2_replay_latch = v160_v269_cell2_replay_latch_u;
  v160_v269_cell1_v_delayed = v160_v269_cell1_v_delayed_u;
  v160_v269_cell2_v_delayed = v160_v269_cell2_v_delayed_u;
  v160_v269_wasted = v160_v269_wasted_u;
  return cstate;
}