#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v154_v_i_0;
double v154_v_i_1;
double v154_v_i_2;
double v154_v_i_3;
double v154_voo = 0.0;
double v154_state = 0.0;


static double  v154_vx  =  0 ,  v154_vy  =  0 ,  v154_vz  =  0 ,  v154_g  =  0 ,  v154_v  =  0 ,  v154_ft  =  0 ,  v154_theta  =  0 ,  v154_v_O  =  0 ; //the continuous vars
static double  v154_vx_u , v154_vy_u , v154_vz_u , v154_g_u , v154_v_u , v154_ft_u , v154_theta_u , v154_v_O_u ; // and their updates
static double  v154_vx_init , v154_vy_init , v154_vz_init , v154_g_init , v154_v_init , v154_ft_init , v154_theta_init , v154_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v154_t1 , v154_t2 , v154_t3 , v154_t4 }; // state declarations

enum states v154 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v154_t1 ):
    if (True == False) {;}
    else if  (v154_g > (44.5)) {
      v154_vx_u = (0.3 * v154_v) ;
      v154_vy_u = 0 ;
      v154_vz_u = (0.7 * v154_v) ;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v154_theta_u = (v154_v / 30.0) ;
      v154_v_O_u = (131.1 + (- (80.1 * pow ( ((v154_v / 30.0)) , (0.5) )))) ;
      v154_ft_u = f (v154_theta,4.0e-2) ;
      cstate =  v154_t2 ;
      force_init_update = False;
    }

    else if ( v154_v <= (44.5)
               && v154_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v154_vx_init = v154_vx ;
      slope =  (v154_vx * -8.7) ;
      v154_vx_u = (slope * d) + v154_vx ;
      if ((pstate != cstate) || force_init_update) v154_vy_init = v154_vy ;
      slope =  (v154_vy * -190.9) ;
      v154_vy_u = (slope * d) + v154_vy ;
      if ((pstate != cstate) || force_init_update) v154_vz_init = v154_vz ;
      slope =  (v154_vz * -190.4) ;
      v154_vz_u = (slope * d) + v154_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v154_t1 ;
      force_init_update = False;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v154_v_u = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_voo = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154!\n");
      exit(1);
    }
    break;
  case ( v154_t2 ):
    if (True == False) {;}
    else if  (v154_v >= (44.5)) {
      v154_vx_u = v154_vx ;
      v154_vy_u = v154_vy ;
      v154_vz_u = v154_vz ;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v154_t3 ;
      force_init_update = False;
    }
    else if  (v154_g <= (44.5)
               && v154_v < (44.5)) {
      v154_vx_u = v154_vx ;
      v154_vy_u = v154_vy ;
      v154_vz_u = v154_vz ;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v154_t1 ;
      force_init_update = False;
    }

    else if ( v154_v < (44.5)
               && v154_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v154_vx_init = v154_vx ;
      slope =  ((v154_vx * -23.6) + (777200.0 * v154_g)) ;
      v154_vx_u = (slope * d) + v154_vx ;
      if ((pstate != cstate) || force_init_update) v154_vy_init = v154_vy ;
      slope =  ((v154_vy * -45.5) + (58900.0 * v154_g)) ;
      v154_vy_u = (slope * d) + v154_vy ;
      if ((pstate != cstate) || force_init_update) v154_vz_init = v154_vz ;
      slope =  ((v154_vz * -12.9) + (276600.0 * v154_g)) ;
      v154_vz_u = (slope * d) + v154_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v154_t2 ;
      force_init_update = False;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v154_v_u = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_voo = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154!\n");
      exit(1);
    }
    break;
  case ( v154_t3 ):
    if (True == False) {;}
    else if  (v154_v >= (131.1)) {
      v154_vx_u = v154_vx ;
      v154_vy_u = v154_vy ;
      v154_vz_u = v154_vz ;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v154_t4 ;
      force_init_update = False;
    }

    else if ( v154_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v154_vx_init = v154_vx ;
      slope =  (v154_vx * -6.9) ;
      v154_vx_u = (slope * d) + v154_vx ;
      if ((pstate != cstate) || force_init_update) v154_vy_init = v154_vy ;
      slope =  (v154_vy * 75.9) ;
      v154_vy_u = (slope * d) + v154_vy ;
      if ((pstate != cstate) || force_init_update) v154_vz_init = v154_vz ;
      slope =  (v154_vz * 6826.5) ;
      v154_vz_u = (slope * d) + v154_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v154_t3 ;
      force_init_update = False;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v154_v_u = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_voo = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154!\n");
      exit(1);
    }
    break;
  case ( v154_t4 ):
    if (True == False) {;}
    else if  (v154_v <= (30.0)) {
      v154_vx_u = v154_vx ;
      v154_vy_u = v154_vy ;
      v154_vz_u = v154_vz ;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v154_t1 ;
      force_init_update = False;
    }

    else if ( v154_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v154_vx_init = v154_vx ;
      slope =  (v154_vx * -33.2) ;
      v154_vx_u = (slope * d) + v154_vx ;
      if ((pstate != cstate) || force_init_update) v154_vy_init = v154_vy ;
      slope =  ((v154_vy * 20.0) * v154_ft) ;
      v154_vy_u = (slope * d) + v154_vy ;
      if ((pstate != cstate) || force_init_update) v154_vz_init = v154_vz ;
      slope =  ((v154_vz * 2.0) * v154_ft) ;
      v154_vz_u = (slope * d) + v154_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v154_t4 ;
      force_init_update = False;
      v154_g_u = ((((((((((((v154_v_i_0 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v154_v_i_1 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v154_v_i_2 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v154_v_i_3 + (- ((v154_vx + (- v154_vy)) + v154_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v154_v_u = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_voo = ((v154_vx + (- v154_vy)) + v154_vz) ;
      v154_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154!\n");
      exit(1);
    }
    break;
  }
  v154_vx = v154_vx_u;
  v154_vy = v154_vy_u;
  v154_vz = v154_vz_u;
  v154_g = v154_g_u;
  v154_v = v154_v_u;
  v154_ft = v154_ft_u;
  v154_theta = v154_theta_u;
  v154_v_O = v154_v_O_u;
  return cstate;
}