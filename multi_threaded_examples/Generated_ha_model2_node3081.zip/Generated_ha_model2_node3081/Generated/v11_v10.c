#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v11_v10_update_c1vd();
extern double v11_v10_update_c2vd();
extern double v11_v10_update_c1md();
extern double v11_v10_update_c2md();
extern double v11_v10_update_buffer_index(double,double,double,double);
extern double v11_v10_update_latch1(double,double);
extern double v11_v10_update_latch2(double,double);
extern double v11_v10_update_ocell1(double,double);
extern double v11_v10_update_ocell2(double,double);
double v11_v10_cell1_v;
double v11_v10_cell1_mode;
double v11_v10_cell2_v;
double v11_v10_cell2_mode;
double v11_v10_cell1_v_replay = 0.0;
double v11_v10_cell2_v_replay = 0.0;


static double  v11_v10_k  =  0.0 ,  v11_v10_cell1_mode_delayed  =  0.0 ,  v11_v10_cell2_mode_delayed  =  0.0 ,  v11_v10_from_cell  =  0.0 ,  v11_v10_cell1_replay_latch  =  0.0 ,  v11_v10_cell2_replay_latch  =  0.0 ,  v11_v10_cell1_v_delayed  =  0.0 ,  v11_v10_cell2_v_delayed  =  0.0 ,  v11_v10_wasted  =  0.0 ; //the continuous vars
static double  v11_v10_k_u , v11_v10_cell1_mode_delayed_u , v11_v10_cell2_mode_delayed_u , v11_v10_from_cell_u , v11_v10_cell1_replay_latch_u , v11_v10_cell2_replay_latch_u , v11_v10_cell1_v_delayed_u , v11_v10_cell2_v_delayed_u , v11_v10_wasted_u ; // and their updates
static double  v11_v10_k_init , v11_v10_cell1_mode_delayed_init , v11_v10_cell2_mode_delayed_init , v11_v10_from_cell_init , v11_v10_cell1_replay_latch_init , v11_v10_cell2_replay_latch_init , v11_v10_cell1_v_delayed_init , v11_v10_cell2_v_delayed_init , v11_v10_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v11_v10_idle , v11_v10_annhilate , v11_v10_previous_drection1 , v11_v10_previous_direction2 , v11_v10_wait_cell1 , v11_v10_replay_cell1 , v11_v10_replay_cell2 , v11_v10_wait_cell2 }; // state declarations

enum states v11_v10 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v11_v10_idle ):
    if (True == False) {;}
    else if  (v11_v10_cell2_mode == (2.0) && (v11_v10_cell1_mode != (2.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v11_v10_cell1_mode == (2.0) && (v11_v10_cell2_mode != (2.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v11_v10_cell1_mode == (2.0) && (v11_v10_cell2_mode == (2.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_idle ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_annhilate ):
    if (True == False) {;}
    else if  (v11_v10_cell1_mode != (2.0) && (v11_v10_cell2_mode != (2.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_from_cell_u = 0 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_previous_drection1 ):
    if (True == False) {;}
    else if  (v11_v10_from_cell == (1.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (0.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (2.0) && (v11_v10_cell2_mode_delayed == (0.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (2.0) && (v11_v10_cell2_mode_delayed != (0.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_previous_drection1 ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_previous_direction2 ):
    if (True == False) {;}
    else if  (v11_v10_from_cell == (1.0) && (v11_v10_cell1_mode_delayed != (0.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (2.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (0.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v11_v10_from_cell == (1.0) && (v11_v10_cell1_mode_delayed == (0.0))) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_previous_direction2 ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_wait_cell1 ):
    if (True == False) {;}
    else if  (v11_v10_cell2_mode == (2.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
    }
    else if  (v11_v10_k >= (44.981747135599996)) {
      v11_v10_from_cell_u = 1 ;
      v11_v10_cell1_replay_latch_u = 1 ;
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_wait_cell1 ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_replay_cell1 ):
    if (True == False) {;}
    else if  (v11_v10_cell1_mode == (2.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_annhilate ;
      force_init_update = False;
    }
    else if  (v11_v10_k >= (44.981747135599996)) {
      v11_v10_from_cell_u = 2 ;
      v11_v10_cell2_replay_latch_u = 1 ;
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_replay_cell1 ;
      force_init_update = False;
      v11_v10_cell1_replay_latch_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_replay_cell2 ):
    if (True == False) {;}
    else if  (v11_v10_k >= (10.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_replay_cell2 ;
      force_init_update = False;
      v11_v10_cell2_replay_latch_u = 1 ;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  case ( v11_v10_wait_cell2 ):
    if (True == False) {;}
    else if  (v11_v10_k >= (10.0)) {
      v11_v10_k_u = 1 ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
      cstate =  v11_v10_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v11_v10_k_init = v11_v10_k ;
      slope =  1 ;
      v11_v10_k_u = (slope * d) + v11_v10_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v11_v10_wait_cell2 ;
      force_init_update = False;
      v11_v10_cell1_v_delayed_u = v11_v10_update_c1vd () ;
      v11_v10_cell2_v_delayed_u = v11_v10_update_c2vd () ;
      v11_v10_cell1_mode_delayed_u = v11_v10_update_c1md () ;
      v11_v10_cell2_mode_delayed_u = v11_v10_update_c2md () ;
      v11_v10_wasted_u = v11_v10_update_buffer_index (v11_v10_cell1_v,v11_v10_cell2_v,v11_v10_cell1_mode,v11_v10_cell2_mode) ;
      v11_v10_cell1_replay_latch_u = v11_v10_update_latch1 (v11_v10_cell1_mode_delayed,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_replay_latch_u = v11_v10_update_latch2 (v11_v10_cell2_mode_delayed,v11_v10_cell2_replay_latch_u) ;
      v11_v10_cell1_v_replay = v11_v10_update_ocell1 (v11_v10_cell1_v_delayed_u,v11_v10_cell1_replay_latch_u) ;
      v11_v10_cell2_v_replay = v11_v10_update_ocell2 (v11_v10_cell2_v_delayed_u,v11_v10_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11_v10!\n");
      exit(1);
    }
    break;
  }
  v11_v10_k = v11_v10_k_u;
  v11_v10_cell1_mode_delayed = v11_v10_cell1_mode_delayed_u;
  v11_v10_cell2_mode_delayed = v11_v10_cell2_mode_delayed_u;
  v11_v10_from_cell = v11_v10_from_cell_u;
  v11_v10_cell1_replay_latch = v11_v10_cell1_replay_latch_u;
  v11_v10_cell2_replay_latch = v11_v10_cell2_replay_latch_u;
  v11_v10_cell1_v_delayed = v11_v10_cell1_v_delayed_u;
  v11_v10_cell2_v_delayed = v11_v10_cell2_v_delayed_u;
  v11_v10_wasted = v11_v10_wasted_u;
  return cstate;
}