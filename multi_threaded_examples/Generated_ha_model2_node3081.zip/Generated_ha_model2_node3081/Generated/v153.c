#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v153_v_i_0;
double v153_v_i_1;
double v153_v_i_2;
double v153_v_i_3;
double v153_voo = 0.0;
double v153_state = 0.0;


static double  v153_vx  =  0 ,  v153_vy  =  0 ,  v153_vz  =  0 ,  v153_g  =  0 ,  v153_v  =  0 ,  v153_ft  =  0 ,  v153_theta  =  0 ,  v153_v_O  =  0 ; //the continuous vars
static double  v153_vx_u , v153_vy_u , v153_vz_u , v153_g_u , v153_v_u , v153_ft_u , v153_theta_u , v153_v_O_u ; // and their updates
static double  v153_vx_init , v153_vy_init , v153_vz_init , v153_g_init , v153_v_init , v153_ft_init , v153_theta_init , v153_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v153_t1 , v153_t2 , v153_t3 , v153_t4 }; // state declarations

enum states v153 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v153_t1 ):
    if (True == False) {;}
    else if  (v153_g > (44.5)) {
      v153_vx_u = (0.3 * v153_v) ;
      v153_vy_u = 0 ;
      v153_vz_u = (0.7 * v153_v) ;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      v153_theta_u = (v153_v / 30.0) ;
      v153_v_O_u = (131.1 + (- (80.1 * pow ( ((v153_v / 30.0)) , (0.5) )))) ;
      v153_ft_u = f (v153_theta,4.0e-2) ;
      cstate =  v153_t2 ;
      force_init_update = False;
    }

    else if ( v153_v <= (44.5)
               && v153_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v153_vx_init = v153_vx ;
      slope =  (v153_vx * -8.7) ;
      v153_vx_u = (slope * d) + v153_vx ;
      if ((pstate != cstate) || force_init_update) v153_vy_init = v153_vy ;
      slope =  (v153_vy * -190.9) ;
      v153_vy_u = (slope * d) + v153_vy ;
      if ((pstate != cstate) || force_init_update) v153_vz_init = v153_vz ;
      slope =  (v153_vz * -190.4) ;
      v153_vz_u = (slope * d) + v153_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v153_t1 ;
      force_init_update = False;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      v153_v_u = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_voo = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v153!\n");
      exit(1);
    }
    break;
  case ( v153_t2 ):
    if (True == False) {;}
    else if  (v153_v >= (44.5)) {
      v153_vx_u = v153_vx ;
      v153_vy_u = v153_vy ;
      v153_vz_u = v153_vz ;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v153_t3 ;
      force_init_update = False;
    }
    else if  (v153_g <= (44.5)
               && v153_v < (44.5)) {
      v153_vx_u = v153_vx ;
      v153_vy_u = v153_vy ;
      v153_vz_u = v153_vz ;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v153_t1 ;
      force_init_update = False;
    }

    else if ( v153_v < (44.5)
               && v153_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v153_vx_init = v153_vx ;
      slope =  ((v153_vx * -23.6) + (777200.0 * v153_g)) ;
      v153_vx_u = (slope * d) + v153_vx ;
      if ((pstate != cstate) || force_init_update) v153_vy_init = v153_vy ;
      slope =  ((v153_vy * -45.5) + (58900.0 * v153_g)) ;
      v153_vy_u = (slope * d) + v153_vy ;
      if ((pstate != cstate) || force_init_update) v153_vz_init = v153_vz ;
      slope =  ((v153_vz * -12.9) + (276600.0 * v153_g)) ;
      v153_vz_u = (slope * d) + v153_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v153_t2 ;
      force_init_update = False;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      v153_v_u = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_voo = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v153!\n");
      exit(1);
    }
    break;
  case ( v153_t3 ):
    if (True == False) {;}
    else if  (v153_v >= (131.1)) {
      v153_vx_u = v153_vx ;
      v153_vy_u = v153_vy ;
      v153_vz_u = v153_vz ;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v153_t4 ;
      force_init_update = False;
    }

    else if ( v153_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v153_vx_init = v153_vx ;
      slope =  (v153_vx * -6.9) ;
      v153_vx_u = (slope * d) + v153_vx ;
      if ((pstate != cstate) || force_init_update) v153_vy_init = v153_vy ;
      slope =  (v153_vy * 75.9) ;
      v153_vy_u = (slope * d) + v153_vy ;
      if ((pstate != cstate) || force_init_update) v153_vz_init = v153_vz ;
      slope =  (v153_vz * 6826.5) ;
      v153_vz_u = (slope * d) + v153_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v153_t3 ;
      force_init_update = False;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      v153_v_u = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_voo = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v153!\n");
      exit(1);
    }
    break;
  case ( v153_t4 ):
    if (True == False) {;}
    else if  (v153_v <= (30.0)) {
      v153_vx_u = v153_vx ;
      v153_vy_u = v153_vy ;
      v153_vz_u = v153_vz ;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v153_t1 ;
      force_init_update = False;
    }

    else if ( v153_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v153_vx_init = v153_vx ;
      slope =  (v153_vx * -33.2) ;
      v153_vx_u = (slope * d) + v153_vx ;
      if ((pstate != cstate) || force_init_update) v153_vy_init = v153_vy ;
      slope =  ((v153_vy * 20.0) * v153_ft) ;
      v153_vy_u = (slope * d) + v153_vy ;
      if ((pstate != cstate) || force_init_update) v153_vz_init = v153_vz ;
      slope =  ((v153_vz * 2.0) * v153_ft) ;
      v153_vz_u = (slope * d) + v153_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v153_t4 ;
      force_init_update = False;
      v153_g_u = ((((((((((((v153_v_i_0 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v153_v_i_1 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v153_v_i_2 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v153_v_i_3 + (- ((v153_vx + (- v153_vy)) + v153_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) + 0) ;
      v153_v_u = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_voo = ((v153_vx + (- v153_vy)) + v153_vz) ;
      v153_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v153!\n");
      exit(1);
    }
    break;
  }
  v153_vx = v153_vx_u;
  v153_vy = v153_vy_u;
  v153_vz = v153_vz_u;
  v153_g = v153_g_u;
  v153_v = v153_v_u;
  v153_ft = v153_ft_u;
  v153_theta = v153_theta_u;
  v153_v_O = v153_v_O_u;
  return cstate;
}