#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v156_v_i_0;
double v156_v_i_1;
double v156_v_i_2;
double v156_v_i_3;
double v156_voo = 0.0;
double v156_state = 0.0;


static double  v156_vx  =  0 ,  v156_vy  =  0 ,  v156_vz  =  0 ,  v156_g  =  0 ,  v156_v  =  0 ,  v156_ft  =  0 ,  v156_theta  =  0 ,  v156_v_O  =  0 ; //the continuous vars
static double  v156_vx_u , v156_vy_u , v156_vz_u , v156_g_u , v156_v_u , v156_ft_u , v156_theta_u , v156_v_O_u ; // and their updates
static double  v156_vx_init , v156_vy_init , v156_vz_init , v156_g_init , v156_v_init , v156_ft_init , v156_theta_init , v156_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v156_t1 , v156_t2 , v156_t3 , v156_t4 }; // state declarations

enum states v156 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v156_t1 ):
    if (True == False) {;}
    else if  (v156_g > (44.5)) {
      v156_vx_u = (0.3 * v156_v) ;
      v156_vy_u = 0 ;
      v156_vz_u = (0.7 * v156_v) ;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v156_theta_u = (v156_v / 30.0) ;
      v156_v_O_u = (131.1 + (- (80.1 * pow ( ((v156_v / 30.0)) , (0.5) )))) ;
      v156_ft_u = f (v156_theta,4.0e-2) ;
      cstate =  v156_t2 ;
      force_init_update = False;
    }

    else if ( v156_v <= (44.5)
               && v156_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v156_vx_init = v156_vx ;
      slope =  (v156_vx * -8.7) ;
      v156_vx_u = (slope * d) + v156_vx ;
      if ((pstate != cstate) || force_init_update) v156_vy_init = v156_vy ;
      slope =  (v156_vy * -190.9) ;
      v156_vy_u = (slope * d) + v156_vy ;
      if ((pstate != cstate) || force_init_update) v156_vz_init = v156_vz ;
      slope =  (v156_vz * -190.4) ;
      v156_vz_u = (slope * d) + v156_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v156_t1 ;
      force_init_update = False;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v156_v_u = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_voo = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156!\n");
      exit(1);
    }
    break;
  case ( v156_t2 ):
    if (True == False) {;}
    else if  (v156_v >= (44.5)) {
      v156_vx_u = v156_vx ;
      v156_vy_u = v156_vy ;
      v156_vz_u = v156_vz ;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v156_t3 ;
      force_init_update = False;
    }
    else if  (v156_g <= (44.5)
               && v156_v < (44.5)) {
      v156_vx_u = v156_vx ;
      v156_vy_u = v156_vy ;
      v156_vz_u = v156_vz ;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v156_t1 ;
      force_init_update = False;
    }

    else if ( v156_v < (44.5)
               && v156_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v156_vx_init = v156_vx ;
      slope =  ((v156_vx * -23.6) + (777200.0 * v156_g)) ;
      v156_vx_u = (slope * d) + v156_vx ;
      if ((pstate != cstate) || force_init_update) v156_vy_init = v156_vy ;
      slope =  ((v156_vy * -45.5) + (58900.0 * v156_g)) ;
      v156_vy_u = (slope * d) + v156_vy ;
      if ((pstate != cstate) || force_init_update) v156_vz_init = v156_vz ;
      slope =  ((v156_vz * -12.9) + (276600.0 * v156_g)) ;
      v156_vz_u = (slope * d) + v156_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v156_t2 ;
      force_init_update = False;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v156_v_u = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_voo = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156!\n");
      exit(1);
    }
    break;
  case ( v156_t3 ):
    if (True == False) {;}
    else if  (v156_v >= (131.1)) {
      v156_vx_u = v156_vx ;
      v156_vy_u = v156_vy ;
      v156_vz_u = v156_vz ;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v156_t4 ;
      force_init_update = False;
    }

    else if ( v156_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v156_vx_init = v156_vx ;
      slope =  (v156_vx * -6.9) ;
      v156_vx_u = (slope * d) + v156_vx ;
      if ((pstate != cstate) || force_init_update) v156_vy_init = v156_vy ;
      slope =  (v156_vy * 75.9) ;
      v156_vy_u = (slope * d) + v156_vy ;
      if ((pstate != cstate) || force_init_update) v156_vz_init = v156_vz ;
      slope =  (v156_vz * 6826.5) ;
      v156_vz_u = (slope * d) + v156_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v156_t3 ;
      force_init_update = False;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v156_v_u = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_voo = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156!\n");
      exit(1);
    }
    break;
  case ( v156_t4 ):
    if (True == False) {;}
    else if  (v156_v <= (30.0)) {
      v156_vx_u = v156_vx ;
      v156_vy_u = v156_vy ;
      v156_vz_u = v156_vz ;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v156_t1 ;
      force_init_update = False;
    }

    else if ( v156_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v156_vx_init = v156_vx ;
      slope =  (v156_vx * -33.2) ;
      v156_vx_u = (slope * d) + v156_vx ;
      if ((pstate != cstate) || force_init_update) v156_vy_init = v156_vy ;
      slope =  ((v156_vy * 20.0) * v156_ft) ;
      v156_vy_u = (slope * d) + v156_vy ;
      if ((pstate != cstate) || force_init_update) v156_vz_init = v156_vz ;
      slope =  ((v156_vz * 2.0) * v156_ft) ;
      v156_vz_u = (slope * d) + v156_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v156_t4 ;
      force_init_update = False;
      v156_g_u = ((((((((((((v156_v_i_0 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v156_v_i_1 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v156_v_i_2 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v156_v_i_3 + (- ((v156_vx + (- v156_vy)) + v156_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v156_v_u = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_voo = ((v156_vx + (- v156_vy)) + v156_vz) ;
      v156_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156!\n");
      exit(1);
    }
    break;
  }
  v156_vx = v156_vx_u;
  v156_vy = v156_vy_u;
  v156_vz = v156_vz_u;
  v156_g = v156_g_u;
  v156_v = v156_v_u;
  v156_ft = v156_ft_u;
  v156_theta = v156_theta_u;
  v156_v_O = v156_v_O_u;
  return cstate;
}