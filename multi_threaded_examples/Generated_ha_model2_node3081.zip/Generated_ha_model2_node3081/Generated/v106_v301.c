#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v106_v301_update_c1vd();
extern double v106_v301_update_c2vd();
extern double v106_v301_update_c1md();
extern double v106_v301_update_c2md();
extern double v106_v301_update_buffer_index(double,double,double,double);
extern double v106_v301_update_latch1(double,double);
extern double v106_v301_update_latch2(double,double);
extern double v106_v301_update_ocell1(double,double);
extern double v106_v301_update_ocell2(double,double);
double v106_v301_cell1_v;
double v106_v301_cell1_mode;
double v106_v301_cell2_v;
double v106_v301_cell2_mode;
double v106_v301_cell1_v_replay = 0.0;
double v106_v301_cell2_v_replay = 0.0;


static double  v106_v301_k  =  0.0 ,  v106_v301_cell1_mode_delayed  =  0.0 ,  v106_v301_cell2_mode_delayed  =  0.0 ,  v106_v301_from_cell  =  0.0 ,  v106_v301_cell1_replay_latch  =  0.0 ,  v106_v301_cell2_replay_latch  =  0.0 ,  v106_v301_cell1_v_delayed  =  0.0 ,  v106_v301_cell2_v_delayed  =  0.0 ,  v106_v301_wasted  =  0.0 ; //the continuous vars
static double  v106_v301_k_u , v106_v301_cell1_mode_delayed_u , v106_v301_cell2_mode_delayed_u , v106_v301_from_cell_u , v106_v301_cell1_replay_latch_u , v106_v301_cell2_replay_latch_u , v106_v301_cell1_v_delayed_u , v106_v301_cell2_v_delayed_u , v106_v301_wasted_u ; // and their updates
static double  v106_v301_k_init , v106_v301_cell1_mode_delayed_init , v106_v301_cell2_mode_delayed_init , v106_v301_from_cell_init , v106_v301_cell1_replay_latch_init , v106_v301_cell2_replay_latch_init , v106_v301_cell1_v_delayed_init , v106_v301_cell2_v_delayed_init , v106_v301_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v106_v301_idle , v106_v301_annhilate , v106_v301_previous_drection1 , v106_v301_previous_direction2 , v106_v301_wait_cell1 , v106_v301_replay_cell1 , v106_v301_replay_cell2 , v106_v301_wait_cell2 }; // state declarations

enum states v106_v301 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v106_v301_idle ):
    if (True == False) {;}
    else if  (v106_v301_cell2_mode == (2.0) && (v106_v301_cell1_mode != (2.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v106_v301_cell1_mode == (2.0) && (v106_v301_cell2_mode != (2.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v106_v301_cell1_mode == (2.0) && (v106_v301_cell2_mode == (2.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_idle ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_annhilate ):
    if (True == False) {;}
    else if  (v106_v301_cell1_mode != (2.0) && (v106_v301_cell2_mode != (2.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_from_cell_u = 0 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_previous_drection1 ):
    if (True == False) {;}
    else if  (v106_v301_from_cell == (1.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (0.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (2.0) && (v106_v301_cell2_mode_delayed == (0.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (2.0) && (v106_v301_cell2_mode_delayed != (0.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_previous_drection1 ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_previous_direction2 ):
    if (True == False) {;}
    else if  (v106_v301_from_cell == (1.0) && (v106_v301_cell1_mode_delayed != (0.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (2.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (0.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v106_v301_from_cell == (1.0) && (v106_v301_cell1_mode_delayed == (0.0))) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_previous_direction2 ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_wait_cell1 ):
    if (True == False) {;}
    else if  (v106_v301_cell2_mode == (2.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
    }
    else if  (v106_v301_k >= (117.39201779199999)) {
      v106_v301_from_cell_u = 1 ;
      v106_v301_cell1_replay_latch_u = 1 ;
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_wait_cell1 ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_replay_cell1 ):
    if (True == False) {;}
    else if  (v106_v301_cell1_mode == (2.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_annhilate ;
      force_init_update = False;
    }
    else if  (v106_v301_k >= (117.39201779199999)) {
      v106_v301_from_cell_u = 2 ;
      v106_v301_cell2_replay_latch_u = 1 ;
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_replay_cell1 ;
      force_init_update = False;
      v106_v301_cell1_replay_latch_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_replay_cell2 ):
    if (True == False) {;}
    else if  (v106_v301_k >= (10.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_replay_cell2 ;
      force_init_update = False;
      v106_v301_cell2_replay_latch_u = 1 ;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  case ( v106_v301_wait_cell2 ):
    if (True == False) {;}
    else if  (v106_v301_k >= (10.0)) {
      v106_v301_k_u = 1 ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
      cstate =  v106_v301_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v106_v301_k_init = v106_v301_k ;
      slope =  1 ;
      v106_v301_k_u = (slope * d) + v106_v301_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v106_v301_wait_cell2 ;
      force_init_update = False;
      v106_v301_cell1_v_delayed_u = v106_v301_update_c1vd () ;
      v106_v301_cell2_v_delayed_u = v106_v301_update_c2vd () ;
      v106_v301_cell1_mode_delayed_u = v106_v301_update_c1md () ;
      v106_v301_cell2_mode_delayed_u = v106_v301_update_c2md () ;
      v106_v301_wasted_u = v106_v301_update_buffer_index (v106_v301_cell1_v,v106_v301_cell2_v,v106_v301_cell1_mode,v106_v301_cell2_mode) ;
      v106_v301_cell1_replay_latch_u = v106_v301_update_latch1 (v106_v301_cell1_mode_delayed,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_replay_latch_u = v106_v301_update_latch2 (v106_v301_cell2_mode_delayed,v106_v301_cell2_replay_latch_u) ;
      v106_v301_cell1_v_replay = v106_v301_update_ocell1 (v106_v301_cell1_v_delayed_u,v106_v301_cell1_replay_latch_u) ;
      v106_v301_cell2_v_replay = v106_v301_update_ocell2 (v106_v301_cell2_v_delayed_u,v106_v301_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106_v301!\n");
      exit(1);
    }
    break;
  }
  v106_v301_k = v106_v301_k_u;
  v106_v301_cell1_mode_delayed = v106_v301_cell1_mode_delayed_u;
  v106_v301_cell2_mode_delayed = v106_v301_cell2_mode_delayed_u;
  v106_v301_from_cell = v106_v301_from_cell_u;
  v106_v301_cell1_replay_latch = v106_v301_cell1_replay_latch_u;
  v106_v301_cell2_replay_latch = v106_v301_cell2_replay_latch_u;
  v106_v301_cell1_v_delayed = v106_v301_cell1_v_delayed_u;
  v106_v301_cell2_v_delayed = v106_v301_cell2_v_delayed_u;
  v106_v301_wasted = v106_v301_wasted_u;
  return cstate;
}