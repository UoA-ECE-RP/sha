#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v182_v_i_0;
double v182_v_i_1;
double v182_v_i_2;
double v182_voo = 0.0;
double v182_state = 0.0;


static double  v182_vx  =  0 ,  v182_vy  =  0 ,  v182_vz  =  0 ,  v182_g  =  0 ,  v182_v  =  0 ,  v182_ft  =  0 ,  v182_theta  =  0 ,  v182_v_O  =  0 ; //the continuous vars
static double  v182_vx_u , v182_vy_u , v182_vz_u , v182_g_u , v182_v_u , v182_ft_u , v182_theta_u , v182_v_O_u ; // and their updates
static double  v182_vx_init , v182_vy_init , v182_vz_init , v182_g_init , v182_v_init , v182_ft_init , v182_theta_init , v182_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v182_t1 , v182_t2 , v182_t3 , v182_t4 }; // state declarations

enum states v182 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v182_t1 ):
    if (True == False) {;}
    else if  (v182_g > (44.5)) {
      v182_vx_u = (0.3 * v182_v) ;
      v182_vy_u = 0 ;
      v182_vz_u = (0.7 * v182_v) ;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v182_theta_u = (v182_v / 30.0) ;
      v182_v_O_u = (131.1 + (- (80.1 * pow ( ((v182_v / 30.0)) , (0.5) )))) ;
      v182_ft_u = f (v182_theta,4.0e-2) ;
      cstate =  v182_t2 ;
      force_init_update = False;
    }

    else if ( v182_v <= (44.5)
               && v182_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v182_vx_init = v182_vx ;
      slope =  (v182_vx * -8.7) ;
      v182_vx_u = (slope * d) + v182_vx ;
      if ((pstate != cstate) || force_init_update) v182_vy_init = v182_vy ;
      slope =  (v182_vy * -190.9) ;
      v182_vy_u = (slope * d) + v182_vy ;
      if ((pstate != cstate) || force_init_update) v182_vz_init = v182_vz ;
      slope =  (v182_vz * -190.4) ;
      v182_vz_u = (slope * d) + v182_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v182_t1 ;
      force_init_update = False;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v182_v_u = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_voo = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v182!\n");
      exit(1);
    }
    break;
  case ( v182_t2 ):
    if (True == False) {;}
    else if  (v182_v >= (44.5)) {
      v182_vx_u = v182_vx ;
      v182_vy_u = v182_vy ;
      v182_vz_u = v182_vz ;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v182_t3 ;
      force_init_update = False;
    }
    else if  (v182_g <= (44.5)
               && v182_v < (44.5)) {
      v182_vx_u = v182_vx ;
      v182_vy_u = v182_vy ;
      v182_vz_u = v182_vz ;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v182_t1 ;
      force_init_update = False;
    }

    else if ( v182_v < (44.5)
               && v182_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v182_vx_init = v182_vx ;
      slope =  ((v182_vx * -23.6) + (777200.0 * v182_g)) ;
      v182_vx_u = (slope * d) + v182_vx ;
      if ((pstate != cstate) || force_init_update) v182_vy_init = v182_vy ;
      slope =  ((v182_vy * -45.5) + (58900.0 * v182_g)) ;
      v182_vy_u = (slope * d) + v182_vy ;
      if ((pstate != cstate) || force_init_update) v182_vz_init = v182_vz ;
      slope =  ((v182_vz * -12.9) + (276600.0 * v182_g)) ;
      v182_vz_u = (slope * d) + v182_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v182_t2 ;
      force_init_update = False;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v182_v_u = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_voo = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v182!\n");
      exit(1);
    }
    break;
  case ( v182_t3 ):
    if (True == False) {;}
    else if  (v182_v >= (131.1)) {
      v182_vx_u = v182_vx ;
      v182_vy_u = v182_vy ;
      v182_vz_u = v182_vz ;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v182_t4 ;
      force_init_update = False;
    }

    else if ( v182_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v182_vx_init = v182_vx ;
      slope =  (v182_vx * -6.9) ;
      v182_vx_u = (slope * d) + v182_vx ;
      if ((pstate != cstate) || force_init_update) v182_vy_init = v182_vy ;
      slope =  (v182_vy * 75.9) ;
      v182_vy_u = (slope * d) + v182_vy ;
      if ((pstate != cstate) || force_init_update) v182_vz_init = v182_vz ;
      slope =  (v182_vz * 6826.5) ;
      v182_vz_u = (slope * d) + v182_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v182_t3 ;
      force_init_update = False;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v182_v_u = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_voo = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v182!\n");
      exit(1);
    }
    break;
  case ( v182_t4 ):
    if (True == False) {;}
    else if  (v182_v <= (30.0)) {
      v182_vx_u = v182_vx ;
      v182_vy_u = v182_vy ;
      v182_vz_u = v182_vz ;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v182_t1 ;
      force_init_update = False;
    }

    else if ( v182_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v182_vx_init = v182_vx ;
      slope =  (v182_vx * -33.2) ;
      v182_vx_u = (slope * d) + v182_vx ;
      if ((pstate != cstate) || force_init_update) v182_vy_init = v182_vy ;
      slope =  ((v182_vy * 20.0) * v182_ft) ;
      v182_vy_u = (slope * d) + v182_vy ;
      if ((pstate != cstate) || force_init_update) v182_vz_init = v182_vz ;
      slope =  ((v182_vz * 2.0) * v182_ft) ;
      v182_vz_u = (slope * d) + v182_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v182_t4 ;
      force_init_update = False;
      v182_g_u = ((((((((((((v182_v_i_0 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218)) + ((((v182_v_i_1 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v182_v_i_2 + (- ((v182_vx + (- v182_vy)) + v182_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v182_v_u = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_voo = ((v182_vx + (- v182_vy)) + v182_vz) ;
      v182_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v182!\n");
      exit(1);
    }
    break;
  }
  v182_vx = v182_vx_u;
  v182_vy = v182_vy_u;
  v182_vz = v182_vz_u;
  v182_g = v182_g_u;
  v182_v = v182_v_u;
  v182_ft = v182_ft_u;
  v182_theta = v182_theta_u;
  v182_v_O = v182_v_O_u;
  return cstate;
}