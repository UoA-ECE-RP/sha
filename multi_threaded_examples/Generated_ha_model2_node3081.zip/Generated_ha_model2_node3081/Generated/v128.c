#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v128_v_i_0;
double v128_v_i_1;
double v128_v_i_2;
double v128_voo = 0.0;
double v128_state = 0.0;


static double  v128_vx  =  0 ,  v128_vy  =  0 ,  v128_vz  =  0 ,  v128_g  =  0 ,  v128_v  =  0 ,  v128_ft  =  0 ,  v128_theta  =  0 ,  v128_v_O  =  0 ; //the continuous vars
static double  v128_vx_u , v128_vy_u , v128_vz_u , v128_g_u , v128_v_u , v128_ft_u , v128_theta_u , v128_v_O_u ; // and their updates
static double  v128_vx_init , v128_vy_init , v128_vz_init , v128_g_init , v128_v_init , v128_ft_init , v128_theta_init , v128_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v128_t1 , v128_t2 , v128_t3 , v128_t4 }; // state declarations

enum states v128 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v128_t1 ):
    if (True == False) {;}
    else if  (v128_g > (44.5)) {
      v128_vx_u = (0.3 * v128_v) ;
      v128_vy_u = 0 ;
      v128_vz_u = (0.7 * v128_v) ;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v128_theta_u = (v128_v / 30.0) ;
      v128_v_O_u = (131.1 + (- (80.1 * pow ( ((v128_v / 30.0)) , (0.5) )))) ;
      v128_ft_u = f (v128_theta,4.0e-2) ;
      cstate =  v128_t2 ;
      force_init_update = False;
    }

    else if ( v128_v <= (44.5)
               && v128_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v128_vx_init = v128_vx ;
      slope =  (v128_vx * -8.7) ;
      v128_vx_u = (slope * d) + v128_vx ;
      if ((pstate != cstate) || force_init_update) v128_vy_init = v128_vy ;
      slope =  (v128_vy * -190.9) ;
      v128_vy_u = (slope * d) + v128_vy ;
      if ((pstate != cstate) || force_init_update) v128_vz_init = v128_vz ;
      slope =  (v128_vz * -190.4) ;
      v128_vz_u = (slope * d) + v128_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v128_t1 ;
      force_init_update = False;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v128_v_u = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_voo = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v128!\n");
      exit(1);
    }
    break;
  case ( v128_t2 ):
    if (True == False) {;}
    else if  (v128_v >= (44.5)) {
      v128_vx_u = v128_vx ;
      v128_vy_u = v128_vy ;
      v128_vz_u = v128_vz ;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v128_t3 ;
      force_init_update = False;
    }
    else if  (v128_g <= (44.5)
               && v128_v < (44.5)) {
      v128_vx_u = v128_vx ;
      v128_vy_u = v128_vy ;
      v128_vz_u = v128_vz ;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v128_t1 ;
      force_init_update = False;
    }

    else if ( v128_v < (44.5)
               && v128_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v128_vx_init = v128_vx ;
      slope =  ((v128_vx * -23.6) + (777200.0 * v128_g)) ;
      v128_vx_u = (slope * d) + v128_vx ;
      if ((pstate != cstate) || force_init_update) v128_vy_init = v128_vy ;
      slope =  ((v128_vy * -45.5) + (58900.0 * v128_g)) ;
      v128_vy_u = (slope * d) + v128_vy ;
      if ((pstate != cstate) || force_init_update) v128_vz_init = v128_vz ;
      slope =  ((v128_vz * -12.9) + (276600.0 * v128_g)) ;
      v128_vz_u = (slope * d) + v128_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v128_t2 ;
      force_init_update = False;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v128_v_u = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_voo = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v128!\n");
      exit(1);
    }
    break;
  case ( v128_t3 ):
    if (True == False) {;}
    else if  (v128_v >= (131.1)) {
      v128_vx_u = v128_vx ;
      v128_vy_u = v128_vy ;
      v128_vz_u = v128_vz ;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v128_t4 ;
      force_init_update = False;
    }

    else if ( v128_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v128_vx_init = v128_vx ;
      slope =  (v128_vx * -6.9) ;
      v128_vx_u = (slope * d) + v128_vx ;
      if ((pstate != cstate) || force_init_update) v128_vy_init = v128_vy ;
      slope =  (v128_vy * 75.9) ;
      v128_vy_u = (slope * d) + v128_vy ;
      if ((pstate != cstate) || force_init_update) v128_vz_init = v128_vz ;
      slope =  (v128_vz * 6826.5) ;
      v128_vz_u = (slope * d) + v128_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v128_t3 ;
      force_init_update = False;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v128_v_u = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_voo = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v128!\n");
      exit(1);
    }
    break;
  case ( v128_t4 ):
    if (True == False) {;}
    else if  (v128_v <= (30.0)) {
      v128_vx_u = v128_vx ;
      v128_vy_u = v128_vy ;
      v128_vz_u = v128_vz ;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v128_t1 ;
      force_init_update = False;
    }

    else if ( v128_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v128_vx_init = v128_vx ;
      slope =  (v128_vx * -33.2) ;
      v128_vx_u = (slope * d) + v128_vx ;
      if ((pstate != cstate) || force_init_update) v128_vy_init = v128_vy ;
      slope =  ((v128_vy * 20.0) * v128_ft) ;
      v128_vy_u = (slope * d) + v128_vy ;
      if ((pstate != cstate) || force_init_update) v128_vz_init = v128_vz ;
      slope =  ((v128_vz * 2.0) * v128_ft) ;
      v128_vz_u = (slope * d) + v128_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v128_t4 ;
      force_init_update = False;
      v128_g_u = ((((((((((((v128_v_i_0 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242)) + ((((v128_v_i_1 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v128_v_i_2 + (- ((v128_vx + (- v128_vy)) + v128_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.65562085732))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v128_v_u = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_voo = ((v128_vx + (- v128_vy)) + v128_vz) ;
      v128_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v128!\n");
      exit(1);
    }
    break;
  }
  v128_vx = v128_vx_u;
  v128_vy = v128_vy_u;
  v128_vz = v128_vz_u;
  v128_g = v128_g_u;
  v128_v = v128_v_u;
  v128_ft = v128_ft_u;
  v128_theta = v128_theta_u;
  v128_v_O = v128_v_O_u;
  return cstate;
}