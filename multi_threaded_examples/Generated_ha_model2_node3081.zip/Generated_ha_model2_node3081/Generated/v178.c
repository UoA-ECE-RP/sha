#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v178_v_i_0;
double v178_v_i_1;
double v178_v_i_2;
double v178_voo = 0.0;
double v178_state = 0.0;


static double  v178_vx  =  0 ,  v178_vy  =  0 ,  v178_vz  =  0 ,  v178_g  =  0 ,  v178_v  =  0 ,  v178_ft  =  0 ,  v178_theta  =  0 ,  v178_v_O  =  0 ; //the continuous vars
static double  v178_vx_u , v178_vy_u , v178_vz_u , v178_g_u , v178_v_u , v178_ft_u , v178_theta_u , v178_v_O_u ; // and their updates
static double  v178_vx_init , v178_vy_init , v178_vz_init , v178_g_init , v178_v_init , v178_ft_init , v178_theta_init , v178_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v178_t1 , v178_t2 , v178_t3 , v178_t4 }; // state declarations

enum states v178 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v178_t1 ):
    if (True == False) {;}
    else if  (v178_g > (44.5)) {
      v178_vx_u = (0.3 * v178_v) ;
      v178_vy_u = 0 ;
      v178_vz_u = (0.7 * v178_v) ;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v178_theta_u = (v178_v / 30.0) ;
      v178_v_O_u = (131.1 + (- (80.1 * pow ( ((v178_v / 30.0)) , (0.5) )))) ;
      v178_ft_u = f (v178_theta,4.0e-2) ;
      cstate =  v178_t2 ;
      force_init_update = False;
    }

    else if ( v178_v <= (44.5)
               && v178_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v178_vx_init = v178_vx ;
      slope =  (v178_vx * -8.7) ;
      v178_vx_u = (slope * d) + v178_vx ;
      if ((pstate != cstate) || force_init_update) v178_vy_init = v178_vy ;
      slope =  (v178_vy * -190.9) ;
      v178_vy_u = (slope * d) + v178_vy ;
      if ((pstate != cstate) || force_init_update) v178_vz_init = v178_vz ;
      slope =  (v178_vz * -190.4) ;
      v178_vz_u = (slope * d) + v178_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v178_t1 ;
      force_init_update = False;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v178_v_u = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_voo = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v178!\n");
      exit(1);
    }
    break;
  case ( v178_t2 ):
    if (True == False) {;}
    else if  (v178_v >= (44.5)) {
      v178_vx_u = v178_vx ;
      v178_vy_u = v178_vy ;
      v178_vz_u = v178_vz ;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v178_t3 ;
      force_init_update = False;
    }
    else if  (v178_g <= (44.5)
               && v178_v < (44.5)) {
      v178_vx_u = v178_vx ;
      v178_vy_u = v178_vy ;
      v178_vz_u = v178_vz ;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v178_t1 ;
      force_init_update = False;
    }

    else if ( v178_v < (44.5)
               && v178_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v178_vx_init = v178_vx ;
      slope =  ((v178_vx * -23.6) + (777200.0 * v178_g)) ;
      v178_vx_u = (slope * d) + v178_vx ;
      if ((pstate != cstate) || force_init_update) v178_vy_init = v178_vy ;
      slope =  ((v178_vy * -45.5) + (58900.0 * v178_g)) ;
      v178_vy_u = (slope * d) + v178_vy ;
      if ((pstate != cstate) || force_init_update) v178_vz_init = v178_vz ;
      slope =  ((v178_vz * -12.9) + (276600.0 * v178_g)) ;
      v178_vz_u = (slope * d) + v178_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v178_t2 ;
      force_init_update = False;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v178_v_u = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_voo = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v178!\n");
      exit(1);
    }
    break;
  case ( v178_t3 ):
    if (True == False) {;}
    else if  (v178_v >= (131.1)) {
      v178_vx_u = v178_vx ;
      v178_vy_u = v178_vy ;
      v178_vz_u = v178_vz ;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v178_t4 ;
      force_init_update = False;
    }

    else if ( v178_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v178_vx_init = v178_vx ;
      slope =  (v178_vx * -6.9) ;
      v178_vx_u = (slope * d) + v178_vx ;
      if ((pstate != cstate) || force_init_update) v178_vy_init = v178_vy ;
      slope =  (v178_vy * 75.9) ;
      v178_vy_u = (slope * d) + v178_vy ;
      if ((pstate != cstate) || force_init_update) v178_vz_init = v178_vz ;
      slope =  (v178_vz * 6826.5) ;
      v178_vz_u = (slope * d) + v178_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v178_t3 ;
      force_init_update = False;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v178_v_u = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_voo = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v178!\n");
      exit(1);
    }
    break;
  case ( v178_t4 ):
    if (True == False) {;}
    else if  (v178_v <= (30.0)) {
      v178_vx_u = v178_vx ;
      v178_vy_u = v178_vy ;
      v178_vz_u = v178_vz ;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v178_t1 ;
      force_init_update = False;
    }

    else if ( v178_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v178_vx_init = v178_vx ;
      slope =  (v178_vx * -33.2) ;
      v178_vx_u = (slope * d) + v178_vx ;
      if ((pstate != cstate) || force_init_update) v178_vy_init = v178_vy ;
      slope =  ((v178_vy * 20.0) * v178_ft) ;
      v178_vy_u = (slope * d) + v178_vy ;
      if ((pstate != cstate) || force_init_update) v178_vz_init = v178_vz ;
      slope =  ((v178_vz * 2.0) * v178_ft) ;
      v178_vz_u = (slope * d) + v178_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v178_t4 ;
      force_init_update = False;
      v178_g_u = ((((((((((((v178_v_i_0 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v178_v_i_1 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v178_v_i_2 + (- ((v178_vx + (- v178_vy)) + v178_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.317158976))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v178_v_u = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_voo = ((v178_vx + (- v178_vy)) + v178_vz) ;
      v178_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v178!\n");
      exit(1);
    }
    break;
  }
  v178_vx = v178_vx_u;
  v178_vy = v178_vy_u;
  v178_vz = v178_vz_u;
  v178_g = v178_g_u;
  v178_v = v178_v_u;
  v178_ft = v178_ft_u;
  v178_theta = v178_theta_u;
  v178_v_O = v178_v_O_u;
  return cstate;
}