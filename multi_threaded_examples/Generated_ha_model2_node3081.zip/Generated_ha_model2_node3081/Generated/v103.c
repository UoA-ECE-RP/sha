#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v103_v_i_0;
double v103_v_i_1;
double v103_v_i_2;
double v103_voo = 0.0;
double v103_state = 0.0;


static double  v103_vx  =  0 ,  v103_vy  =  0 ,  v103_vz  =  0 ,  v103_g  =  0 ,  v103_v  =  0 ,  v103_ft  =  0 ,  v103_theta  =  0 ,  v103_v_O  =  0 ; //the continuous vars
static double  v103_vx_u , v103_vy_u , v103_vz_u , v103_g_u , v103_v_u , v103_ft_u , v103_theta_u , v103_v_O_u ; // and their updates
static double  v103_vx_init , v103_vy_init , v103_vz_init , v103_g_init , v103_v_init , v103_ft_init , v103_theta_init , v103_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v103_t1 , v103_t2 , v103_t3 , v103_t4 }; // state declarations

enum states v103 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v103_t1 ):
    if (True == False) {;}
    else if  (v103_g > (44.5)) {
      v103_vx_u = (0.3 * v103_v) ;
      v103_vy_u = 0 ;
      v103_vz_u = (0.7 * v103_v) ;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v103_theta_u = (v103_v / 30.0) ;
      v103_v_O_u = (131.1 + (- (80.1 * pow ( ((v103_v / 30.0)) , (0.5) )))) ;
      v103_ft_u = f (v103_theta,4.0e-2) ;
      cstate =  v103_t2 ;
      force_init_update = False;
    }

    else if ( v103_v <= (44.5)
               && v103_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v103_vx_init = v103_vx ;
      slope =  (v103_vx * -8.7) ;
      v103_vx_u = (slope * d) + v103_vx ;
      if ((pstate != cstate) || force_init_update) v103_vy_init = v103_vy ;
      slope =  (v103_vy * -190.9) ;
      v103_vy_u = (slope * d) + v103_vy ;
      if ((pstate != cstate) || force_init_update) v103_vz_init = v103_vz ;
      slope =  (v103_vz * -190.4) ;
      v103_vz_u = (slope * d) + v103_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v103_t1 ;
      force_init_update = False;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v103_v_u = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_voo = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v103!\n");
      exit(1);
    }
    break;
  case ( v103_t2 ):
    if (True == False) {;}
    else if  (v103_v >= (44.5)) {
      v103_vx_u = v103_vx ;
      v103_vy_u = v103_vy ;
      v103_vz_u = v103_vz ;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v103_t3 ;
      force_init_update = False;
    }
    else if  (v103_g <= (44.5)
               && v103_v < (44.5)) {
      v103_vx_u = v103_vx ;
      v103_vy_u = v103_vy ;
      v103_vz_u = v103_vz ;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v103_t1 ;
      force_init_update = False;
    }

    else if ( v103_v < (44.5)
               && v103_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v103_vx_init = v103_vx ;
      slope =  ((v103_vx * -23.6) + (777200.0 * v103_g)) ;
      v103_vx_u = (slope * d) + v103_vx ;
      if ((pstate != cstate) || force_init_update) v103_vy_init = v103_vy ;
      slope =  ((v103_vy * -45.5) + (58900.0 * v103_g)) ;
      v103_vy_u = (slope * d) + v103_vy ;
      if ((pstate != cstate) || force_init_update) v103_vz_init = v103_vz ;
      slope =  ((v103_vz * -12.9) + (276600.0 * v103_g)) ;
      v103_vz_u = (slope * d) + v103_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v103_t2 ;
      force_init_update = False;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v103_v_u = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_voo = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v103!\n");
      exit(1);
    }
    break;
  case ( v103_t3 ):
    if (True == False) {;}
    else if  (v103_v >= (131.1)) {
      v103_vx_u = v103_vx ;
      v103_vy_u = v103_vy ;
      v103_vz_u = v103_vz ;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v103_t4 ;
      force_init_update = False;
    }

    else if ( v103_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v103_vx_init = v103_vx ;
      slope =  (v103_vx * -6.9) ;
      v103_vx_u = (slope * d) + v103_vx ;
      if ((pstate != cstate) || force_init_update) v103_vy_init = v103_vy ;
      slope =  (v103_vy * 75.9) ;
      v103_vy_u = (slope * d) + v103_vy ;
      if ((pstate != cstate) || force_init_update) v103_vz_init = v103_vz ;
      slope =  (v103_vz * 6826.5) ;
      v103_vz_u = (slope * d) + v103_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v103_t3 ;
      force_init_update = False;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v103_v_u = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_voo = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v103!\n");
      exit(1);
    }
    break;
  case ( v103_t4 ):
    if (True == False) {;}
    else if  (v103_v <= (30.0)) {
      v103_vx_u = v103_vx ;
      v103_vy_u = v103_vy ;
      v103_vz_u = v103_vz ;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v103_t1 ;
      force_init_update = False;
    }

    else if ( v103_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v103_vx_init = v103_vx ;
      slope =  (v103_vx * -33.2) ;
      v103_vx_u = (slope * d) + v103_vx ;
      if ((pstate != cstate) || force_init_update) v103_vy_init = v103_vy ;
      slope =  ((v103_vy * 20.0) * v103_ft) ;
      v103_vy_u = (slope * d) + v103_vy ;
      if ((pstate != cstate) || force_init_update) v103_vz_init = v103_vz ;
      slope =  ((v103_vz * 2.0) * v103_ft) ;
      v103_vz_u = (slope * d) + v103_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v103_t4 ;
      force_init_update = False;
      v103_g_u = ((((((((((((v103_v_i_0 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v103_v_i_1 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v103_v_i_2 + (- ((v103_vx + (- v103_vy)) + v103_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v103_v_u = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_voo = ((v103_vx + (- v103_vy)) + v103_vz) ;
      v103_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v103!\n");
      exit(1);
    }
    break;
  }
  v103_vx = v103_vx_u;
  v103_vy = v103_vy_u;
  v103_vz = v103_vz_u;
  v103_g = v103_g_u;
  v103_v = v103_v_u;
  v103_ft = v103_ft_u;
  v103_theta = v103_theta_u;
  v103_v_O = v103_v_O_u;
  return cstate;
}