#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v172_v394_update_c1vd();
extern double v172_v394_update_c2vd();
extern double v172_v394_update_c1md();
extern double v172_v394_update_c2md();
extern double v172_v394_update_buffer_index(double,double,double,double);
extern double v172_v394_update_latch1(double,double);
extern double v172_v394_update_latch2(double,double);
extern double v172_v394_update_ocell1(double,double);
extern double v172_v394_update_ocell2(double,double);
double v172_v394_cell1_v;
double v172_v394_cell1_mode;
double v172_v394_cell2_v;
double v172_v394_cell2_mode;
double v172_v394_cell1_v_replay = 0.0;
double v172_v394_cell2_v_replay = 0.0;


static double  v172_v394_k  =  0.0 ,  v172_v394_cell1_mode_delayed  =  0.0 ,  v172_v394_cell2_mode_delayed  =  0.0 ,  v172_v394_from_cell  =  0.0 ,  v172_v394_cell1_replay_latch  =  0.0 ,  v172_v394_cell2_replay_latch  =  0.0 ,  v172_v394_cell1_v_delayed  =  0.0 ,  v172_v394_cell2_v_delayed  =  0.0 ,  v172_v394_wasted  =  0.0 ; //the continuous vars
static double  v172_v394_k_u , v172_v394_cell1_mode_delayed_u , v172_v394_cell2_mode_delayed_u , v172_v394_from_cell_u , v172_v394_cell1_replay_latch_u , v172_v394_cell2_replay_latch_u , v172_v394_cell1_v_delayed_u , v172_v394_cell2_v_delayed_u , v172_v394_wasted_u ; // and their updates
static double  v172_v394_k_init , v172_v394_cell1_mode_delayed_init , v172_v394_cell2_mode_delayed_init , v172_v394_from_cell_init , v172_v394_cell1_replay_latch_init , v172_v394_cell2_replay_latch_init , v172_v394_cell1_v_delayed_init , v172_v394_cell2_v_delayed_init , v172_v394_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v172_v394_idle , v172_v394_annhilate , v172_v394_previous_drection1 , v172_v394_previous_direction2 , v172_v394_wait_cell1 , v172_v394_replay_cell1 , v172_v394_replay_cell2 , v172_v394_wait_cell2 }; // state declarations

enum states v172_v394 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v172_v394_idle ):
    if (True == False) {;}
    else if  (v172_v394_cell2_mode == (2.0) && (v172_v394_cell1_mode != (2.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v172_v394_cell1_mode == (2.0) && (v172_v394_cell2_mode != (2.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v172_v394_cell1_mode == (2.0) && (v172_v394_cell2_mode == (2.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_idle ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_annhilate ):
    if (True == False) {;}
    else if  (v172_v394_cell1_mode != (2.0) && (v172_v394_cell2_mode != (2.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_from_cell_u = 0 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_previous_drection1 ):
    if (True == False) {;}
    else if  (v172_v394_from_cell == (1.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (0.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (2.0) && (v172_v394_cell2_mode_delayed == (0.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (2.0) && (v172_v394_cell2_mode_delayed != (0.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_previous_drection1 ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_previous_direction2 ):
    if (True == False) {;}
    else if  (v172_v394_from_cell == (1.0) && (v172_v394_cell1_mode_delayed != (0.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (2.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (0.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v172_v394_from_cell == (1.0) && (v172_v394_cell1_mode_delayed == (0.0))) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_previous_direction2 ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_wait_cell1 ):
    if (True == False) {;}
    else if  (v172_v394_cell2_mode == (2.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
    }
    else if  (v172_v394_k >= (89.1468471912)) {
      v172_v394_from_cell_u = 1 ;
      v172_v394_cell1_replay_latch_u = 1 ;
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_wait_cell1 ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_replay_cell1 ):
    if (True == False) {;}
    else if  (v172_v394_cell1_mode == (2.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_annhilate ;
      force_init_update = False;
    }
    else if  (v172_v394_k >= (89.1468471912)) {
      v172_v394_from_cell_u = 2 ;
      v172_v394_cell2_replay_latch_u = 1 ;
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_replay_cell1 ;
      force_init_update = False;
      v172_v394_cell1_replay_latch_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_replay_cell2 ):
    if (True == False) {;}
    else if  (v172_v394_k >= (10.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_replay_cell2 ;
      force_init_update = False;
      v172_v394_cell2_replay_latch_u = 1 ;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  case ( v172_v394_wait_cell2 ):
    if (True == False) {;}
    else if  (v172_v394_k >= (10.0)) {
      v172_v394_k_u = 1 ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
      cstate =  v172_v394_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v172_v394_k_init = v172_v394_k ;
      slope =  1 ;
      v172_v394_k_u = (slope * d) + v172_v394_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v172_v394_wait_cell2 ;
      force_init_update = False;
      v172_v394_cell1_v_delayed_u = v172_v394_update_c1vd () ;
      v172_v394_cell2_v_delayed_u = v172_v394_update_c2vd () ;
      v172_v394_cell1_mode_delayed_u = v172_v394_update_c1md () ;
      v172_v394_cell2_mode_delayed_u = v172_v394_update_c2md () ;
      v172_v394_wasted_u = v172_v394_update_buffer_index (v172_v394_cell1_v,v172_v394_cell2_v,v172_v394_cell1_mode,v172_v394_cell2_mode) ;
      v172_v394_cell1_replay_latch_u = v172_v394_update_latch1 (v172_v394_cell1_mode_delayed,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_replay_latch_u = v172_v394_update_latch2 (v172_v394_cell2_mode_delayed,v172_v394_cell2_replay_latch_u) ;
      v172_v394_cell1_v_replay = v172_v394_update_ocell1 (v172_v394_cell1_v_delayed_u,v172_v394_cell1_replay_latch_u) ;
      v172_v394_cell2_v_replay = v172_v394_update_ocell2 (v172_v394_cell2_v_delayed_u,v172_v394_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172_v394!\n");
      exit(1);
    }
    break;
  }
  v172_v394_k = v172_v394_k_u;
  v172_v394_cell1_mode_delayed = v172_v394_cell1_mode_delayed_u;
  v172_v394_cell2_mode_delayed = v172_v394_cell2_mode_delayed_u;
  v172_v394_from_cell = v172_v394_from_cell_u;
  v172_v394_cell1_replay_latch = v172_v394_cell1_replay_latch_u;
  v172_v394_cell2_replay_latch = v172_v394_cell2_replay_latch_u;
  v172_v394_cell1_v_delayed = v172_v394_cell1_v_delayed_u;
  v172_v394_cell2_v_delayed = v172_v394_cell2_v_delayed_u;
  v172_v394_wasted = v172_v394_wasted_u;
  return cstate;
}