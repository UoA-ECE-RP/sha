#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v157_v476_update_c1vd();
extern double v157_v476_update_c2vd();
extern double v157_v476_update_c1md();
extern double v157_v476_update_c2md();
extern double v157_v476_update_buffer_index(double,double,double,double);
extern double v157_v476_update_latch1(double,double);
extern double v157_v476_update_latch2(double,double);
extern double v157_v476_update_ocell1(double,double);
extern double v157_v476_update_ocell2(double,double);
double v157_v476_cell1_v;
double v157_v476_cell1_mode;
double v157_v476_cell2_v;
double v157_v476_cell2_mode;
double v157_v476_cell1_v_replay = 0.0;
double v157_v476_cell2_v_replay = 0.0;


static double  v157_v476_k  =  0.0 ,  v157_v476_cell1_mode_delayed  =  0.0 ,  v157_v476_cell2_mode_delayed  =  0.0 ,  v157_v476_from_cell  =  0.0 ,  v157_v476_cell1_replay_latch  =  0.0 ,  v157_v476_cell2_replay_latch  =  0.0 ,  v157_v476_cell1_v_delayed  =  0.0 ,  v157_v476_cell2_v_delayed  =  0.0 ,  v157_v476_wasted  =  0.0 ; //the continuous vars
static double  v157_v476_k_u , v157_v476_cell1_mode_delayed_u , v157_v476_cell2_mode_delayed_u , v157_v476_from_cell_u , v157_v476_cell1_replay_latch_u , v157_v476_cell2_replay_latch_u , v157_v476_cell1_v_delayed_u , v157_v476_cell2_v_delayed_u , v157_v476_wasted_u ; // and their updates
static double  v157_v476_k_init , v157_v476_cell1_mode_delayed_init , v157_v476_cell2_mode_delayed_init , v157_v476_from_cell_init , v157_v476_cell1_replay_latch_init , v157_v476_cell2_replay_latch_init , v157_v476_cell1_v_delayed_init , v157_v476_cell2_v_delayed_init , v157_v476_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v157_v476_idle , v157_v476_annhilate , v157_v476_previous_drection1 , v157_v476_previous_direction2 , v157_v476_wait_cell1 , v157_v476_replay_cell1 , v157_v476_replay_cell2 , v157_v476_wait_cell2 }; // state declarations

enum states v157_v476 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v157_v476_idle ):
    if (True == False) {;}
    else if  (v157_v476_cell2_mode == (2.0) && (v157_v476_cell1_mode != (2.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v157_v476_cell1_mode == (2.0) && (v157_v476_cell2_mode != (2.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v157_v476_cell1_mode == (2.0) && (v157_v476_cell2_mode == (2.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_idle ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_annhilate ):
    if (True == False) {;}
    else if  (v157_v476_cell1_mode != (2.0) && (v157_v476_cell2_mode != (2.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_from_cell_u = 0 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_previous_drection1 ):
    if (True == False) {;}
    else if  (v157_v476_from_cell == (1.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (0.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (2.0) && (v157_v476_cell2_mode_delayed == (0.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (2.0) && (v157_v476_cell2_mode_delayed != (0.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_previous_drection1 ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_previous_direction2 ):
    if (True == False) {;}
    else if  (v157_v476_from_cell == (1.0) && (v157_v476_cell1_mode_delayed != (0.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (2.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (0.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v157_v476_from_cell == (1.0) && (v157_v476_cell1_mode_delayed == (0.0))) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_previous_direction2 ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_wait_cell1 ):
    if (True == False) {;}
    else if  (v157_v476_cell2_mode == (2.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
    }
    else if  (v157_v476_k >= (138.655212124)) {
      v157_v476_from_cell_u = 1 ;
      v157_v476_cell1_replay_latch_u = 1 ;
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_wait_cell1 ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_replay_cell1 ):
    if (True == False) {;}
    else if  (v157_v476_cell1_mode == (2.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_annhilate ;
      force_init_update = False;
    }
    else if  (v157_v476_k >= (138.655212124)) {
      v157_v476_from_cell_u = 2 ;
      v157_v476_cell2_replay_latch_u = 1 ;
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_replay_cell1 ;
      force_init_update = False;
      v157_v476_cell1_replay_latch_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_replay_cell2 ):
    if (True == False) {;}
    else if  (v157_v476_k >= (10.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_replay_cell2 ;
      force_init_update = False;
      v157_v476_cell2_replay_latch_u = 1 ;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  case ( v157_v476_wait_cell2 ):
    if (True == False) {;}
    else if  (v157_v476_k >= (10.0)) {
      v157_v476_k_u = 1 ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
      cstate =  v157_v476_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v157_v476_k_init = v157_v476_k ;
      slope =  1 ;
      v157_v476_k_u = (slope * d) + v157_v476_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v157_v476_wait_cell2 ;
      force_init_update = False;
      v157_v476_cell1_v_delayed_u = v157_v476_update_c1vd () ;
      v157_v476_cell2_v_delayed_u = v157_v476_update_c2vd () ;
      v157_v476_cell1_mode_delayed_u = v157_v476_update_c1md () ;
      v157_v476_cell2_mode_delayed_u = v157_v476_update_c2md () ;
      v157_v476_wasted_u = v157_v476_update_buffer_index (v157_v476_cell1_v,v157_v476_cell2_v,v157_v476_cell1_mode,v157_v476_cell2_mode) ;
      v157_v476_cell1_replay_latch_u = v157_v476_update_latch1 (v157_v476_cell1_mode_delayed,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_replay_latch_u = v157_v476_update_latch2 (v157_v476_cell2_mode_delayed,v157_v476_cell2_replay_latch_u) ;
      v157_v476_cell1_v_replay = v157_v476_update_ocell1 (v157_v476_cell1_v_delayed_u,v157_v476_cell1_replay_latch_u) ;
      v157_v476_cell2_v_replay = v157_v476_update_ocell2 (v157_v476_cell2_v_delayed_u,v157_v476_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v157_v476!\n");
      exit(1);
    }
    break;
  }
  v157_v476_k = v157_v476_k_u;
  v157_v476_cell1_mode_delayed = v157_v476_cell1_mode_delayed_u;
  v157_v476_cell2_mode_delayed = v157_v476_cell2_mode_delayed_u;
  v157_v476_from_cell = v157_v476_from_cell_u;
  v157_v476_cell1_replay_latch = v157_v476_cell1_replay_latch_u;
  v157_v476_cell2_replay_latch = v157_v476_cell2_replay_latch_u;
  v157_v476_cell1_v_delayed = v157_v476_cell1_v_delayed_u;
  v157_v476_cell2_v_delayed = v157_v476_cell2_v_delayed_u;
  v157_v476_wasted = v157_v476_wasted_u;
  return cstate;
}