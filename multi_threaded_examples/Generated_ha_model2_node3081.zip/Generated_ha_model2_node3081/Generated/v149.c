#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v149_v_i_0;
double v149_v_i_1;
double v149_v_i_2;
double v149_v_i_3;
double v149_voo = 0.0;
double v149_state = 0.0;


static double  v149_vx  =  0 ,  v149_vy  =  0 ,  v149_vz  =  0 ,  v149_g  =  0 ,  v149_v  =  0 ,  v149_ft  =  0 ,  v149_theta  =  0 ,  v149_v_O  =  0 ; //the continuous vars
static double  v149_vx_u , v149_vy_u , v149_vz_u , v149_g_u , v149_v_u , v149_ft_u , v149_theta_u , v149_v_O_u ; // and their updates
static double  v149_vx_init , v149_vy_init , v149_vz_init , v149_g_init , v149_v_init , v149_ft_init , v149_theta_init , v149_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v149_t1 , v149_t2 , v149_t3 , v149_t4 }; // state declarations

enum states v149 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v149_t1 ):
    if (True == False) {;}
    else if  (v149_g > (44.5)) {
      v149_vx_u = (0.3 * v149_v) ;
      v149_vy_u = 0 ;
      v149_vz_u = (0.7 * v149_v) ;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      v149_theta_u = (v149_v / 30.0) ;
      v149_v_O_u = (131.1 + (- (80.1 * pow ( ((v149_v / 30.0)) , (0.5) )))) ;
      v149_ft_u = f (v149_theta,4.0e-2) ;
      cstate =  v149_t2 ;
      force_init_update = False;
    }

    else if ( v149_v <= (44.5)
               && v149_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v149_vx_init = v149_vx ;
      slope =  (v149_vx * -8.7) ;
      v149_vx_u = (slope * d) + v149_vx ;
      if ((pstate != cstate) || force_init_update) v149_vy_init = v149_vy ;
      slope =  (v149_vy * -190.9) ;
      v149_vy_u = (slope * d) + v149_vy ;
      if ((pstate != cstate) || force_init_update) v149_vz_init = v149_vz ;
      slope =  (v149_vz * -190.4) ;
      v149_vz_u = (slope * d) + v149_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v149_t1 ;
      force_init_update = False;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      v149_v_u = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_voo = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149!\n");
      exit(1);
    }
    break;
  case ( v149_t2 ):
    if (True == False) {;}
    else if  (v149_v >= (44.5)) {
      v149_vx_u = v149_vx ;
      v149_vy_u = v149_vy ;
      v149_vz_u = v149_vz ;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v149_t3 ;
      force_init_update = False;
    }
    else if  (v149_g <= (44.5)
               && v149_v < (44.5)) {
      v149_vx_u = v149_vx ;
      v149_vy_u = v149_vy ;
      v149_vz_u = v149_vz ;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v149_t1 ;
      force_init_update = False;
    }

    else if ( v149_v < (44.5)
               && v149_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v149_vx_init = v149_vx ;
      slope =  ((v149_vx * -23.6) + (777200.0 * v149_g)) ;
      v149_vx_u = (slope * d) + v149_vx ;
      if ((pstate != cstate) || force_init_update) v149_vy_init = v149_vy ;
      slope =  ((v149_vy * -45.5) + (58900.0 * v149_g)) ;
      v149_vy_u = (slope * d) + v149_vy ;
      if ((pstate != cstate) || force_init_update) v149_vz_init = v149_vz ;
      slope =  ((v149_vz * -12.9) + (276600.0 * v149_g)) ;
      v149_vz_u = (slope * d) + v149_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v149_t2 ;
      force_init_update = False;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      v149_v_u = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_voo = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149!\n");
      exit(1);
    }
    break;
  case ( v149_t3 ):
    if (True == False) {;}
    else if  (v149_v >= (131.1)) {
      v149_vx_u = v149_vx ;
      v149_vy_u = v149_vy ;
      v149_vz_u = v149_vz ;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v149_t4 ;
      force_init_update = False;
    }

    else if ( v149_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v149_vx_init = v149_vx ;
      slope =  (v149_vx * -6.9) ;
      v149_vx_u = (slope * d) + v149_vx ;
      if ((pstate != cstate) || force_init_update) v149_vy_init = v149_vy ;
      slope =  (v149_vy * 75.9) ;
      v149_vy_u = (slope * d) + v149_vy ;
      if ((pstate != cstate) || force_init_update) v149_vz_init = v149_vz ;
      slope =  (v149_vz * 6826.5) ;
      v149_vz_u = (slope * d) + v149_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v149_t3 ;
      force_init_update = False;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      v149_v_u = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_voo = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149!\n");
      exit(1);
    }
    break;
  case ( v149_t4 ):
    if (True == False) {;}
    else if  (v149_v <= (30.0)) {
      v149_vx_u = v149_vx ;
      v149_vy_u = v149_vy ;
      v149_vz_u = v149_vz ;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v149_t1 ;
      force_init_update = False;
    }

    else if ( v149_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v149_vx_init = v149_vx ;
      slope =  (v149_vx * -33.2) ;
      v149_vx_u = (slope * d) + v149_vx ;
      if ((pstate != cstate) || force_init_update) v149_vy_init = v149_vy ;
      slope =  ((v149_vy * 20.0) * v149_ft) ;
      v149_vy_u = (slope * d) + v149_vy ;
      if ((pstate != cstate) || force_init_update) v149_vz_init = v149_vz ;
      slope =  ((v149_vz * 2.0) * v149_ft) ;
      v149_vz_u = (slope * d) + v149_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v149_t4 ;
      force_init_update = False;
      v149_g_u = ((((((((((((v149_v_i_0 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v149_v_i_1 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v149_v_i_2 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.91297186152))) + ((((v149_v_i_3 + (- ((v149_vx + (- v149_vy)) + v149_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.88830835031))) + 0) + 0) + 0) + 0) + 0) ;
      v149_v_u = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_voo = ((v149_vx + (- v149_vy)) + v149_vz) ;
      v149_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149!\n");
      exit(1);
    }
    break;
  }
  v149_vx = v149_vx_u;
  v149_vy = v149_vy_u;
  v149_vz = v149_vz_u;
  v149_g = v149_g_u;
  v149_v = v149_v_u;
  v149_ft = v149_ft_u;
  v149_theta = v149_theta_u;
  v149_v_O = v149_v_O_u;
  return cstate;
}