#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v152_v_i_0;
double v152_v_i_1;
double v152_v_i_2;
double v152_v_i_3;
double v152_v_i_4;
double v152_voo = 0.0;
double v152_state = 0.0;


static double  v152_vx  =  0 ,  v152_vy  =  0 ,  v152_vz  =  0 ,  v152_g  =  0 ,  v152_v  =  0 ,  v152_ft  =  0 ,  v152_theta  =  0 ,  v152_v_O  =  0 ; //the continuous vars
static double  v152_vx_u , v152_vy_u , v152_vz_u , v152_g_u , v152_v_u , v152_ft_u , v152_theta_u , v152_v_O_u ; // and their updates
static double  v152_vx_init , v152_vy_init , v152_vz_init , v152_g_init , v152_v_init , v152_ft_init , v152_theta_init , v152_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v152_t1 , v152_t2 , v152_t3 , v152_t4 }; // state declarations

enum states v152 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v152_t1 ):
    if (True == False) {;}
    else if  (v152_g > (44.5)) {
      v152_vx_u = (0.3 * v152_v) ;
      v152_vy_u = 0 ;
      v152_vz_u = (0.7 * v152_v) ;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      v152_theta_u = (v152_v / 30.0) ;
      v152_v_O_u = (131.1 + (- (80.1 * pow ( ((v152_v / 30.0)) , (0.5) )))) ;
      v152_ft_u = f (v152_theta,4.0e-2) ;
      cstate =  v152_t2 ;
      force_init_update = False;
    }

    else if ( v152_v <= (44.5)
               && v152_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v152_vx_init = v152_vx ;
      slope =  (v152_vx * -8.7) ;
      v152_vx_u = (slope * d) + v152_vx ;
      if ((pstate != cstate) || force_init_update) v152_vy_init = v152_vy ;
      slope =  (v152_vy * -190.9) ;
      v152_vy_u = (slope * d) + v152_vy ;
      if ((pstate != cstate) || force_init_update) v152_vz_init = v152_vz ;
      slope =  (v152_vz * -190.4) ;
      v152_vz_u = (slope * d) + v152_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v152_t1 ;
      force_init_update = False;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      v152_v_u = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_voo = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152!\n");
      exit(1);
    }
    break;
  case ( v152_t2 ):
    if (True == False) {;}
    else if  (v152_v >= (44.5)) {
      v152_vx_u = v152_vx ;
      v152_vy_u = v152_vy ;
      v152_vz_u = v152_vz ;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      cstate =  v152_t3 ;
      force_init_update = False;
    }
    else if  (v152_g <= (44.5)
               && v152_v < (44.5)) {
      v152_vx_u = v152_vx ;
      v152_vy_u = v152_vy ;
      v152_vz_u = v152_vz ;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      cstate =  v152_t1 ;
      force_init_update = False;
    }

    else if ( v152_v < (44.5)
               && v152_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v152_vx_init = v152_vx ;
      slope =  ((v152_vx * -23.6) + (777200.0 * v152_g)) ;
      v152_vx_u = (slope * d) + v152_vx ;
      if ((pstate != cstate) || force_init_update) v152_vy_init = v152_vy ;
      slope =  ((v152_vy * -45.5) + (58900.0 * v152_g)) ;
      v152_vy_u = (slope * d) + v152_vy ;
      if ((pstate != cstate) || force_init_update) v152_vz_init = v152_vz ;
      slope =  ((v152_vz * -12.9) + (276600.0 * v152_g)) ;
      v152_vz_u = (slope * d) + v152_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v152_t2 ;
      force_init_update = False;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      v152_v_u = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_voo = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152!\n");
      exit(1);
    }
    break;
  case ( v152_t3 ):
    if (True == False) {;}
    else if  (v152_v >= (131.1)) {
      v152_vx_u = v152_vx ;
      v152_vy_u = v152_vy ;
      v152_vz_u = v152_vz ;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      cstate =  v152_t4 ;
      force_init_update = False;
    }

    else if ( v152_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v152_vx_init = v152_vx ;
      slope =  (v152_vx * -6.9) ;
      v152_vx_u = (slope * d) + v152_vx ;
      if ((pstate != cstate) || force_init_update) v152_vy_init = v152_vy ;
      slope =  (v152_vy * 75.9) ;
      v152_vy_u = (slope * d) + v152_vy ;
      if ((pstate != cstate) || force_init_update) v152_vz_init = v152_vz ;
      slope =  (v152_vz * 6826.5) ;
      v152_vz_u = (slope * d) + v152_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v152_t3 ;
      force_init_update = False;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      v152_v_u = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_voo = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152!\n");
      exit(1);
    }
    break;
  case ( v152_t4 ):
    if (True == False) {;}
    else if  (v152_v <= (30.0)) {
      v152_vx_u = v152_vx ;
      v152_vy_u = v152_vy ;
      v152_vz_u = v152_vz ;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      cstate =  v152_t1 ;
      force_init_update = False;
    }

    else if ( v152_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v152_vx_init = v152_vx ;
      slope =  (v152_vx * -33.2) ;
      v152_vx_u = (slope * d) + v152_vx ;
      if ((pstate != cstate) || force_init_update) v152_vy_init = v152_vy ;
      slope =  ((v152_vy * 20.0) * v152_ft) ;
      v152_vy_u = (slope * d) + v152_vy ;
      if ((pstate != cstate) || force_init_update) v152_vz_init = v152_vz ;
      slope =  ((v152_vz * 2.0) * v152_ft) ;
      v152_vz_u = (slope * d) + v152_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v152_t4 ;
      force_init_update = False;
      v152_g_u = ((((((((((((v152_v_i_0 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v152_v_i_1 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v152_v_i_2 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v152_v_i_3 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.36699422543))) + ((((v152_v_i_4 + (- ((v152_vx + (- v152_vy)) + v152_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.25285964977))) + 0) + 0) + 0) + 0) ;
      v152_v_u = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_voo = ((v152_vx + (- v152_vy)) + v152_vz) ;
      v152_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152!\n");
      exit(1);
    }
    break;
  }
  v152_vx = v152_vx_u;
  v152_vy = v152_vy_u;
  v152_vz = v152_vz_u;
  v152_g = v152_g_u;
  v152_v = v152_v_u;
  v152_ft = v152_ft_u;
  v152_theta = v152_theta_u;
  v152_v_O = v152_v_O_u;
  return cstate;
}