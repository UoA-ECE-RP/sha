#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v105_v_i_0;
double v105_v_i_1;
double v105_v_i_2;
double v105_v_i_3;
double v105_voo = 0.0;
double v105_state = 0.0;


static double  v105_vx  =  0 ,  v105_vy  =  0 ,  v105_vz  =  0 ,  v105_g  =  0 ,  v105_v  =  0 ,  v105_ft  =  0 ,  v105_theta  =  0 ,  v105_v_O  =  0 ; //the continuous vars
static double  v105_vx_u , v105_vy_u , v105_vz_u , v105_g_u , v105_v_u , v105_ft_u , v105_theta_u , v105_v_O_u ; // and their updates
static double  v105_vx_init , v105_vy_init , v105_vz_init , v105_g_init , v105_v_init , v105_ft_init , v105_theta_init , v105_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v105_t1 , v105_t2 , v105_t3 , v105_t4 }; // state declarations

enum states v105 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v105_t1 ):
    if (True == False) {;}
    else if  (v105_g > (44.5)) {
      v105_vx_u = (0.3 * v105_v) ;
      v105_vy_u = 0 ;
      v105_vz_u = (0.7 * v105_v) ;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      v105_theta_u = (v105_v / 30.0) ;
      v105_v_O_u = (131.1 + (- (80.1 * pow ( ((v105_v / 30.0)) , (0.5) )))) ;
      v105_ft_u = f (v105_theta,4.0e-2) ;
      cstate =  v105_t2 ;
      force_init_update = False;
    }

    else if ( v105_v <= (44.5)
               && v105_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v105_vx_init = v105_vx ;
      slope =  (v105_vx * -8.7) ;
      v105_vx_u = (slope * d) + v105_vx ;
      if ((pstate != cstate) || force_init_update) v105_vy_init = v105_vy ;
      slope =  (v105_vy * -190.9) ;
      v105_vy_u = (slope * d) + v105_vy ;
      if ((pstate != cstate) || force_init_update) v105_vz_init = v105_vz ;
      slope =  (v105_vz * -190.4) ;
      v105_vz_u = (slope * d) + v105_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v105_t1 ;
      force_init_update = False;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      v105_v_u = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_voo = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105!\n");
      exit(1);
    }
    break;
  case ( v105_t2 ):
    if (True == False) {;}
    else if  (v105_v >= (44.5)) {
      v105_vx_u = v105_vx ;
      v105_vy_u = v105_vy ;
      v105_vz_u = v105_vz ;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v105_t3 ;
      force_init_update = False;
    }
    else if  (v105_g <= (44.5)
               && v105_v < (44.5)) {
      v105_vx_u = v105_vx ;
      v105_vy_u = v105_vy ;
      v105_vz_u = v105_vz ;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v105_t1 ;
      force_init_update = False;
    }

    else if ( v105_v < (44.5)
               && v105_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v105_vx_init = v105_vx ;
      slope =  ((v105_vx * -23.6) + (777200.0 * v105_g)) ;
      v105_vx_u = (slope * d) + v105_vx ;
      if ((pstate != cstate) || force_init_update) v105_vy_init = v105_vy ;
      slope =  ((v105_vy * -45.5) + (58900.0 * v105_g)) ;
      v105_vy_u = (slope * d) + v105_vy ;
      if ((pstate != cstate) || force_init_update) v105_vz_init = v105_vz ;
      slope =  ((v105_vz * -12.9) + (276600.0 * v105_g)) ;
      v105_vz_u = (slope * d) + v105_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v105_t2 ;
      force_init_update = False;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      v105_v_u = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_voo = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105!\n");
      exit(1);
    }
    break;
  case ( v105_t3 ):
    if (True == False) {;}
    else if  (v105_v >= (131.1)) {
      v105_vx_u = v105_vx ;
      v105_vy_u = v105_vy ;
      v105_vz_u = v105_vz ;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v105_t4 ;
      force_init_update = False;
    }

    else if ( v105_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v105_vx_init = v105_vx ;
      slope =  (v105_vx * -6.9) ;
      v105_vx_u = (slope * d) + v105_vx ;
      if ((pstate != cstate) || force_init_update) v105_vy_init = v105_vy ;
      slope =  (v105_vy * 75.9) ;
      v105_vy_u = (slope * d) + v105_vy ;
      if ((pstate != cstate) || force_init_update) v105_vz_init = v105_vz ;
      slope =  (v105_vz * 6826.5) ;
      v105_vz_u = (slope * d) + v105_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v105_t3 ;
      force_init_update = False;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      v105_v_u = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_voo = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105!\n");
      exit(1);
    }
    break;
  case ( v105_t4 ):
    if (True == False) {;}
    else if  (v105_v <= (30.0)) {
      v105_vx_u = v105_vx ;
      v105_vy_u = v105_vy ;
      v105_vz_u = v105_vz ;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v105_t1 ;
      force_init_update = False;
    }

    else if ( v105_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v105_vx_init = v105_vx ;
      slope =  (v105_vx * -33.2) ;
      v105_vx_u = (slope * d) + v105_vx ;
      if ((pstate != cstate) || force_init_update) v105_vy_init = v105_vy ;
      slope =  ((v105_vy * 20.0) * v105_ft) ;
      v105_vy_u = (slope * d) + v105_vy ;
      if ((pstate != cstate) || force_init_update) v105_vz_init = v105_vz ;
      slope =  ((v105_vz * 2.0) * v105_ft) ;
      v105_vz_u = (slope * d) + v105_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v105_t4 ;
      force_init_update = False;
      v105_g_u = ((((((((((((v105_v_i_0 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v105_v_i_1 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v105_v_i_2 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.7951086729))) + ((((v105_v_i_3 + (- ((v105_vx + (- v105_vy)) + v105_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17177812899))) + 0) + 0) + 0) + 0) + 0) ;
      v105_v_u = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_voo = ((v105_vx + (- v105_vy)) + v105_vz) ;
      v105_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105!\n");
      exit(1);
    }
    break;
  }
  v105_vx = v105_vx_u;
  v105_vy = v105_vy_u;
  v105_vz = v105_vz_u;
  v105_g = v105_g_u;
  v105_v = v105_v_u;
  v105_ft = v105_ft_u;
  v105_theta = v105_theta_u;
  v105_v_O = v105_v_O_u;
  return cstate;
}