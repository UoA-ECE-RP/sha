#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v136_v_i_0;
double v136_v_i_1;
double v136_v_i_2;
double v136_voo = 0.0;
double v136_state = 0.0;


static double  v136_vx  =  0 ,  v136_vy  =  0 ,  v136_vz  =  0 ,  v136_g  =  0 ,  v136_v  =  0 ,  v136_ft  =  0 ,  v136_theta  =  0 ,  v136_v_O  =  0 ; //the continuous vars
static double  v136_vx_u , v136_vy_u , v136_vz_u , v136_g_u , v136_v_u , v136_ft_u , v136_theta_u , v136_v_O_u ; // and their updates
static double  v136_vx_init , v136_vy_init , v136_vz_init , v136_g_init , v136_v_init , v136_ft_init , v136_theta_init , v136_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v136_t1 , v136_t2 , v136_t3 , v136_t4 }; // state declarations

enum states v136 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v136_t1 ):
    if (True == False) {;}
    else if  (v136_g > (44.5)) {
      v136_vx_u = (0.3 * v136_v) ;
      v136_vy_u = 0 ;
      v136_vz_u = (0.7 * v136_v) ;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v136_theta_u = (v136_v / 30.0) ;
      v136_v_O_u = (131.1 + (- (80.1 * pow ( ((v136_v / 30.0)) , (0.5) )))) ;
      v136_ft_u = f (v136_theta,4.0e-2) ;
      cstate =  v136_t2 ;
      force_init_update = False;
    }

    else if ( v136_v <= (44.5)
               && v136_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v136_vx_init = v136_vx ;
      slope =  (v136_vx * -8.7) ;
      v136_vx_u = (slope * d) + v136_vx ;
      if ((pstate != cstate) || force_init_update) v136_vy_init = v136_vy ;
      slope =  (v136_vy * -190.9) ;
      v136_vy_u = (slope * d) + v136_vy ;
      if ((pstate != cstate) || force_init_update) v136_vz_init = v136_vz ;
      slope =  (v136_vz * -190.4) ;
      v136_vz_u = (slope * d) + v136_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v136_t1 ;
      force_init_update = False;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v136_v_u = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_voo = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136!\n");
      exit(1);
    }
    break;
  case ( v136_t2 ):
    if (True == False) {;}
    else if  (v136_v >= (44.5)) {
      v136_vx_u = v136_vx ;
      v136_vy_u = v136_vy ;
      v136_vz_u = v136_vz ;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v136_t3 ;
      force_init_update = False;
    }
    else if  (v136_g <= (44.5)
               && v136_v < (44.5)) {
      v136_vx_u = v136_vx ;
      v136_vy_u = v136_vy ;
      v136_vz_u = v136_vz ;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v136_t1 ;
      force_init_update = False;
    }

    else if ( v136_v < (44.5)
               && v136_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v136_vx_init = v136_vx ;
      slope =  ((v136_vx * -23.6) + (777200.0 * v136_g)) ;
      v136_vx_u = (slope * d) + v136_vx ;
      if ((pstate != cstate) || force_init_update) v136_vy_init = v136_vy ;
      slope =  ((v136_vy * -45.5) + (58900.0 * v136_g)) ;
      v136_vy_u = (slope * d) + v136_vy ;
      if ((pstate != cstate) || force_init_update) v136_vz_init = v136_vz ;
      slope =  ((v136_vz * -12.9) + (276600.0 * v136_g)) ;
      v136_vz_u = (slope * d) + v136_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v136_t2 ;
      force_init_update = False;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v136_v_u = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_voo = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136!\n");
      exit(1);
    }
    break;
  case ( v136_t3 ):
    if (True == False) {;}
    else if  (v136_v >= (131.1)) {
      v136_vx_u = v136_vx ;
      v136_vy_u = v136_vy ;
      v136_vz_u = v136_vz ;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v136_t4 ;
      force_init_update = False;
    }

    else if ( v136_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v136_vx_init = v136_vx ;
      slope =  (v136_vx * -6.9) ;
      v136_vx_u = (slope * d) + v136_vx ;
      if ((pstate != cstate) || force_init_update) v136_vy_init = v136_vy ;
      slope =  (v136_vy * 75.9) ;
      v136_vy_u = (slope * d) + v136_vy ;
      if ((pstate != cstate) || force_init_update) v136_vz_init = v136_vz ;
      slope =  (v136_vz * 6826.5) ;
      v136_vz_u = (slope * d) + v136_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v136_t3 ;
      force_init_update = False;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v136_v_u = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_voo = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136!\n");
      exit(1);
    }
    break;
  case ( v136_t4 ):
    if (True == False) {;}
    else if  (v136_v <= (30.0)) {
      v136_vx_u = v136_vx ;
      v136_vy_u = v136_vy ;
      v136_vz_u = v136_vz ;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v136_t1 ;
      force_init_update = False;
    }

    else if ( v136_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v136_vx_init = v136_vx ;
      slope =  (v136_vx * -33.2) ;
      v136_vx_u = (slope * d) + v136_vx ;
      if ((pstate != cstate) || force_init_update) v136_vy_init = v136_vy ;
      slope =  ((v136_vy * 20.0) * v136_ft) ;
      v136_vy_u = (slope * d) + v136_vy ;
      if ((pstate != cstate) || force_init_update) v136_vz_init = v136_vz ;
      slope =  ((v136_vz * 2.0) * v136_ft) ;
      v136_vz_u = (slope * d) + v136_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v136_t4 ;
      force_init_update = False;
      v136_g_u = ((((((((((((v136_v_i_0 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10159663804)) + ((((v136_v_i_1 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v136_v_i_2 + (- ((v136_vx + (- v136_vy)) + v136_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.70698086761))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v136_v_u = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_voo = ((v136_vx + (- v136_vy)) + v136_vz) ;
      v136_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v136!\n");
      exit(1);
    }
    break;
  }
  v136_vx = v136_vx_u;
  v136_vy = v136_vy_u;
  v136_vz = v136_vz_u;
  v136_g = v136_g_u;
  v136_v = v136_v_u;
  v136_ft = v136_ft_u;
  v136_theta = v136_theta_u;
  v136_v_O = v136_v_O_u;
  return cstate;
}