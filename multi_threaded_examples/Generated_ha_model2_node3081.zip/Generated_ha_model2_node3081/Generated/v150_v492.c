#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v150_v492_update_c1vd();
extern double v150_v492_update_c2vd();
extern double v150_v492_update_c1md();
extern double v150_v492_update_c2md();
extern double v150_v492_update_buffer_index(double,double,double,double);
extern double v150_v492_update_latch1(double,double);
extern double v150_v492_update_latch2(double,double);
extern double v150_v492_update_ocell1(double,double);
extern double v150_v492_update_ocell2(double,double);
double v150_v492_cell1_v;
double v150_v492_cell1_mode;
double v150_v492_cell2_v;
double v150_v492_cell2_mode;
double v150_v492_cell1_v_replay = 0.0;
double v150_v492_cell2_v_replay = 0.0;


static double  v150_v492_k  =  0.0 ,  v150_v492_cell1_mode_delayed  =  0.0 ,  v150_v492_cell2_mode_delayed  =  0.0 ,  v150_v492_from_cell  =  0.0 ,  v150_v492_cell1_replay_latch  =  0.0 ,  v150_v492_cell2_replay_latch  =  0.0 ,  v150_v492_cell1_v_delayed  =  0.0 ,  v150_v492_cell2_v_delayed  =  0.0 ,  v150_v492_wasted  =  0.0 ; //the continuous vars
static double  v150_v492_k_u , v150_v492_cell1_mode_delayed_u , v150_v492_cell2_mode_delayed_u , v150_v492_from_cell_u , v150_v492_cell1_replay_latch_u , v150_v492_cell2_replay_latch_u , v150_v492_cell1_v_delayed_u , v150_v492_cell2_v_delayed_u , v150_v492_wasted_u ; // and their updates
static double  v150_v492_k_init , v150_v492_cell1_mode_delayed_init , v150_v492_cell2_mode_delayed_init , v150_v492_from_cell_init , v150_v492_cell1_replay_latch_init , v150_v492_cell2_replay_latch_init , v150_v492_cell1_v_delayed_init , v150_v492_cell2_v_delayed_init , v150_v492_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v150_v492_idle , v150_v492_annhilate , v150_v492_previous_drection1 , v150_v492_previous_direction2 , v150_v492_wait_cell1 , v150_v492_replay_cell1 , v150_v492_replay_cell2 , v150_v492_wait_cell2 }; // state declarations

enum states v150_v492 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v150_v492_idle ):
    if (True == False) {;}
    else if  (v150_v492_cell2_mode == (2.0) && (v150_v492_cell1_mode != (2.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v150_v492_cell1_mode == (2.0) && (v150_v492_cell2_mode != (2.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v150_v492_cell1_mode == (2.0) && (v150_v492_cell2_mode == (2.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_idle ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_annhilate ):
    if (True == False) {;}
    else if  (v150_v492_cell1_mode != (2.0) && (v150_v492_cell2_mode != (2.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_from_cell_u = 0 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_previous_drection1 ):
    if (True == False) {;}
    else if  (v150_v492_from_cell == (1.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (0.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (2.0) && (v150_v492_cell2_mode_delayed == (0.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (2.0) && (v150_v492_cell2_mode_delayed != (0.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_previous_drection1 ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_previous_direction2 ):
    if (True == False) {;}
    else if  (v150_v492_from_cell == (1.0) && (v150_v492_cell1_mode_delayed != (0.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (2.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (0.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v150_v492_from_cell == (1.0) && (v150_v492_cell1_mode_delayed == (0.0))) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_previous_direction2 ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_wait_cell1 ):
    if (True == False) {;}
    else if  (v150_v492_cell2_mode == (2.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
    }
    else if  (v150_v492_k >= (77.3373647903)) {
      v150_v492_from_cell_u = 1 ;
      v150_v492_cell1_replay_latch_u = 1 ;
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_wait_cell1 ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_replay_cell1 ):
    if (True == False) {;}
    else if  (v150_v492_cell1_mode == (2.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_annhilate ;
      force_init_update = False;
    }
    else if  (v150_v492_k >= (77.3373647903)) {
      v150_v492_from_cell_u = 2 ;
      v150_v492_cell2_replay_latch_u = 1 ;
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_replay_cell1 ;
      force_init_update = False;
      v150_v492_cell1_replay_latch_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_replay_cell2 ):
    if (True == False) {;}
    else if  (v150_v492_k >= (10.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_replay_cell2 ;
      force_init_update = False;
      v150_v492_cell2_replay_latch_u = 1 ;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  case ( v150_v492_wait_cell2 ):
    if (True == False) {;}
    else if  (v150_v492_k >= (10.0)) {
      v150_v492_k_u = 1 ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
      cstate =  v150_v492_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v150_v492_k_init = v150_v492_k ;
      slope =  1 ;
      v150_v492_k_u = (slope * d) + v150_v492_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v150_v492_wait_cell2 ;
      force_init_update = False;
      v150_v492_cell1_v_delayed_u = v150_v492_update_c1vd () ;
      v150_v492_cell2_v_delayed_u = v150_v492_update_c2vd () ;
      v150_v492_cell1_mode_delayed_u = v150_v492_update_c1md () ;
      v150_v492_cell2_mode_delayed_u = v150_v492_update_c2md () ;
      v150_v492_wasted_u = v150_v492_update_buffer_index (v150_v492_cell1_v,v150_v492_cell2_v,v150_v492_cell1_mode,v150_v492_cell2_mode) ;
      v150_v492_cell1_replay_latch_u = v150_v492_update_latch1 (v150_v492_cell1_mode_delayed,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_replay_latch_u = v150_v492_update_latch2 (v150_v492_cell2_mode_delayed,v150_v492_cell2_replay_latch_u) ;
      v150_v492_cell1_v_replay = v150_v492_update_ocell1 (v150_v492_cell1_v_delayed_u,v150_v492_cell1_replay_latch_u) ;
      v150_v492_cell2_v_replay = v150_v492_update_ocell2 (v150_v492_cell2_v_delayed_u,v150_v492_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v150_v492!\n");
      exit(1);
    }
    break;
  }
  v150_v492_k = v150_v492_k_u;
  v150_v492_cell1_mode_delayed = v150_v492_cell1_mode_delayed_u;
  v150_v492_cell2_mode_delayed = v150_v492_cell2_mode_delayed_u;
  v150_v492_from_cell = v150_v492_from_cell_u;
  v150_v492_cell1_replay_latch = v150_v492_cell1_replay_latch_u;
  v150_v492_cell2_replay_latch = v150_v492_cell2_replay_latch_u;
  v150_v492_cell1_v_delayed = v150_v492_cell1_v_delayed_u;
  v150_v492_cell2_v_delayed = v150_v492_cell2_v_delayed_u;
  v150_v492_wasted = v150_v492_wasted_u;
  return cstate;
}