#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v16_v_i_0;
double v16_v_i_1;
double v16_v_i_2;
double v16_voo = 0.0;
double v16_state = 0.0;


static double  v16_vx  =  0 ,  v16_vy  =  0 ,  v16_vz  =  0 ,  v16_g  =  0 ,  v16_v  =  0 ,  v16_ft  =  0 ,  v16_theta  =  0 ,  v16_v_O  =  0 ; //the continuous vars
static double  v16_vx_u , v16_vy_u , v16_vz_u , v16_g_u , v16_v_u , v16_ft_u , v16_theta_u , v16_v_O_u ; // and their updates
static double  v16_vx_init , v16_vy_init , v16_vz_init , v16_g_init , v16_v_init , v16_ft_init , v16_theta_init , v16_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v16_t1 , v16_t2 , v16_t3 , v16_t4 }; // state declarations

enum states v16 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v16_t1 ):
    if (True == False) {;}
    else if  (v16_g > (44.5)) {
      v16_vx_u = (0.3 * v16_v) ;
      v16_vy_u = 0 ;
      v16_vz_u = (0.7 * v16_v) ;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v16_theta_u = (v16_v / 30.0) ;
      v16_v_O_u = (131.1 + (- (80.1 * pow ( ((v16_v / 30.0)) , (0.5) )))) ;
      v16_ft_u = f (v16_theta,4.0e-2) ;
      cstate =  v16_t2 ;
      force_init_update = False;
    }

    else if ( v16_v <= (44.5)
               && v16_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v16_vx_init = v16_vx ;
      slope =  (v16_vx * -8.7) ;
      v16_vx_u = (slope * d) + v16_vx ;
      if ((pstate != cstate) || force_init_update) v16_vy_init = v16_vy ;
      slope =  (v16_vy * -190.9) ;
      v16_vy_u = (slope * d) + v16_vy ;
      if ((pstate != cstate) || force_init_update) v16_vz_init = v16_vz ;
      slope =  (v16_vz * -190.4) ;
      v16_vz_u = (slope * d) + v16_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v16_t1 ;
      force_init_update = False;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v16_v_u = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_voo = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16!\n");
      exit(1);
    }
    break;
  case ( v16_t2 ):
    if (True == False) {;}
    else if  (v16_v >= (44.5)) {
      v16_vx_u = v16_vx ;
      v16_vy_u = v16_vy ;
      v16_vz_u = v16_vz ;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v16_t3 ;
      force_init_update = False;
    }
    else if  (v16_g <= (44.5)
               && v16_v < (44.5)) {
      v16_vx_u = v16_vx ;
      v16_vy_u = v16_vy ;
      v16_vz_u = v16_vz ;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v16_t1 ;
      force_init_update = False;
    }

    else if ( v16_v < (44.5) && 
              v16_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v16_vx_init = v16_vx ;
      slope =  ((v16_vx * -23.6) + (777200.0 * v16_g)) ;
      v16_vx_u = (slope * d) + v16_vx ;
      if ((pstate != cstate) || force_init_update) v16_vy_init = v16_vy ;
      slope =  ((v16_vy * -45.5) + (58900.0 * v16_g)) ;
      v16_vy_u = (slope * d) + v16_vy ;
      if ((pstate != cstate) || force_init_update) v16_vz_init = v16_vz ;
      slope =  ((v16_vz * -12.9) + (276600.0 * v16_g)) ;
      v16_vz_u = (slope * d) + v16_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v16_t2 ;
      force_init_update = False;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v16_v_u = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_voo = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16!\n");
      exit(1);
    }
    break;
  case ( v16_t3 ):
    if (True == False) {;}
    else if  (v16_v >= (131.1)) {
      v16_vx_u = v16_vx ;
      v16_vy_u = v16_vy ;
      v16_vz_u = v16_vz ;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v16_t4 ;
      force_init_update = False;
    }

    else if ( v16_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v16_vx_init = v16_vx ;
      slope =  (v16_vx * -6.9) ;
      v16_vx_u = (slope * d) + v16_vx ;
      if ((pstate != cstate) || force_init_update) v16_vy_init = v16_vy ;
      slope =  (v16_vy * 75.9) ;
      v16_vy_u = (slope * d) + v16_vy ;
      if ((pstate != cstate) || force_init_update) v16_vz_init = v16_vz ;
      slope =  (v16_vz * 6826.5) ;
      v16_vz_u = (slope * d) + v16_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v16_t3 ;
      force_init_update = False;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v16_v_u = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_voo = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16!\n");
      exit(1);
    }
    break;
  case ( v16_t4 ):
    if (True == False) {;}
    else if  (v16_v <= (30.0)) {
      v16_vx_u = v16_vx ;
      v16_vy_u = v16_vy ;
      v16_vz_u = v16_vz ;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v16_t1 ;
      force_init_update = False;
    }

    else if ( v16_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v16_vx_init = v16_vx ;
      slope =  (v16_vx * -33.2) ;
      v16_vx_u = (slope * d) + v16_vx ;
      if ((pstate != cstate) || force_init_update) v16_vy_init = v16_vy ;
      slope =  ((v16_vy * 20.0) * v16_ft) ;
      v16_vy_u = (slope * d) + v16_vy ;
      if ((pstate != cstate) || force_init_update) v16_vz_init = v16_vz ;
      slope =  ((v16_vz * 2.0) * v16_ft) ;
      v16_vz_u = (slope * d) + v16_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v16_t4 ;
      force_init_update = False;
      v16_g_u = ((((((((((((v16_v_i_0 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v16_v_i_1 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.20855572493))) + ((((v16_v_i_2 + (- ((v16_vx + (- v16_vy)) + v16_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.61416060324))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v16_v_u = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_voo = ((v16_vx + (- v16_vy)) + v16_vz) ;
      v16_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v16!\n");
      exit(1);
    }
    break;
  }
  v16_vx = v16_vx_u;
  v16_vy = v16_vy_u;
  v16_vz = v16_vz_u;
  v16_g = v16_g_u;
  v16_v = v16_v_u;
  v16_ft = v16_ft_u;
  v16_theta = v16_theta_u;
  v16_v_O = v16_v_O_u;
  return cstate;
}