#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v119_v_i_0;
double v119_v_i_1;
double v119_v_i_2;
double v119_v_i_3;
double v119_voo = 0.0;
double v119_state = 0.0;


static double  v119_vx  =  0 ,  v119_vy  =  0 ,  v119_vz  =  0 ,  v119_g  =  0 ,  v119_v  =  0 ,  v119_ft  =  0 ,  v119_theta  =  0 ,  v119_v_O  =  0 ; //the continuous vars
static double  v119_vx_u , v119_vy_u , v119_vz_u , v119_g_u , v119_v_u , v119_ft_u , v119_theta_u , v119_v_O_u ; // and their updates
static double  v119_vx_init , v119_vy_init , v119_vz_init , v119_g_init , v119_v_init , v119_ft_init , v119_theta_init , v119_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v119_t1 , v119_t2 , v119_t3 , v119_t4 }; // state declarations

enum states v119 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v119_t1 ):
    if (True == False) {;}
    else if  (v119_g > (44.5)) {
      v119_vx_u = (0.3 * v119_v) ;
      v119_vy_u = 0 ;
      v119_vz_u = (0.7 * v119_v) ;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      v119_theta_u = (v119_v / 30.0) ;
      v119_v_O_u = (131.1 + (- (80.1 * pow ( ((v119_v / 30.0)) , (0.5) )))) ;
      v119_ft_u = f (v119_theta,4.0e-2) ;
      cstate =  v119_t2 ;
      force_init_update = False;
    }

    else if ( v119_v <= (44.5)
               && v119_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v119_vx_init = v119_vx ;
      slope =  (v119_vx * -8.7) ;
      v119_vx_u = (slope * d) + v119_vx ;
      if ((pstate != cstate) || force_init_update) v119_vy_init = v119_vy ;
      slope =  (v119_vy * -190.9) ;
      v119_vy_u = (slope * d) + v119_vy ;
      if ((pstate != cstate) || force_init_update) v119_vz_init = v119_vz ;
      slope =  (v119_vz * -190.4) ;
      v119_vz_u = (slope * d) + v119_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v119_t1 ;
      force_init_update = False;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      v119_v_u = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_voo = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119!\n");
      exit(1);
    }
    break;
  case ( v119_t2 ):
    if (True == False) {;}
    else if  (v119_v >= (44.5)) {
      v119_vx_u = v119_vx ;
      v119_vy_u = v119_vy ;
      v119_vz_u = v119_vz ;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v119_t3 ;
      force_init_update = False;
    }
    else if  (v119_g <= (44.5)
               && v119_v < (44.5)) {
      v119_vx_u = v119_vx ;
      v119_vy_u = v119_vy ;
      v119_vz_u = v119_vz ;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v119_t1 ;
      force_init_update = False;
    }

    else if ( v119_v < (44.5)
               && v119_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v119_vx_init = v119_vx ;
      slope =  ((v119_vx * -23.6) + (777200.0 * v119_g)) ;
      v119_vx_u = (slope * d) + v119_vx ;
      if ((pstate != cstate) || force_init_update) v119_vy_init = v119_vy ;
      slope =  ((v119_vy * -45.5) + (58900.0 * v119_g)) ;
      v119_vy_u = (slope * d) + v119_vy ;
      if ((pstate != cstate) || force_init_update) v119_vz_init = v119_vz ;
      slope =  ((v119_vz * -12.9) + (276600.0 * v119_g)) ;
      v119_vz_u = (slope * d) + v119_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v119_t2 ;
      force_init_update = False;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      v119_v_u = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_voo = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119!\n");
      exit(1);
    }
    break;
  case ( v119_t3 ):
    if (True == False) {;}
    else if  (v119_v >= (131.1)) {
      v119_vx_u = v119_vx ;
      v119_vy_u = v119_vy ;
      v119_vz_u = v119_vz ;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v119_t4 ;
      force_init_update = False;
    }

    else if ( v119_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v119_vx_init = v119_vx ;
      slope =  (v119_vx * -6.9) ;
      v119_vx_u = (slope * d) + v119_vx ;
      if ((pstate != cstate) || force_init_update) v119_vy_init = v119_vy ;
      slope =  (v119_vy * 75.9) ;
      v119_vy_u = (slope * d) + v119_vy ;
      if ((pstate != cstate) || force_init_update) v119_vz_init = v119_vz ;
      slope =  (v119_vz * 6826.5) ;
      v119_vz_u = (slope * d) + v119_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v119_t3 ;
      force_init_update = False;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      v119_v_u = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_voo = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119!\n");
      exit(1);
    }
    break;
  case ( v119_t4 ):
    if (True == False) {;}
    else if  (v119_v <= (30.0)) {
      v119_vx_u = v119_vx ;
      v119_vy_u = v119_vy ;
      v119_vz_u = v119_vz ;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v119_t1 ;
      force_init_update = False;
    }

    else if ( v119_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v119_vx_init = v119_vx ;
      slope =  (v119_vx * -33.2) ;
      v119_vx_u = (slope * d) + v119_vx ;
      if ((pstate != cstate) || force_init_update) v119_vy_init = v119_vy ;
      slope =  ((v119_vy * 20.0) * v119_ft) ;
      v119_vy_u = (slope * d) + v119_vy ;
      if ((pstate != cstate) || force_init_update) v119_vz_init = v119_vz ;
      slope =  ((v119_vz * 2.0) * v119_ft) ;
      v119_vz_u = (slope * d) + v119_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v119_t4 ;
      force_init_update = False;
      v119_g_u = ((((((((((((v119_v_i_0 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.31612947636)) + ((((v119_v_i_1 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308))) + ((((v119_v_i_2 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.79829956857))) + ((((v119_v_i_3 + (- ((v119_vx + (- v119_vy)) + v119_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87980794604))) + 0) + 0) + 0) + 0) + 0) ;
      v119_v_u = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_voo = ((v119_vx + (- v119_vy)) + v119_vz) ;
      v119_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v119!\n");
      exit(1);
    }
    break;
  }
  v119_vx = v119_vx_u;
  v119_vy = v119_vy_u;
  v119_vz = v119_vz_u;
  v119_g = v119_g_u;
  v119_v = v119_v_u;
  v119_ft = v119_ft_u;
  v119_theta = v119_theta_u;
  v119_v_O = v119_v_O_u;
  return cstate;
}