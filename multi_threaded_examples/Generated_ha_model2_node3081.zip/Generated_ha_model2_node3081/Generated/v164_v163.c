#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v164_v163_update_c1vd();
extern double v164_v163_update_c2vd();
extern double v164_v163_update_c1md();
extern double v164_v163_update_c2md();
extern double v164_v163_update_buffer_index(double,double,double,double);
extern double v164_v163_update_latch1(double,double);
extern double v164_v163_update_latch2(double,double);
extern double v164_v163_update_ocell1(double,double);
extern double v164_v163_update_ocell2(double,double);
double v164_v163_cell1_v;
double v164_v163_cell1_mode;
double v164_v163_cell2_v;
double v164_v163_cell2_mode;
double v164_v163_cell1_v_replay = 0.0;
double v164_v163_cell2_v_replay = 0.0;


static double  v164_v163_k  =  0.0 ,  v164_v163_cell1_mode_delayed  =  0.0 ,  v164_v163_cell2_mode_delayed  =  0.0 ,  v164_v163_from_cell  =  0.0 ,  v164_v163_cell1_replay_latch  =  0.0 ,  v164_v163_cell2_replay_latch  =  0.0 ,  v164_v163_cell1_v_delayed  =  0.0 ,  v164_v163_cell2_v_delayed  =  0.0 ,  v164_v163_wasted  =  0.0 ; //the continuous vars
static double  v164_v163_k_u , v164_v163_cell1_mode_delayed_u , v164_v163_cell2_mode_delayed_u , v164_v163_from_cell_u , v164_v163_cell1_replay_latch_u , v164_v163_cell2_replay_latch_u , v164_v163_cell1_v_delayed_u , v164_v163_cell2_v_delayed_u , v164_v163_wasted_u ; // and their updates
static double  v164_v163_k_init , v164_v163_cell1_mode_delayed_init , v164_v163_cell2_mode_delayed_init , v164_v163_from_cell_init , v164_v163_cell1_replay_latch_init , v164_v163_cell2_replay_latch_init , v164_v163_cell1_v_delayed_init , v164_v163_cell2_v_delayed_init , v164_v163_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v164_v163_idle , v164_v163_annhilate , v164_v163_previous_drection1 , v164_v163_previous_direction2 , v164_v163_wait_cell1 , v164_v163_replay_cell1 , v164_v163_replay_cell2 , v164_v163_wait_cell2 }; // state declarations

enum states v164_v163 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v164_v163_idle ):
    if (True == False) {;}
    else if  (v164_v163_cell2_mode == (2.0) && (v164_v163_cell1_mode != (2.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v164_v163_cell1_mode == (2.0) && (v164_v163_cell2_mode != (2.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v164_v163_cell1_mode == (2.0) && (v164_v163_cell2_mode == (2.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_idle ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_annhilate ):
    if (True == False) {;}
    else if  (v164_v163_cell1_mode != (2.0) && (v164_v163_cell2_mode != (2.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_from_cell_u = 0 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_previous_drection1 ):
    if (True == False) {;}
    else if  (v164_v163_from_cell == (1.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (0.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (2.0) && (v164_v163_cell2_mode_delayed == (0.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (2.0) && (v164_v163_cell2_mode_delayed != (0.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_previous_drection1 ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_previous_direction2 ):
    if (True == False) {;}
    else if  (v164_v163_from_cell == (1.0) && (v164_v163_cell1_mode_delayed != (0.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (2.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (0.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v164_v163_from_cell == (1.0) && (v164_v163_cell1_mode_delayed == (0.0))) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_previous_direction2 ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_wait_cell1 ):
    if (True == False) {;}
    else if  (v164_v163_cell2_mode == (2.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v164_v163_k >= (80.00362836469999)) {
      v164_v163_from_cell_u = 1 ;
      v164_v163_cell1_replay_latch_u = 1 ;
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_wait_cell1 ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_replay_cell1 ):
    if (True == False) {;}
    else if  (v164_v163_cell1_mode == (2.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v164_v163_k >= (80.00362836469999)) {
      v164_v163_from_cell_u = 2 ;
      v164_v163_cell2_replay_latch_u = 1 ;
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_replay_cell1 ;
      force_init_update = False;
      v164_v163_cell1_replay_latch_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_replay_cell2 ):
    if (True == False) {;}
    else if  (v164_v163_k >= (10.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_replay_cell2 ;
      force_init_update = False;
      v164_v163_cell2_replay_latch_u = 1 ;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  case ( v164_v163_wait_cell2 ):
    if (True == False) {;}
    else if  (v164_v163_k >= (10.0)) {
      v164_v163_k_u = 1 ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
      cstate =  v164_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v164_v163_k_init = v164_v163_k ;
      slope =  1 ;
      v164_v163_k_u = (slope * d) + v164_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v164_v163_wait_cell2 ;
      force_init_update = False;
      v164_v163_cell1_v_delayed_u = v164_v163_update_c1vd () ;
      v164_v163_cell2_v_delayed_u = v164_v163_update_c2vd () ;
      v164_v163_cell1_mode_delayed_u = v164_v163_update_c1md () ;
      v164_v163_cell2_mode_delayed_u = v164_v163_update_c2md () ;
      v164_v163_wasted_u = v164_v163_update_buffer_index (v164_v163_cell1_v,v164_v163_cell2_v,v164_v163_cell1_mode,v164_v163_cell2_mode) ;
      v164_v163_cell1_replay_latch_u = v164_v163_update_latch1 (v164_v163_cell1_mode_delayed,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_replay_latch_u = v164_v163_update_latch2 (v164_v163_cell2_mode_delayed,v164_v163_cell2_replay_latch_u) ;
      v164_v163_cell1_v_replay = v164_v163_update_ocell1 (v164_v163_cell1_v_delayed_u,v164_v163_cell1_replay_latch_u) ;
      v164_v163_cell2_v_replay = v164_v163_update_ocell2 (v164_v163_cell2_v_delayed_u,v164_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v164_v163!\n");
      exit(1);
    }
    break;
  }
  v164_v163_k = v164_v163_k_u;
  v164_v163_cell1_mode_delayed = v164_v163_cell1_mode_delayed_u;
  v164_v163_cell2_mode_delayed = v164_v163_cell2_mode_delayed_u;
  v164_v163_from_cell = v164_v163_from_cell_u;
  v164_v163_cell1_replay_latch = v164_v163_cell1_replay_latch_u;
  v164_v163_cell2_replay_latch = v164_v163_cell2_replay_latch_u;
  v164_v163_cell1_v_delayed = v164_v163_cell1_v_delayed_u;
  v164_v163_cell2_v_delayed = v164_v163_cell2_v_delayed_u;
  v164_v163_wasted = v164_v163_wasted_u;
  return cstate;
}