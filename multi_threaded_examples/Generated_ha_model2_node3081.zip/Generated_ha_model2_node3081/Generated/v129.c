#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v129_v_i_0;
double v129_v_i_1;
double v129_v_i_2;
double v129_v_i_3;
double v129_voo = 0.0;
double v129_state = 0.0;


static double  v129_vx  =  0 ,  v129_vy  =  0 ,  v129_vz  =  0 ,  v129_g  =  0 ,  v129_v  =  0 ,  v129_ft  =  0 ,  v129_theta  =  0 ,  v129_v_O  =  0 ; //the continuous vars
static double  v129_vx_u , v129_vy_u , v129_vz_u , v129_g_u , v129_v_u , v129_ft_u , v129_theta_u , v129_v_O_u ; // and their updates
static double  v129_vx_init , v129_vy_init , v129_vz_init , v129_g_init , v129_v_init , v129_ft_init , v129_theta_init , v129_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v129_t1 , v129_t2 , v129_t3 , v129_t4 }; // state declarations

enum states v129 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v129_t1 ):
    if (True == False) {;}
    else if  (v129_g > (44.5)) {
      v129_vx_u = (0.3 * v129_v) ;
      v129_vy_u = 0 ;
      v129_vz_u = (0.7 * v129_v) ;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      v129_theta_u = (v129_v / 30.0) ;
      v129_v_O_u = (131.1 + (- (80.1 * pow ( ((v129_v / 30.0)) , (0.5) )))) ;
      v129_ft_u = f (v129_theta,4.0e-2) ;
      cstate =  v129_t2 ;
      force_init_update = False;
    }

    else if ( v129_v <= (44.5)
               && v129_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v129_vx_init = v129_vx ;
      slope =  (v129_vx * -8.7) ;
      v129_vx_u = (slope * d) + v129_vx ;
      if ((pstate != cstate) || force_init_update) v129_vy_init = v129_vy ;
      slope =  (v129_vy * -190.9) ;
      v129_vy_u = (slope * d) + v129_vy ;
      if ((pstate != cstate) || force_init_update) v129_vz_init = v129_vz ;
      slope =  (v129_vz * -190.4) ;
      v129_vz_u = (slope * d) + v129_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v129_t1 ;
      force_init_update = False;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      v129_v_u = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_voo = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129!\n");
      exit(1);
    }
    break;
  case ( v129_t2 ):
    if (True == False) {;}
    else if  (v129_v >= (44.5)) {
      v129_vx_u = v129_vx ;
      v129_vy_u = v129_vy ;
      v129_vz_u = v129_vz ;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v129_t3 ;
      force_init_update = False;
    }
    else if  (v129_g <= (44.5)
               && v129_v < (44.5)) {
      v129_vx_u = v129_vx ;
      v129_vy_u = v129_vy ;
      v129_vz_u = v129_vz ;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v129_t1 ;
      force_init_update = False;
    }

    else if ( v129_v < (44.5)
               && v129_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v129_vx_init = v129_vx ;
      slope =  ((v129_vx * -23.6) + (777200.0 * v129_g)) ;
      v129_vx_u = (slope * d) + v129_vx ;
      if ((pstate != cstate) || force_init_update) v129_vy_init = v129_vy ;
      slope =  ((v129_vy * -45.5) + (58900.0 * v129_g)) ;
      v129_vy_u = (slope * d) + v129_vy ;
      if ((pstate != cstate) || force_init_update) v129_vz_init = v129_vz ;
      slope =  ((v129_vz * -12.9) + (276600.0 * v129_g)) ;
      v129_vz_u = (slope * d) + v129_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v129_t2 ;
      force_init_update = False;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      v129_v_u = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_voo = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129!\n");
      exit(1);
    }
    break;
  case ( v129_t3 ):
    if (True == False) {;}
    else if  (v129_v >= (131.1)) {
      v129_vx_u = v129_vx ;
      v129_vy_u = v129_vy ;
      v129_vz_u = v129_vz ;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v129_t4 ;
      force_init_update = False;
    }

    else if ( v129_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v129_vx_init = v129_vx ;
      slope =  (v129_vx * -6.9) ;
      v129_vx_u = (slope * d) + v129_vx ;
      if ((pstate != cstate) || force_init_update) v129_vy_init = v129_vy ;
      slope =  (v129_vy * 75.9) ;
      v129_vy_u = (slope * d) + v129_vy ;
      if ((pstate != cstate) || force_init_update) v129_vz_init = v129_vz ;
      slope =  (v129_vz * 6826.5) ;
      v129_vz_u = (slope * d) + v129_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v129_t3 ;
      force_init_update = False;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      v129_v_u = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_voo = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129!\n");
      exit(1);
    }
    break;
  case ( v129_t4 ):
    if (True == False) {;}
    else if  (v129_v <= (30.0)) {
      v129_vx_u = v129_vx ;
      v129_vy_u = v129_vy ;
      v129_vz_u = v129_vz ;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v129_t1 ;
      force_init_update = False;
    }

    else if ( v129_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v129_vx_init = v129_vx ;
      slope =  (v129_vx * -33.2) ;
      v129_vx_u = (slope * d) + v129_vx ;
      if ((pstate != cstate) || force_init_update) v129_vy_init = v129_vy ;
      slope =  ((v129_vy * 20.0) * v129_ft) ;
      v129_vy_u = (slope * d) + v129_vy ;
      if ((pstate != cstate) || force_init_update) v129_vz_init = v129_vz ;
      slope =  ((v129_vz * 2.0) * v129_ft) ;
      v129_vz_u = (slope * d) + v129_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v129_t4 ;
      force_init_update = False;
      v129_g_u = ((((((((((((v129_v_i_0 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924)) + ((((v129_v_i_1 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v129_v_i_2 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44129492332))) + ((((v129_v_i_3 + (- ((v129_vx + (- v129_vy)) + v129_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.04168145934))) + 0) + 0) + 0) + 0) + 0) ;
      v129_v_u = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_voo = ((v129_vx + (- v129_vy)) + v129_vz) ;
      v129_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v129!\n");
      exit(1);
    }
    break;
  }
  v129_vx = v129_vx_u;
  v129_vy = v129_vy_u;
  v129_vz = v129_vz_u;
  v129_g = v129_g_u;
  v129_v = v129_v_u;
  v129_ft = v129_ft_u;
  v129_theta = v129_theta_u;
  v129_v_O = v129_v_O_u;
  return cstate;
}