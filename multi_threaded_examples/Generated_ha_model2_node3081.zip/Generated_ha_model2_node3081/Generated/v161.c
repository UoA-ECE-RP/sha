#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v161_v_i_0;
double v161_v_i_1;
double v161_v_i_2;
double v161_v_i_3;
double v161_voo = 0.0;
double v161_state = 0.0;


static double  v161_vx  =  0 ,  v161_vy  =  0 ,  v161_vz  =  0 ,  v161_g  =  0 ,  v161_v  =  0 ,  v161_ft  =  0 ,  v161_theta  =  0 ,  v161_v_O  =  0 ; //the continuous vars
static double  v161_vx_u , v161_vy_u , v161_vz_u , v161_g_u , v161_v_u , v161_ft_u , v161_theta_u , v161_v_O_u ; // and their updates
static double  v161_vx_init , v161_vy_init , v161_vz_init , v161_g_init , v161_v_init , v161_ft_init , v161_theta_init , v161_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v161_t1 , v161_t2 , v161_t3 , v161_t4 }; // state declarations

enum states v161 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v161_t1 ):
    if (True == False) {;}
    else if  (v161_g > (44.5)) {
      v161_vx_u = (0.3 * v161_v) ;
      v161_vy_u = 0 ;
      v161_vz_u = (0.7 * v161_v) ;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      v161_theta_u = (v161_v / 30.0) ;
      v161_v_O_u = (131.1 + (- (80.1 * pow ( ((v161_v / 30.0)) , (0.5) )))) ;
      v161_ft_u = f (v161_theta,4.0e-2) ;
      cstate =  v161_t2 ;
      force_init_update = False;
    }

    else if ( v161_v <= (44.5)
               && v161_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v161_vx_init = v161_vx ;
      slope =  (v161_vx * -8.7) ;
      v161_vx_u = (slope * d) + v161_vx ;
      if ((pstate != cstate) || force_init_update) v161_vy_init = v161_vy ;
      slope =  (v161_vy * -190.9) ;
      v161_vy_u = (slope * d) + v161_vy ;
      if ((pstate != cstate) || force_init_update) v161_vz_init = v161_vz ;
      slope =  (v161_vz * -190.4) ;
      v161_vz_u = (slope * d) + v161_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v161_t1 ;
      force_init_update = False;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      v161_v_u = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_voo = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161!\n");
      exit(1);
    }
    break;
  case ( v161_t2 ):
    if (True == False) {;}
    else if  (v161_v >= (44.5)) {
      v161_vx_u = v161_vx ;
      v161_vy_u = v161_vy ;
      v161_vz_u = v161_vz ;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v161_t3 ;
      force_init_update = False;
    }
    else if  (v161_g <= (44.5)
               && v161_v < (44.5)) {
      v161_vx_u = v161_vx ;
      v161_vy_u = v161_vy ;
      v161_vz_u = v161_vz ;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v161_t1 ;
      force_init_update = False;
    }

    else if ( v161_v < (44.5)
               && v161_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v161_vx_init = v161_vx ;
      slope =  ((v161_vx * -23.6) + (777200.0 * v161_g)) ;
      v161_vx_u = (slope * d) + v161_vx ;
      if ((pstate != cstate) || force_init_update) v161_vy_init = v161_vy ;
      slope =  ((v161_vy * -45.5) + (58900.0 * v161_g)) ;
      v161_vy_u = (slope * d) + v161_vy ;
      if ((pstate != cstate) || force_init_update) v161_vz_init = v161_vz ;
      slope =  ((v161_vz * -12.9) + (276600.0 * v161_g)) ;
      v161_vz_u = (slope * d) + v161_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v161_t2 ;
      force_init_update = False;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      v161_v_u = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_voo = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161!\n");
      exit(1);
    }
    break;
  case ( v161_t3 ):
    if (True == False) {;}
    else if  (v161_v >= (131.1)) {
      v161_vx_u = v161_vx ;
      v161_vy_u = v161_vy ;
      v161_vz_u = v161_vz ;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v161_t4 ;
      force_init_update = False;
    }

    else if ( v161_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v161_vx_init = v161_vx ;
      slope =  (v161_vx * -6.9) ;
      v161_vx_u = (slope * d) + v161_vx ;
      if ((pstate != cstate) || force_init_update) v161_vy_init = v161_vy ;
      slope =  (v161_vy * 75.9) ;
      v161_vy_u = (slope * d) + v161_vy ;
      if ((pstate != cstate) || force_init_update) v161_vz_init = v161_vz ;
      slope =  (v161_vz * 6826.5) ;
      v161_vz_u = (slope * d) + v161_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v161_t3 ;
      force_init_update = False;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      v161_v_u = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_voo = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161!\n");
      exit(1);
    }
    break;
  case ( v161_t4 ):
    if (True == False) {;}
    else if  (v161_v <= (30.0)) {
      v161_vx_u = v161_vx ;
      v161_vy_u = v161_vy ;
      v161_vz_u = v161_vz ;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v161_t1 ;
      force_init_update = False;
    }

    else if ( v161_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v161_vx_init = v161_vx ;
      slope =  (v161_vx * -33.2) ;
      v161_vx_u = (slope * d) + v161_vx ;
      if ((pstate != cstate) || force_init_update) v161_vy_init = v161_vy ;
      slope =  ((v161_vy * 20.0) * v161_ft) ;
      v161_vy_u = (slope * d) + v161_vy ;
      if ((pstate != cstate) || force_init_update) v161_vz_init = v161_vz ;
      slope =  ((v161_vz * 2.0) * v161_ft) ;
      v161_vz_u = (slope * d) + v161_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v161_t4 ;
      force_init_update = False;
      v161_g_u = ((((((((((((v161_v_i_0 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v161_v_i_1 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + ((((v161_v_i_2 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v161_v_i_3 + (- ((v161_vx + (- v161_vy)) + v161_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.09435512791))) + 0) + 0) + 0) + 0) + 0) ;
      v161_v_u = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_voo = ((v161_vx + (- v161_vy)) + v161_vz) ;
      v161_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161!\n");
      exit(1);
    }
    break;
  }
  v161_vx = v161_vx_u;
  v161_vy = v161_vy_u;
  v161_vz = v161_vz_u;
  v161_g = v161_g_u;
  v161_v = v161_v_u;
  v161_ft = v161_ft_u;
  v161_theta = v161_theta_u;
  v161_v_O = v161_v_O_u;
  return cstate;
}