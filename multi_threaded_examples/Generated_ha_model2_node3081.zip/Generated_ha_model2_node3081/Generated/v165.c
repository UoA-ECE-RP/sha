#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v165_v_i_0;
double v165_v_i_1;
double v165_v_i_2;
double v165_v_i_3;
double v165_voo = 0.0;
double v165_state = 0.0;


static double  v165_vx  =  0 ,  v165_vy  =  0 ,  v165_vz  =  0 ,  v165_g  =  0 ,  v165_v  =  0 ,  v165_ft  =  0 ,  v165_theta  =  0 ,  v165_v_O  =  0 ; //the continuous vars
static double  v165_vx_u , v165_vy_u , v165_vz_u , v165_g_u , v165_v_u , v165_ft_u , v165_theta_u , v165_v_O_u ; // and their updates
static double  v165_vx_init , v165_vy_init , v165_vz_init , v165_g_init , v165_v_init , v165_ft_init , v165_theta_init , v165_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v165_t1 , v165_t2 , v165_t3 , v165_t4 }; // state declarations

enum states v165 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v165_t1 ):
    if (True == False) {;}
    else if  (v165_g > (44.5)) {
      v165_vx_u = (0.3 * v165_v) ;
      v165_vy_u = 0 ;
      v165_vz_u = (0.7 * v165_v) ;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v165_theta_u = (v165_v / 30.0) ;
      v165_v_O_u = (131.1 + (- (80.1 * pow ( ((v165_v / 30.0)) , (0.5) )))) ;
      v165_ft_u = f (v165_theta,4.0e-2) ;
      cstate =  v165_t2 ;
      force_init_update = False;
    }

    else if ( v165_v <= (44.5)
               && v165_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v165_vx_init = v165_vx ;
      slope =  (v165_vx * -8.7) ;
      v165_vx_u = (slope * d) + v165_vx ;
      if ((pstate != cstate) || force_init_update) v165_vy_init = v165_vy ;
      slope =  (v165_vy * -190.9) ;
      v165_vy_u = (slope * d) + v165_vy ;
      if ((pstate != cstate) || force_init_update) v165_vz_init = v165_vz ;
      slope =  (v165_vz * -190.4) ;
      v165_vz_u = (slope * d) + v165_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v165_t1 ;
      force_init_update = False;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v165_v_u = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_voo = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v165!\n");
      exit(1);
    }
    break;
  case ( v165_t2 ):
    if (True == False) {;}
    else if  (v165_v >= (44.5)) {
      v165_vx_u = v165_vx ;
      v165_vy_u = v165_vy ;
      v165_vz_u = v165_vz ;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v165_t3 ;
      force_init_update = False;
    }
    else if  (v165_g <= (44.5)
               && v165_v < (44.5)) {
      v165_vx_u = v165_vx ;
      v165_vy_u = v165_vy ;
      v165_vz_u = v165_vz ;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v165_t1 ;
      force_init_update = False;
    }

    else if ( v165_v < (44.5)
               && v165_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v165_vx_init = v165_vx ;
      slope =  ((v165_vx * -23.6) + (777200.0 * v165_g)) ;
      v165_vx_u = (slope * d) + v165_vx ;
      if ((pstate != cstate) || force_init_update) v165_vy_init = v165_vy ;
      slope =  ((v165_vy * -45.5) + (58900.0 * v165_g)) ;
      v165_vy_u = (slope * d) + v165_vy ;
      if ((pstate != cstate) || force_init_update) v165_vz_init = v165_vz ;
      slope =  ((v165_vz * -12.9) + (276600.0 * v165_g)) ;
      v165_vz_u = (slope * d) + v165_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v165_t2 ;
      force_init_update = False;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v165_v_u = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_voo = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v165!\n");
      exit(1);
    }
    break;
  case ( v165_t3 ):
    if (True == False) {;}
    else if  (v165_v >= (131.1)) {
      v165_vx_u = v165_vx ;
      v165_vy_u = v165_vy ;
      v165_vz_u = v165_vz ;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v165_t4 ;
      force_init_update = False;
    }

    else if ( v165_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v165_vx_init = v165_vx ;
      slope =  (v165_vx * -6.9) ;
      v165_vx_u = (slope * d) + v165_vx ;
      if ((pstate != cstate) || force_init_update) v165_vy_init = v165_vy ;
      slope =  (v165_vy * 75.9) ;
      v165_vy_u = (slope * d) + v165_vy ;
      if ((pstate != cstate) || force_init_update) v165_vz_init = v165_vz ;
      slope =  (v165_vz * 6826.5) ;
      v165_vz_u = (slope * d) + v165_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v165_t3 ;
      force_init_update = False;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v165_v_u = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_voo = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v165!\n");
      exit(1);
    }
    break;
  case ( v165_t4 ):
    if (True == False) {;}
    else if  (v165_v <= (30.0)) {
      v165_vx_u = v165_vx ;
      v165_vy_u = v165_vy ;
      v165_vz_u = v165_vz ;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v165_t1 ;
      force_init_update = False;
    }

    else if ( v165_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v165_vx_init = v165_vx ;
      slope =  (v165_vx * -33.2) ;
      v165_vx_u = (slope * d) + v165_vx ;
      if ((pstate != cstate) || force_init_update) v165_vy_init = v165_vy ;
      slope =  ((v165_vy * 20.0) * v165_ft) ;
      v165_vy_u = (slope * d) + v165_vy ;
      if ((pstate != cstate) || force_init_update) v165_vz_init = v165_vz ;
      slope =  ((v165_vz * 2.0) * v165_ft) ;
      v165_vz_u = (slope * d) + v165_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v165_t4 ;
      force_init_update = False;
      v165_g_u = ((((((((((((v165_v_i_0 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v165_v_i_1 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v165_v_i_2 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v165_v_i_3 + (- ((v165_vx + (- v165_vy)) + v165_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.8510653387))) + 0) + 0) + 0) + 0) + 0) ;
      v165_v_u = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_voo = ((v165_vx + (- v165_vy)) + v165_vz) ;
      v165_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v165!\n");
      exit(1);
    }
    break;
  }
  v165_vx = v165_vx_u;
  v165_vy = v165_vy_u;
  v165_vz = v165_vz_u;
  v165_g = v165_g_u;
  v165_v = v165_v_u;
  v165_ft = v165_ft_u;
  v165_theta = v165_theta_u;
  v165_v_O = v165_v_O_u;
  return cstate;
}