#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v15_v_i_0;
double v15_v_i_1;
double v15_v_i_2;
double v15_voo = 0.0;
double v15_state = 0.0;


static double  v15_vx  =  0 ,  v15_vy  =  0 ,  v15_vz  =  0 ,  v15_g  =  0 ,  v15_v  =  0 ,  v15_ft  =  0 ,  v15_theta  =  0 ,  v15_v_O  =  0 ; //the continuous vars
static double  v15_vx_u , v15_vy_u , v15_vz_u , v15_g_u , v15_v_u , v15_ft_u , v15_theta_u , v15_v_O_u ; // and their updates
static double  v15_vx_init , v15_vy_init , v15_vz_init , v15_g_init , v15_v_init , v15_ft_init , v15_theta_init , v15_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v15_t1 , v15_t2 , v15_t3 , v15_t4 }; // state declarations

enum states v15 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v15_t1 ):
    if (True == False) {;}
    else if  (v15_g > (44.5)) {
      v15_vx_u = (0.3 * v15_v) ;
      v15_vy_u = 0 ;
      v15_vz_u = (0.7 * v15_v) ;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v15_theta_u = (v15_v / 30.0) ;
      v15_v_O_u = (131.1 + (- (80.1 * pow ( ((v15_v / 30.0)) , (0.5) )))) ;
      v15_ft_u = f (v15_theta,4.0e-2) ;
      cstate =  v15_t2 ;
      force_init_update = False;
    }

    else if ( v15_v <= (44.5)
               && v15_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v15_vx_init = v15_vx ;
      slope =  (v15_vx * -8.7) ;
      v15_vx_u = (slope * d) + v15_vx ;
      if ((pstate != cstate) || force_init_update) v15_vy_init = v15_vy ;
      slope =  (v15_vy * -190.9) ;
      v15_vy_u = (slope * d) + v15_vy ;
      if ((pstate != cstate) || force_init_update) v15_vz_init = v15_vz ;
      slope =  (v15_vz * -190.4) ;
      v15_vz_u = (slope * d) + v15_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v15_t1 ;
      force_init_update = False;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v15_v_u = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_voo = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v15!\n");
      exit(1);
    }
    break;
  case ( v15_t2 ):
    if (True == False) {;}
    else if  (v15_v >= (44.5)) {
      v15_vx_u = v15_vx ;
      v15_vy_u = v15_vy ;
      v15_vz_u = v15_vz ;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v15_t3 ;
      force_init_update = False;
    }
    else if  (v15_g <= (44.5)
               && v15_v < (44.5)) {
      v15_vx_u = v15_vx ;
      v15_vy_u = v15_vy ;
      v15_vz_u = v15_vz ;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v15_t1 ;
      force_init_update = False;
    }

    else if ( v15_v < (44.5) && 
              v15_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v15_vx_init = v15_vx ;
      slope =  ((v15_vx * -23.6) + (777200.0 * v15_g)) ;
      v15_vx_u = (slope * d) + v15_vx ;
      if ((pstate != cstate) || force_init_update) v15_vy_init = v15_vy ;
      slope =  ((v15_vy * -45.5) + (58900.0 * v15_g)) ;
      v15_vy_u = (slope * d) + v15_vy ;
      if ((pstate != cstate) || force_init_update) v15_vz_init = v15_vz ;
      slope =  ((v15_vz * -12.9) + (276600.0 * v15_g)) ;
      v15_vz_u = (slope * d) + v15_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v15_t2 ;
      force_init_update = False;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v15_v_u = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_voo = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v15!\n");
      exit(1);
    }
    break;
  case ( v15_t3 ):
    if (True == False) {;}
    else if  (v15_v >= (131.1)) {
      v15_vx_u = v15_vx ;
      v15_vy_u = v15_vy ;
      v15_vz_u = v15_vz ;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v15_t4 ;
      force_init_update = False;
    }

    else if ( v15_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v15_vx_init = v15_vx ;
      slope =  (v15_vx * -6.9) ;
      v15_vx_u = (slope * d) + v15_vx ;
      if ((pstate != cstate) || force_init_update) v15_vy_init = v15_vy ;
      slope =  (v15_vy * 75.9) ;
      v15_vy_u = (slope * d) + v15_vy ;
      if ((pstate != cstate) || force_init_update) v15_vz_init = v15_vz ;
      slope =  (v15_vz * 6826.5) ;
      v15_vz_u = (slope * d) + v15_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v15_t3 ;
      force_init_update = False;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v15_v_u = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_voo = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v15!\n");
      exit(1);
    }
    break;
  case ( v15_t4 ):
    if (True == False) {;}
    else if  (v15_v <= (30.0)) {
      v15_vx_u = v15_vx ;
      v15_vy_u = v15_vy ;
      v15_vz_u = v15_vz ;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v15_t1 ;
      force_init_update = False;
    }

    else if ( v15_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v15_vx_init = v15_vx ;
      slope =  (v15_vx * -33.2) ;
      v15_vx_u = (slope * d) + v15_vx ;
      if ((pstate != cstate) || force_init_update) v15_vy_init = v15_vy ;
      slope =  ((v15_vy * 20.0) * v15_ft) ;
      v15_vy_u = (slope * d) + v15_vy ;
      if ((pstate != cstate) || force_init_update) v15_vz_init = v15_vz ;
      slope =  ((v15_vz * 2.0) * v15_ft) ;
      v15_vz_u = (slope * d) + v15_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v15_t4 ;
      force_init_update = False;
      v15_g_u = ((((((((((((v15_v_i_0 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v15_v_i_1 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v15_v_i_2 + (- ((v15_vx + (- v15_vy)) + v15_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.302138931232))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v15_v_u = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_voo = ((v15_vx + (- v15_vy)) + v15_vz) ;
      v15_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v15!\n");
      exit(1);
    }
    break;
  }
  v15_vx = v15_vx_u;
  v15_vy = v15_vy_u;
  v15_vz = v15_vz_u;
  v15_g = v15_g_u;
  v15_v = v15_v_u;
  v15_ft = v15_ft_u;
  v15_theta = v15_theta_u;
  v15_v_O = v15_v_O_u;
  return cstate;
}