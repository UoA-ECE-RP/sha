#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v117_v116_update_c1vd();
extern double v117_v116_update_c2vd();
extern double v117_v116_update_c1md();
extern double v117_v116_update_c2md();
extern double v117_v116_update_buffer_index(double,double,double,double);
extern double v117_v116_update_latch1(double,double);
extern double v117_v116_update_latch2(double,double);
extern double v117_v116_update_ocell1(double,double);
extern double v117_v116_update_ocell2(double,double);
double v117_v116_cell1_v;
double v117_v116_cell1_mode;
double v117_v116_cell2_v;
double v117_v116_cell2_mode;
double v117_v116_cell1_v_replay = 0.0;
double v117_v116_cell2_v_replay = 0.0;


static double  v117_v116_k  =  0.0 ,  v117_v116_cell1_mode_delayed  =  0.0 ,  v117_v116_cell2_mode_delayed  =  0.0 ,  v117_v116_from_cell  =  0.0 ,  v117_v116_cell1_replay_latch  =  0.0 ,  v117_v116_cell2_replay_latch  =  0.0 ,  v117_v116_cell1_v_delayed  =  0.0 ,  v117_v116_cell2_v_delayed  =  0.0 ,  v117_v116_wasted  =  0.0 ; //the continuous vars
static double  v117_v116_k_u , v117_v116_cell1_mode_delayed_u , v117_v116_cell2_mode_delayed_u , v117_v116_from_cell_u , v117_v116_cell1_replay_latch_u , v117_v116_cell2_replay_latch_u , v117_v116_cell1_v_delayed_u , v117_v116_cell2_v_delayed_u , v117_v116_wasted_u ; // and their updates
static double  v117_v116_k_init , v117_v116_cell1_mode_delayed_init , v117_v116_cell2_mode_delayed_init , v117_v116_from_cell_init , v117_v116_cell1_replay_latch_init , v117_v116_cell2_replay_latch_init , v117_v116_cell1_v_delayed_init , v117_v116_cell2_v_delayed_init , v117_v116_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v117_v116_idle , v117_v116_annhilate , v117_v116_previous_drection1 , v117_v116_previous_direction2 , v117_v116_wait_cell1 , v117_v116_replay_cell1 , v117_v116_replay_cell2 , v117_v116_wait_cell2 }; // state declarations

enum states v117_v116 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v117_v116_idle ):
    if (True == False) {;}
    else if  (v117_v116_cell2_mode == (2.0) && (v117_v116_cell1_mode != (2.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v117_v116_cell1_mode == (2.0) && (v117_v116_cell2_mode != (2.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v117_v116_cell1_mode == (2.0) && (v117_v116_cell2_mode == (2.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_idle ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_annhilate ):
    if (True == False) {;}
    else if  (v117_v116_cell1_mode != (2.0) && (v117_v116_cell2_mode != (2.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_from_cell_u = 0 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_previous_drection1 ):
    if (True == False) {;}
    else if  (v117_v116_from_cell == (1.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (0.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (2.0) && (v117_v116_cell2_mode_delayed == (0.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (2.0) && (v117_v116_cell2_mode_delayed != (0.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_previous_drection1 ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_previous_direction2 ):
    if (True == False) {;}
    else if  (v117_v116_from_cell == (1.0) && (v117_v116_cell1_mode_delayed != (0.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (2.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (0.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v117_v116_from_cell == (1.0) && (v117_v116_cell1_mode_delayed == (0.0))) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_previous_direction2 ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_wait_cell1 ):
    if (True == False) {;}
    else if  (v117_v116_cell2_mode == (2.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
    }
    else if  (v117_v116_k >= (44.8904134828)) {
      v117_v116_from_cell_u = 1 ;
      v117_v116_cell1_replay_latch_u = 1 ;
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_wait_cell1 ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_replay_cell1 ):
    if (True == False) {;}
    else if  (v117_v116_cell1_mode == (2.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_annhilate ;
      force_init_update = False;
    }
    else if  (v117_v116_k >= (44.8904134828)) {
      v117_v116_from_cell_u = 2 ;
      v117_v116_cell2_replay_latch_u = 1 ;
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_replay_cell1 ;
      force_init_update = False;
      v117_v116_cell1_replay_latch_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_replay_cell2 ):
    if (True == False) {;}
    else if  (v117_v116_k >= (10.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_replay_cell2 ;
      force_init_update = False;
      v117_v116_cell2_replay_latch_u = 1 ;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  case ( v117_v116_wait_cell2 ):
    if (True == False) {;}
    else if  (v117_v116_k >= (10.0)) {
      v117_v116_k_u = 1 ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
      cstate =  v117_v116_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v117_v116_k_init = v117_v116_k ;
      slope =  1 ;
      v117_v116_k_u = (slope * d) + v117_v116_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v117_v116_wait_cell2 ;
      force_init_update = False;
      v117_v116_cell1_v_delayed_u = v117_v116_update_c1vd () ;
      v117_v116_cell2_v_delayed_u = v117_v116_update_c2vd () ;
      v117_v116_cell1_mode_delayed_u = v117_v116_update_c1md () ;
      v117_v116_cell2_mode_delayed_u = v117_v116_update_c2md () ;
      v117_v116_wasted_u = v117_v116_update_buffer_index (v117_v116_cell1_v,v117_v116_cell2_v,v117_v116_cell1_mode,v117_v116_cell2_mode) ;
      v117_v116_cell1_replay_latch_u = v117_v116_update_latch1 (v117_v116_cell1_mode_delayed,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_replay_latch_u = v117_v116_update_latch2 (v117_v116_cell2_mode_delayed,v117_v116_cell2_replay_latch_u) ;
      v117_v116_cell1_v_replay = v117_v116_update_ocell1 (v117_v116_cell1_v_delayed_u,v117_v116_cell1_replay_latch_u) ;
      v117_v116_cell2_v_replay = v117_v116_update_ocell2 (v117_v116_cell2_v_delayed_u,v117_v116_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117_v116!\n");
      exit(1);
    }
    break;
  }
  v117_v116_k = v117_v116_k_u;
  v117_v116_cell1_mode_delayed = v117_v116_cell1_mode_delayed_u;
  v117_v116_cell2_mode_delayed = v117_v116_cell2_mode_delayed_u;
  v117_v116_from_cell = v117_v116_from_cell_u;
  v117_v116_cell1_replay_latch = v117_v116_cell1_replay_latch_u;
  v117_v116_cell2_replay_latch = v117_v116_cell2_replay_latch_u;
  v117_v116_cell1_v_delayed = v117_v116_cell1_v_delayed_u;
  v117_v116_cell2_v_delayed = v117_v116_cell2_v_delayed_u;
  v117_v116_wasted = v117_v116_wasted_u;
  return cstate;
}