#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v169_v_i_0;
double v169_v_i_1;
double v169_v_i_2;
double v169_v_i_3;
double v169_voo = 0.0;
double v169_state = 0.0;


static double  v169_vx  =  0 ,  v169_vy  =  0 ,  v169_vz  =  0 ,  v169_g  =  0 ,  v169_v  =  0 ,  v169_ft  =  0 ,  v169_theta  =  0 ,  v169_v_O  =  0 ; //the continuous vars
static double  v169_vx_u , v169_vy_u , v169_vz_u , v169_g_u , v169_v_u , v169_ft_u , v169_theta_u , v169_v_O_u ; // and their updates
static double  v169_vx_init , v169_vy_init , v169_vz_init , v169_g_init , v169_v_init , v169_ft_init , v169_theta_init , v169_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v169_t1 , v169_t2 , v169_t3 , v169_t4 }; // state declarations

enum states v169 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v169_t1 ):
    if (True == False) {;}
    else if  (v169_g > (44.5)) {
      v169_vx_u = (0.3 * v169_v) ;
      v169_vy_u = 0 ;
      v169_vz_u = (0.7 * v169_v) ;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      v169_theta_u = (v169_v / 30.0) ;
      v169_v_O_u = (131.1 + (- (80.1 * pow ( ((v169_v / 30.0)) , (0.5) )))) ;
      v169_ft_u = f (v169_theta,4.0e-2) ;
      cstate =  v169_t2 ;
      force_init_update = False;
    }

    else if ( v169_v <= (44.5)
               && v169_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v169_vx_init = v169_vx ;
      slope =  (v169_vx * -8.7) ;
      v169_vx_u = (slope * d) + v169_vx ;
      if ((pstate != cstate) || force_init_update) v169_vy_init = v169_vy ;
      slope =  (v169_vy * -190.9) ;
      v169_vy_u = (slope * d) + v169_vy ;
      if ((pstate != cstate) || force_init_update) v169_vz_init = v169_vz ;
      slope =  (v169_vz * -190.4) ;
      v169_vz_u = (slope * d) + v169_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v169_t1 ;
      force_init_update = False;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      v169_v_u = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_voo = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v169!\n");
      exit(1);
    }
    break;
  case ( v169_t2 ):
    if (True == False) {;}
    else if  (v169_v >= (44.5)) {
      v169_vx_u = v169_vx ;
      v169_vy_u = v169_vy ;
      v169_vz_u = v169_vz ;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v169_t3 ;
      force_init_update = False;
    }
    else if  (v169_g <= (44.5)
               && v169_v < (44.5)) {
      v169_vx_u = v169_vx ;
      v169_vy_u = v169_vy ;
      v169_vz_u = v169_vz ;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v169_t1 ;
      force_init_update = False;
    }

    else if ( v169_v < (44.5)
               && v169_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v169_vx_init = v169_vx ;
      slope =  ((v169_vx * -23.6) + (777200.0 * v169_g)) ;
      v169_vx_u = (slope * d) + v169_vx ;
      if ((pstate != cstate) || force_init_update) v169_vy_init = v169_vy ;
      slope =  ((v169_vy * -45.5) + (58900.0 * v169_g)) ;
      v169_vy_u = (slope * d) + v169_vy ;
      if ((pstate != cstate) || force_init_update) v169_vz_init = v169_vz ;
      slope =  ((v169_vz * -12.9) + (276600.0 * v169_g)) ;
      v169_vz_u = (slope * d) + v169_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v169_t2 ;
      force_init_update = False;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      v169_v_u = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_voo = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v169!\n");
      exit(1);
    }
    break;
  case ( v169_t3 ):
    if (True == False) {;}
    else if  (v169_v >= (131.1)) {
      v169_vx_u = v169_vx ;
      v169_vy_u = v169_vy ;
      v169_vz_u = v169_vz ;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v169_t4 ;
      force_init_update = False;
    }

    else if ( v169_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v169_vx_init = v169_vx ;
      slope =  (v169_vx * -6.9) ;
      v169_vx_u = (slope * d) + v169_vx ;
      if ((pstate != cstate) || force_init_update) v169_vy_init = v169_vy ;
      slope =  (v169_vy * 75.9) ;
      v169_vy_u = (slope * d) + v169_vy ;
      if ((pstate != cstate) || force_init_update) v169_vz_init = v169_vz ;
      slope =  (v169_vz * 6826.5) ;
      v169_vz_u = (slope * d) + v169_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v169_t3 ;
      force_init_update = False;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      v169_v_u = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_voo = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v169!\n");
      exit(1);
    }
    break;
  case ( v169_t4 ):
    if (True == False) {;}
    else if  (v169_v <= (30.0)) {
      v169_vx_u = v169_vx ;
      v169_vy_u = v169_vy ;
      v169_vz_u = v169_vz ;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v169_t1 ;
      force_init_update = False;
    }

    else if ( v169_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v169_vx_init = v169_vx ;
      slope =  (v169_vx * -33.2) ;
      v169_vx_u = (slope * d) + v169_vx ;
      if ((pstate != cstate) || force_init_update) v169_vy_init = v169_vy ;
      slope =  ((v169_vy * 20.0) * v169_ft) ;
      v169_vy_u = (slope * d) + v169_vy ;
      if ((pstate != cstate) || force_init_update) v169_vz_init = v169_vz ;
      slope =  ((v169_vz * 2.0) * v169_ft) ;
      v169_vz_u = (slope * d) + v169_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v169_t4 ;
      force_init_update = False;
      v169_g_u = ((((((((((((v169_v_i_0 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v169_v_i_1 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.49372787069))) + ((((v169_v_i_2 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.96779503248))) + ((((v169_v_i_3 + (- ((v169_vx + (- v169_vy)) + v169_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.82978247508))) + 0) + 0) + 0) + 0) + 0) ;
      v169_v_u = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_voo = ((v169_vx + (- v169_vy)) + v169_vz) ;
      v169_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v169!\n");
      exit(1);
    }
    break;
  }
  v169_vx = v169_vx_u;
  v169_vy = v169_vy_u;
  v169_vz = v169_vz_u;
  v169_g = v169_g_u;
  v169_v = v169_v_u;
  v169_ft = v169_ft_u;
  v169_theta = v169_theta_u;
  v169_v_O = v169_v_O_u;
  return cstate;
}