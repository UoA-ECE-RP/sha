#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v138_v137_update_c1vd();
extern double v138_v137_update_c2vd();
extern double v138_v137_update_c1md();
extern double v138_v137_update_c2md();
extern double v138_v137_update_buffer_index(double,double,double,double);
extern double v138_v137_update_latch1(double,double);
extern double v138_v137_update_latch2(double,double);
extern double v138_v137_update_ocell1(double,double);
extern double v138_v137_update_ocell2(double,double);
double v138_v137_cell1_v;
double v138_v137_cell1_mode;
double v138_v137_cell2_v;
double v138_v137_cell2_mode;
double v138_v137_cell1_v_replay = 0.0;
double v138_v137_cell2_v_replay = 0.0;


static double  v138_v137_k  =  0.0 ,  v138_v137_cell1_mode_delayed  =  0.0 ,  v138_v137_cell2_mode_delayed  =  0.0 ,  v138_v137_from_cell  =  0.0 ,  v138_v137_cell1_replay_latch  =  0.0 ,  v138_v137_cell2_replay_latch  =  0.0 ,  v138_v137_cell1_v_delayed  =  0.0 ,  v138_v137_cell2_v_delayed  =  0.0 ,  v138_v137_wasted  =  0.0 ; //the continuous vars
static double  v138_v137_k_u , v138_v137_cell1_mode_delayed_u , v138_v137_cell2_mode_delayed_u , v138_v137_from_cell_u , v138_v137_cell1_replay_latch_u , v138_v137_cell2_replay_latch_u , v138_v137_cell1_v_delayed_u , v138_v137_cell2_v_delayed_u , v138_v137_wasted_u ; // and their updates
static double  v138_v137_k_init , v138_v137_cell1_mode_delayed_init , v138_v137_cell2_mode_delayed_init , v138_v137_from_cell_init , v138_v137_cell1_replay_latch_init , v138_v137_cell2_replay_latch_init , v138_v137_cell1_v_delayed_init , v138_v137_cell2_v_delayed_init , v138_v137_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v138_v137_idle , v138_v137_annhilate , v138_v137_previous_drection1 , v138_v137_previous_direction2 , v138_v137_wait_cell1 , v138_v137_replay_cell1 , v138_v137_replay_cell2 , v138_v137_wait_cell2 }; // state declarations

enum states v138_v137 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v138_v137_idle ):
    if (True == False) {;}
    else if  (v138_v137_cell2_mode == (2.0) && (v138_v137_cell1_mode != (2.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v138_v137_cell1_mode == (2.0) && (v138_v137_cell2_mode != (2.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v138_v137_cell1_mode == (2.0) && (v138_v137_cell2_mode == (2.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_idle ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_annhilate ):
    if (True == False) {;}
    else if  (v138_v137_cell1_mode != (2.0) && (v138_v137_cell2_mode != (2.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_from_cell_u = 0 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_previous_drection1 ):
    if (True == False) {;}
    else if  (v138_v137_from_cell == (1.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (0.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (2.0) && (v138_v137_cell2_mode_delayed == (0.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (2.0) && (v138_v137_cell2_mode_delayed != (0.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_previous_drection1 ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_previous_direction2 ):
    if (True == False) {;}
    else if  (v138_v137_from_cell == (1.0) && (v138_v137_cell1_mode_delayed != (0.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (2.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (0.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v138_v137_from_cell == (1.0) && (v138_v137_cell1_mode_delayed == (0.0))) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_previous_direction2 ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_wait_cell1 ):
    if (True == False) {;}
    else if  (v138_v137_cell2_mode == (2.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
    }
    else if  (v138_v137_k >= (44.8904134828)) {
      v138_v137_from_cell_u = 1 ;
      v138_v137_cell1_replay_latch_u = 1 ;
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_wait_cell1 ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_replay_cell1 ):
    if (True == False) {;}
    else if  (v138_v137_cell1_mode == (2.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_annhilate ;
      force_init_update = False;
    }
    else if  (v138_v137_k >= (44.8904134828)) {
      v138_v137_from_cell_u = 2 ;
      v138_v137_cell2_replay_latch_u = 1 ;
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_replay_cell1 ;
      force_init_update = False;
      v138_v137_cell1_replay_latch_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_replay_cell2 ):
    if (True == False) {;}
    else if  (v138_v137_k >= (10.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_replay_cell2 ;
      force_init_update = False;
      v138_v137_cell2_replay_latch_u = 1 ;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  case ( v138_v137_wait_cell2 ):
    if (True == False) {;}
    else if  (v138_v137_k >= (10.0)) {
      v138_v137_k_u = 1 ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
      cstate =  v138_v137_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v138_v137_k_init = v138_v137_k ;
      slope =  1 ;
      v138_v137_k_u = (slope * d) + v138_v137_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v138_v137_wait_cell2 ;
      force_init_update = False;
      v138_v137_cell1_v_delayed_u = v138_v137_update_c1vd () ;
      v138_v137_cell2_v_delayed_u = v138_v137_update_c2vd () ;
      v138_v137_cell1_mode_delayed_u = v138_v137_update_c1md () ;
      v138_v137_cell2_mode_delayed_u = v138_v137_update_c2md () ;
      v138_v137_wasted_u = v138_v137_update_buffer_index (v138_v137_cell1_v,v138_v137_cell2_v,v138_v137_cell1_mode,v138_v137_cell2_mode) ;
      v138_v137_cell1_replay_latch_u = v138_v137_update_latch1 (v138_v137_cell1_mode_delayed,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_replay_latch_u = v138_v137_update_latch2 (v138_v137_cell2_mode_delayed,v138_v137_cell2_replay_latch_u) ;
      v138_v137_cell1_v_replay = v138_v137_update_ocell1 (v138_v137_cell1_v_delayed_u,v138_v137_cell1_replay_latch_u) ;
      v138_v137_cell2_v_replay = v138_v137_update_ocell2 (v138_v137_cell2_v_delayed_u,v138_v137_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v138_v137!\n");
      exit(1);
    }
    break;
  }
  v138_v137_k = v138_v137_k_u;
  v138_v137_cell1_mode_delayed = v138_v137_cell1_mode_delayed_u;
  v138_v137_cell2_mode_delayed = v138_v137_cell2_mode_delayed_u;
  v138_v137_from_cell = v138_v137_from_cell_u;
  v138_v137_cell1_replay_latch = v138_v137_cell1_replay_latch_u;
  v138_v137_cell2_replay_latch = v138_v137_cell2_replay_latch_u;
  v138_v137_cell1_v_delayed = v138_v137_cell1_v_delayed_u;
  v138_v137_cell2_v_delayed = v138_v137_cell2_v_delayed_u;
  v138_v137_wasted = v138_v137_wasted_u;
  return cstate;
}