#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v131_v132_update_c1vd();
extern double v131_v132_update_c2vd();
extern double v131_v132_update_c1md();
extern double v131_v132_update_c2md();
extern double v131_v132_update_buffer_index(double,double,double,double);
extern double v131_v132_update_latch1(double,double);
extern double v131_v132_update_latch2(double,double);
extern double v131_v132_update_ocell1(double,double);
extern double v131_v132_update_ocell2(double,double);
double v131_v132_cell1_v;
double v131_v132_cell1_mode;
double v131_v132_cell2_v;
double v131_v132_cell2_mode;
double v131_v132_cell1_v_replay = 0.0;
double v131_v132_cell2_v_replay = 0.0;


static double  v131_v132_k  =  0.0 ,  v131_v132_cell1_mode_delayed  =  0.0 ,  v131_v132_cell2_mode_delayed  =  0.0 ,  v131_v132_from_cell  =  0.0 ,  v131_v132_cell1_replay_latch  =  0.0 ,  v131_v132_cell2_replay_latch  =  0.0 ,  v131_v132_cell1_v_delayed  =  0.0 ,  v131_v132_cell2_v_delayed  =  0.0 ,  v131_v132_wasted  =  0.0 ; //the continuous vars
static double  v131_v132_k_u , v131_v132_cell1_mode_delayed_u , v131_v132_cell2_mode_delayed_u , v131_v132_from_cell_u , v131_v132_cell1_replay_latch_u , v131_v132_cell2_replay_latch_u , v131_v132_cell1_v_delayed_u , v131_v132_cell2_v_delayed_u , v131_v132_wasted_u ; // and their updates
static double  v131_v132_k_init , v131_v132_cell1_mode_delayed_init , v131_v132_cell2_mode_delayed_init , v131_v132_from_cell_init , v131_v132_cell1_replay_latch_init , v131_v132_cell2_replay_latch_init , v131_v132_cell1_v_delayed_init , v131_v132_cell2_v_delayed_init , v131_v132_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v131_v132_idle , v131_v132_annhilate , v131_v132_previous_drection1 , v131_v132_previous_direction2 , v131_v132_wait_cell1 , v131_v132_replay_cell1 , v131_v132_replay_cell2 , v131_v132_wait_cell2 }; // state declarations

enum states v131_v132 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v131_v132_idle ):
    if (True == False) {;}
    else if  (v131_v132_cell2_mode == (2.0) && (v131_v132_cell1_mode != (2.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v131_v132_cell1_mode == (2.0) && (v131_v132_cell2_mode != (2.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v131_v132_cell1_mode == (2.0) && (v131_v132_cell2_mode == (2.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_idle ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_annhilate ):
    if (True == False) {;}
    else if  (v131_v132_cell1_mode != (2.0) && (v131_v132_cell2_mode != (2.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_from_cell_u = 0 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_previous_drection1 ):
    if (True == False) {;}
    else if  (v131_v132_from_cell == (1.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (0.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (2.0) && (v131_v132_cell2_mode_delayed == (0.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (2.0) && (v131_v132_cell2_mode_delayed != (0.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_previous_drection1 ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_previous_direction2 ):
    if (True == False) {;}
    else if  (v131_v132_from_cell == (1.0) && (v131_v132_cell1_mode_delayed != (0.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (2.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (0.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v131_v132_from_cell == (1.0) && (v131_v132_cell1_mode_delayed == (0.0))) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_previous_direction2 ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_wait_cell1 ):
    if (True == False) {;}
    else if  (v131_v132_cell2_mode == (2.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
    }
    else if  (v131_v132_k >= (68.2518027897)) {
      v131_v132_from_cell_u = 1 ;
      v131_v132_cell1_replay_latch_u = 1 ;
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_wait_cell1 ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_replay_cell1 ):
    if (True == False) {;}
    else if  (v131_v132_cell1_mode == (2.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_annhilate ;
      force_init_update = False;
    }
    else if  (v131_v132_k >= (68.2518027897)) {
      v131_v132_from_cell_u = 2 ;
      v131_v132_cell2_replay_latch_u = 1 ;
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_replay_cell1 ;
      force_init_update = False;
      v131_v132_cell1_replay_latch_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_replay_cell2 ):
    if (True == False) {;}
    else if  (v131_v132_k >= (10.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_replay_cell2 ;
      force_init_update = False;
      v131_v132_cell2_replay_latch_u = 1 ;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  case ( v131_v132_wait_cell2 ):
    if (True == False) {;}
    else if  (v131_v132_k >= (10.0)) {
      v131_v132_k_u = 1 ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
      cstate =  v131_v132_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v131_v132_k_init = v131_v132_k ;
      slope =  1 ;
      v131_v132_k_u = (slope * d) + v131_v132_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v131_v132_wait_cell2 ;
      force_init_update = False;
      v131_v132_cell1_v_delayed_u = v131_v132_update_c1vd () ;
      v131_v132_cell2_v_delayed_u = v131_v132_update_c2vd () ;
      v131_v132_cell1_mode_delayed_u = v131_v132_update_c1md () ;
      v131_v132_cell2_mode_delayed_u = v131_v132_update_c2md () ;
      v131_v132_wasted_u = v131_v132_update_buffer_index (v131_v132_cell1_v,v131_v132_cell2_v,v131_v132_cell1_mode,v131_v132_cell2_mode) ;
      v131_v132_cell1_replay_latch_u = v131_v132_update_latch1 (v131_v132_cell1_mode_delayed,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_replay_latch_u = v131_v132_update_latch2 (v131_v132_cell2_mode_delayed,v131_v132_cell2_replay_latch_u) ;
      v131_v132_cell1_v_replay = v131_v132_update_ocell1 (v131_v132_cell1_v_delayed_u,v131_v132_cell1_replay_latch_u) ;
      v131_v132_cell2_v_replay = v131_v132_update_ocell2 (v131_v132_cell2_v_delayed_u,v131_v132_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v131_v132!\n");
      exit(1);
    }
    break;
  }
  v131_v132_k = v131_v132_k_u;
  v131_v132_cell1_mode_delayed = v131_v132_cell1_mode_delayed_u;
  v131_v132_cell2_mode_delayed = v131_v132_cell2_mode_delayed_u;
  v131_v132_from_cell = v131_v132_from_cell_u;
  v131_v132_cell1_replay_latch = v131_v132_cell1_replay_latch_u;
  v131_v132_cell2_replay_latch = v131_v132_cell2_replay_latch_u;
  v131_v132_cell1_v_delayed = v131_v132_cell1_v_delayed_u;
  v131_v132_cell2_v_delayed = v131_v132_cell2_v_delayed_u;
  v131_v132_wasted = v131_v132_wasted_u;
  return cstate;
}