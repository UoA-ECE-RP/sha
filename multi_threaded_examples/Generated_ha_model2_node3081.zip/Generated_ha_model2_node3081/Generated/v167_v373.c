#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v167_v373_update_c1vd();
extern double v167_v373_update_c2vd();
extern double v167_v373_update_c1md();
extern double v167_v373_update_c2md();
extern double v167_v373_update_buffer_index(double,double,double,double);
extern double v167_v373_update_latch1(double,double);
extern double v167_v373_update_latch2(double,double);
extern double v167_v373_update_ocell1(double,double);
extern double v167_v373_update_ocell2(double,double);
double v167_v373_cell1_v;
double v167_v373_cell1_mode;
double v167_v373_cell2_v;
double v167_v373_cell2_mode;
double v167_v373_cell1_v_replay = 0.0;
double v167_v373_cell2_v_replay = 0.0;


static double  v167_v373_k  =  0.0 ,  v167_v373_cell1_mode_delayed  =  0.0 ,  v167_v373_cell2_mode_delayed  =  0.0 ,  v167_v373_from_cell  =  0.0 ,  v167_v373_cell1_replay_latch  =  0.0 ,  v167_v373_cell2_replay_latch  =  0.0 ,  v167_v373_cell1_v_delayed  =  0.0 ,  v167_v373_cell2_v_delayed  =  0.0 ,  v167_v373_wasted  =  0.0 ; //the continuous vars
static double  v167_v373_k_u , v167_v373_cell1_mode_delayed_u , v167_v373_cell2_mode_delayed_u , v167_v373_from_cell_u , v167_v373_cell1_replay_latch_u , v167_v373_cell2_replay_latch_u , v167_v373_cell1_v_delayed_u , v167_v373_cell2_v_delayed_u , v167_v373_wasted_u ; // and their updates
static double  v167_v373_k_init , v167_v373_cell1_mode_delayed_init , v167_v373_cell2_mode_delayed_init , v167_v373_from_cell_init , v167_v373_cell1_replay_latch_init , v167_v373_cell2_replay_latch_init , v167_v373_cell1_v_delayed_init , v167_v373_cell2_v_delayed_init , v167_v373_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v167_v373_idle , v167_v373_annhilate , v167_v373_previous_drection1 , v167_v373_previous_direction2 , v167_v373_wait_cell1 , v167_v373_replay_cell1 , v167_v373_replay_cell2 , v167_v373_wait_cell2 }; // state declarations

enum states v167_v373 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v167_v373_idle ):
    if (True == False) {;}
    else if  (v167_v373_cell2_mode == (2.0) && (v167_v373_cell1_mode != (2.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v167_v373_cell1_mode == (2.0) && (v167_v373_cell2_mode != (2.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v167_v373_cell1_mode == (2.0) && (v167_v373_cell2_mode == (2.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_idle ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_annhilate ):
    if (True == False) {;}
    else if  (v167_v373_cell1_mode != (2.0) && (v167_v373_cell2_mode != (2.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_from_cell_u = 0 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_previous_drection1 ):
    if (True == False) {;}
    else if  (v167_v373_from_cell == (1.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (0.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (2.0) && (v167_v373_cell2_mode_delayed == (0.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (2.0) && (v167_v373_cell2_mode_delayed != (0.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_previous_drection1 ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_previous_direction2 ):
    if (True == False) {;}
    else if  (v167_v373_from_cell == (1.0) && (v167_v373_cell1_mode_delayed != (0.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (2.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (0.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v167_v373_from_cell == (1.0) && (v167_v373_cell1_mode_delayed == (0.0))) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_previous_direction2 ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_wait_cell1 ):
    if (True == False) {;}
    else if  (v167_v373_cell2_mode == (2.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
    }
    else if  (v167_v373_k >= (91.83332397759999)) {
      v167_v373_from_cell_u = 1 ;
      v167_v373_cell1_replay_latch_u = 1 ;
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_wait_cell1 ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_replay_cell1 ):
    if (True == False) {;}
    else if  (v167_v373_cell1_mode == (2.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_annhilate ;
      force_init_update = False;
    }
    else if  (v167_v373_k >= (91.83332397759999)) {
      v167_v373_from_cell_u = 2 ;
      v167_v373_cell2_replay_latch_u = 1 ;
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_replay_cell1 ;
      force_init_update = False;
      v167_v373_cell1_replay_latch_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_replay_cell2 ):
    if (True == False) {;}
    else if  (v167_v373_k >= (10.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_replay_cell2 ;
      force_init_update = False;
      v167_v373_cell2_replay_latch_u = 1 ;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  case ( v167_v373_wait_cell2 ):
    if (True == False) {;}
    else if  (v167_v373_k >= (10.0)) {
      v167_v373_k_u = 1 ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
      cstate =  v167_v373_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v167_v373_k_init = v167_v373_k ;
      slope =  1 ;
      v167_v373_k_u = (slope * d) + v167_v373_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v167_v373_wait_cell2 ;
      force_init_update = False;
      v167_v373_cell1_v_delayed_u = v167_v373_update_c1vd () ;
      v167_v373_cell2_v_delayed_u = v167_v373_update_c2vd () ;
      v167_v373_cell1_mode_delayed_u = v167_v373_update_c1md () ;
      v167_v373_cell2_mode_delayed_u = v167_v373_update_c2md () ;
      v167_v373_wasted_u = v167_v373_update_buffer_index (v167_v373_cell1_v,v167_v373_cell2_v,v167_v373_cell1_mode,v167_v373_cell2_mode) ;
      v167_v373_cell1_replay_latch_u = v167_v373_update_latch1 (v167_v373_cell1_mode_delayed,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_replay_latch_u = v167_v373_update_latch2 (v167_v373_cell2_mode_delayed,v167_v373_cell2_replay_latch_u) ;
      v167_v373_cell1_v_replay = v167_v373_update_ocell1 (v167_v373_cell1_v_delayed_u,v167_v373_cell1_replay_latch_u) ;
      v167_v373_cell2_v_replay = v167_v373_update_ocell2 (v167_v373_cell2_v_delayed_u,v167_v373_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167_v373!\n");
      exit(1);
    }
    break;
  }
  v167_v373_k = v167_v373_k_u;
  v167_v373_cell1_mode_delayed = v167_v373_cell1_mode_delayed_u;
  v167_v373_cell2_mode_delayed = v167_v373_cell2_mode_delayed_u;
  v167_v373_from_cell = v167_v373_from_cell_u;
  v167_v373_cell1_replay_latch = v167_v373_cell1_replay_latch_u;
  v167_v373_cell2_replay_latch = v167_v373_cell2_replay_latch_u;
  v167_v373_cell1_v_delayed = v167_v373_cell1_v_delayed_u;
  v167_v373_cell2_v_delayed = v167_v373_cell2_v_delayed_u;
  v167_v373_wasted = v167_v373_wasted_u;
  return cstate;
}