#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v145_v387_update_c1vd();
extern double v145_v387_update_c2vd();
extern double v145_v387_update_c1md();
extern double v145_v387_update_c2md();
extern double v145_v387_update_buffer_index(double,double,double,double);
extern double v145_v387_update_latch1(double,double);
extern double v145_v387_update_latch2(double,double);
extern double v145_v387_update_ocell1(double,double);
extern double v145_v387_update_ocell2(double,double);
double v145_v387_cell1_v;
double v145_v387_cell1_mode;
double v145_v387_cell2_v;
double v145_v387_cell2_mode;
double v145_v387_cell1_v_replay = 0.0;
double v145_v387_cell2_v_replay = 0.0;


static double  v145_v387_k  =  0.0 ,  v145_v387_cell1_mode_delayed  =  0.0 ,  v145_v387_cell2_mode_delayed  =  0.0 ,  v145_v387_from_cell  =  0.0 ,  v145_v387_cell1_replay_latch  =  0.0 ,  v145_v387_cell2_replay_latch  =  0.0 ,  v145_v387_cell1_v_delayed  =  0.0 ,  v145_v387_cell2_v_delayed  =  0.0 ,  v145_v387_wasted  =  0.0 ; //the continuous vars
static double  v145_v387_k_u , v145_v387_cell1_mode_delayed_u , v145_v387_cell2_mode_delayed_u , v145_v387_from_cell_u , v145_v387_cell1_replay_latch_u , v145_v387_cell2_replay_latch_u , v145_v387_cell1_v_delayed_u , v145_v387_cell2_v_delayed_u , v145_v387_wasted_u ; // and their updates
static double  v145_v387_k_init , v145_v387_cell1_mode_delayed_init , v145_v387_cell2_mode_delayed_init , v145_v387_from_cell_init , v145_v387_cell1_replay_latch_init , v145_v387_cell2_replay_latch_init , v145_v387_cell1_v_delayed_init , v145_v387_cell2_v_delayed_init , v145_v387_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v145_v387_idle , v145_v387_annhilate , v145_v387_previous_drection1 , v145_v387_previous_direction2 , v145_v387_wait_cell1 , v145_v387_replay_cell1 , v145_v387_replay_cell2 , v145_v387_wait_cell2 }; // state declarations

enum states v145_v387 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v145_v387_idle ):
    if (True == False) {;}
    else if  (v145_v387_cell2_mode == (2.0) && (v145_v387_cell1_mode != (2.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v145_v387_cell1_mode == (2.0) && (v145_v387_cell2_mode != (2.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v145_v387_cell1_mode == (2.0) && (v145_v387_cell2_mode == (2.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_idle ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_annhilate ):
    if (True == False) {;}
    else if  (v145_v387_cell1_mode != (2.0) && (v145_v387_cell2_mode != (2.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_from_cell_u = 0 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_previous_drection1 ):
    if (True == False) {;}
    else if  (v145_v387_from_cell == (1.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (0.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (2.0) && (v145_v387_cell2_mode_delayed == (0.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (2.0) && (v145_v387_cell2_mode_delayed != (0.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_previous_drection1 ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_previous_direction2 ):
    if (True == False) {;}
    else if  (v145_v387_from_cell == (1.0) && (v145_v387_cell1_mode_delayed != (0.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (2.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (0.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v145_v387_from_cell == (1.0) && (v145_v387_cell1_mode_delayed == (0.0))) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_previous_direction2 ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_wait_cell1 ):
    if (True == False) {;}
    else if  (v145_v387_cell2_mode == (2.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
    }
    else if  (v145_v387_k >= (94.8115386165)) {
      v145_v387_from_cell_u = 1 ;
      v145_v387_cell1_replay_latch_u = 1 ;
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_wait_cell1 ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_replay_cell1 ):
    if (True == False) {;}
    else if  (v145_v387_cell1_mode == (2.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_annhilate ;
      force_init_update = False;
    }
    else if  (v145_v387_k >= (94.8115386165)) {
      v145_v387_from_cell_u = 2 ;
      v145_v387_cell2_replay_latch_u = 1 ;
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_replay_cell1 ;
      force_init_update = False;
      v145_v387_cell1_replay_latch_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_replay_cell2 ):
    if (True == False) {;}
    else if  (v145_v387_k >= (10.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_replay_cell2 ;
      force_init_update = False;
      v145_v387_cell2_replay_latch_u = 1 ;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  case ( v145_v387_wait_cell2 ):
    if (True == False) {;}
    else if  (v145_v387_k >= (10.0)) {
      v145_v387_k_u = 1 ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
      cstate =  v145_v387_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v145_v387_k_init = v145_v387_k ;
      slope =  1 ;
      v145_v387_k_u = (slope * d) + v145_v387_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v145_v387_wait_cell2 ;
      force_init_update = False;
      v145_v387_cell1_v_delayed_u = v145_v387_update_c1vd () ;
      v145_v387_cell2_v_delayed_u = v145_v387_update_c2vd () ;
      v145_v387_cell1_mode_delayed_u = v145_v387_update_c1md () ;
      v145_v387_cell2_mode_delayed_u = v145_v387_update_c2md () ;
      v145_v387_wasted_u = v145_v387_update_buffer_index (v145_v387_cell1_v,v145_v387_cell2_v,v145_v387_cell1_mode,v145_v387_cell2_mode) ;
      v145_v387_cell1_replay_latch_u = v145_v387_update_latch1 (v145_v387_cell1_mode_delayed,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_replay_latch_u = v145_v387_update_latch2 (v145_v387_cell2_mode_delayed,v145_v387_cell2_replay_latch_u) ;
      v145_v387_cell1_v_replay = v145_v387_update_ocell1 (v145_v387_cell1_v_delayed_u,v145_v387_cell1_replay_latch_u) ;
      v145_v387_cell2_v_replay = v145_v387_update_ocell2 (v145_v387_cell2_v_delayed_u,v145_v387_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145_v387!\n");
      exit(1);
    }
    break;
  }
  v145_v387_k = v145_v387_k_u;
  v145_v387_cell1_mode_delayed = v145_v387_cell1_mode_delayed_u;
  v145_v387_cell2_mode_delayed = v145_v387_cell2_mode_delayed_u;
  v145_v387_from_cell = v145_v387_from_cell_u;
  v145_v387_cell1_replay_latch = v145_v387_cell1_replay_latch_u;
  v145_v387_cell2_replay_latch = v145_v387_cell2_replay_latch_u;
  v145_v387_cell1_v_delayed = v145_v387_cell1_v_delayed_u;
  v145_v387_cell2_v_delayed = v145_v387_cell2_v_delayed_u;
  v145_v387_wasted = v145_v387_wasted_u;
  return cstate;
}