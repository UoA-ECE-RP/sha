#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v105_v106_update_c1vd();
extern double v105_v106_update_c2vd();
extern double v105_v106_update_c1md();
extern double v105_v106_update_c2md();
extern double v105_v106_update_buffer_index(double,double,double,double);
extern double v105_v106_update_latch1(double,double);
extern double v105_v106_update_latch2(double,double);
extern double v105_v106_update_ocell1(double,double);
extern double v105_v106_update_ocell2(double,double);
double v105_v106_cell1_v;
double v105_v106_cell1_mode;
double v105_v106_cell2_v;
double v105_v106_cell2_mode;
double v105_v106_cell1_v_replay = 0.0;
double v105_v106_cell2_v_replay = 0.0;


static double  v105_v106_k  =  0.0 ,  v105_v106_cell1_mode_delayed  =  0.0 ,  v105_v106_cell2_mode_delayed  =  0.0 ,  v105_v106_from_cell  =  0.0 ,  v105_v106_cell1_replay_latch  =  0.0 ,  v105_v106_cell2_replay_latch  =  0.0 ,  v105_v106_cell1_v_delayed  =  0.0 ,  v105_v106_cell2_v_delayed  =  0.0 ,  v105_v106_wasted  =  0.0 ; //the continuous vars
static double  v105_v106_k_u , v105_v106_cell1_mode_delayed_u , v105_v106_cell2_mode_delayed_u , v105_v106_from_cell_u , v105_v106_cell1_replay_latch_u , v105_v106_cell2_replay_latch_u , v105_v106_cell1_v_delayed_u , v105_v106_cell2_v_delayed_u , v105_v106_wasted_u ; // and their updates
static double  v105_v106_k_init , v105_v106_cell1_mode_delayed_init , v105_v106_cell2_mode_delayed_init , v105_v106_from_cell_init , v105_v106_cell1_replay_latch_init , v105_v106_cell2_replay_latch_init , v105_v106_cell1_v_delayed_init , v105_v106_cell2_v_delayed_init , v105_v106_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v105_v106_idle , v105_v106_annhilate , v105_v106_previous_drection1 , v105_v106_previous_direction2 , v105_v106_wait_cell1 , v105_v106_replay_cell1 , v105_v106_replay_cell2 , v105_v106_wait_cell2 }; // state declarations

enum states v105_v106 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v105_v106_idle ):
    if (True == False) {;}
    else if  (v105_v106_cell2_mode == (2.0) && (v105_v106_cell1_mode != (2.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v105_v106_cell1_mode == (2.0) && (v105_v106_cell2_mode != (2.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v105_v106_cell1_mode == (2.0) && (v105_v106_cell2_mode == (2.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_idle ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_annhilate ):
    if (True == False) {;}
    else if  (v105_v106_cell1_mode != (2.0) && (v105_v106_cell2_mode != (2.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_from_cell_u = 0 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_previous_drection1 ):
    if (True == False) {;}
    else if  (v105_v106_from_cell == (1.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (0.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (2.0) && (v105_v106_cell2_mode_delayed == (0.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (2.0) && (v105_v106_cell2_mode_delayed != (0.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_previous_drection1 ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_previous_direction2 ):
    if (True == False) {;}
    else if  (v105_v106_from_cell == (1.0) && (v105_v106_cell1_mode_delayed != (0.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (2.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (0.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v105_v106_from_cell == (1.0) && (v105_v106_cell1_mode_delayed == (0.0))) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_previous_direction2 ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_wait_cell1 ):
    if (True == False) {;}
    else if  (v105_v106_cell2_mode == (2.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
    }
    else if  (v105_v106_k >= (80.00362836469999)) {
      v105_v106_from_cell_u = 1 ;
      v105_v106_cell1_replay_latch_u = 1 ;
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_wait_cell1 ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_replay_cell1 ):
    if (True == False) {;}
    else if  (v105_v106_cell1_mode == (2.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_annhilate ;
      force_init_update = False;
    }
    else if  (v105_v106_k >= (80.00362836469999)) {
      v105_v106_from_cell_u = 2 ;
      v105_v106_cell2_replay_latch_u = 1 ;
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_replay_cell1 ;
      force_init_update = False;
      v105_v106_cell1_replay_latch_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_replay_cell2 ):
    if (True == False) {;}
    else if  (v105_v106_k >= (10.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_replay_cell2 ;
      force_init_update = False;
      v105_v106_cell2_replay_latch_u = 1 ;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  case ( v105_v106_wait_cell2 ):
    if (True == False) {;}
    else if  (v105_v106_k >= (10.0)) {
      v105_v106_k_u = 1 ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
      cstate =  v105_v106_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v105_v106_k_init = v105_v106_k ;
      slope =  1 ;
      v105_v106_k_u = (slope * d) + v105_v106_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v105_v106_wait_cell2 ;
      force_init_update = False;
      v105_v106_cell1_v_delayed_u = v105_v106_update_c1vd () ;
      v105_v106_cell2_v_delayed_u = v105_v106_update_c2vd () ;
      v105_v106_cell1_mode_delayed_u = v105_v106_update_c1md () ;
      v105_v106_cell2_mode_delayed_u = v105_v106_update_c2md () ;
      v105_v106_wasted_u = v105_v106_update_buffer_index (v105_v106_cell1_v,v105_v106_cell2_v,v105_v106_cell1_mode,v105_v106_cell2_mode) ;
      v105_v106_cell1_replay_latch_u = v105_v106_update_latch1 (v105_v106_cell1_mode_delayed,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_replay_latch_u = v105_v106_update_latch2 (v105_v106_cell2_mode_delayed,v105_v106_cell2_replay_latch_u) ;
      v105_v106_cell1_v_replay = v105_v106_update_ocell1 (v105_v106_cell1_v_delayed_u,v105_v106_cell1_replay_latch_u) ;
      v105_v106_cell2_v_replay = v105_v106_update_ocell2 (v105_v106_cell2_v_delayed_u,v105_v106_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v105_v106!\n");
      exit(1);
    }
    break;
  }
  v105_v106_k = v105_v106_k_u;
  v105_v106_cell1_mode_delayed = v105_v106_cell1_mode_delayed_u;
  v105_v106_cell2_mode_delayed = v105_v106_cell2_mode_delayed_u;
  v105_v106_from_cell = v105_v106_from_cell_u;
  v105_v106_cell1_replay_latch = v105_v106_cell1_replay_latch_u;
  v105_v106_cell2_replay_latch = v105_v106_cell2_replay_latch_u;
  v105_v106_cell1_v_delayed = v105_v106_cell1_v_delayed_u;
  v105_v106_cell2_v_delayed = v105_v106_cell2_v_delayed_u;
  v105_v106_wasted = v105_v106_wasted_u;
  return cstate;
}