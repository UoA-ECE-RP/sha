#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v174_v_i_0;
double v174_v_i_1;
double v174_v_i_2;
double v174_v_i_3;
double v174_voo = 0.0;
double v174_state = 0.0;


static double  v174_vx  =  0 ,  v174_vy  =  0 ,  v174_vz  =  0 ,  v174_g  =  0 ,  v174_v  =  0 ,  v174_ft  =  0 ,  v174_theta  =  0 ,  v174_v_O  =  0 ; //the continuous vars
static double  v174_vx_u , v174_vy_u , v174_vz_u , v174_g_u , v174_v_u , v174_ft_u , v174_theta_u , v174_v_O_u ; // and their updates
static double  v174_vx_init , v174_vy_init , v174_vz_init , v174_g_init , v174_v_init , v174_ft_init , v174_theta_init , v174_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v174_t1 , v174_t2 , v174_t3 , v174_t4 }; // state declarations

enum states v174 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v174_t1 ):
    if (True == False) {;}
    else if  (v174_g > (44.5)) {
      v174_vx_u = (0.3 * v174_v) ;
      v174_vy_u = 0 ;
      v174_vz_u = (0.7 * v174_v) ;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      v174_theta_u = (v174_v / 30.0) ;
      v174_v_O_u = (131.1 + (- (80.1 * pow ( ((v174_v / 30.0)) , (0.5) )))) ;
      v174_ft_u = f (v174_theta,4.0e-2) ;
      cstate =  v174_t2 ;
      force_init_update = False;
    }

    else if ( v174_v <= (44.5)
               && v174_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v174_vx_init = v174_vx ;
      slope =  (v174_vx * -8.7) ;
      v174_vx_u = (slope * d) + v174_vx ;
      if ((pstate != cstate) || force_init_update) v174_vy_init = v174_vy ;
      slope =  (v174_vy * -190.9) ;
      v174_vy_u = (slope * d) + v174_vy ;
      if ((pstate != cstate) || force_init_update) v174_vz_init = v174_vz ;
      slope =  (v174_vz * -190.4) ;
      v174_vz_u = (slope * d) + v174_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v174_t1 ;
      force_init_update = False;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      v174_v_u = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_voo = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v174!\n");
      exit(1);
    }
    break;
  case ( v174_t2 ):
    if (True == False) {;}
    else if  (v174_v >= (44.5)) {
      v174_vx_u = v174_vx ;
      v174_vy_u = v174_vy ;
      v174_vz_u = v174_vz ;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v174_t3 ;
      force_init_update = False;
    }
    else if  (v174_g <= (44.5)
               && v174_v < (44.5)) {
      v174_vx_u = v174_vx ;
      v174_vy_u = v174_vy ;
      v174_vz_u = v174_vz ;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v174_t1 ;
      force_init_update = False;
    }

    else if ( v174_v < (44.5)
               && v174_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v174_vx_init = v174_vx ;
      slope =  ((v174_vx * -23.6) + (777200.0 * v174_g)) ;
      v174_vx_u = (slope * d) + v174_vx ;
      if ((pstate != cstate) || force_init_update) v174_vy_init = v174_vy ;
      slope =  ((v174_vy * -45.5) + (58900.0 * v174_g)) ;
      v174_vy_u = (slope * d) + v174_vy ;
      if ((pstate != cstate) || force_init_update) v174_vz_init = v174_vz ;
      slope =  ((v174_vz * -12.9) + (276600.0 * v174_g)) ;
      v174_vz_u = (slope * d) + v174_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v174_t2 ;
      force_init_update = False;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      v174_v_u = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_voo = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v174!\n");
      exit(1);
    }
    break;
  case ( v174_t3 ):
    if (True == False) {;}
    else if  (v174_v >= (131.1)) {
      v174_vx_u = v174_vx ;
      v174_vy_u = v174_vy ;
      v174_vz_u = v174_vz ;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v174_t4 ;
      force_init_update = False;
    }

    else if ( v174_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v174_vx_init = v174_vx ;
      slope =  (v174_vx * -6.9) ;
      v174_vx_u = (slope * d) + v174_vx ;
      if ((pstate != cstate) || force_init_update) v174_vy_init = v174_vy ;
      slope =  (v174_vy * 75.9) ;
      v174_vy_u = (slope * d) + v174_vy ;
      if ((pstate != cstate) || force_init_update) v174_vz_init = v174_vz ;
      slope =  (v174_vz * 6826.5) ;
      v174_vz_u = (slope * d) + v174_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v174_t3 ;
      force_init_update = False;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      v174_v_u = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_voo = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v174!\n");
      exit(1);
    }
    break;
  case ( v174_t4 ):
    if (True == False) {;}
    else if  (v174_v <= (30.0)) {
      v174_vx_u = v174_vx ;
      v174_vy_u = v174_vy ;
      v174_vz_u = v174_vz ;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v174_t1 ;
      force_init_update = False;
    }

    else if ( v174_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v174_vx_init = v174_vx ;
      slope =  (v174_vx * -33.2) ;
      v174_vx_u = (slope * d) + v174_vx ;
      if ((pstate != cstate) || force_init_update) v174_vy_init = v174_vy ;
      slope =  ((v174_vy * 20.0) * v174_ft) ;
      v174_vy_u = (slope * d) + v174_vy ;
      if ((pstate != cstate) || force_init_update) v174_vz_init = v174_vz ;
      slope =  ((v174_vz * 2.0) * v174_ft) ;
      v174_vz_u = (slope * d) + v174_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v174_t4 ;
      force_init_update = False;
      v174_g_u = ((((((((((((v174_v_i_0 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v174_v_i_1 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v174_v_i_2 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10346825939))) + ((((v174_v_i_3 + (- ((v174_vx + (- v174_vy)) + v174_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.75809125935))) + 0) + 0) + 0) + 0) + 0) ;
      v174_v_u = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_voo = ((v174_vx + (- v174_vy)) + v174_vz) ;
      v174_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v174!\n");
      exit(1);
    }
    break;
  }
  v174_vx = v174_vx_u;
  v174_vy = v174_vy_u;
  v174_vz = v174_vz_u;
  v174_g = v174_g_u;
  v174_v = v174_v_u;
  v174_ft = v174_ft_u;
  v174_theta = v174_theta_u;
  v174_v_O = v174_v_O_u;
  return cstate;
}