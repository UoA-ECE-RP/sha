#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v142_v_i_0;
double v142_v_i_1;
double v142_v_i_2;
double v142_v_i_3;
double v142_voo = 0.0;
double v142_state = 0.0;


static double  v142_vx  =  0 ,  v142_vy  =  0 ,  v142_vz  =  0 ,  v142_g  =  0 ,  v142_v  =  0 ,  v142_ft  =  0 ,  v142_theta  =  0 ,  v142_v_O  =  0 ; //the continuous vars
static double  v142_vx_u , v142_vy_u , v142_vz_u , v142_g_u , v142_v_u , v142_ft_u , v142_theta_u , v142_v_O_u ; // and their updates
static double  v142_vx_init , v142_vy_init , v142_vz_init , v142_g_init , v142_v_init , v142_ft_init , v142_theta_init , v142_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v142_t1 , v142_t2 , v142_t3 , v142_t4 }; // state declarations

enum states v142 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v142_t1 ):
    if (True == False) {;}
    else if  (v142_g > (44.5)) {
      v142_vx_u = (0.3 * v142_v) ;
      v142_vy_u = 0 ;
      v142_vz_u = (0.7 * v142_v) ;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      v142_theta_u = (v142_v / 30.0) ;
      v142_v_O_u = (131.1 + (- (80.1 * pow ( ((v142_v / 30.0)) , (0.5) )))) ;
      v142_ft_u = f (v142_theta,4.0e-2) ;
      cstate =  v142_t2 ;
      force_init_update = False;
    }

    else if ( v142_v <= (44.5)
               && v142_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v142_vx_init = v142_vx ;
      slope =  (v142_vx * -8.7) ;
      v142_vx_u = (slope * d) + v142_vx ;
      if ((pstate != cstate) || force_init_update) v142_vy_init = v142_vy ;
      slope =  (v142_vy * -190.9) ;
      v142_vy_u = (slope * d) + v142_vy ;
      if ((pstate != cstate) || force_init_update) v142_vz_init = v142_vz ;
      slope =  (v142_vz * -190.4) ;
      v142_vz_u = (slope * d) + v142_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v142_t1 ;
      force_init_update = False;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      v142_v_u = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_voo = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v142!\n");
      exit(1);
    }
    break;
  case ( v142_t2 ):
    if (True == False) {;}
    else if  (v142_v >= (44.5)) {
      v142_vx_u = v142_vx ;
      v142_vy_u = v142_vy ;
      v142_vz_u = v142_vz ;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v142_t3 ;
      force_init_update = False;
    }
    else if  (v142_g <= (44.5)
               && v142_v < (44.5)) {
      v142_vx_u = v142_vx ;
      v142_vy_u = v142_vy ;
      v142_vz_u = v142_vz ;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v142_t1 ;
      force_init_update = False;
    }

    else if ( v142_v < (44.5)
               && v142_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v142_vx_init = v142_vx ;
      slope =  ((v142_vx * -23.6) + (777200.0 * v142_g)) ;
      v142_vx_u = (slope * d) + v142_vx ;
      if ((pstate != cstate) || force_init_update) v142_vy_init = v142_vy ;
      slope =  ((v142_vy * -45.5) + (58900.0 * v142_g)) ;
      v142_vy_u = (slope * d) + v142_vy ;
      if ((pstate != cstate) || force_init_update) v142_vz_init = v142_vz ;
      slope =  ((v142_vz * -12.9) + (276600.0 * v142_g)) ;
      v142_vz_u = (slope * d) + v142_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v142_t2 ;
      force_init_update = False;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      v142_v_u = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_voo = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v142!\n");
      exit(1);
    }
    break;
  case ( v142_t3 ):
    if (True == False) {;}
    else if  (v142_v >= (131.1)) {
      v142_vx_u = v142_vx ;
      v142_vy_u = v142_vy ;
      v142_vz_u = v142_vz ;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v142_t4 ;
      force_init_update = False;
    }

    else if ( v142_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v142_vx_init = v142_vx ;
      slope =  (v142_vx * -6.9) ;
      v142_vx_u = (slope * d) + v142_vx ;
      if ((pstate != cstate) || force_init_update) v142_vy_init = v142_vy ;
      slope =  (v142_vy * 75.9) ;
      v142_vy_u = (slope * d) + v142_vy ;
      if ((pstate != cstate) || force_init_update) v142_vz_init = v142_vz ;
      slope =  (v142_vz * 6826.5) ;
      v142_vz_u = (slope * d) + v142_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v142_t3 ;
      force_init_update = False;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      v142_v_u = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_voo = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v142!\n");
      exit(1);
    }
    break;
  case ( v142_t4 ):
    if (True == False) {;}
    else if  (v142_v <= (30.0)) {
      v142_vx_u = v142_vx ;
      v142_vy_u = v142_vy ;
      v142_vz_u = v142_vz ;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v142_t1 ;
      force_init_update = False;
    }

    else if ( v142_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v142_vx_init = v142_vx ;
      slope =  (v142_vx * -33.2) ;
      v142_vx_u = (slope * d) + v142_vx ;
      if ((pstate != cstate) || force_init_update) v142_vy_init = v142_vy ;
      slope =  ((v142_vy * 20.0) * v142_ft) ;
      v142_vy_u = (slope * d) + v142_vy ;
      if ((pstate != cstate) || force_init_update) v142_vz_init = v142_vz ;
      slope =  ((v142_vz * 2.0) * v142_ft) ;
      v142_vz_u = (slope * d) + v142_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v142_t4 ;
      force_init_update = False;
      v142_g_u = ((((((((((((v142_v_i_0 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v142_v_i_1 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10142669777))) + ((((v142_v_i_2 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34892224751))) + ((((v142_v_i_3 + (- ((v142_vx + (- v142_vy)) + v142_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13577963648))) + 0) + 0) + 0) + 0) + 0) ;
      v142_v_u = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_voo = ((v142_vx + (- v142_vy)) + v142_vz) ;
      v142_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v142!\n");
      exit(1);
    }
    break;
  }
  v142_vx = v142_vx_u;
  v142_vy = v142_vy_u;
  v142_vz = v142_vz_u;
  v142_g = v142_g_u;
  v142_v = v142_v_u;
  v142_ft = v142_ft_u;
  v142_theta = v142_theta_u;
  v142_v_O = v142_v_O_u;
  return cstate;
}