#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v160_v159_update_c1vd();
extern double v160_v159_update_c2vd();
extern double v160_v159_update_c1md();
extern double v160_v159_update_c2md();
extern double v160_v159_update_buffer_index(double,double,double,double);
extern double v160_v159_update_latch1(double,double);
extern double v160_v159_update_latch2(double,double);
extern double v160_v159_update_ocell1(double,double);
extern double v160_v159_update_ocell2(double,double);
double v160_v159_cell1_v;
double v160_v159_cell1_mode;
double v160_v159_cell2_v;
double v160_v159_cell2_mode;
double v160_v159_cell1_v_replay = 0.0;
double v160_v159_cell2_v_replay = 0.0;


static double  v160_v159_k  =  0.0 ,  v160_v159_cell1_mode_delayed  =  0.0 ,  v160_v159_cell2_mode_delayed  =  0.0 ,  v160_v159_from_cell  =  0.0 ,  v160_v159_cell1_replay_latch  =  0.0 ,  v160_v159_cell2_replay_latch  =  0.0 ,  v160_v159_cell1_v_delayed  =  0.0 ,  v160_v159_cell2_v_delayed  =  0.0 ,  v160_v159_wasted  =  0.0 ; //the continuous vars
static double  v160_v159_k_u , v160_v159_cell1_mode_delayed_u , v160_v159_cell2_mode_delayed_u , v160_v159_from_cell_u , v160_v159_cell1_replay_latch_u , v160_v159_cell2_replay_latch_u , v160_v159_cell1_v_delayed_u , v160_v159_cell2_v_delayed_u , v160_v159_wasted_u ; // and their updates
static double  v160_v159_k_init , v160_v159_cell1_mode_delayed_init , v160_v159_cell2_mode_delayed_init , v160_v159_from_cell_init , v160_v159_cell1_replay_latch_init , v160_v159_cell2_replay_latch_init , v160_v159_cell1_v_delayed_init , v160_v159_cell2_v_delayed_init , v160_v159_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v160_v159_idle , v160_v159_annhilate , v160_v159_previous_drection1 , v160_v159_previous_direction2 , v160_v159_wait_cell1 , v160_v159_replay_cell1 , v160_v159_replay_cell2 , v160_v159_wait_cell2 }; // state declarations

enum states v160_v159 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v160_v159_idle ):
    if (True == False) {;}
    else if  (v160_v159_cell2_mode == (2.0) && (v160_v159_cell1_mode != (2.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v160_v159_cell1_mode == (2.0) && (v160_v159_cell2_mode != (2.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v160_v159_cell1_mode == (2.0) && (v160_v159_cell2_mode == (2.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_idle ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_annhilate ):
    if (True == False) {;}
    else if  (v160_v159_cell1_mode != (2.0) && (v160_v159_cell2_mode != (2.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_from_cell_u = 0 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_previous_drection1 ):
    if (True == False) {;}
    else if  (v160_v159_from_cell == (1.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (0.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (2.0) && (v160_v159_cell2_mode_delayed == (0.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (2.0) && (v160_v159_cell2_mode_delayed != (0.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_previous_drection1 ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_previous_direction2 ):
    if (True == False) {;}
    else if  (v160_v159_from_cell == (1.0) && (v160_v159_cell1_mode_delayed != (0.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (2.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (0.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v160_v159_from_cell == (1.0) && (v160_v159_cell1_mode_delayed == (0.0))) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_previous_direction2 ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_wait_cell1 ):
    if (True == False) {;}
    else if  (v160_v159_cell2_mode == (2.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v159_k >= (10.4761071909)) {
      v160_v159_from_cell_u = 1 ;
      v160_v159_cell1_replay_latch_u = 1 ;
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_wait_cell1 ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_replay_cell1 ):
    if (True == False) {;}
    else if  (v160_v159_cell1_mode == (2.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v160_v159_k >= (10.4761071909)) {
      v160_v159_from_cell_u = 2 ;
      v160_v159_cell2_replay_latch_u = 1 ;
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_replay_cell1 ;
      force_init_update = False;
      v160_v159_cell1_replay_latch_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_replay_cell2 ):
    if (True == False) {;}
    else if  (v160_v159_k >= (10.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_replay_cell2 ;
      force_init_update = False;
      v160_v159_cell2_replay_latch_u = 1 ;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  case ( v160_v159_wait_cell2 ):
    if (True == False) {;}
    else if  (v160_v159_k >= (10.0)) {
      v160_v159_k_u = 1 ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
      cstate =  v160_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v160_v159_k_init = v160_v159_k ;
      slope =  1 ;
      v160_v159_k_u = (slope * d) + v160_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v160_v159_wait_cell2 ;
      force_init_update = False;
      v160_v159_cell1_v_delayed_u = v160_v159_update_c1vd () ;
      v160_v159_cell2_v_delayed_u = v160_v159_update_c2vd () ;
      v160_v159_cell1_mode_delayed_u = v160_v159_update_c1md () ;
      v160_v159_cell2_mode_delayed_u = v160_v159_update_c2md () ;
      v160_v159_wasted_u = v160_v159_update_buffer_index (v160_v159_cell1_v,v160_v159_cell2_v,v160_v159_cell1_mode,v160_v159_cell2_mode) ;
      v160_v159_cell1_replay_latch_u = v160_v159_update_latch1 (v160_v159_cell1_mode_delayed,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_replay_latch_u = v160_v159_update_latch2 (v160_v159_cell2_mode_delayed,v160_v159_cell2_replay_latch_u) ;
      v160_v159_cell1_v_replay = v160_v159_update_ocell1 (v160_v159_cell1_v_delayed_u,v160_v159_cell1_replay_latch_u) ;
      v160_v159_cell2_v_replay = v160_v159_update_ocell2 (v160_v159_cell2_v_delayed_u,v160_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160_v159!\n");
      exit(1);
    }
    break;
  }
  v160_v159_k = v160_v159_k_u;
  v160_v159_cell1_mode_delayed = v160_v159_cell1_mode_delayed_u;
  v160_v159_cell2_mode_delayed = v160_v159_cell2_mode_delayed_u;
  v160_v159_from_cell = v160_v159_from_cell_u;
  v160_v159_cell1_replay_latch = v160_v159_cell1_replay_latch_u;
  v160_v159_cell2_replay_latch = v160_v159_cell2_replay_latch_u;
  v160_v159_cell1_v_delayed = v160_v159_cell1_v_delayed_u;
  v160_v159_cell2_v_delayed = v160_v159_cell2_v_delayed_u;
  v160_v159_wasted = v160_v159_wasted_u;
  return cstate;
}