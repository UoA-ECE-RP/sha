#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v108_v_i_0;
double v108_v_i_1;
double v108_v_i_2;
double v108_voo = 0.0;
double v108_state = 0.0;


static double  v108_vx  =  0 ,  v108_vy  =  0 ,  v108_vz  =  0 ,  v108_g  =  0 ,  v108_v  =  0 ,  v108_ft  =  0 ,  v108_theta  =  0 ,  v108_v_O  =  0 ; //the continuous vars
static double  v108_vx_u , v108_vy_u , v108_vz_u , v108_g_u , v108_v_u , v108_ft_u , v108_theta_u , v108_v_O_u ; // and their updates
static double  v108_vx_init , v108_vy_init , v108_vz_init , v108_g_init , v108_v_init , v108_ft_init , v108_theta_init , v108_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v108_t1 , v108_t2 , v108_t3 , v108_t4 }; // state declarations

enum states v108 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v108_t1 ):
    if (True == False) {;}
    else if  (v108_g > (44.5)) {
      v108_vx_u = (0.3 * v108_v) ;
      v108_vy_u = 0 ;
      v108_vz_u = (0.7 * v108_v) ;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v108_theta_u = (v108_v / 30.0) ;
      v108_v_O_u = (131.1 + (- (80.1 * pow ( ((v108_v / 30.0)) , (0.5) )))) ;
      v108_ft_u = f (v108_theta,4.0e-2) ;
      cstate =  v108_t2 ;
      force_init_update = False;
    }

    else if ( v108_v <= (44.5)
               && v108_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v108_vx_init = v108_vx ;
      slope =  (v108_vx * -8.7) ;
      v108_vx_u = (slope * d) + v108_vx ;
      if ((pstate != cstate) || force_init_update) v108_vy_init = v108_vy ;
      slope =  (v108_vy * -190.9) ;
      v108_vy_u = (slope * d) + v108_vy ;
      if ((pstate != cstate) || force_init_update) v108_vz_init = v108_vz ;
      slope =  (v108_vz * -190.4) ;
      v108_vz_u = (slope * d) + v108_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v108_t1 ;
      force_init_update = False;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v108_v_u = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_voo = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v108!\n");
      exit(1);
    }
    break;
  case ( v108_t2 ):
    if (True == False) {;}
    else if  (v108_v >= (44.5)) {
      v108_vx_u = v108_vx ;
      v108_vy_u = v108_vy ;
      v108_vz_u = v108_vz ;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v108_t3 ;
      force_init_update = False;
    }
    else if  (v108_g <= (44.5)
               && v108_v < (44.5)) {
      v108_vx_u = v108_vx ;
      v108_vy_u = v108_vy ;
      v108_vz_u = v108_vz ;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v108_t1 ;
      force_init_update = False;
    }

    else if ( v108_v < (44.5)
               && v108_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v108_vx_init = v108_vx ;
      slope =  ((v108_vx * -23.6) + (777200.0 * v108_g)) ;
      v108_vx_u = (slope * d) + v108_vx ;
      if ((pstate != cstate) || force_init_update) v108_vy_init = v108_vy ;
      slope =  ((v108_vy * -45.5) + (58900.0 * v108_g)) ;
      v108_vy_u = (slope * d) + v108_vy ;
      if ((pstate != cstate) || force_init_update) v108_vz_init = v108_vz ;
      slope =  ((v108_vz * -12.9) + (276600.0 * v108_g)) ;
      v108_vz_u = (slope * d) + v108_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v108_t2 ;
      force_init_update = False;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v108_v_u = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_voo = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v108!\n");
      exit(1);
    }
    break;
  case ( v108_t3 ):
    if (True == False) {;}
    else if  (v108_v >= (131.1)) {
      v108_vx_u = v108_vx ;
      v108_vy_u = v108_vy ;
      v108_vz_u = v108_vz ;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v108_t4 ;
      force_init_update = False;
    }

    else if ( v108_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v108_vx_init = v108_vx ;
      slope =  (v108_vx * -6.9) ;
      v108_vx_u = (slope * d) + v108_vx ;
      if ((pstate != cstate) || force_init_update) v108_vy_init = v108_vy ;
      slope =  (v108_vy * 75.9) ;
      v108_vy_u = (slope * d) + v108_vy ;
      if ((pstate != cstate) || force_init_update) v108_vz_init = v108_vz ;
      slope =  (v108_vz * 6826.5) ;
      v108_vz_u = (slope * d) + v108_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v108_t3 ;
      force_init_update = False;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v108_v_u = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_voo = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v108!\n");
      exit(1);
    }
    break;
  case ( v108_t4 ):
    if (True == False) {;}
    else if  (v108_v <= (30.0)) {
      v108_vx_u = v108_vx ;
      v108_vy_u = v108_vy ;
      v108_vz_u = v108_vz ;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v108_t1 ;
      force_init_update = False;
    }

    else if ( v108_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v108_vx_init = v108_vx ;
      slope =  (v108_vx * -33.2) ;
      v108_vx_u = (slope * d) + v108_vx ;
      if ((pstate != cstate) || force_init_update) v108_vy_init = v108_vy ;
      slope =  ((v108_vy * 20.0) * v108_ft) ;
      v108_vy_u = (slope * d) + v108_vy ;
      if ((pstate != cstate) || force_init_update) v108_vz_init = v108_vz ;
      slope =  ((v108_vz * 2.0) * v108_ft) ;
      v108_vz_u = (slope * d) + v108_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v108_t4 ;
      force_init_update = False;
      v108_g_u = ((((((((((((v108_v_i_0 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v108_v_i_1 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v108_v_i_2 + (- ((v108_vx + (- v108_vy)) + v108_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.96740006362))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v108_v_u = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_voo = ((v108_vx + (- v108_vy)) + v108_vz) ;
      v108_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v108!\n");
      exit(1);
    }
    break;
  }
  v108_vx = v108_vx_u;
  v108_vy = v108_vy_u;
  v108_vz = v108_vz_u;
  v108_g = v108_g_u;
  v108_v = v108_v_u;
  v108_ft = v108_ft_u;
  v108_theta = v108_theta_u;
  v108_v_O = v108_v_O_u;
  return cstate;
}