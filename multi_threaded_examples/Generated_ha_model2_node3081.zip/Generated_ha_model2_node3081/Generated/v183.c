#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v183_v_i_0;
double v183_v_i_1;
double v183_v_i_2;
double v183_voo = 0.0;
double v183_state = 0.0;


static double  v183_vx  =  0 ,  v183_vy  =  0 ,  v183_vz  =  0 ,  v183_g  =  0 ,  v183_v  =  0 ,  v183_ft  =  0 ,  v183_theta  =  0 ,  v183_v_O  =  0 ; //the continuous vars
static double  v183_vx_u , v183_vy_u , v183_vz_u , v183_g_u , v183_v_u , v183_ft_u , v183_theta_u , v183_v_O_u ; // and their updates
static double  v183_vx_init , v183_vy_init , v183_vz_init , v183_g_init , v183_v_init , v183_ft_init , v183_theta_init , v183_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v183_t1 , v183_t2 , v183_t3 , v183_t4 }; // state declarations

enum states v183 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v183_t1 ):
    if (True == False) {;}
    else if  (v183_g > (44.5)) {
      v183_vx_u = (0.3 * v183_v) ;
      v183_vy_u = 0 ;
      v183_vz_u = (0.7 * v183_v) ;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v183_theta_u = (v183_v / 30.0) ;
      v183_v_O_u = (131.1 + (- (80.1 * pow ( ((v183_v / 30.0)) , (0.5) )))) ;
      v183_ft_u = f (v183_theta,4.0e-2) ;
      cstate =  v183_t2 ;
      force_init_update = False;
    }

    else if ( v183_v <= (44.5)
               && v183_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v183_vx_init = v183_vx ;
      slope =  (v183_vx * -8.7) ;
      v183_vx_u = (slope * d) + v183_vx ;
      if ((pstate != cstate) || force_init_update) v183_vy_init = v183_vy ;
      slope =  (v183_vy * -190.9) ;
      v183_vy_u = (slope * d) + v183_vy ;
      if ((pstate != cstate) || force_init_update) v183_vz_init = v183_vz ;
      slope =  (v183_vz * -190.4) ;
      v183_vz_u = (slope * d) + v183_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v183_t1 ;
      force_init_update = False;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v183_v_u = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_voo = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v183!\n");
      exit(1);
    }
    break;
  case ( v183_t2 ):
    if (True == False) {;}
    else if  (v183_v >= (44.5)) {
      v183_vx_u = v183_vx ;
      v183_vy_u = v183_vy ;
      v183_vz_u = v183_vz ;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v183_t3 ;
      force_init_update = False;
    }
    else if  (v183_g <= (44.5)
               && v183_v < (44.5)) {
      v183_vx_u = v183_vx ;
      v183_vy_u = v183_vy ;
      v183_vz_u = v183_vz ;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v183_t1 ;
      force_init_update = False;
    }

    else if ( v183_v < (44.5)
               && v183_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v183_vx_init = v183_vx ;
      slope =  ((v183_vx * -23.6) + (777200.0 * v183_g)) ;
      v183_vx_u = (slope * d) + v183_vx ;
      if ((pstate != cstate) || force_init_update) v183_vy_init = v183_vy ;
      slope =  ((v183_vy * -45.5) + (58900.0 * v183_g)) ;
      v183_vy_u = (slope * d) + v183_vy ;
      if ((pstate != cstate) || force_init_update) v183_vz_init = v183_vz ;
      slope =  ((v183_vz * -12.9) + (276600.0 * v183_g)) ;
      v183_vz_u = (slope * d) + v183_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v183_t2 ;
      force_init_update = False;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v183_v_u = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_voo = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v183!\n");
      exit(1);
    }
    break;
  case ( v183_t3 ):
    if (True == False) {;}
    else if  (v183_v >= (131.1)) {
      v183_vx_u = v183_vx ;
      v183_vy_u = v183_vy ;
      v183_vz_u = v183_vz ;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v183_t4 ;
      force_init_update = False;
    }

    else if ( v183_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v183_vx_init = v183_vx ;
      slope =  (v183_vx * -6.9) ;
      v183_vx_u = (slope * d) + v183_vx ;
      if ((pstate != cstate) || force_init_update) v183_vy_init = v183_vy ;
      slope =  (v183_vy * 75.9) ;
      v183_vy_u = (slope * d) + v183_vy ;
      if ((pstate != cstate) || force_init_update) v183_vz_init = v183_vz ;
      slope =  (v183_vz * 6826.5) ;
      v183_vz_u = (slope * d) + v183_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v183_t3 ;
      force_init_update = False;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v183_v_u = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_voo = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v183!\n");
      exit(1);
    }
    break;
  case ( v183_t4 ):
    if (True == False) {;}
    else if  (v183_v <= (30.0)) {
      v183_vx_u = v183_vx ;
      v183_vy_u = v183_vy ;
      v183_vz_u = v183_vz ;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v183_t1 ;
      force_init_update = False;
    }

    else if ( v183_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v183_vx_init = v183_vx ;
      slope =  (v183_vx * -33.2) ;
      v183_vx_u = (slope * d) + v183_vx ;
      if ((pstate != cstate) || force_init_update) v183_vy_init = v183_vy ;
      slope =  ((v183_vy * 20.0) * v183_ft) ;
      v183_vy_u = (slope * d) + v183_vy ;
      if ((pstate != cstate) || force_init_update) v183_vz_init = v183_vz ;
      slope =  ((v183_vz * 2.0) * v183_ft) ;
      v183_vz_u = (slope * d) + v183_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v183_t4 ;
      force_init_update = False;
      v183_g_u = ((((((((((((v183_v_i_0 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603)) + ((((v183_v_i_1 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v183_v_i_2 + (- ((v183_vx + (- v183_vy)) + v183_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v183_v_u = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_voo = ((v183_vx + (- v183_vy)) + v183_vz) ;
      v183_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v183!\n");
      exit(1);
    }
    break;
  }
  v183_vx = v183_vx_u;
  v183_vy = v183_vy_u;
  v183_vz = v183_vz_u;
  v183_g = v183_g_u;
  v183_v = v183_v_u;
  v183_ft = v183_ft_u;
  v183_theta = v183_theta_u;
  v183_v_O = v183_v_O_u;
  return cstate;
}