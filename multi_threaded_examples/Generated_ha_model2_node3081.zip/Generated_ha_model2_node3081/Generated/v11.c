#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v11_v_i_0;
double v11_v_i_1;
double v11_v_i_2;
double v11_voo = 0.0;
double v11_state = 0.0;


static double  v11_vx  =  0 ,  v11_vy  =  0 ,  v11_vz  =  0 ,  v11_g  =  0 ,  v11_v  =  0 ,  v11_ft  =  0 ,  v11_theta  =  0 ,  v11_v_O  =  0 ; //the continuous vars
static double  v11_vx_u , v11_vy_u , v11_vz_u , v11_g_u , v11_v_u , v11_ft_u , v11_theta_u , v11_v_O_u ; // and their updates
static double  v11_vx_init , v11_vy_init , v11_vz_init , v11_g_init , v11_v_init , v11_ft_init , v11_theta_init , v11_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v11_t1 , v11_t2 , v11_t3 , v11_t4 }; // state declarations

enum states v11 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v11_t1 ):
    if (True == False) {;}
    else if  (v11_g > (44.5)) {
      v11_vx_u = (0.3 * v11_v) ;
      v11_vy_u = 0 ;
      v11_vz_u = (0.7 * v11_v) ;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v11_theta_u = (v11_v / 30.0) ;
      v11_v_O_u = (131.1 + (- (80.1 * pow ( ((v11_v / 30.0)) , (0.5) )))) ;
      v11_ft_u = f (v11_theta,4.0e-2) ;
      cstate =  v11_t2 ;
      force_init_update = False;
    }

    else if ( v11_v <= (44.5)
               && v11_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v11_vx_init = v11_vx ;
      slope =  (v11_vx * -8.7) ;
      v11_vx_u = (slope * d) + v11_vx ;
      if ((pstate != cstate) || force_init_update) v11_vy_init = v11_vy ;
      slope =  (v11_vy * -190.9) ;
      v11_vy_u = (slope * d) + v11_vy ;
      if ((pstate != cstate) || force_init_update) v11_vz_init = v11_vz ;
      slope =  (v11_vz * -190.4) ;
      v11_vz_u = (slope * d) + v11_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v11_t1 ;
      force_init_update = False;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v11_v_u = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_voo = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11!\n");
      exit(1);
    }
    break;
  case ( v11_t2 ):
    if (True == False) {;}
    else if  (v11_v >= (44.5)) {
      v11_vx_u = v11_vx ;
      v11_vy_u = v11_vy ;
      v11_vz_u = v11_vz ;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v11_t3 ;
      force_init_update = False;
    }
    else if  (v11_g <= (44.5)
               && v11_v < (44.5)) {
      v11_vx_u = v11_vx ;
      v11_vy_u = v11_vy ;
      v11_vz_u = v11_vz ;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v11_t1 ;
      force_init_update = False;
    }

    else if ( v11_v < (44.5) && 
              v11_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v11_vx_init = v11_vx ;
      slope =  ((v11_vx * -23.6) + (777200.0 * v11_g)) ;
      v11_vx_u = (slope * d) + v11_vx ;
      if ((pstate != cstate) || force_init_update) v11_vy_init = v11_vy ;
      slope =  ((v11_vy * -45.5) + (58900.0 * v11_g)) ;
      v11_vy_u = (slope * d) + v11_vy ;
      if ((pstate != cstate) || force_init_update) v11_vz_init = v11_vz ;
      slope =  ((v11_vz * -12.9) + (276600.0 * v11_g)) ;
      v11_vz_u = (slope * d) + v11_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v11_t2 ;
      force_init_update = False;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v11_v_u = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_voo = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11!\n");
      exit(1);
    }
    break;
  case ( v11_t3 ):
    if (True == False) {;}
    else if  (v11_v >= (131.1)) {
      v11_vx_u = v11_vx ;
      v11_vy_u = v11_vy ;
      v11_vz_u = v11_vz ;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v11_t4 ;
      force_init_update = False;
    }

    else if ( v11_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v11_vx_init = v11_vx ;
      slope =  (v11_vx * -6.9) ;
      v11_vx_u = (slope * d) + v11_vx ;
      if ((pstate != cstate) || force_init_update) v11_vy_init = v11_vy ;
      slope =  (v11_vy * 75.9) ;
      v11_vy_u = (slope * d) + v11_vy ;
      if ((pstate != cstate) || force_init_update) v11_vz_init = v11_vz ;
      slope =  (v11_vz * 6826.5) ;
      v11_vz_u = (slope * d) + v11_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v11_t3 ;
      force_init_update = False;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v11_v_u = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_voo = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11!\n");
      exit(1);
    }
    break;
  case ( v11_t4 ):
    if (True == False) {;}
    else if  (v11_v <= (30.0)) {
      v11_vx_u = v11_vx ;
      v11_vy_u = v11_vy ;
      v11_vz_u = v11_vz ;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v11_t1 ;
      force_init_update = False;
    }

    else if ( v11_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v11_vx_init = v11_vx ;
      slope =  (v11_vx * -33.2) ;
      v11_vx_u = (slope * d) + v11_vx ;
      if ((pstate != cstate) || force_init_update) v11_vy_init = v11_vy ;
      slope =  ((v11_vy * 20.0) * v11_ft) ;
      v11_vy_u = (slope * d) + v11_vy ;
      if ((pstate != cstate) || force_init_update) v11_vz_init = v11_vz ;
      slope =  ((v11_vz * 2.0) * v11_ft) ;
      v11_vz_u = (slope * d) + v11_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v11_t4 ;
      force_init_update = False;
      v11_g_u = ((((((((((((v11_v_i_0 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v11_v_i_1 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791))) + ((((v11_v_i_2 + (- ((v11_vx + (- v11_vy)) + v11_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v11_v_u = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_voo = ((v11_vx + (- v11_vy)) + v11_vz) ;
      v11_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v11!\n");
      exit(1);
    }
    break;
  }
  v11_vx = v11_vx_u;
  v11_vy = v11_vy_u;
  v11_vz = v11_vz_u;
  v11_g = v11_g_u;
  v11_v = v11_v_u;
  v11_ft = v11_ft_u;
  v11_theta = v11_theta_u;
  v11_v_O = v11_v_O_u;
  return cstate;
}