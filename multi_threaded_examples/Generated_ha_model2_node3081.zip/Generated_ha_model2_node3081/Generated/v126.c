#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v126_v_i_0;
double v126_v_i_1;
double v126_v_i_2;
double v126_voo = 0.0;
double v126_state = 0.0;


static double  v126_vx  =  0 ,  v126_vy  =  0 ,  v126_vz  =  0 ,  v126_g  =  0 ,  v126_v  =  0 ,  v126_ft  =  0 ,  v126_theta  =  0 ,  v126_v_O  =  0 ; //the continuous vars
static double  v126_vx_u , v126_vy_u , v126_vz_u , v126_g_u , v126_v_u , v126_ft_u , v126_theta_u , v126_v_O_u ; // and their updates
static double  v126_vx_init , v126_vy_init , v126_vz_init , v126_g_init , v126_v_init , v126_ft_init , v126_theta_init , v126_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v126_t1 , v126_t2 , v126_t3 , v126_t4 }; // state declarations

enum states v126 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v126_t1 ):
    if (True == False) {;}
    else if  (v126_g > (44.5)) {
      v126_vx_u = (0.3 * v126_v) ;
      v126_vy_u = 0 ;
      v126_vz_u = (0.7 * v126_v) ;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v126_theta_u = (v126_v / 30.0) ;
      v126_v_O_u = (131.1 + (- (80.1 * pow ( ((v126_v / 30.0)) , (0.5) )))) ;
      v126_ft_u = f (v126_theta,4.0e-2) ;
      cstate =  v126_t2 ;
      force_init_update = False;
    }

    else if ( v126_v <= (44.5)
               && v126_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v126_vx_init = v126_vx ;
      slope =  (v126_vx * -8.7) ;
      v126_vx_u = (slope * d) + v126_vx ;
      if ((pstate != cstate) || force_init_update) v126_vy_init = v126_vy ;
      slope =  (v126_vy * -190.9) ;
      v126_vy_u = (slope * d) + v126_vy ;
      if ((pstate != cstate) || force_init_update) v126_vz_init = v126_vz ;
      slope =  (v126_vz * -190.4) ;
      v126_vz_u = (slope * d) + v126_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v126_t1 ;
      force_init_update = False;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v126_v_u = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_voo = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v126!\n");
      exit(1);
    }
    break;
  case ( v126_t2 ):
    if (True == False) {;}
    else if  (v126_v >= (44.5)) {
      v126_vx_u = v126_vx ;
      v126_vy_u = v126_vy ;
      v126_vz_u = v126_vz ;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v126_t3 ;
      force_init_update = False;
    }
    else if  (v126_g <= (44.5)
               && v126_v < (44.5)) {
      v126_vx_u = v126_vx ;
      v126_vy_u = v126_vy ;
      v126_vz_u = v126_vz ;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v126_t1 ;
      force_init_update = False;
    }

    else if ( v126_v < (44.5)
               && v126_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v126_vx_init = v126_vx ;
      slope =  ((v126_vx * -23.6) + (777200.0 * v126_g)) ;
      v126_vx_u = (slope * d) + v126_vx ;
      if ((pstate != cstate) || force_init_update) v126_vy_init = v126_vy ;
      slope =  ((v126_vy * -45.5) + (58900.0 * v126_g)) ;
      v126_vy_u = (slope * d) + v126_vy ;
      if ((pstate != cstate) || force_init_update) v126_vz_init = v126_vz ;
      slope =  ((v126_vz * -12.9) + (276600.0 * v126_g)) ;
      v126_vz_u = (slope * d) + v126_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v126_t2 ;
      force_init_update = False;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v126_v_u = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_voo = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v126!\n");
      exit(1);
    }
    break;
  case ( v126_t3 ):
    if (True == False) {;}
    else if  (v126_v >= (131.1)) {
      v126_vx_u = v126_vx ;
      v126_vy_u = v126_vy ;
      v126_vz_u = v126_vz ;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v126_t4 ;
      force_init_update = False;
    }

    else if ( v126_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v126_vx_init = v126_vx ;
      slope =  (v126_vx * -6.9) ;
      v126_vx_u = (slope * d) + v126_vx ;
      if ((pstate != cstate) || force_init_update) v126_vy_init = v126_vy ;
      slope =  (v126_vy * 75.9) ;
      v126_vy_u = (slope * d) + v126_vy ;
      if ((pstate != cstate) || force_init_update) v126_vz_init = v126_vz ;
      slope =  (v126_vz * 6826.5) ;
      v126_vz_u = (slope * d) + v126_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v126_t3 ;
      force_init_update = False;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v126_v_u = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_voo = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v126!\n");
      exit(1);
    }
    break;
  case ( v126_t4 ):
    if (True == False) {;}
    else if  (v126_v <= (30.0)) {
      v126_vx_u = v126_vx ;
      v126_vy_u = v126_vy ;
      v126_vz_u = v126_vz ;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v126_t1 ;
      force_init_update = False;
    }

    else if ( v126_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v126_vx_init = v126_vx ;
      slope =  (v126_vx * -33.2) ;
      v126_vx_u = (slope * d) + v126_vx ;
      if ((pstate != cstate) || force_init_update) v126_vy_init = v126_vy ;
      slope =  ((v126_vy * 20.0) * v126_ft) ;
      v126_vy_u = (slope * d) + v126_vy ;
      if ((pstate != cstate) || force_init_update) v126_vz_init = v126_vz ;
      slope =  ((v126_vz * 2.0) * v126_ft) ;
      v126_vz_u = (slope * d) + v126_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v126_t4 ;
      force_init_update = False;
      v126_g_u = ((((((((((((v126_v_i_0 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275)) + ((((v126_v_i_1 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419))) + ((((v126_v_i_2 + (- ((v126_vx + (- v126_vy)) + v126_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v126_v_u = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_voo = ((v126_vx + (- v126_vy)) + v126_vz) ;
      v126_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v126!\n");
      exit(1);
    }
    break;
  }
  v126_vx = v126_vx_u;
  v126_vy = v126_vy_u;
  v126_vz = v126_vz_u;
  v126_g = v126_g_u;
  v126_v = v126_v_u;
  v126_ft = v126_ft_u;
  v126_theta = v126_theta_u;
  v126_v_O = v126_v_O_u;
  return cstate;
}