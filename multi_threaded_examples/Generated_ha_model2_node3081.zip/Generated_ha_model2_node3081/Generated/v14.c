#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v14_v_i_0;
double v14_v_i_1;
double v14_v_i_2;
double v14_v_i_3;
double v14_voo = 0.0;
double v14_state = 0.0;


static double  v14_vx  =  0 ,  v14_vy  =  0 ,  v14_vz  =  0 ,  v14_g  =  0 ,  v14_v  =  0 ,  v14_ft  =  0 ,  v14_theta  =  0 ,  v14_v_O  =  0 ; //the continuous vars
static double  v14_vx_u , v14_vy_u , v14_vz_u , v14_g_u , v14_v_u , v14_ft_u , v14_theta_u , v14_v_O_u ; // and their updates
static double  v14_vx_init , v14_vy_init , v14_vz_init , v14_g_init , v14_v_init , v14_ft_init , v14_theta_init , v14_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v14_t1 , v14_t2 , v14_t3 , v14_t4 }; // state declarations

enum states v14 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v14_t1 ):
    if (True == False) {;}
    else if  (v14_g > (44.5)) {
      v14_vx_u = (0.3 * v14_v) ;
      v14_vy_u = 0 ;
      v14_vz_u = (0.7 * v14_v) ;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      v14_theta_u = (v14_v / 30.0) ;
      v14_v_O_u = (131.1 + (- (80.1 * pow ( ((v14_v / 30.0)) , (0.5) )))) ;
      v14_ft_u = f (v14_theta,4.0e-2) ;
      cstate =  v14_t2 ;
      force_init_update = False;
    }

    else if ( v14_v <= (44.5)
               && v14_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v14_vx_init = v14_vx ;
      slope =  (v14_vx * -8.7) ;
      v14_vx_u = (slope * d) + v14_vx ;
      if ((pstate != cstate) || force_init_update) v14_vy_init = v14_vy ;
      slope =  (v14_vy * -190.9) ;
      v14_vy_u = (slope * d) + v14_vy ;
      if ((pstate != cstate) || force_init_update) v14_vz_init = v14_vz ;
      slope =  (v14_vz * -190.4) ;
      v14_vz_u = (slope * d) + v14_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v14_t1 ;
      force_init_update = False;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      v14_v_u = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_voo = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14!\n");
      exit(1);
    }
    break;
  case ( v14_t2 ):
    if (True == False) {;}
    else if  (v14_v >= (44.5)) {
      v14_vx_u = v14_vx ;
      v14_vy_u = v14_vy ;
      v14_vz_u = v14_vz ;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v14_t3 ;
      force_init_update = False;
    }
    else if  (v14_g <= (44.5)
               && v14_v < (44.5)) {
      v14_vx_u = v14_vx ;
      v14_vy_u = v14_vy ;
      v14_vz_u = v14_vz ;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v14_t1 ;
      force_init_update = False;
    }

    else if ( v14_v < (44.5) && 
              v14_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v14_vx_init = v14_vx ;
      slope =  ((v14_vx * -23.6) + (777200.0 * v14_g)) ;
      v14_vx_u = (slope * d) + v14_vx ;
      if ((pstate != cstate) || force_init_update) v14_vy_init = v14_vy ;
      slope =  ((v14_vy * -45.5) + (58900.0 * v14_g)) ;
      v14_vy_u = (slope * d) + v14_vy ;
      if ((pstate != cstate) || force_init_update) v14_vz_init = v14_vz ;
      slope =  ((v14_vz * -12.9) + (276600.0 * v14_g)) ;
      v14_vz_u = (slope * d) + v14_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v14_t2 ;
      force_init_update = False;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      v14_v_u = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_voo = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14!\n");
      exit(1);
    }
    break;
  case ( v14_t3 ):
    if (True == False) {;}
    else if  (v14_v >= (131.1)) {
      v14_vx_u = v14_vx ;
      v14_vy_u = v14_vy ;
      v14_vz_u = v14_vz ;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v14_t4 ;
      force_init_update = False;
    }

    else if ( v14_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v14_vx_init = v14_vx ;
      slope =  (v14_vx * -6.9) ;
      v14_vx_u = (slope * d) + v14_vx ;
      if ((pstate != cstate) || force_init_update) v14_vy_init = v14_vy ;
      slope =  (v14_vy * 75.9) ;
      v14_vy_u = (slope * d) + v14_vy ;
      if ((pstate != cstate) || force_init_update) v14_vz_init = v14_vz ;
      slope =  (v14_vz * 6826.5) ;
      v14_vz_u = (slope * d) + v14_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v14_t3 ;
      force_init_update = False;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      v14_v_u = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_voo = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14!\n");
      exit(1);
    }
    break;
  case ( v14_t4 ):
    if (True == False) {;}
    else if  (v14_v <= (30.0)) {
      v14_vx_u = v14_vx ;
      v14_vy_u = v14_vy ;
      v14_vz_u = v14_vz ;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v14_t1 ;
      force_init_update = False;
    }

    else if ( v14_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v14_vx_init = v14_vx ;
      slope =  (v14_vx * -33.2) ;
      v14_vx_u = (slope * d) + v14_vx ;
      if ((pstate != cstate) || force_init_update) v14_vy_init = v14_vy ;
      slope =  ((v14_vy * 20.0) * v14_ft) ;
      v14_vy_u = (slope * d) + v14_vy ;
      if ((pstate != cstate) || force_init_update) v14_vz_init = v14_vz ;
      slope =  ((v14_vz * 2.0) * v14_ft) ;
      v14_vz_u = (slope * d) + v14_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v14_t4 ;
      force_init_update = False;
      v14_g_u = ((((((((((((v14_v_i_0 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.86149095197e-2)) + ((((v14_v_i_1 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.1605971034))) + ((((v14_v_i_2 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.12214856926))) + ((((v14_v_i_3 + (- ((v14_vx + (- v14_vy)) + v14_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.440014832948))) + 0) + 0) + 0) + 0) + 0) ;
      v14_v_u = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_voo = ((v14_vx + (- v14_vy)) + v14_vz) ;
      v14_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14!\n");
      exit(1);
    }
    break;
  }
  v14_vx = v14_vx_u;
  v14_vy = v14_vy_u;
  v14_vz = v14_vz_u;
  v14_g = v14_g_u;
  v14_v = v14_v_u;
  v14_ft = v14_ft_u;
  v14_theta = v14_theta_u;
  v14_v_O = v14_v_O_u;
  return cstate;
}