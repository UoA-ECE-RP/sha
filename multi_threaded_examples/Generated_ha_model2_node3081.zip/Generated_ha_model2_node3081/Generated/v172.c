#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v172_v_i_0;
double v172_v_i_1;
double v172_v_i_2;
double v172_v_i_3;
double v172_voo = 0.0;
double v172_state = 0.0;


static double  v172_vx  =  0 ,  v172_vy  =  0 ,  v172_vz  =  0 ,  v172_g  =  0 ,  v172_v  =  0 ,  v172_ft  =  0 ,  v172_theta  =  0 ,  v172_v_O  =  0 ; //the continuous vars
static double  v172_vx_u , v172_vy_u , v172_vz_u , v172_g_u , v172_v_u , v172_ft_u , v172_theta_u , v172_v_O_u ; // and their updates
static double  v172_vx_init , v172_vy_init , v172_vz_init , v172_g_init , v172_v_init , v172_ft_init , v172_theta_init , v172_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v172_t1 , v172_t2 , v172_t3 , v172_t4 }; // state declarations

enum states v172 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v172_t1 ):
    if (True == False) {;}
    else if  (v172_g > (44.5)) {
      v172_vx_u = (0.3 * v172_v) ;
      v172_vy_u = 0 ;
      v172_vz_u = (0.7 * v172_v) ;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      v172_theta_u = (v172_v / 30.0) ;
      v172_v_O_u = (131.1 + (- (80.1 * pow ( ((v172_v / 30.0)) , (0.5) )))) ;
      v172_ft_u = f (v172_theta,4.0e-2) ;
      cstate =  v172_t2 ;
      force_init_update = False;
    }

    else if ( v172_v <= (44.5)
               && v172_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v172_vx_init = v172_vx ;
      slope =  (v172_vx * -8.7) ;
      v172_vx_u = (slope * d) + v172_vx ;
      if ((pstate != cstate) || force_init_update) v172_vy_init = v172_vy ;
      slope =  (v172_vy * -190.9) ;
      v172_vy_u = (slope * d) + v172_vy ;
      if ((pstate != cstate) || force_init_update) v172_vz_init = v172_vz ;
      slope =  (v172_vz * -190.4) ;
      v172_vz_u = (slope * d) + v172_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v172_t1 ;
      force_init_update = False;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      v172_v_u = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_voo = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172!\n");
      exit(1);
    }
    break;
  case ( v172_t2 ):
    if (True == False) {;}
    else if  (v172_v >= (44.5)) {
      v172_vx_u = v172_vx ;
      v172_vy_u = v172_vy ;
      v172_vz_u = v172_vz ;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v172_t3 ;
      force_init_update = False;
    }
    else if  (v172_g <= (44.5)
               && v172_v < (44.5)) {
      v172_vx_u = v172_vx ;
      v172_vy_u = v172_vy ;
      v172_vz_u = v172_vz ;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v172_t1 ;
      force_init_update = False;
    }

    else if ( v172_v < (44.5)
               && v172_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v172_vx_init = v172_vx ;
      slope =  ((v172_vx * -23.6) + (777200.0 * v172_g)) ;
      v172_vx_u = (slope * d) + v172_vx ;
      if ((pstate != cstate) || force_init_update) v172_vy_init = v172_vy ;
      slope =  ((v172_vy * -45.5) + (58900.0 * v172_g)) ;
      v172_vy_u = (slope * d) + v172_vy ;
      if ((pstate != cstate) || force_init_update) v172_vz_init = v172_vz ;
      slope =  ((v172_vz * -12.9) + (276600.0 * v172_g)) ;
      v172_vz_u = (slope * d) + v172_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v172_t2 ;
      force_init_update = False;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      v172_v_u = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_voo = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172!\n");
      exit(1);
    }
    break;
  case ( v172_t3 ):
    if (True == False) {;}
    else if  (v172_v >= (131.1)) {
      v172_vx_u = v172_vx ;
      v172_vy_u = v172_vy ;
      v172_vz_u = v172_vz ;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v172_t4 ;
      force_init_update = False;
    }

    else if ( v172_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v172_vx_init = v172_vx ;
      slope =  (v172_vx * -6.9) ;
      v172_vx_u = (slope * d) + v172_vx ;
      if ((pstate != cstate) || force_init_update) v172_vy_init = v172_vy ;
      slope =  (v172_vy * 75.9) ;
      v172_vy_u = (slope * d) + v172_vy ;
      if ((pstate != cstate) || force_init_update) v172_vz_init = v172_vz ;
      slope =  (v172_vz * 6826.5) ;
      v172_vz_u = (slope * d) + v172_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v172_t3 ;
      force_init_update = False;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      v172_v_u = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_voo = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172!\n");
      exit(1);
    }
    break;
  case ( v172_t4 ):
    if (True == False) {;}
    else if  (v172_v <= (30.0)) {
      v172_vx_u = v172_vx ;
      v172_vy_u = v172_vy ;
      v172_vz_u = v172_vz ;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v172_t1 ;
      force_init_update = False;
    }

    else if ( v172_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v172_vx_init = v172_vx ;
      slope =  (v172_vx * -33.2) ;
      v172_vx_u = (slope * d) + v172_vx ;
      if ((pstate != cstate) || force_init_update) v172_vy_init = v172_vy ;
      slope =  ((v172_vy * 20.0) * v172_ft) ;
      v172_vy_u = (slope * d) + v172_vy ;
      if ((pstate != cstate) || force_init_update) v172_vz_init = v172_vz ;
      slope =  ((v172_vz * 2.0) * v172_ft) ;
      v172_vz_u = (slope * d) + v172_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v172_t4 ;
      force_init_update = False;
      v172_g_u = ((((((((((((v172_v_i_0 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522)) + ((((v172_v_i_1 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v172_v_i_2 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + ((((v172_v_i_3 + (- ((v172_vx + (- v172_vy)) + v172_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33999860916))) + 0) + 0) + 0) + 0) + 0) ;
      v172_v_u = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_voo = ((v172_vx + (- v172_vy)) + v172_vz) ;
      v172_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v172!\n");
      exit(1);
    }
    break;
  }
  v172_vx = v172_vx_u;
  v172_vy = v172_vy_u;
  v172_vz = v172_vz_u;
  v172_g = v172_g_u;
  v172_v = v172_v_u;
  v172_ft = v172_ft_u;
  v172_theta = v172_theta_u;
  v172_v_O = v172_v_O_u;
  return cstate;
}