#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v179_v415_update_c1vd();
extern double v179_v415_update_c2vd();
extern double v179_v415_update_c1md();
extern double v179_v415_update_c2md();
extern double v179_v415_update_buffer_index(double,double,double,double);
extern double v179_v415_update_latch1(double,double);
extern double v179_v415_update_latch2(double,double);
extern double v179_v415_update_ocell1(double,double);
extern double v179_v415_update_ocell2(double,double);
double v179_v415_cell1_v;
double v179_v415_cell1_mode;
double v179_v415_cell2_v;
double v179_v415_cell2_mode;
double v179_v415_cell1_v_replay = 0.0;
double v179_v415_cell2_v_replay = 0.0;


static double  v179_v415_k  =  0.0 ,  v179_v415_cell1_mode_delayed  =  0.0 ,  v179_v415_cell2_mode_delayed  =  0.0 ,  v179_v415_from_cell  =  0.0 ,  v179_v415_cell1_replay_latch  =  0.0 ,  v179_v415_cell2_replay_latch  =  0.0 ,  v179_v415_cell1_v_delayed  =  0.0 ,  v179_v415_cell2_v_delayed  =  0.0 ,  v179_v415_wasted  =  0.0 ; //the continuous vars
static double  v179_v415_k_u , v179_v415_cell1_mode_delayed_u , v179_v415_cell2_mode_delayed_u , v179_v415_from_cell_u , v179_v415_cell1_replay_latch_u , v179_v415_cell2_replay_latch_u , v179_v415_cell1_v_delayed_u , v179_v415_cell2_v_delayed_u , v179_v415_wasted_u ; // and their updates
static double  v179_v415_k_init , v179_v415_cell1_mode_delayed_init , v179_v415_cell2_mode_delayed_init , v179_v415_from_cell_init , v179_v415_cell1_replay_latch_init , v179_v415_cell2_replay_latch_init , v179_v415_cell1_v_delayed_init , v179_v415_cell2_v_delayed_init , v179_v415_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v179_v415_idle , v179_v415_annhilate , v179_v415_previous_drection1 , v179_v415_previous_direction2 , v179_v415_wait_cell1 , v179_v415_replay_cell1 , v179_v415_replay_cell2 , v179_v415_wait_cell2 }; // state declarations

enum states v179_v415 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v179_v415_idle ):
    if (True == False) {;}
    else if  (v179_v415_cell2_mode == (2.0) && (v179_v415_cell1_mode != (2.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v179_v415_cell1_mode == (2.0) && (v179_v415_cell2_mode != (2.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v179_v415_cell1_mode == (2.0) && (v179_v415_cell2_mode == (2.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_idle ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_annhilate ):
    if (True == False) {;}
    else if  (v179_v415_cell1_mode != (2.0) && (v179_v415_cell2_mode != (2.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_from_cell_u = 0 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_previous_drection1 ):
    if (True == False) {;}
    else if  (v179_v415_from_cell == (1.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (0.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (2.0) && (v179_v415_cell2_mode_delayed == (0.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (2.0) && (v179_v415_cell2_mode_delayed != (0.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_previous_drection1 ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_previous_direction2 ):
    if (True == False) {;}
    else if  (v179_v415_from_cell == (1.0) && (v179_v415_cell1_mode_delayed != (0.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (2.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (0.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v179_v415_from_cell == (1.0) && (v179_v415_cell1_mode_delayed == (0.0))) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_previous_direction2 ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_wait_cell1 ):
    if (True == False) {;}
    else if  (v179_v415_cell2_mode == (2.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
    }
    else if  (v179_v415_k >= (120.172636867)) {
      v179_v415_from_cell_u = 1 ;
      v179_v415_cell1_replay_latch_u = 1 ;
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_wait_cell1 ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_replay_cell1 ):
    if (True == False) {;}
    else if  (v179_v415_cell1_mode == (2.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_annhilate ;
      force_init_update = False;
    }
    else if  (v179_v415_k >= (120.172636867)) {
      v179_v415_from_cell_u = 2 ;
      v179_v415_cell2_replay_latch_u = 1 ;
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_replay_cell1 ;
      force_init_update = False;
      v179_v415_cell1_replay_latch_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_replay_cell2 ):
    if (True == False) {;}
    else if  (v179_v415_k >= (10.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_replay_cell2 ;
      force_init_update = False;
      v179_v415_cell2_replay_latch_u = 1 ;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  case ( v179_v415_wait_cell2 ):
    if (True == False) {;}
    else if  (v179_v415_k >= (10.0)) {
      v179_v415_k_u = 1 ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
      cstate =  v179_v415_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v179_v415_k_init = v179_v415_k ;
      slope =  1 ;
      v179_v415_k_u = (slope * d) + v179_v415_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v179_v415_wait_cell2 ;
      force_init_update = False;
      v179_v415_cell1_v_delayed_u = v179_v415_update_c1vd () ;
      v179_v415_cell2_v_delayed_u = v179_v415_update_c2vd () ;
      v179_v415_cell1_mode_delayed_u = v179_v415_update_c1md () ;
      v179_v415_cell2_mode_delayed_u = v179_v415_update_c2md () ;
      v179_v415_wasted_u = v179_v415_update_buffer_index (v179_v415_cell1_v,v179_v415_cell2_v,v179_v415_cell1_mode,v179_v415_cell2_mode) ;
      v179_v415_cell1_replay_latch_u = v179_v415_update_latch1 (v179_v415_cell1_mode_delayed,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_replay_latch_u = v179_v415_update_latch2 (v179_v415_cell2_mode_delayed,v179_v415_cell2_replay_latch_u) ;
      v179_v415_cell1_v_replay = v179_v415_update_ocell1 (v179_v415_cell1_v_delayed_u,v179_v415_cell1_replay_latch_u) ;
      v179_v415_cell2_v_replay = v179_v415_update_ocell2 (v179_v415_cell2_v_delayed_u,v179_v415_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179_v415!\n");
      exit(1);
    }
    break;
  }
  v179_v415_k = v179_v415_k_u;
  v179_v415_cell1_mode_delayed = v179_v415_cell1_mode_delayed_u;
  v179_v415_cell2_mode_delayed = v179_v415_cell2_mode_delayed_u;
  v179_v415_from_cell = v179_v415_from_cell_u;
  v179_v415_cell1_replay_latch = v179_v415_cell1_replay_latch_u;
  v179_v415_cell2_replay_latch = v179_v415_cell2_replay_latch_u;
  v179_v415_cell1_v_delayed = v179_v415_cell1_v_delayed_u;
  v179_v415_cell2_v_delayed = v179_v415_cell2_v_delayed_u;
  v179_v415_wasted = v179_v415_wasted_u;
  return cstate;
}