#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v110_v_i_0;
double v110_v_i_1;
double v110_v_i_2;
double v110_v_i_3;
double v110_v_i_4;
double v110_voo = 0.0;
double v110_state = 0.0;


static double  v110_vx  =  0 ,  v110_vy  =  0 ,  v110_vz  =  0 ,  v110_g  =  0 ,  v110_v  =  0 ,  v110_ft  =  0 ,  v110_theta  =  0 ,  v110_v_O  =  0 ; //the continuous vars
static double  v110_vx_u , v110_vy_u , v110_vz_u , v110_g_u , v110_v_u , v110_ft_u , v110_theta_u , v110_v_O_u ; // and their updates
static double  v110_vx_init , v110_vy_init , v110_vz_init , v110_g_init , v110_v_init , v110_ft_init , v110_theta_init , v110_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v110_t1 , v110_t2 , v110_t3 , v110_t4 }; // state declarations

enum states v110 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v110_t1 ):
    if (True == False) {;}
    else if  (v110_g > (44.5)) {
      v110_vx_u = (0.3 * v110_v) ;
      v110_vy_u = 0 ;
      v110_vz_u = (0.7 * v110_v) ;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      v110_theta_u = (v110_v / 30.0) ;
      v110_v_O_u = (131.1 + (- (80.1 * pow ( ((v110_v / 30.0)) , (0.5) )))) ;
      v110_ft_u = f (v110_theta,4.0e-2) ;
      cstate =  v110_t2 ;
      force_init_update = False;
    }

    else if ( v110_v <= (44.5)
               && v110_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v110_vx_init = v110_vx ;
      slope =  (v110_vx * -8.7) ;
      v110_vx_u = (slope * d) + v110_vx ;
      if ((pstate != cstate) || force_init_update) v110_vy_init = v110_vy ;
      slope =  (v110_vy * -190.9) ;
      v110_vy_u = (slope * d) + v110_vy ;
      if ((pstate != cstate) || force_init_update) v110_vz_init = v110_vz ;
      slope =  (v110_vz * -190.4) ;
      v110_vz_u = (slope * d) + v110_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v110_t1 ;
      force_init_update = False;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      v110_v_u = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_voo = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110!\n");
      exit(1);
    }
    break;
  case ( v110_t2 ):
    if (True == False) {;}
    else if  (v110_v >= (44.5)) {
      v110_vx_u = v110_vx ;
      v110_vy_u = v110_vy ;
      v110_vz_u = v110_vz ;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      cstate =  v110_t3 ;
      force_init_update = False;
    }
    else if  (v110_g <= (44.5)
               && v110_v < (44.5)) {
      v110_vx_u = v110_vx ;
      v110_vy_u = v110_vy ;
      v110_vz_u = v110_vz ;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      cstate =  v110_t1 ;
      force_init_update = False;
    }

    else if ( v110_v < (44.5)
               && v110_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v110_vx_init = v110_vx ;
      slope =  ((v110_vx * -23.6) + (777200.0 * v110_g)) ;
      v110_vx_u = (slope * d) + v110_vx ;
      if ((pstate != cstate) || force_init_update) v110_vy_init = v110_vy ;
      slope =  ((v110_vy * -45.5) + (58900.0 * v110_g)) ;
      v110_vy_u = (slope * d) + v110_vy ;
      if ((pstate != cstate) || force_init_update) v110_vz_init = v110_vz ;
      slope =  ((v110_vz * -12.9) + (276600.0 * v110_g)) ;
      v110_vz_u = (slope * d) + v110_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v110_t2 ;
      force_init_update = False;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      v110_v_u = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_voo = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110!\n");
      exit(1);
    }
    break;
  case ( v110_t3 ):
    if (True == False) {;}
    else if  (v110_v >= (131.1)) {
      v110_vx_u = v110_vx ;
      v110_vy_u = v110_vy ;
      v110_vz_u = v110_vz ;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      cstate =  v110_t4 ;
      force_init_update = False;
    }

    else if ( v110_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v110_vx_init = v110_vx ;
      slope =  (v110_vx * -6.9) ;
      v110_vx_u = (slope * d) + v110_vx ;
      if ((pstate != cstate) || force_init_update) v110_vy_init = v110_vy ;
      slope =  (v110_vy * 75.9) ;
      v110_vy_u = (slope * d) + v110_vy ;
      if ((pstate != cstate) || force_init_update) v110_vz_init = v110_vz ;
      slope =  (v110_vz * 6826.5) ;
      v110_vz_u = (slope * d) + v110_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v110_t3 ;
      force_init_update = False;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      v110_v_u = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_voo = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110!\n");
      exit(1);
    }
    break;
  case ( v110_t4 ):
    if (True == False) {;}
    else if  (v110_v <= (30.0)) {
      v110_vx_u = v110_vx ;
      v110_vy_u = v110_vy ;
      v110_vz_u = v110_vz ;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      cstate =  v110_t1 ;
      force_init_update = False;
    }

    else if ( v110_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v110_vx_init = v110_vx ;
      slope =  (v110_vx * -33.2) ;
      v110_vx_u = (slope * d) + v110_vx ;
      if ((pstate != cstate) || force_init_update) v110_vy_init = v110_vy ;
      slope =  ((v110_vy * 20.0) * v110_ft) ;
      v110_vy_u = (slope * d) + v110_vy ;
      if ((pstate != cstate) || force_init_update) v110_vz_init = v110_vz ;
      slope =  ((v110_vz * 2.0) * v110_ft) ;
      v110_vz_u = (slope * d) + v110_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v110_t4 ;
      force_init_update = False;
      v110_g_u = ((((((((((((v110_v_i_0 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v110_v_i_1 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v110_v_i_2 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.49528645932))) + ((((v110_v_i_3 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.94771856874))) + ((((v110_v_i_4 + (- ((v110_vx + (- v110_vy)) + v110_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.13574076288))) + 0) + 0) + 0) + 0) ;
      v110_v_u = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_voo = ((v110_vx + (- v110_vy)) + v110_vz) ;
      v110_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110!\n");
      exit(1);
    }
    break;
  }
  v110_vx = v110_vx_u;
  v110_vy = v110_vy_u;
  v110_vz = v110_vz_u;
  v110_g = v110_g_u;
  v110_v = v110_v_u;
  v110_ft = v110_ft_u;
  v110_theta = v110_theta_u;
  v110_v_O = v110_v_O_u;
  return cstate;
}