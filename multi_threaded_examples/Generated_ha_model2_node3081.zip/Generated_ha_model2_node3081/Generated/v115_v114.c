#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v115_v114_update_c1vd();
extern double v115_v114_update_c2vd();
extern double v115_v114_update_c1md();
extern double v115_v114_update_c2md();
extern double v115_v114_update_buffer_index(double,double,double,double);
extern double v115_v114_update_latch1(double,double);
extern double v115_v114_update_latch2(double,double);
extern double v115_v114_update_ocell1(double,double);
extern double v115_v114_update_ocell2(double,double);
double v115_v114_cell1_v;
double v115_v114_cell1_mode;
double v115_v114_cell2_v;
double v115_v114_cell2_mode;
double v115_v114_cell1_v_replay = 0.0;
double v115_v114_cell2_v_replay = 0.0;


static double  v115_v114_k  =  0.0 ,  v115_v114_cell1_mode_delayed  =  0.0 ,  v115_v114_cell2_mode_delayed  =  0.0 ,  v115_v114_from_cell  =  0.0 ,  v115_v114_cell1_replay_latch  =  0.0 ,  v115_v114_cell2_replay_latch  =  0.0 ,  v115_v114_cell1_v_delayed  =  0.0 ,  v115_v114_cell2_v_delayed  =  0.0 ,  v115_v114_wasted  =  0.0 ; //the continuous vars
static double  v115_v114_k_u , v115_v114_cell1_mode_delayed_u , v115_v114_cell2_mode_delayed_u , v115_v114_from_cell_u , v115_v114_cell1_replay_latch_u , v115_v114_cell2_replay_latch_u , v115_v114_cell1_v_delayed_u , v115_v114_cell2_v_delayed_u , v115_v114_wasted_u ; // and their updates
static double  v115_v114_k_init , v115_v114_cell1_mode_delayed_init , v115_v114_cell2_mode_delayed_init , v115_v114_from_cell_init , v115_v114_cell1_replay_latch_init , v115_v114_cell2_replay_latch_init , v115_v114_cell1_v_delayed_init , v115_v114_cell2_v_delayed_init , v115_v114_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v115_v114_idle , v115_v114_annhilate , v115_v114_previous_drection1 , v115_v114_previous_direction2 , v115_v114_wait_cell1 , v115_v114_replay_cell1 , v115_v114_replay_cell2 , v115_v114_wait_cell2 }; // state declarations

enum states v115_v114 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v115_v114_idle ):
    if (True == False) {;}
    else if  (v115_v114_cell2_mode == (2.0) && (v115_v114_cell1_mode != (2.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v115_v114_cell1_mode == (2.0) && (v115_v114_cell2_mode != (2.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v115_v114_cell1_mode == (2.0) && (v115_v114_cell2_mode == (2.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_idle ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_annhilate ):
    if (True == False) {;}
    else if  (v115_v114_cell1_mode != (2.0) && (v115_v114_cell2_mode != (2.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_from_cell_u = 0 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_previous_drection1 ):
    if (True == False) {;}
    else if  (v115_v114_from_cell == (1.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (0.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (2.0) && (v115_v114_cell2_mode_delayed == (0.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (2.0) && (v115_v114_cell2_mode_delayed != (0.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_previous_drection1 ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_previous_direction2 ):
    if (True == False) {;}
    else if  (v115_v114_from_cell == (1.0) && (v115_v114_cell1_mode_delayed != (0.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (2.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (0.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v115_v114_from_cell == (1.0) && (v115_v114_cell1_mode_delayed == (0.0))) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_previous_direction2 ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_wait_cell1 ):
    if (True == False) {;}
    else if  (v115_v114_cell2_mode == (2.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
    }
    else if  (v115_v114_k >= (68.25177585109999)) {
      v115_v114_from_cell_u = 1 ;
      v115_v114_cell1_replay_latch_u = 1 ;
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_wait_cell1 ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_replay_cell1 ):
    if (True == False) {;}
    else if  (v115_v114_cell1_mode == (2.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_annhilate ;
      force_init_update = False;
    }
    else if  (v115_v114_k >= (68.25177585109999)) {
      v115_v114_from_cell_u = 2 ;
      v115_v114_cell2_replay_latch_u = 1 ;
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_replay_cell1 ;
      force_init_update = False;
      v115_v114_cell1_replay_latch_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_replay_cell2 ):
    if (True == False) {;}
    else if  (v115_v114_k >= (10.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_replay_cell2 ;
      force_init_update = False;
      v115_v114_cell2_replay_latch_u = 1 ;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  case ( v115_v114_wait_cell2 ):
    if (True == False) {;}
    else if  (v115_v114_k >= (10.0)) {
      v115_v114_k_u = 1 ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
      cstate =  v115_v114_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v115_v114_k_init = v115_v114_k ;
      slope =  1 ;
      v115_v114_k_u = (slope * d) + v115_v114_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v115_v114_wait_cell2 ;
      force_init_update = False;
      v115_v114_cell1_v_delayed_u = v115_v114_update_c1vd () ;
      v115_v114_cell2_v_delayed_u = v115_v114_update_c2vd () ;
      v115_v114_cell1_mode_delayed_u = v115_v114_update_c1md () ;
      v115_v114_cell2_mode_delayed_u = v115_v114_update_c2md () ;
      v115_v114_wasted_u = v115_v114_update_buffer_index (v115_v114_cell1_v,v115_v114_cell2_v,v115_v114_cell1_mode,v115_v114_cell2_mode) ;
      v115_v114_cell1_replay_latch_u = v115_v114_update_latch1 (v115_v114_cell1_mode_delayed,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_replay_latch_u = v115_v114_update_latch2 (v115_v114_cell2_mode_delayed,v115_v114_cell2_replay_latch_u) ;
      v115_v114_cell1_v_replay = v115_v114_update_ocell1 (v115_v114_cell1_v_delayed_u,v115_v114_cell1_replay_latch_u) ;
      v115_v114_cell2_v_replay = v115_v114_update_ocell2 (v115_v114_cell2_v_delayed_u,v115_v114_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115_v114!\n");
      exit(1);
    }
    break;
  }
  v115_v114_k = v115_v114_k_u;
  v115_v114_cell1_mode_delayed = v115_v114_cell1_mode_delayed_u;
  v115_v114_cell2_mode_delayed = v115_v114_cell2_mode_delayed_u;
  v115_v114_from_cell = v115_v114_from_cell_u;
  v115_v114_cell1_replay_latch = v115_v114_cell1_replay_latch_u;
  v115_v114_cell2_replay_latch = v115_v114_cell2_replay_latch_u;
  v115_v114_cell1_v_delayed = v115_v114_cell1_v_delayed_u;
  v115_v114_cell2_v_delayed = v115_v114_cell2_v_delayed_u;
  v115_v114_wasted = v115_v114_wasted_u;
  return cstate;
}