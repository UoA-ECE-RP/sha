#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v160_v_i_0;
double v160_v_i_1;
double v160_v_i_2;
double v160_voo = 0.0;
double v160_state = 0.0;


static double  v160_vx  =  0 ,  v160_vy  =  0 ,  v160_vz  =  0 ,  v160_g  =  0 ,  v160_v  =  0 ,  v160_ft  =  0 ,  v160_theta  =  0 ,  v160_v_O  =  0 ; //the continuous vars
static double  v160_vx_u , v160_vy_u , v160_vz_u , v160_g_u , v160_v_u , v160_ft_u , v160_theta_u , v160_v_O_u ; // and their updates
static double  v160_vx_init , v160_vy_init , v160_vz_init , v160_g_init , v160_v_init , v160_ft_init , v160_theta_init , v160_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v160_t1 , v160_t2 , v160_t3 , v160_t4 }; // state declarations

enum states v160 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v160_t1 ):
    if (True == False) {;}
    else if  (v160_g > (44.5)) {
      v160_vx_u = (0.3 * v160_v) ;
      v160_vy_u = 0 ;
      v160_vz_u = (0.7 * v160_v) ;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v160_theta_u = (v160_v / 30.0) ;
      v160_v_O_u = (131.1 + (- (80.1 * pow ( ((v160_v / 30.0)) , (0.5) )))) ;
      v160_ft_u = f (v160_theta,4.0e-2) ;
      cstate =  v160_t2 ;
      force_init_update = False;
    }

    else if ( v160_v <= (44.5)
               && v160_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v160_vx_init = v160_vx ;
      slope =  (v160_vx * -8.7) ;
      v160_vx_u = (slope * d) + v160_vx ;
      if ((pstate != cstate) || force_init_update) v160_vy_init = v160_vy ;
      slope =  (v160_vy * -190.9) ;
      v160_vy_u = (slope * d) + v160_vy ;
      if ((pstate != cstate) || force_init_update) v160_vz_init = v160_vz ;
      slope =  (v160_vz * -190.4) ;
      v160_vz_u = (slope * d) + v160_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v160_t1 ;
      force_init_update = False;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v160_v_u = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_voo = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160!\n");
      exit(1);
    }
    break;
  case ( v160_t2 ):
    if (True == False) {;}
    else if  (v160_v >= (44.5)) {
      v160_vx_u = v160_vx ;
      v160_vy_u = v160_vy ;
      v160_vz_u = v160_vz ;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v160_t3 ;
      force_init_update = False;
    }
    else if  (v160_g <= (44.5)
               && v160_v < (44.5)) {
      v160_vx_u = v160_vx ;
      v160_vy_u = v160_vy ;
      v160_vz_u = v160_vz ;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v160_t1 ;
      force_init_update = False;
    }

    else if ( v160_v < (44.5)
               && v160_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v160_vx_init = v160_vx ;
      slope =  ((v160_vx * -23.6) + (777200.0 * v160_g)) ;
      v160_vx_u = (slope * d) + v160_vx ;
      if ((pstate != cstate) || force_init_update) v160_vy_init = v160_vy ;
      slope =  ((v160_vy * -45.5) + (58900.0 * v160_g)) ;
      v160_vy_u = (slope * d) + v160_vy ;
      if ((pstate != cstate) || force_init_update) v160_vz_init = v160_vz ;
      slope =  ((v160_vz * -12.9) + (276600.0 * v160_g)) ;
      v160_vz_u = (slope * d) + v160_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v160_t2 ;
      force_init_update = False;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v160_v_u = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_voo = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160!\n");
      exit(1);
    }
    break;
  case ( v160_t3 ):
    if (True == False) {;}
    else if  (v160_v >= (131.1)) {
      v160_vx_u = v160_vx ;
      v160_vy_u = v160_vy ;
      v160_vz_u = v160_vz ;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v160_t4 ;
      force_init_update = False;
    }

    else if ( v160_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v160_vx_init = v160_vx ;
      slope =  (v160_vx * -6.9) ;
      v160_vx_u = (slope * d) + v160_vx ;
      if ((pstate != cstate) || force_init_update) v160_vy_init = v160_vy ;
      slope =  (v160_vy * 75.9) ;
      v160_vy_u = (slope * d) + v160_vy ;
      if ((pstate != cstate) || force_init_update) v160_vz_init = v160_vz ;
      slope =  (v160_vz * 6826.5) ;
      v160_vz_u = (slope * d) + v160_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v160_t3 ;
      force_init_update = False;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v160_v_u = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_voo = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160!\n");
      exit(1);
    }
    break;
  case ( v160_t4 ):
    if (True == False) {;}
    else if  (v160_v <= (30.0)) {
      v160_vx_u = v160_vx ;
      v160_vy_u = v160_vy ;
      v160_vz_u = v160_vz ;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v160_t1 ;
      force_init_update = False;
    }

    else if ( v160_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v160_vx_init = v160_vx ;
      slope =  (v160_vx * -33.2) ;
      v160_vx_u = (slope * d) + v160_vx ;
      if ((pstate != cstate) || force_init_update) v160_vy_init = v160_vy ;
      slope =  ((v160_vy * 20.0) * v160_ft) ;
      v160_vy_u = (slope * d) + v160_vy ;
      if ((pstate != cstate) || force_init_update) v160_vz_init = v160_vz ;
      slope =  ((v160_vz * 2.0) * v160_ft) ;
      v160_vz_u = (slope * d) + v160_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v160_t4 ;
      force_init_update = False;
      v160_g_u = ((((((((((((v160_v_i_0 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922)) + ((((v160_v_i_1 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v160_v_i_2 + (- ((v160_vx + (- v160_vy)) + v160_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17897726181))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v160_v_u = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_voo = ((v160_vx + (- v160_vy)) + v160_vz) ;
      v160_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v160!\n");
      exit(1);
    }
    break;
  }
  v160_vx = v160_vx_u;
  v160_vy = v160_vy_u;
  v160_vz = v160_vz_u;
  v160_g = v160_g_u;
  v160_v = v160_v_u;
  v160_ft = v160_ft_u;
  v160_theta = v160_theta_u;
  v160_v_O = v160_v_O_u;
  return cstate;
}