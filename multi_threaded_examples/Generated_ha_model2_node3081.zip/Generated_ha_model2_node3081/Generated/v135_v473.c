#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v135_v473_update_c1vd();
extern double v135_v473_update_c2vd();
extern double v135_v473_update_c1md();
extern double v135_v473_update_c2md();
extern double v135_v473_update_buffer_index(double,double,double,double);
extern double v135_v473_update_latch1(double,double);
extern double v135_v473_update_latch2(double,double);
extern double v135_v473_update_ocell1(double,double);
extern double v135_v473_update_ocell2(double,double);
double v135_v473_cell1_v;
double v135_v473_cell1_mode;
double v135_v473_cell2_v;
double v135_v473_cell2_mode;
double v135_v473_cell1_v_replay = 0.0;
double v135_v473_cell2_v_replay = 0.0;


static double  v135_v473_k  =  0.0 ,  v135_v473_cell1_mode_delayed  =  0.0 ,  v135_v473_cell2_mode_delayed  =  0.0 ,  v135_v473_from_cell  =  0.0 ,  v135_v473_cell1_replay_latch  =  0.0 ,  v135_v473_cell2_replay_latch  =  0.0 ,  v135_v473_cell1_v_delayed  =  0.0 ,  v135_v473_cell2_v_delayed  =  0.0 ,  v135_v473_wasted  =  0.0 ; //the continuous vars
static double  v135_v473_k_u , v135_v473_cell1_mode_delayed_u , v135_v473_cell2_mode_delayed_u , v135_v473_from_cell_u , v135_v473_cell1_replay_latch_u , v135_v473_cell2_replay_latch_u , v135_v473_cell1_v_delayed_u , v135_v473_cell2_v_delayed_u , v135_v473_wasted_u ; // and their updates
static double  v135_v473_k_init , v135_v473_cell1_mode_delayed_init , v135_v473_cell2_mode_delayed_init , v135_v473_from_cell_init , v135_v473_cell1_replay_latch_init , v135_v473_cell2_replay_latch_init , v135_v473_cell1_v_delayed_init , v135_v473_cell2_v_delayed_init , v135_v473_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v135_v473_idle , v135_v473_annhilate , v135_v473_previous_drection1 , v135_v473_previous_direction2 , v135_v473_wait_cell1 , v135_v473_replay_cell1 , v135_v473_replay_cell2 , v135_v473_wait_cell2 }; // state declarations

enum states v135_v473 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v135_v473_idle ):
    if (True == False) {;}
    else if  (v135_v473_cell2_mode == (2.0) && (v135_v473_cell1_mode != (2.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v135_v473_cell1_mode == (2.0) && (v135_v473_cell2_mode != (2.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v135_v473_cell1_mode == (2.0) && (v135_v473_cell2_mode == (2.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_idle ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_annhilate ):
    if (True == False) {;}
    else if  (v135_v473_cell1_mode != (2.0) && (v135_v473_cell2_mode != (2.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_from_cell_u = 0 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_previous_drection1 ):
    if (True == False) {;}
    else if  (v135_v473_from_cell == (1.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (0.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (2.0) && (v135_v473_cell2_mode_delayed == (0.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (2.0) && (v135_v473_cell2_mode_delayed != (0.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_previous_drection1 ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_previous_direction2 ):
    if (True == False) {;}
    else if  (v135_v473_from_cell == (1.0) && (v135_v473_cell1_mode_delayed != (0.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (2.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (0.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v135_v473_from_cell == (1.0) && (v135_v473_cell1_mode_delayed == (0.0))) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_previous_direction2 ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_wait_cell1 ):
    if (True == False) {;}
    else if  (v135_v473_cell2_mode == (2.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
    }
    else if  (v135_v473_k >= (83.3791670447)) {
      v135_v473_from_cell_u = 1 ;
      v135_v473_cell1_replay_latch_u = 1 ;
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_wait_cell1 ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_replay_cell1 ):
    if (True == False) {;}
    else if  (v135_v473_cell1_mode == (2.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_annhilate ;
      force_init_update = False;
    }
    else if  (v135_v473_k >= (83.3791670447)) {
      v135_v473_from_cell_u = 2 ;
      v135_v473_cell2_replay_latch_u = 1 ;
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_replay_cell1 ;
      force_init_update = False;
      v135_v473_cell1_replay_latch_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_replay_cell2 ):
    if (True == False) {;}
    else if  (v135_v473_k >= (10.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_replay_cell2 ;
      force_init_update = False;
      v135_v473_cell2_replay_latch_u = 1 ;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  case ( v135_v473_wait_cell2 ):
    if (True == False) {;}
    else if  (v135_v473_k >= (10.0)) {
      v135_v473_k_u = 1 ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
      cstate =  v135_v473_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v135_v473_k_init = v135_v473_k ;
      slope =  1 ;
      v135_v473_k_u = (slope * d) + v135_v473_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v135_v473_wait_cell2 ;
      force_init_update = False;
      v135_v473_cell1_v_delayed_u = v135_v473_update_c1vd () ;
      v135_v473_cell2_v_delayed_u = v135_v473_update_c2vd () ;
      v135_v473_cell1_mode_delayed_u = v135_v473_update_c1md () ;
      v135_v473_cell2_mode_delayed_u = v135_v473_update_c2md () ;
      v135_v473_wasted_u = v135_v473_update_buffer_index (v135_v473_cell1_v,v135_v473_cell2_v,v135_v473_cell1_mode,v135_v473_cell2_mode) ;
      v135_v473_cell1_replay_latch_u = v135_v473_update_latch1 (v135_v473_cell1_mode_delayed,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_replay_latch_u = v135_v473_update_latch2 (v135_v473_cell2_mode_delayed,v135_v473_cell2_replay_latch_u) ;
      v135_v473_cell1_v_replay = v135_v473_update_ocell1 (v135_v473_cell1_v_delayed_u,v135_v473_cell1_replay_latch_u) ;
      v135_v473_cell2_v_replay = v135_v473_update_ocell2 (v135_v473_cell2_v_delayed_u,v135_v473_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v135_v473!\n");
      exit(1);
    }
    break;
  }
  v135_v473_k = v135_v473_k_u;
  v135_v473_cell1_mode_delayed = v135_v473_cell1_mode_delayed_u;
  v135_v473_cell2_mode_delayed = v135_v473_cell2_mode_delayed_u;
  v135_v473_from_cell = v135_v473_from_cell_u;
  v135_v473_cell1_replay_latch = v135_v473_cell1_replay_latch_u;
  v135_v473_cell2_replay_latch = v135_v473_cell2_replay_latch_u;
  v135_v473_cell1_v_delayed = v135_v473_cell1_v_delayed_u;
  v135_v473_cell2_v_delayed = v135_v473_cell2_v_delayed_u;
  v135_v473_wasted = v135_v473_wasted_u;
  return cstate;
}