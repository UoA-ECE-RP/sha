#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v106_v_i_0;
double v106_v_i_1;
double v106_v_i_2;
double v106_v_i_3;
double v106_voo = 0.0;
double v106_state = 0.0;


static double  v106_vx  =  0 ,  v106_vy  =  0 ,  v106_vz  =  0 ,  v106_g  =  0 ,  v106_v  =  0 ,  v106_ft  =  0 ,  v106_theta  =  0 ,  v106_v_O  =  0 ; //the continuous vars
static double  v106_vx_u , v106_vy_u , v106_vz_u , v106_g_u , v106_v_u , v106_ft_u , v106_theta_u , v106_v_O_u ; // and their updates
static double  v106_vx_init , v106_vy_init , v106_vz_init , v106_g_init , v106_v_init , v106_ft_init , v106_theta_init , v106_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v106_t1 , v106_t2 , v106_t3 , v106_t4 }; // state declarations

enum states v106 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v106_t1 ):
    if (True == False) {;}
    else if  (v106_g > (44.5)) {
      v106_vx_u = (0.3 * v106_v) ;
      v106_vy_u = 0 ;
      v106_vz_u = (0.7 * v106_v) ;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      v106_theta_u = (v106_v / 30.0) ;
      v106_v_O_u = (131.1 + (- (80.1 * pow ( ((v106_v / 30.0)) , (0.5) )))) ;
      v106_ft_u = f (v106_theta,4.0e-2) ;
      cstate =  v106_t2 ;
      force_init_update = False;
    }

    else if ( v106_v <= (44.5)
               && v106_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v106_vx_init = v106_vx ;
      slope =  (v106_vx * -8.7) ;
      v106_vx_u = (slope * d) + v106_vx ;
      if ((pstate != cstate) || force_init_update) v106_vy_init = v106_vy ;
      slope =  (v106_vy * -190.9) ;
      v106_vy_u = (slope * d) + v106_vy ;
      if ((pstate != cstate) || force_init_update) v106_vz_init = v106_vz ;
      slope =  (v106_vz * -190.4) ;
      v106_vz_u = (slope * d) + v106_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v106_t1 ;
      force_init_update = False;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      v106_v_u = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_voo = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106!\n");
      exit(1);
    }
    break;
  case ( v106_t2 ):
    if (True == False) {;}
    else if  (v106_v >= (44.5)) {
      v106_vx_u = v106_vx ;
      v106_vy_u = v106_vy ;
      v106_vz_u = v106_vz ;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v106_t3 ;
      force_init_update = False;
    }
    else if  (v106_g <= (44.5)
               && v106_v < (44.5)) {
      v106_vx_u = v106_vx ;
      v106_vy_u = v106_vy ;
      v106_vz_u = v106_vz ;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v106_t1 ;
      force_init_update = False;
    }

    else if ( v106_v < (44.5)
               && v106_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v106_vx_init = v106_vx ;
      slope =  ((v106_vx * -23.6) + (777200.0 * v106_g)) ;
      v106_vx_u = (slope * d) + v106_vx ;
      if ((pstate != cstate) || force_init_update) v106_vy_init = v106_vy ;
      slope =  ((v106_vy * -45.5) + (58900.0 * v106_g)) ;
      v106_vy_u = (slope * d) + v106_vy ;
      if ((pstate != cstate) || force_init_update) v106_vz_init = v106_vz ;
      slope =  ((v106_vz * -12.9) + (276600.0 * v106_g)) ;
      v106_vz_u = (slope * d) + v106_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v106_t2 ;
      force_init_update = False;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      v106_v_u = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_voo = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106!\n");
      exit(1);
    }
    break;
  case ( v106_t3 ):
    if (True == False) {;}
    else if  (v106_v >= (131.1)) {
      v106_vx_u = v106_vx ;
      v106_vy_u = v106_vy ;
      v106_vz_u = v106_vz ;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v106_t4 ;
      force_init_update = False;
    }

    else if ( v106_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v106_vx_init = v106_vx ;
      slope =  (v106_vx * -6.9) ;
      v106_vx_u = (slope * d) + v106_vx ;
      if ((pstate != cstate) || force_init_update) v106_vy_init = v106_vy ;
      slope =  (v106_vy * 75.9) ;
      v106_vy_u = (slope * d) + v106_vy ;
      if ((pstate != cstate) || force_init_update) v106_vz_init = v106_vz ;
      slope =  (v106_vz * 6826.5) ;
      v106_vz_u = (slope * d) + v106_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v106_t3 ;
      force_init_update = False;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      v106_v_u = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_voo = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106!\n");
      exit(1);
    }
    break;
  case ( v106_t4 ):
    if (True == False) {;}
    else if  (v106_v <= (30.0)) {
      v106_vx_u = v106_vx ;
      v106_vy_u = v106_vy ;
      v106_vz_u = v106_vz ;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v106_t1 ;
      force_init_update = False;
    }

    else if ( v106_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v106_vx_init = v106_vx ;
      slope =  (v106_vx * -33.2) ;
      v106_vx_u = (slope * d) + v106_vx ;
      if ((pstate != cstate) || force_init_update) v106_vy_init = v106_vy ;
      slope =  ((v106_vy * 20.0) * v106_ft) ;
      v106_vy_u = (slope * d) + v106_vy ;
      if ((pstate != cstate) || force_init_update) v106_vz_init = v106_vz ;
      slope =  ((v106_vz * 2.0) * v106_ft) ;
      v106_vz_u = (slope * d) + v106_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v106_t4 ;
      force_init_update = False;
      v106_g_u = ((((((((((((v106_v_i_0 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v106_v_i_1 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v106_v_i_2 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.24356096038))) + ((((v106_v_i_3 + (- ((v106_vx + (- v106_vy)) + v106_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08140071147))) + 0) + 0) + 0) + 0) + 0) ;
      v106_v_u = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_voo = ((v106_vx + (- v106_vy)) + v106_vz) ;
      v106_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v106!\n");
      exit(1);
    }
    break;
  }
  v106_vx = v106_vx_u;
  v106_vy = v106_vy_u;
  v106_vz = v106_vz_u;
  v106_g = v106_g_u;
  v106_v = v106_v_u;
  v106_ft = v106_ft_u;
  v106_theta = v106_theta_u;
  v106_v_O = v106_v_O_u;
  return cstate;
}