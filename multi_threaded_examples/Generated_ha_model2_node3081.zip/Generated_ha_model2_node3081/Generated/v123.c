#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v123_v_i_0;
double v123_v_i_1;
double v123_v_i_2;
double v123_voo = 0.0;
double v123_state = 0.0;


static double  v123_vx  =  0 ,  v123_vy  =  0 ,  v123_vz  =  0 ,  v123_g  =  0 ,  v123_v  =  0 ,  v123_ft  =  0 ,  v123_theta  =  0 ,  v123_v_O  =  0 ; //the continuous vars
static double  v123_vx_u , v123_vy_u , v123_vz_u , v123_g_u , v123_v_u , v123_ft_u , v123_theta_u , v123_v_O_u ; // and their updates
static double  v123_vx_init , v123_vy_init , v123_vz_init , v123_g_init , v123_v_init , v123_ft_init , v123_theta_init , v123_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v123_t1 , v123_t2 , v123_t3 , v123_t4 }; // state declarations

enum states v123 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v123_t1 ):
    if (True == False) {;}
    else if  (v123_g > (44.5)) {
      v123_vx_u = (0.3 * v123_v) ;
      v123_vy_u = 0 ;
      v123_vz_u = (0.7 * v123_v) ;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v123_theta_u = (v123_v / 30.0) ;
      v123_v_O_u = (131.1 + (- (80.1 * pow ( ((v123_v / 30.0)) , (0.5) )))) ;
      v123_ft_u = f (v123_theta,4.0e-2) ;
      cstate =  v123_t2 ;
      force_init_update = False;
    }

    else if ( v123_v <= (44.5)
               && v123_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v123_vx_init = v123_vx ;
      slope =  (v123_vx * -8.7) ;
      v123_vx_u = (slope * d) + v123_vx ;
      if ((pstate != cstate) || force_init_update) v123_vy_init = v123_vy ;
      slope =  (v123_vy * -190.9) ;
      v123_vy_u = (slope * d) + v123_vy ;
      if ((pstate != cstate) || force_init_update) v123_vz_init = v123_vz ;
      slope =  (v123_vz * -190.4) ;
      v123_vz_u = (slope * d) + v123_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v123_t1 ;
      force_init_update = False;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v123_v_u = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_voo = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123!\n");
      exit(1);
    }
    break;
  case ( v123_t2 ):
    if (True == False) {;}
    else if  (v123_v >= (44.5)) {
      v123_vx_u = v123_vx ;
      v123_vy_u = v123_vy ;
      v123_vz_u = v123_vz ;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v123_t3 ;
      force_init_update = False;
    }
    else if  (v123_g <= (44.5)
               && v123_v < (44.5)) {
      v123_vx_u = v123_vx ;
      v123_vy_u = v123_vy ;
      v123_vz_u = v123_vz ;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v123_t1 ;
      force_init_update = False;
    }

    else if ( v123_v < (44.5)
               && v123_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v123_vx_init = v123_vx ;
      slope =  ((v123_vx * -23.6) + (777200.0 * v123_g)) ;
      v123_vx_u = (slope * d) + v123_vx ;
      if ((pstate != cstate) || force_init_update) v123_vy_init = v123_vy ;
      slope =  ((v123_vy * -45.5) + (58900.0 * v123_g)) ;
      v123_vy_u = (slope * d) + v123_vy ;
      if ((pstate != cstate) || force_init_update) v123_vz_init = v123_vz ;
      slope =  ((v123_vz * -12.9) + (276600.0 * v123_g)) ;
      v123_vz_u = (slope * d) + v123_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v123_t2 ;
      force_init_update = False;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v123_v_u = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_voo = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123!\n");
      exit(1);
    }
    break;
  case ( v123_t3 ):
    if (True == False) {;}
    else if  (v123_v >= (131.1)) {
      v123_vx_u = v123_vx ;
      v123_vy_u = v123_vy ;
      v123_vz_u = v123_vz ;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v123_t4 ;
      force_init_update = False;
    }

    else if ( v123_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v123_vx_init = v123_vx ;
      slope =  (v123_vx * -6.9) ;
      v123_vx_u = (slope * d) + v123_vx ;
      if ((pstate != cstate) || force_init_update) v123_vy_init = v123_vy ;
      slope =  (v123_vy * 75.9) ;
      v123_vy_u = (slope * d) + v123_vy ;
      if ((pstate != cstate) || force_init_update) v123_vz_init = v123_vz ;
      slope =  (v123_vz * 6826.5) ;
      v123_vz_u = (slope * d) + v123_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v123_t3 ;
      force_init_update = False;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v123_v_u = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_voo = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123!\n");
      exit(1);
    }
    break;
  case ( v123_t4 ):
    if (True == False) {;}
    else if  (v123_v <= (30.0)) {
      v123_vx_u = v123_vx ;
      v123_vy_u = v123_vy ;
      v123_vz_u = v123_vz ;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v123_t1 ;
      force_init_update = False;
    }

    else if ( v123_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v123_vx_init = v123_vx ;
      slope =  (v123_vx * -33.2) ;
      v123_vx_u = (slope * d) + v123_vx ;
      if ((pstate != cstate) || force_init_update) v123_vy_init = v123_vy ;
      slope =  ((v123_vy * 20.0) * v123_ft) ;
      v123_vy_u = (slope * d) + v123_vy ;
      if ((pstate != cstate) || force_init_update) v123_vz_init = v123_vz ;
      slope =  ((v123_vz * 2.0) * v123_ft) ;
      v123_vz_u = (slope * d) + v123_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v123_t4 ;
      force_init_update = False;
      v123_g_u = ((((((((((((v123_v_i_0 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289)) + ((((v123_v_i_1 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.89039317617))) + ((((v123_v_i_2 + (- ((v123_vx + (- v123_vy)) + v123_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v123_v_u = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_voo = ((v123_vx + (- v123_vy)) + v123_vz) ;
      v123_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v123!\n");
      exit(1);
    }
    break;
  }
  v123_vx = v123_vx_u;
  v123_vy = v123_vy_u;
  v123_vz = v123_vz_u;
  v123_g = v123_g_u;
  v123_v = v123_v_u;
  v123_ft = v123_ft_u;
  v123_theta = v123_theta_u;
  v123_v_O = v123_v_O_u;
  return cstate;
}