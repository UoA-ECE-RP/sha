#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v104_v_i_0;
double v104_v_i_1;
double v104_v_i_2;
double v104_voo = 0.0;
double v104_state = 0.0;


static double  v104_vx  =  0 ,  v104_vy  =  0 ,  v104_vz  =  0 ,  v104_g  =  0 ,  v104_v  =  0 ,  v104_ft  =  0 ,  v104_theta  =  0 ,  v104_v_O  =  0 ; //the continuous vars
static double  v104_vx_u , v104_vy_u , v104_vz_u , v104_g_u , v104_v_u , v104_ft_u , v104_theta_u , v104_v_O_u ; // and their updates
static double  v104_vx_init , v104_vy_init , v104_vz_init , v104_g_init , v104_v_init , v104_ft_init , v104_theta_init , v104_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v104_t1 , v104_t2 , v104_t3 , v104_t4 }; // state declarations

enum states v104 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v104_t1 ):
    if (True == False) {;}
    else if  (v104_g > (44.5)) {
      v104_vx_u = (0.3 * v104_v) ;
      v104_vy_u = 0 ;
      v104_vz_u = (0.7 * v104_v) ;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v104_theta_u = (v104_v / 30.0) ;
      v104_v_O_u = (131.1 + (- (80.1 * pow ( ((v104_v / 30.0)) , (0.5) )))) ;
      v104_ft_u = f (v104_theta,4.0e-2) ;
      cstate =  v104_t2 ;
      force_init_update = False;
    }

    else if ( v104_v <= (44.5)
               && v104_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v104_vx_init = v104_vx ;
      slope =  (v104_vx * -8.7) ;
      v104_vx_u = (slope * d) + v104_vx ;
      if ((pstate != cstate) || force_init_update) v104_vy_init = v104_vy ;
      slope =  (v104_vy * -190.9) ;
      v104_vy_u = (slope * d) + v104_vy ;
      if ((pstate != cstate) || force_init_update) v104_vz_init = v104_vz ;
      slope =  (v104_vz * -190.4) ;
      v104_vz_u = (slope * d) + v104_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v104_t1 ;
      force_init_update = False;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v104_v_u = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_voo = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104!\n");
      exit(1);
    }
    break;
  case ( v104_t2 ):
    if (True == False) {;}
    else if  (v104_v >= (44.5)) {
      v104_vx_u = v104_vx ;
      v104_vy_u = v104_vy ;
      v104_vz_u = v104_vz ;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v104_t3 ;
      force_init_update = False;
    }
    else if  (v104_g <= (44.5)
               && v104_v < (44.5)) {
      v104_vx_u = v104_vx ;
      v104_vy_u = v104_vy ;
      v104_vz_u = v104_vz ;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v104_t1 ;
      force_init_update = False;
    }

    else if ( v104_v < (44.5)
               && v104_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v104_vx_init = v104_vx ;
      slope =  ((v104_vx * -23.6) + (777200.0 * v104_g)) ;
      v104_vx_u = (slope * d) + v104_vx ;
      if ((pstate != cstate) || force_init_update) v104_vy_init = v104_vy ;
      slope =  ((v104_vy * -45.5) + (58900.0 * v104_g)) ;
      v104_vy_u = (slope * d) + v104_vy ;
      if ((pstate != cstate) || force_init_update) v104_vz_init = v104_vz ;
      slope =  ((v104_vz * -12.9) + (276600.0 * v104_g)) ;
      v104_vz_u = (slope * d) + v104_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v104_t2 ;
      force_init_update = False;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v104_v_u = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_voo = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104!\n");
      exit(1);
    }
    break;
  case ( v104_t3 ):
    if (True == False) {;}
    else if  (v104_v >= (131.1)) {
      v104_vx_u = v104_vx ;
      v104_vy_u = v104_vy ;
      v104_vz_u = v104_vz ;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v104_t4 ;
      force_init_update = False;
    }

    else if ( v104_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v104_vx_init = v104_vx ;
      slope =  (v104_vx * -6.9) ;
      v104_vx_u = (slope * d) + v104_vx ;
      if ((pstate != cstate) || force_init_update) v104_vy_init = v104_vy ;
      slope =  (v104_vy * 75.9) ;
      v104_vy_u = (slope * d) + v104_vy ;
      if ((pstate != cstate) || force_init_update) v104_vz_init = v104_vz ;
      slope =  (v104_vz * 6826.5) ;
      v104_vz_u = (slope * d) + v104_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v104_t3 ;
      force_init_update = False;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v104_v_u = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_voo = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104!\n");
      exit(1);
    }
    break;
  case ( v104_t4 ):
    if (True == False) {;}
    else if  (v104_v <= (30.0)) {
      v104_vx_u = v104_vx ;
      v104_vy_u = v104_vy ;
      v104_vz_u = v104_vz ;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v104_t1 ;
      force_init_update = False;
    }

    else if ( v104_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v104_vx_init = v104_vx ;
      slope =  (v104_vx * -33.2) ;
      v104_vx_u = (slope * d) + v104_vx ;
      if ((pstate != cstate) || force_init_update) v104_vy_init = v104_vy ;
      slope =  ((v104_vy * 20.0) * v104_ft) ;
      v104_vy_u = (slope * d) + v104_vy ;
      if ((pstate != cstate) || force_init_update) v104_vz_init = v104_vz ;
      slope =  ((v104_vz * 2.0) * v104_ft) ;
      v104_vz_u = (slope * d) + v104_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v104_t4 ;
      force_init_update = False;
      v104_g_u = ((((((((((((v104_v_i_0 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v104_v_i_1 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v104_v_i_2 + (- ((v104_vx + (- v104_vy)) + v104_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.17706629893))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v104_v_u = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_voo = ((v104_vx + (- v104_vy)) + v104_vz) ;
      v104_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v104!\n");
      exit(1);
    }
    break;
  }
  v104_vx = v104_vx_u;
  v104_vy = v104_vy_u;
  v104_vz = v104_vz_u;
  v104_g = v104_g_u;
  v104_v = v104_v_u;
  v104_ft = v104_ft_u;
  v104_theta = v104_theta_u;
  v104_v_O = v104_v_O_u;
  return cstate;
}