#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v117_v_i_0;
double v117_v_i_1;
double v117_v_i_2;
double v117_voo = 0.0;
double v117_state = 0.0;


static double  v117_vx  =  0 ,  v117_vy  =  0 ,  v117_vz  =  0 ,  v117_g  =  0 ,  v117_v  =  0 ,  v117_ft  =  0 ,  v117_theta  =  0 ,  v117_v_O  =  0 ; //the continuous vars
static double  v117_vx_u , v117_vy_u , v117_vz_u , v117_g_u , v117_v_u , v117_ft_u , v117_theta_u , v117_v_O_u ; // and their updates
static double  v117_vx_init , v117_vy_init , v117_vz_init , v117_g_init , v117_v_init , v117_ft_init , v117_theta_init , v117_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v117_t1 , v117_t2 , v117_t3 , v117_t4 }; // state declarations

enum states v117 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v117_t1 ):
    if (True == False) {;}
    else if  (v117_g > (44.5)) {
      v117_vx_u = (0.3 * v117_v) ;
      v117_vy_u = 0 ;
      v117_vz_u = (0.7 * v117_v) ;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v117_theta_u = (v117_v / 30.0) ;
      v117_v_O_u = (131.1 + (- (80.1 * pow ( ((v117_v / 30.0)) , (0.5) )))) ;
      v117_ft_u = f (v117_theta,4.0e-2) ;
      cstate =  v117_t2 ;
      force_init_update = False;
    }

    else if ( v117_v <= (44.5)
               && v117_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v117_vx_init = v117_vx ;
      slope =  (v117_vx * -8.7) ;
      v117_vx_u = (slope * d) + v117_vx ;
      if ((pstate != cstate) || force_init_update) v117_vy_init = v117_vy ;
      slope =  (v117_vy * -190.9) ;
      v117_vy_u = (slope * d) + v117_vy ;
      if ((pstate != cstate) || force_init_update) v117_vz_init = v117_vz ;
      slope =  (v117_vz * -190.4) ;
      v117_vz_u = (slope * d) + v117_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v117_t1 ;
      force_init_update = False;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v117_v_u = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_voo = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117!\n");
      exit(1);
    }
    break;
  case ( v117_t2 ):
    if (True == False) {;}
    else if  (v117_v >= (44.5)) {
      v117_vx_u = v117_vx ;
      v117_vy_u = v117_vy ;
      v117_vz_u = v117_vz ;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v117_t3 ;
      force_init_update = False;
    }
    else if  (v117_g <= (44.5)
               && v117_v < (44.5)) {
      v117_vx_u = v117_vx ;
      v117_vy_u = v117_vy ;
      v117_vz_u = v117_vz ;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v117_t1 ;
      force_init_update = False;
    }

    else if ( v117_v < (44.5)
               && v117_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v117_vx_init = v117_vx ;
      slope =  ((v117_vx * -23.6) + (777200.0 * v117_g)) ;
      v117_vx_u = (slope * d) + v117_vx ;
      if ((pstate != cstate) || force_init_update) v117_vy_init = v117_vy ;
      slope =  ((v117_vy * -45.5) + (58900.0 * v117_g)) ;
      v117_vy_u = (slope * d) + v117_vy ;
      if ((pstate != cstate) || force_init_update) v117_vz_init = v117_vz ;
      slope =  ((v117_vz * -12.9) + (276600.0 * v117_g)) ;
      v117_vz_u = (slope * d) + v117_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v117_t2 ;
      force_init_update = False;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v117_v_u = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_voo = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117!\n");
      exit(1);
    }
    break;
  case ( v117_t3 ):
    if (True == False) {;}
    else if  (v117_v >= (131.1)) {
      v117_vx_u = v117_vx ;
      v117_vy_u = v117_vy ;
      v117_vz_u = v117_vz ;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v117_t4 ;
      force_init_update = False;
    }

    else if ( v117_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v117_vx_init = v117_vx ;
      slope =  (v117_vx * -6.9) ;
      v117_vx_u = (slope * d) + v117_vx ;
      if ((pstate != cstate) || force_init_update) v117_vy_init = v117_vy ;
      slope =  (v117_vy * 75.9) ;
      v117_vy_u = (slope * d) + v117_vy ;
      if ((pstate != cstate) || force_init_update) v117_vz_init = v117_vz ;
      slope =  (v117_vz * 6826.5) ;
      v117_vz_u = (slope * d) + v117_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v117_t3 ;
      force_init_update = False;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v117_v_u = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_voo = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117!\n");
      exit(1);
    }
    break;
  case ( v117_t4 ):
    if (True == False) {;}
    else if  (v117_v <= (30.0)) {
      v117_vx_u = v117_vx ;
      v117_vy_u = v117_vy ;
      v117_vz_u = v117_vz ;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v117_t1 ;
      force_init_update = False;
    }

    else if ( v117_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v117_vx_init = v117_vx ;
      slope =  (v117_vx * -33.2) ;
      v117_vx_u = (slope * d) + v117_vx ;
      if ((pstate != cstate) || force_init_update) v117_vy_init = v117_vy ;
      slope =  ((v117_vy * 20.0) * v117_ft) ;
      v117_vy_u = (slope * d) + v117_vy ;
      if ((pstate != cstate) || force_init_update) v117_vz_init = v117_vz ;
      slope =  ((v117_vz * 2.0) * v117_ft) ;
      v117_vz_u = (slope * d) + v117_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v117_t4 ;
      force_init_update = False;
      v117_g_u = ((((((((((((v117_v_i_0 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v117_v_i_1 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v117_v_i_2 + (- ((v117_vx + (- v117_vy)) + v117_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v117_v_u = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_voo = ((v117_vx + (- v117_vy)) + v117_vz) ;
      v117_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v117!\n");
      exit(1);
    }
    break;
  }
  v117_vx = v117_vx_u;
  v117_vy = v117_vy_u;
  v117_vz = v117_vz_u;
  v117_g = v117_g_u;
  v117_v = v117_v_u;
  v117_ft = v117_ft_u;
  v117_theta = v117_theta_u;
  v117_v_O = v117_v_O_u;
  return cstate;
}