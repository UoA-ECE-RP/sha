#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v162_v163_update_c1vd();
extern double v162_v163_update_c2vd();
extern double v162_v163_update_c1md();
extern double v162_v163_update_c2md();
extern double v162_v163_update_buffer_index(double,double,double,double);
extern double v162_v163_update_latch1(double,double);
extern double v162_v163_update_latch2(double,double);
extern double v162_v163_update_ocell1(double,double);
extern double v162_v163_update_ocell2(double,double);
double v162_v163_cell1_v;
double v162_v163_cell1_mode;
double v162_v163_cell2_v;
double v162_v163_cell2_mode;
double v162_v163_cell1_v_replay = 0.0;
double v162_v163_cell2_v_replay = 0.0;


static double  v162_v163_k  =  0.0 ,  v162_v163_cell1_mode_delayed  =  0.0 ,  v162_v163_cell2_mode_delayed  =  0.0 ,  v162_v163_from_cell  =  0.0 ,  v162_v163_cell1_replay_latch  =  0.0 ,  v162_v163_cell2_replay_latch  =  0.0 ,  v162_v163_cell1_v_delayed  =  0.0 ,  v162_v163_cell2_v_delayed  =  0.0 ,  v162_v163_wasted  =  0.0 ; //the continuous vars
static double  v162_v163_k_u , v162_v163_cell1_mode_delayed_u , v162_v163_cell2_mode_delayed_u , v162_v163_from_cell_u , v162_v163_cell1_replay_latch_u , v162_v163_cell2_replay_latch_u , v162_v163_cell1_v_delayed_u , v162_v163_cell2_v_delayed_u , v162_v163_wasted_u ; // and their updates
static double  v162_v163_k_init , v162_v163_cell1_mode_delayed_init , v162_v163_cell2_mode_delayed_init , v162_v163_from_cell_init , v162_v163_cell1_replay_latch_init , v162_v163_cell2_replay_latch_init , v162_v163_cell1_v_delayed_init , v162_v163_cell2_v_delayed_init , v162_v163_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v162_v163_idle , v162_v163_annhilate , v162_v163_previous_drection1 , v162_v163_previous_direction2 , v162_v163_wait_cell1 , v162_v163_replay_cell1 , v162_v163_replay_cell2 , v162_v163_wait_cell2 }; // state declarations

enum states v162_v163 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v162_v163_idle ):
    if (True == False) {;}
    else if  (v162_v163_cell2_mode == (2.0) && (v162_v163_cell1_mode != (2.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v162_v163_cell1_mode == (2.0) && (v162_v163_cell2_mode != (2.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v162_v163_cell1_mode == (2.0) && (v162_v163_cell2_mode == (2.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_idle ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_annhilate ):
    if (True == False) {;}
    else if  (v162_v163_cell1_mode != (2.0) && (v162_v163_cell2_mode != (2.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_from_cell_u = 0 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_previous_drection1 ):
    if (True == False) {;}
    else if  (v162_v163_from_cell == (1.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (0.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (2.0) && (v162_v163_cell2_mode_delayed == (0.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (2.0) && (v162_v163_cell2_mode_delayed != (0.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_previous_drection1 ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_previous_direction2 ):
    if (True == False) {;}
    else if  (v162_v163_from_cell == (1.0) && (v162_v163_cell1_mode_delayed != (0.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (2.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (0.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v162_v163_from_cell == (1.0) && (v162_v163_cell1_mode_delayed == (0.0))) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_previous_direction2 ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_wait_cell1 ):
    if (True == False) {;}
    else if  (v162_v163_cell2_mode == (2.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v162_v163_k >= (68.25177585109999)) {
      v162_v163_from_cell_u = 1 ;
      v162_v163_cell1_replay_latch_u = 1 ;
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_wait_cell1 ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_replay_cell1 ):
    if (True == False) {;}
    else if  (v162_v163_cell1_mode == (2.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_annhilate ;
      force_init_update = False;
    }
    else if  (v162_v163_k >= (68.25177585109999)) {
      v162_v163_from_cell_u = 2 ;
      v162_v163_cell2_replay_latch_u = 1 ;
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_replay_cell1 ;
      force_init_update = False;
      v162_v163_cell1_replay_latch_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_replay_cell2 ):
    if (True == False) {;}
    else if  (v162_v163_k >= (10.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_replay_cell2 ;
      force_init_update = False;
      v162_v163_cell2_replay_latch_u = 1 ;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  case ( v162_v163_wait_cell2 ):
    if (True == False) {;}
    else if  (v162_v163_k >= (10.0)) {
      v162_v163_k_u = 1 ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
      cstate =  v162_v163_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v162_v163_k_init = v162_v163_k ;
      slope =  1 ;
      v162_v163_k_u = (slope * d) + v162_v163_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v162_v163_wait_cell2 ;
      force_init_update = False;
      v162_v163_cell1_v_delayed_u = v162_v163_update_c1vd () ;
      v162_v163_cell2_v_delayed_u = v162_v163_update_c2vd () ;
      v162_v163_cell1_mode_delayed_u = v162_v163_update_c1md () ;
      v162_v163_cell2_mode_delayed_u = v162_v163_update_c2md () ;
      v162_v163_wasted_u = v162_v163_update_buffer_index (v162_v163_cell1_v,v162_v163_cell2_v,v162_v163_cell1_mode,v162_v163_cell2_mode) ;
      v162_v163_cell1_replay_latch_u = v162_v163_update_latch1 (v162_v163_cell1_mode_delayed,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_replay_latch_u = v162_v163_update_latch2 (v162_v163_cell2_mode_delayed,v162_v163_cell2_replay_latch_u) ;
      v162_v163_cell1_v_replay = v162_v163_update_ocell1 (v162_v163_cell1_v_delayed_u,v162_v163_cell1_replay_latch_u) ;
      v162_v163_cell2_v_replay = v162_v163_update_ocell2 (v162_v163_cell2_v_delayed_u,v162_v163_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v162_v163!\n");
      exit(1);
    }
    break;
  }
  v162_v163_k = v162_v163_k_u;
  v162_v163_cell1_mode_delayed = v162_v163_cell1_mode_delayed_u;
  v162_v163_cell2_mode_delayed = v162_v163_cell2_mode_delayed_u;
  v162_v163_from_cell = v162_v163_from_cell_u;
  v162_v163_cell1_replay_latch = v162_v163_cell1_replay_latch_u;
  v162_v163_cell2_replay_latch = v162_v163_cell2_replay_latch_u;
  v162_v163_cell1_v_delayed = v162_v163_cell1_v_delayed_u;
  v162_v163_cell2_v_delayed = v162_v163_cell2_v_delayed_u;
  v162_v163_wasted = v162_v163_wasted_u;
  return cstate;
}