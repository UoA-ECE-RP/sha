#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v110_v109_update_c1vd();
extern double v110_v109_update_c2vd();
extern double v110_v109_update_c1md();
extern double v110_v109_update_c2md();
extern double v110_v109_update_buffer_index(double,double,double,double);
extern double v110_v109_update_latch1(double,double);
extern double v110_v109_update_latch2(double,double);
extern double v110_v109_update_ocell1(double,double);
extern double v110_v109_update_ocell2(double,double);
double v110_v109_cell1_v;
double v110_v109_cell1_mode;
double v110_v109_cell2_v;
double v110_v109_cell2_mode;
double v110_v109_cell1_v_replay = 0.0;
double v110_v109_cell2_v_replay = 0.0;


static double  v110_v109_k  =  0.0 ,  v110_v109_cell1_mode_delayed  =  0.0 ,  v110_v109_cell2_mode_delayed  =  0.0 ,  v110_v109_from_cell  =  0.0 ,  v110_v109_cell1_replay_latch  =  0.0 ,  v110_v109_cell2_replay_latch  =  0.0 ,  v110_v109_cell1_v_delayed  =  0.0 ,  v110_v109_cell2_v_delayed  =  0.0 ,  v110_v109_wasted  =  0.0 ; //the continuous vars
static double  v110_v109_k_u , v110_v109_cell1_mode_delayed_u , v110_v109_cell2_mode_delayed_u , v110_v109_from_cell_u , v110_v109_cell1_replay_latch_u , v110_v109_cell2_replay_latch_u , v110_v109_cell1_v_delayed_u , v110_v109_cell2_v_delayed_u , v110_v109_wasted_u ; // and their updates
static double  v110_v109_k_init , v110_v109_cell1_mode_delayed_init , v110_v109_cell2_mode_delayed_init , v110_v109_from_cell_init , v110_v109_cell1_replay_latch_init , v110_v109_cell2_replay_latch_init , v110_v109_cell1_v_delayed_init , v110_v109_cell2_v_delayed_init , v110_v109_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v110_v109_idle , v110_v109_annhilate , v110_v109_previous_drection1 , v110_v109_previous_direction2 , v110_v109_wait_cell1 , v110_v109_replay_cell1 , v110_v109_replay_cell2 , v110_v109_wait_cell2 }; // state declarations

enum states v110_v109 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v110_v109_idle ):
    if (True == False) {;}
    else if  (v110_v109_cell2_mode == (2.0) && (v110_v109_cell1_mode != (2.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v110_v109_cell1_mode == (2.0) && (v110_v109_cell2_mode != (2.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v110_v109_cell1_mode == (2.0) && (v110_v109_cell2_mode == (2.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_idle ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_annhilate ):
    if (True == False) {;}
    else if  (v110_v109_cell1_mode != (2.0) && (v110_v109_cell2_mode != (2.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_from_cell_u = 0 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_previous_drection1 ):
    if (True == False) {;}
    else if  (v110_v109_from_cell == (1.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (0.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (2.0) && (v110_v109_cell2_mode_delayed == (0.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (2.0) && (v110_v109_cell2_mode_delayed != (0.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_previous_drection1 ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_previous_direction2 ):
    if (True == False) {;}
    else if  (v110_v109_from_cell == (1.0) && (v110_v109_cell1_mode_delayed != (0.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (2.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (0.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v110_v109_from_cell == (1.0) && (v110_v109_cell1_mode_delayed == (0.0))) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_previous_direction2 ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_wait_cell1 ):
    if (True == False) {;}
    else if  (v110_v109_cell2_mode == (2.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
    }
    else if  (v110_v109_k >= (80.00362836469999)) {
      v110_v109_from_cell_u = 1 ;
      v110_v109_cell1_replay_latch_u = 1 ;
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_wait_cell1 ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_replay_cell1 ):
    if (True == False) {;}
    else if  (v110_v109_cell1_mode == (2.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_annhilate ;
      force_init_update = False;
    }
    else if  (v110_v109_k >= (80.00362836469999)) {
      v110_v109_from_cell_u = 2 ;
      v110_v109_cell2_replay_latch_u = 1 ;
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_replay_cell1 ;
      force_init_update = False;
      v110_v109_cell1_replay_latch_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_replay_cell2 ):
    if (True == False) {;}
    else if  (v110_v109_k >= (10.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_replay_cell2 ;
      force_init_update = False;
      v110_v109_cell2_replay_latch_u = 1 ;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  case ( v110_v109_wait_cell2 ):
    if (True == False) {;}
    else if  (v110_v109_k >= (10.0)) {
      v110_v109_k_u = 1 ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
      cstate =  v110_v109_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v110_v109_k_init = v110_v109_k ;
      slope =  1 ;
      v110_v109_k_u = (slope * d) + v110_v109_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v110_v109_wait_cell2 ;
      force_init_update = False;
      v110_v109_cell1_v_delayed_u = v110_v109_update_c1vd () ;
      v110_v109_cell2_v_delayed_u = v110_v109_update_c2vd () ;
      v110_v109_cell1_mode_delayed_u = v110_v109_update_c1md () ;
      v110_v109_cell2_mode_delayed_u = v110_v109_update_c2md () ;
      v110_v109_wasted_u = v110_v109_update_buffer_index (v110_v109_cell1_v,v110_v109_cell2_v,v110_v109_cell1_mode,v110_v109_cell2_mode) ;
      v110_v109_cell1_replay_latch_u = v110_v109_update_latch1 (v110_v109_cell1_mode_delayed,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_replay_latch_u = v110_v109_update_latch2 (v110_v109_cell2_mode_delayed,v110_v109_cell2_replay_latch_u) ;
      v110_v109_cell1_v_replay = v110_v109_update_ocell1 (v110_v109_cell1_v_delayed_u,v110_v109_cell1_replay_latch_u) ;
      v110_v109_cell2_v_replay = v110_v109_update_ocell2 (v110_v109_cell2_v_delayed_u,v110_v109_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v110_v109!\n");
      exit(1);
    }
    break;
  }
  v110_v109_k = v110_v109_k_u;
  v110_v109_cell1_mode_delayed = v110_v109_cell1_mode_delayed_u;
  v110_v109_cell2_mode_delayed = v110_v109_cell2_mode_delayed_u;
  v110_v109_from_cell = v110_v109_from_cell_u;
  v110_v109_cell1_replay_latch = v110_v109_cell1_replay_latch_u;
  v110_v109_cell2_replay_latch = v110_v109_cell2_replay_latch_u;
  v110_v109_cell1_v_delayed = v110_v109_cell1_v_delayed_u;
  v110_v109_cell2_v_delayed = v110_v109_cell2_v_delayed_u;
  v110_v109_wasted = v110_v109_wasted_u;
  return cstate;
}