#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v120_v_i_0;
double v120_v_i_1;
double v120_v_i_2;
double v120_voo = 0.0;
double v120_state = 0.0;


static double  v120_vx  =  0 ,  v120_vy  =  0 ,  v120_vz  =  0 ,  v120_g  =  0 ,  v120_v  =  0 ,  v120_ft  =  0 ,  v120_theta  =  0 ,  v120_v_O  =  0 ; //the continuous vars
static double  v120_vx_u , v120_vy_u , v120_vz_u , v120_g_u , v120_v_u , v120_ft_u , v120_theta_u , v120_v_O_u ; // and their updates
static double  v120_vx_init , v120_vy_init , v120_vz_init , v120_g_init , v120_v_init , v120_ft_init , v120_theta_init , v120_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v120_t1 , v120_t2 , v120_t3 , v120_t4 }; // state declarations

enum states v120 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v120_t1 ):
    if (True == False) {;}
    else if  (v120_g > (44.5)) {
      v120_vx_u = (0.3 * v120_v) ;
      v120_vy_u = 0 ;
      v120_vz_u = (0.7 * v120_v) ;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v120_theta_u = (v120_v / 30.0) ;
      v120_v_O_u = (131.1 + (- (80.1 * pow ( ((v120_v / 30.0)) , (0.5) )))) ;
      v120_ft_u = f (v120_theta,4.0e-2) ;
      cstate =  v120_t2 ;
      force_init_update = False;
    }

    else if ( v120_v <= (44.5)
               && v120_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v120_vx_init = v120_vx ;
      slope =  (v120_vx * -8.7) ;
      v120_vx_u = (slope * d) + v120_vx ;
      if ((pstate != cstate) || force_init_update) v120_vy_init = v120_vy ;
      slope =  (v120_vy * -190.9) ;
      v120_vy_u = (slope * d) + v120_vy ;
      if ((pstate != cstate) || force_init_update) v120_vz_init = v120_vz ;
      slope =  (v120_vz * -190.4) ;
      v120_vz_u = (slope * d) + v120_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v120_t1 ;
      force_init_update = False;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v120_v_u = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_voo = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v120!\n");
      exit(1);
    }
    break;
  case ( v120_t2 ):
    if (True == False) {;}
    else if  (v120_v >= (44.5)) {
      v120_vx_u = v120_vx ;
      v120_vy_u = v120_vy ;
      v120_vz_u = v120_vz ;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v120_t3 ;
      force_init_update = False;
    }
    else if  (v120_g <= (44.5)
               && v120_v < (44.5)) {
      v120_vx_u = v120_vx ;
      v120_vy_u = v120_vy ;
      v120_vz_u = v120_vz ;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v120_t1 ;
      force_init_update = False;
    }

    else if ( v120_v < (44.5)
               && v120_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v120_vx_init = v120_vx ;
      slope =  ((v120_vx * -23.6) + (777200.0 * v120_g)) ;
      v120_vx_u = (slope * d) + v120_vx ;
      if ((pstate != cstate) || force_init_update) v120_vy_init = v120_vy ;
      slope =  ((v120_vy * -45.5) + (58900.0 * v120_g)) ;
      v120_vy_u = (slope * d) + v120_vy ;
      if ((pstate != cstate) || force_init_update) v120_vz_init = v120_vz ;
      slope =  ((v120_vz * -12.9) + (276600.0 * v120_g)) ;
      v120_vz_u = (slope * d) + v120_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v120_t2 ;
      force_init_update = False;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v120_v_u = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_voo = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v120!\n");
      exit(1);
    }
    break;
  case ( v120_t3 ):
    if (True == False) {;}
    else if  (v120_v >= (131.1)) {
      v120_vx_u = v120_vx ;
      v120_vy_u = v120_vy ;
      v120_vz_u = v120_vz ;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v120_t4 ;
      force_init_update = False;
    }

    else if ( v120_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v120_vx_init = v120_vx ;
      slope =  (v120_vx * -6.9) ;
      v120_vx_u = (slope * d) + v120_vx ;
      if ((pstate != cstate) || force_init_update) v120_vy_init = v120_vy ;
      slope =  (v120_vy * 75.9) ;
      v120_vy_u = (slope * d) + v120_vy ;
      if ((pstate != cstate) || force_init_update) v120_vz_init = v120_vz ;
      slope =  (v120_vz * 6826.5) ;
      v120_vz_u = (slope * d) + v120_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v120_t3 ;
      force_init_update = False;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v120_v_u = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_voo = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v120!\n");
      exit(1);
    }
    break;
  case ( v120_t4 ):
    if (True == False) {;}
    else if  (v120_v <= (30.0)) {
      v120_vx_u = v120_vx ;
      v120_vy_u = v120_vy ;
      v120_vz_u = v120_vz ;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v120_t1 ;
      force_init_update = False;
    }

    else if ( v120_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v120_vx_init = v120_vx ;
      slope =  (v120_vx * -33.2) ;
      v120_vx_u = (slope * d) + v120_vx ;
      if ((pstate != cstate) || force_init_update) v120_vy_init = v120_vy ;
      slope =  ((v120_vy * 20.0) * v120_ft) ;
      v120_vy_u = (slope * d) + v120_vy ;
      if ((pstate != cstate) || force_init_update) v120_vz_init = v120_vz ;
      slope =  ((v120_vz * 2.0) * v120_ft) ;
      v120_vz_u = (slope * d) + v120_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v120_t4 ;
      force_init_update = False;
      v120_g_u = ((((((((((((v120_v_i_0 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.52903073308)) + ((((v120_v_i_1 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084))) + ((((v120_v_i_2 + (- ((v120_vx + (- v120_vy)) + v120_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.58468577791))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v120_v_u = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_voo = ((v120_vx + (- v120_vy)) + v120_vz) ;
      v120_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v120!\n");
      exit(1);
    }
    break;
  }
  v120_vx = v120_vx_u;
  v120_vy = v120_vy_u;
  v120_vz = v120_vz_u;
  v120_g = v120_g_u;
  v120_v = v120_v_u;
  v120_ft = v120_ft_u;
  v120_theta = v120_theta_u;
  v120_v_O = v120_v_O_u;
  return cstate;
}