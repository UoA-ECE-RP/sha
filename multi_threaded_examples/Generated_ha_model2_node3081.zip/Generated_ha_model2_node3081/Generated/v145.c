#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v145_v_i_0;
double v145_v_i_1;
double v145_v_i_2;
double v145_v_i_3;
double v145_voo = 0.0;
double v145_state = 0.0;


static double  v145_vx  =  0 ,  v145_vy  =  0 ,  v145_vz  =  0 ,  v145_g  =  0 ,  v145_v  =  0 ,  v145_ft  =  0 ,  v145_theta  =  0 ,  v145_v_O  =  0 ; //the continuous vars
static double  v145_vx_u , v145_vy_u , v145_vz_u , v145_g_u , v145_v_u , v145_ft_u , v145_theta_u , v145_v_O_u ; // and their updates
static double  v145_vx_init , v145_vy_init , v145_vz_init , v145_g_init , v145_v_init , v145_ft_init , v145_theta_init , v145_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v145_t1 , v145_t2 , v145_t3 , v145_t4 }; // state declarations

enum states v145 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v145_t1 ):
    if (True == False) {;}
    else if  (v145_g > (44.5)) {
      v145_vx_u = (0.3 * v145_v) ;
      v145_vy_u = 0 ;
      v145_vz_u = (0.7 * v145_v) ;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      v145_theta_u = (v145_v / 30.0) ;
      v145_v_O_u = (131.1 + (- (80.1 * pow ( ((v145_v / 30.0)) , (0.5) )))) ;
      v145_ft_u = f (v145_theta,4.0e-2) ;
      cstate =  v145_t2 ;
      force_init_update = False;
    }

    else if ( v145_v <= (44.5)
               && v145_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v145_vx_init = v145_vx ;
      slope =  (v145_vx * -8.7) ;
      v145_vx_u = (slope * d) + v145_vx ;
      if ((pstate != cstate) || force_init_update) v145_vy_init = v145_vy ;
      slope =  (v145_vy * -190.9) ;
      v145_vy_u = (slope * d) + v145_vy ;
      if ((pstate != cstate) || force_init_update) v145_vz_init = v145_vz ;
      slope =  (v145_vz * -190.4) ;
      v145_vz_u = (slope * d) + v145_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v145_t1 ;
      force_init_update = False;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      v145_v_u = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_voo = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145!\n");
      exit(1);
    }
    break;
  case ( v145_t2 ):
    if (True == False) {;}
    else if  (v145_v >= (44.5)) {
      v145_vx_u = v145_vx ;
      v145_vy_u = v145_vy ;
      v145_vz_u = v145_vz ;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v145_t3 ;
      force_init_update = False;
    }
    else if  (v145_g <= (44.5)
               && v145_v < (44.5)) {
      v145_vx_u = v145_vx ;
      v145_vy_u = v145_vy ;
      v145_vz_u = v145_vz ;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v145_t1 ;
      force_init_update = False;
    }

    else if ( v145_v < (44.5)
               && v145_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v145_vx_init = v145_vx ;
      slope =  ((v145_vx * -23.6) + (777200.0 * v145_g)) ;
      v145_vx_u = (slope * d) + v145_vx ;
      if ((pstate != cstate) || force_init_update) v145_vy_init = v145_vy ;
      slope =  ((v145_vy * -45.5) + (58900.0 * v145_g)) ;
      v145_vy_u = (slope * d) + v145_vy ;
      if ((pstate != cstate) || force_init_update) v145_vz_init = v145_vz ;
      slope =  ((v145_vz * -12.9) + (276600.0 * v145_g)) ;
      v145_vz_u = (slope * d) + v145_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v145_t2 ;
      force_init_update = False;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      v145_v_u = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_voo = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145!\n");
      exit(1);
    }
    break;
  case ( v145_t3 ):
    if (True == False) {;}
    else if  (v145_v >= (131.1)) {
      v145_vx_u = v145_vx ;
      v145_vy_u = v145_vy ;
      v145_vz_u = v145_vz ;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v145_t4 ;
      force_init_update = False;
    }

    else if ( v145_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v145_vx_init = v145_vx ;
      slope =  (v145_vx * -6.9) ;
      v145_vx_u = (slope * d) + v145_vx ;
      if ((pstate != cstate) || force_init_update) v145_vy_init = v145_vy ;
      slope =  (v145_vy * 75.9) ;
      v145_vy_u = (slope * d) + v145_vy ;
      if ((pstate != cstate) || force_init_update) v145_vz_init = v145_vz ;
      slope =  (v145_vz * 6826.5) ;
      v145_vz_u = (slope * d) + v145_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v145_t3 ;
      force_init_update = False;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      v145_v_u = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_voo = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145!\n");
      exit(1);
    }
    break;
  case ( v145_t4 ):
    if (True == False) {;}
    else if  (v145_v <= (30.0)) {
      v145_vx_u = v145_vx ;
      v145_vy_u = v145_vy ;
      v145_vz_u = v145_vz ;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v145_t1 ;
      force_init_update = False;
    }

    else if ( v145_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v145_vx_init = v145_vx ;
      slope =  (v145_vx * -33.2) ;
      v145_vx_u = (slope * d) + v145_vx ;
      if ((pstate != cstate) || force_init_update) v145_vy_init = v145_vy ;
      slope =  ((v145_vy * 20.0) * v145_ft) ;
      v145_vy_u = (slope * d) + v145_vy ;
      if ((pstate != cstate) || force_init_update) v145_vz_init = v145_vz ;
      slope =  ((v145_vz * 2.0) * v145_ft) ;
      v145_vz_u = (slope * d) + v145_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v145_t4 ;
      force_init_update = False;
      v145_g_u = ((((((((((((v145_v_i_0 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443)) + ((((v145_v_i_1 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v145_v_i_2 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v145_v_i_3 + (- ((v145_vx + (- v145_vy)) + v145_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.48869001524))) + 0) + 0) + 0) + 0) + 0) ;
      v145_v_u = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_voo = ((v145_vx + (- v145_vy)) + v145_vz) ;
      v145_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v145!\n");
      exit(1);
    }
    break;
  }
  v145_vx = v145_vx_u;
  v145_vy = v145_vy_u;
  v145_vz = v145_vz_u;
  v145_g = v145_g_u;
  v145_v = v145_v_u;
  v145_ft = v145_ft_u;
  v145_theta = v145_theta_u;
  v145_v_O = v145_v_O_u;
  return cstate;
}