#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v161_v162_update_c1vd();
extern double v161_v162_update_c2vd();
extern double v161_v162_update_c1md();
extern double v161_v162_update_c2md();
extern double v161_v162_update_buffer_index(double,double,double,double);
extern double v161_v162_update_latch1(double,double);
extern double v161_v162_update_latch2(double,double);
extern double v161_v162_update_ocell1(double,double);
extern double v161_v162_update_ocell2(double,double);
double v161_v162_cell1_v;
double v161_v162_cell1_mode;
double v161_v162_cell2_v;
double v161_v162_cell2_mode;
double v161_v162_cell1_v_replay = 0.0;
double v161_v162_cell2_v_replay = 0.0;


static double  v161_v162_k  =  0.0 ,  v161_v162_cell1_mode_delayed  =  0.0 ,  v161_v162_cell2_mode_delayed  =  0.0 ,  v161_v162_from_cell  =  0.0 ,  v161_v162_cell1_replay_latch  =  0.0 ,  v161_v162_cell2_replay_latch  =  0.0 ,  v161_v162_cell1_v_delayed  =  0.0 ,  v161_v162_cell2_v_delayed  =  0.0 ,  v161_v162_wasted  =  0.0 ; //the continuous vars
static double  v161_v162_k_u , v161_v162_cell1_mode_delayed_u , v161_v162_cell2_mode_delayed_u , v161_v162_from_cell_u , v161_v162_cell1_replay_latch_u , v161_v162_cell2_replay_latch_u , v161_v162_cell1_v_delayed_u , v161_v162_cell2_v_delayed_u , v161_v162_wasted_u ; // and their updates
static double  v161_v162_k_init , v161_v162_cell1_mode_delayed_init , v161_v162_cell2_mode_delayed_init , v161_v162_from_cell_init , v161_v162_cell1_replay_latch_init , v161_v162_cell2_replay_latch_init , v161_v162_cell1_v_delayed_init , v161_v162_cell2_v_delayed_init , v161_v162_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v161_v162_idle , v161_v162_annhilate , v161_v162_previous_drection1 , v161_v162_previous_direction2 , v161_v162_wait_cell1 , v161_v162_replay_cell1 , v161_v162_replay_cell2 , v161_v162_wait_cell2 }; // state declarations

enum states v161_v162 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v161_v162_idle ):
    if (True == False) {;}
    else if  (v161_v162_cell2_mode == (2.0) && (v161_v162_cell1_mode != (2.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v161_v162_cell1_mode == (2.0) && (v161_v162_cell2_mode != (2.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v161_v162_cell1_mode == (2.0) && (v161_v162_cell2_mode == (2.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_idle ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_annhilate ):
    if (True == False) {;}
    else if  (v161_v162_cell1_mode != (2.0) && (v161_v162_cell2_mode != (2.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_from_cell_u = 0 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_previous_drection1 ):
    if (True == False) {;}
    else if  (v161_v162_from_cell == (1.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (0.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (2.0) && (v161_v162_cell2_mode_delayed == (0.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (2.0) && (v161_v162_cell2_mode_delayed != (0.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_previous_drection1 ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_previous_direction2 ):
    if (True == False) {;}
    else if  (v161_v162_from_cell == (1.0) && (v161_v162_cell1_mode_delayed != (0.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (2.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (0.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v161_v162_from_cell == (1.0) && (v161_v162_cell1_mode_delayed == (0.0))) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_previous_direction2 ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_wait_cell1 ):
    if (True == False) {;}
    else if  (v161_v162_cell2_mode == (2.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
    }
    else if  (v161_v162_k >= (44.8904404214)) {
      v161_v162_from_cell_u = 1 ;
      v161_v162_cell1_replay_latch_u = 1 ;
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_wait_cell1 ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_replay_cell1 ):
    if (True == False) {;}
    else if  (v161_v162_cell1_mode == (2.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_annhilate ;
      force_init_update = False;
    }
    else if  (v161_v162_k >= (44.8904404214)) {
      v161_v162_from_cell_u = 2 ;
      v161_v162_cell2_replay_latch_u = 1 ;
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_replay_cell1 ;
      force_init_update = False;
      v161_v162_cell1_replay_latch_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_replay_cell2 ):
    if (True == False) {;}
    else if  (v161_v162_k >= (10.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_replay_cell2 ;
      force_init_update = False;
      v161_v162_cell2_replay_latch_u = 1 ;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  case ( v161_v162_wait_cell2 ):
    if (True == False) {;}
    else if  (v161_v162_k >= (10.0)) {
      v161_v162_k_u = 1 ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
      cstate =  v161_v162_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v161_v162_k_init = v161_v162_k ;
      slope =  1 ;
      v161_v162_k_u = (slope * d) + v161_v162_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v161_v162_wait_cell2 ;
      force_init_update = False;
      v161_v162_cell1_v_delayed_u = v161_v162_update_c1vd () ;
      v161_v162_cell2_v_delayed_u = v161_v162_update_c2vd () ;
      v161_v162_cell1_mode_delayed_u = v161_v162_update_c1md () ;
      v161_v162_cell2_mode_delayed_u = v161_v162_update_c2md () ;
      v161_v162_wasted_u = v161_v162_update_buffer_index (v161_v162_cell1_v,v161_v162_cell2_v,v161_v162_cell1_mode,v161_v162_cell2_mode) ;
      v161_v162_cell1_replay_latch_u = v161_v162_update_latch1 (v161_v162_cell1_mode_delayed,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_replay_latch_u = v161_v162_update_latch2 (v161_v162_cell2_mode_delayed,v161_v162_cell2_replay_latch_u) ;
      v161_v162_cell1_v_replay = v161_v162_update_ocell1 (v161_v162_cell1_v_delayed_u,v161_v162_cell1_replay_latch_u) ;
      v161_v162_cell2_v_replay = v161_v162_update_ocell2 (v161_v162_cell2_v_delayed_u,v161_v162_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v161_v162!\n");
      exit(1);
    }
    break;
  }
  v161_v162_k = v161_v162_k_u;
  v161_v162_cell1_mode_delayed = v161_v162_cell1_mode_delayed_u;
  v161_v162_cell2_mode_delayed = v161_v162_cell2_mode_delayed_u;
  v161_v162_from_cell = v161_v162_from_cell_u;
  v161_v162_cell1_replay_latch = v161_v162_cell1_replay_latch_u;
  v161_v162_cell2_replay_latch = v161_v162_cell2_replay_latch_u;
  v161_v162_cell1_v_delayed = v161_v162_cell1_v_delayed_u;
  v161_v162_cell2_v_delayed = v161_v162_cell2_v_delayed_u;
  v161_v162_wasted = v161_v162_wasted_u;
  return cstate;
}