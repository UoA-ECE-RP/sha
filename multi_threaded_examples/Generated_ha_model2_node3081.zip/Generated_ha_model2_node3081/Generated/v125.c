#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v125_v_i_0;
double v125_v_i_1;
double v125_v_i_2;
double v125_v_i_3;
double v125_voo = 0.0;
double v125_state = 0.0;


static double  v125_vx  =  0 ,  v125_vy  =  0 ,  v125_vz  =  0 ,  v125_g  =  0 ,  v125_v  =  0 ,  v125_ft  =  0 ,  v125_theta  =  0 ,  v125_v_O  =  0 ; //the continuous vars
static double  v125_vx_u , v125_vy_u , v125_vz_u , v125_g_u , v125_v_u , v125_ft_u , v125_theta_u , v125_v_O_u ; // and their updates
static double  v125_vx_init , v125_vy_init , v125_vz_init , v125_g_init , v125_v_init , v125_ft_init , v125_theta_init , v125_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v125_t1 , v125_t2 , v125_t3 , v125_t4 }; // state declarations

enum states v125 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v125_t1 ):
    if (True == False) {;}
    else if  (v125_g > (44.5)) {
      v125_vx_u = (0.3 * v125_v) ;
      v125_vy_u = 0 ;
      v125_vz_u = (0.7 * v125_v) ;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v125_theta_u = (v125_v / 30.0) ;
      v125_v_O_u = (131.1 + (- (80.1 * pow ( ((v125_v / 30.0)) , (0.5) )))) ;
      v125_ft_u = f (v125_theta,4.0e-2) ;
      cstate =  v125_t2 ;
      force_init_update = False;
    }

    else if ( v125_v <= (44.5)
               && v125_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v125_vx_init = v125_vx ;
      slope =  (v125_vx * -8.7) ;
      v125_vx_u = (slope * d) + v125_vx ;
      if ((pstate != cstate) || force_init_update) v125_vy_init = v125_vy ;
      slope =  (v125_vy * -190.9) ;
      v125_vy_u = (slope * d) + v125_vy ;
      if ((pstate != cstate) || force_init_update) v125_vz_init = v125_vz ;
      slope =  (v125_vz * -190.4) ;
      v125_vz_u = (slope * d) + v125_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v125_t1 ;
      force_init_update = False;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v125_v_u = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_voo = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v125!\n");
      exit(1);
    }
    break;
  case ( v125_t2 ):
    if (True == False) {;}
    else if  (v125_v >= (44.5)) {
      v125_vx_u = v125_vx ;
      v125_vy_u = v125_vy ;
      v125_vz_u = v125_vz ;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v125_t3 ;
      force_init_update = False;
    }
    else if  (v125_g <= (44.5)
               && v125_v < (44.5)) {
      v125_vx_u = v125_vx ;
      v125_vy_u = v125_vy ;
      v125_vz_u = v125_vz ;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v125_t1 ;
      force_init_update = False;
    }

    else if ( v125_v < (44.5)
               && v125_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v125_vx_init = v125_vx ;
      slope =  ((v125_vx * -23.6) + (777200.0 * v125_g)) ;
      v125_vx_u = (slope * d) + v125_vx ;
      if ((pstate != cstate) || force_init_update) v125_vy_init = v125_vy ;
      slope =  ((v125_vy * -45.5) + (58900.0 * v125_g)) ;
      v125_vy_u = (slope * d) + v125_vy ;
      if ((pstate != cstate) || force_init_update) v125_vz_init = v125_vz ;
      slope =  ((v125_vz * -12.9) + (276600.0 * v125_g)) ;
      v125_vz_u = (slope * d) + v125_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v125_t2 ;
      force_init_update = False;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v125_v_u = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_voo = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v125!\n");
      exit(1);
    }
    break;
  case ( v125_t3 ):
    if (True == False) {;}
    else if  (v125_v >= (131.1)) {
      v125_vx_u = v125_vx ;
      v125_vy_u = v125_vy ;
      v125_vz_u = v125_vz ;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v125_t4 ;
      force_init_update = False;
    }

    else if ( v125_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v125_vx_init = v125_vx ;
      slope =  (v125_vx * -6.9) ;
      v125_vx_u = (slope * d) + v125_vx ;
      if ((pstate != cstate) || force_init_update) v125_vy_init = v125_vy ;
      slope =  (v125_vy * 75.9) ;
      v125_vy_u = (slope * d) + v125_vy ;
      if ((pstate != cstate) || force_init_update) v125_vz_init = v125_vz ;
      slope =  (v125_vz * 6826.5) ;
      v125_vz_u = (slope * d) + v125_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v125_t3 ;
      force_init_update = False;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v125_v_u = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_voo = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v125!\n");
      exit(1);
    }
    break;
  case ( v125_t4 ):
    if (True == False) {;}
    else if  (v125_v <= (30.0)) {
      v125_vx_u = v125_vx ;
      v125_vy_u = v125_vy ;
      v125_vz_u = v125_vz ;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v125_t1 ;
      force_init_update = False;
    }

    else if ( v125_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v125_vx_init = v125_vx ;
      slope =  (v125_vx * -33.2) ;
      v125_vx_u = (slope * d) + v125_vx ;
      if ((pstate != cstate) || force_init_update) v125_vy_init = v125_vy ;
      slope =  ((v125_vy * 20.0) * v125_ft) ;
      v125_vy_u = (slope * d) + v125_vy ;
      if ((pstate != cstate) || force_init_update) v125_vz_init = v125_vz ;
      slope =  ((v125_vz * 2.0) * v125_ft) ;
      v125_vz_u = (slope * d) + v125_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v125_t4 ;
      force_init_update = False;
      v125_g_u = ((((((((((((v125_v_i_0 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v125_v_i_1 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79517386275))) + ((((v125_v_i_2 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.01001932516))) + ((((v125_v_i_3 + (- ((v125_vx + (- v125_vy)) + v125_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.37334158561))) + 0) + 0) + 0) + 0) + 0) ;
      v125_v_u = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_voo = ((v125_vx + (- v125_vy)) + v125_vz) ;
      v125_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v125!\n");
      exit(1);
    }
    break;
  }
  v125_vx = v125_vx_u;
  v125_vy = v125_vy_u;
  v125_vz = v125_vz_u;
  v125_g = v125_g_u;
  v125_v = v125_v_u;
  v125_ft = v125_ft_u;
  v125_theta = v125_theta_u;
  v125_v_O = v125_v_O_u;
  return cstate;
}