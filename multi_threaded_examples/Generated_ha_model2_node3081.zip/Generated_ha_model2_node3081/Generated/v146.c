#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v146_v_i_0;
double v146_v_i_1;
double v146_v_i_2;
double v146_v_i_3;
double v146_v_i_4;
double v146_voo = 0.0;
double v146_state = 0.0;


static double  v146_vx  =  0 ,  v146_vy  =  0 ,  v146_vz  =  0 ,  v146_g  =  0 ,  v146_v  =  0 ,  v146_ft  =  0 ,  v146_theta  =  0 ,  v146_v_O  =  0 ; //the continuous vars
static double  v146_vx_u , v146_vy_u , v146_vz_u , v146_g_u , v146_v_u , v146_ft_u , v146_theta_u , v146_v_O_u ; // and their updates
static double  v146_vx_init , v146_vy_init , v146_vz_init , v146_g_init , v146_v_init , v146_ft_init , v146_theta_init , v146_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v146_t1 , v146_t2 , v146_t3 , v146_t4 }; // state declarations

enum states v146 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v146_t1 ):
    if (True == False) {;}
    else if  (v146_g > (44.5)) {
      v146_vx_u = (0.3 * v146_v) ;
      v146_vy_u = 0 ;
      v146_vz_u = (0.7 * v146_v) ;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      v146_theta_u = (v146_v / 30.0) ;
      v146_v_O_u = (131.1 + (- (80.1 * pow ( ((v146_v / 30.0)) , (0.5) )))) ;
      v146_ft_u = f (v146_theta,4.0e-2) ;
      cstate =  v146_t2 ;
      force_init_update = False;
    }

    else if ( v146_v <= (44.5)
               && v146_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v146_vx_init = v146_vx ;
      slope =  (v146_vx * -8.7) ;
      v146_vx_u = (slope * d) + v146_vx ;
      if ((pstate != cstate) || force_init_update) v146_vy_init = v146_vy ;
      slope =  (v146_vy * -190.9) ;
      v146_vy_u = (slope * d) + v146_vy ;
      if ((pstate != cstate) || force_init_update) v146_vz_init = v146_vz ;
      slope =  (v146_vz * -190.4) ;
      v146_vz_u = (slope * d) + v146_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v146_t1 ;
      force_init_update = False;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      v146_v_u = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_voo = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146!\n");
      exit(1);
    }
    break;
  case ( v146_t2 ):
    if (True == False) {;}
    else if  (v146_v >= (44.5)) {
      v146_vx_u = v146_vx ;
      v146_vy_u = v146_vy ;
      v146_vz_u = v146_vz ;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      cstate =  v146_t3 ;
      force_init_update = False;
    }
    else if  (v146_g <= (44.5)
               && v146_v < (44.5)) {
      v146_vx_u = v146_vx ;
      v146_vy_u = v146_vy ;
      v146_vz_u = v146_vz ;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      cstate =  v146_t1 ;
      force_init_update = False;
    }

    else if ( v146_v < (44.5)
               && v146_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v146_vx_init = v146_vx ;
      slope =  ((v146_vx * -23.6) + (777200.0 * v146_g)) ;
      v146_vx_u = (slope * d) + v146_vx ;
      if ((pstate != cstate) || force_init_update) v146_vy_init = v146_vy ;
      slope =  ((v146_vy * -45.5) + (58900.0 * v146_g)) ;
      v146_vy_u = (slope * d) + v146_vy ;
      if ((pstate != cstate) || force_init_update) v146_vz_init = v146_vz ;
      slope =  ((v146_vz * -12.9) + (276600.0 * v146_g)) ;
      v146_vz_u = (slope * d) + v146_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v146_t2 ;
      force_init_update = False;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      v146_v_u = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_voo = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146!\n");
      exit(1);
    }
    break;
  case ( v146_t3 ):
    if (True == False) {;}
    else if  (v146_v >= (131.1)) {
      v146_vx_u = v146_vx ;
      v146_vy_u = v146_vy ;
      v146_vz_u = v146_vz ;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      cstate =  v146_t4 ;
      force_init_update = False;
    }

    else if ( v146_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v146_vx_init = v146_vx ;
      slope =  (v146_vx * -6.9) ;
      v146_vx_u = (slope * d) + v146_vx ;
      if ((pstate != cstate) || force_init_update) v146_vy_init = v146_vy ;
      slope =  (v146_vy * 75.9) ;
      v146_vy_u = (slope * d) + v146_vy ;
      if ((pstate != cstate) || force_init_update) v146_vz_init = v146_vz ;
      slope =  (v146_vz * 6826.5) ;
      v146_vz_u = (slope * d) + v146_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v146_t3 ;
      force_init_update = False;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      v146_v_u = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_voo = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146!\n");
      exit(1);
    }
    break;
  case ( v146_t4 ):
    if (True == False) {;}
    else if  (v146_v <= (30.0)) {
      v146_vx_u = v146_vx ;
      v146_vy_u = v146_vy ;
      v146_vz_u = v146_vz ;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      cstate =  v146_t1 ;
      force_init_update = False;
    }

    else if ( v146_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v146_vx_init = v146_vx ;
      slope =  (v146_vx * -33.2) ;
      v146_vx_u = (slope * d) + v146_vx ;
      if ((pstate != cstate) || force_init_update) v146_vy_init = v146_vy ;
      slope =  ((v146_vy * 20.0) * v146_ft) ;
      v146_vy_u = (slope * d) + v146_vy ;
      if ((pstate != cstate) || force_init_update) v146_vz_init = v146_vz ;
      slope =  ((v146_vz * 2.0) * v146_ft) ;
      v146_vz_u = (slope * d) + v146_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v146_t4 ;
      force_init_update = False;
      v146_g_u = ((((((((((((v146_v_i_0 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v146_v_i_1 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v146_v_i_2 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.52673442539))) + ((((v146_v_i_3 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.61995924761))) + ((((v146_v_i_4 + (- ((v146_vx + (- v146_vy)) + v146_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.28110730661))) + 0) + 0) + 0) + 0) ;
      v146_v_u = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_voo = ((v146_vx + (- v146_vy)) + v146_vz) ;
      v146_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v146!\n");
      exit(1);
    }
    break;
  }
  v146_vx = v146_vx_u;
  v146_vy = v146_vy_u;
  v146_vz = v146_vz_u;
  v146_g = v146_g_u;
  v146_v = v146_v_u;
  v146_ft = v146_ft_u;
  v146_theta = v146_theta_u;
  v146_v_O = v146_v_O_u;
  return cstate;
}