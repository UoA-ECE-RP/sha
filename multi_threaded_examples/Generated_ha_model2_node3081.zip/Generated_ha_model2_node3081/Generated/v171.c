#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v171_v_i_0;
double v171_v_i_1;
double v171_v_i_2;
double v171_voo = 0.0;
double v171_state = 0.0;


static double  v171_vx  =  0 ,  v171_vy  =  0 ,  v171_vz  =  0 ,  v171_g  =  0 ,  v171_v  =  0 ,  v171_ft  =  0 ,  v171_theta  =  0 ,  v171_v_O  =  0 ; //the continuous vars
static double  v171_vx_u , v171_vy_u , v171_vz_u , v171_g_u , v171_v_u , v171_ft_u , v171_theta_u , v171_v_O_u ; // and their updates
static double  v171_vx_init , v171_vy_init , v171_vz_init , v171_g_init , v171_v_init , v171_ft_init , v171_theta_init , v171_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v171_t1 , v171_t2 , v171_t3 , v171_t4 }; // state declarations

enum states v171 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v171_t1 ):
    if (True == False) {;}
    else if  (v171_g > (44.5)) {
      v171_vx_u = (0.3 * v171_v) ;
      v171_vy_u = 0 ;
      v171_vz_u = (0.7 * v171_v) ;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v171_theta_u = (v171_v / 30.0) ;
      v171_v_O_u = (131.1 + (- (80.1 * pow ( ((v171_v / 30.0)) , (0.5) )))) ;
      v171_ft_u = f (v171_theta,4.0e-2) ;
      cstate =  v171_t2 ;
      force_init_update = False;
    }

    else if ( v171_v <= (44.5)
               && v171_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v171_vx_init = v171_vx ;
      slope =  (v171_vx * -8.7) ;
      v171_vx_u = (slope * d) + v171_vx ;
      if ((pstate != cstate) || force_init_update) v171_vy_init = v171_vy ;
      slope =  (v171_vy * -190.9) ;
      v171_vy_u = (slope * d) + v171_vy ;
      if ((pstate != cstate) || force_init_update) v171_vz_init = v171_vz ;
      slope =  (v171_vz * -190.4) ;
      v171_vz_u = (slope * d) + v171_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v171_t1 ;
      force_init_update = False;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v171_v_u = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_voo = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v171!\n");
      exit(1);
    }
    break;
  case ( v171_t2 ):
    if (True == False) {;}
    else if  (v171_v >= (44.5)) {
      v171_vx_u = v171_vx ;
      v171_vy_u = v171_vy ;
      v171_vz_u = v171_vz ;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v171_t3 ;
      force_init_update = False;
    }
    else if  (v171_g <= (44.5)
               && v171_v < (44.5)) {
      v171_vx_u = v171_vx ;
      v171_vy_u = v171_vy ;
      v171_vz_u = v171_vz ;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v171_t1 ;
      force_init_update = False;
    }

    else if ( v171_v < (44.5)
               && v171_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v171_vx_init = v171_vx ;
      slope =  ((v171_vx * -23.6) + (777200.0 * v171_g)) ;
      v171_vx_u = (slope * d) + v171_vx ;
      if ((pstate != cstate) || force_init_update) v171_vy_init = v171_vy ;
      slope =  ((v171_vy * -45.5) + (58900.0 * v171_g)) ;
      v171_vy_u = (slope * d) + v171_vy ;
      if ((pstate != cstate) || force_init_update) v171_vz_init = v171_vz ;
      slope =  ((v171_vz * -12.9) + (276600.0 * v171_g)) ;
      v171_vz_u = (slope * d) + v171_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v171_t2 ;
      force_init_update = False;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v171_v_u = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_voo = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v171!\n");
      exit(1);
    }
    break;
  case ( v171_t3 ):
    if (True == False) {;}
    else if  (v171_v >= (131.1)) {
      v171_vx_u = v171_vx ;
      v171_vy_u = v171_vy ;
      v171_vz_u = v171_vz ;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v171_t4 ;
      force_init_update = False;
    }

    else if ( v171_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v171_vx_init = v171_vx ;
      slope =  (v171_vx * -6.9) ;
      v171_vx_u = (slope * d) + v171_vx ;
      if ((pstate != cstate) || force_init_update) v171_vy_init = v171_vy ;
      slope =  (v171_vy * 75.9) ;
      v171_vy_u = (slope * d) + v171_vy ;
      if ((pstate != cstate) || force_init_update) v171_vz_init = v171_vz ;
      slope =  (v171_vz * 6826.5) ;
      v171_vz_u = (slope * d) + v171_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v171_t3 ;
      force_init_update = False;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v171_v_u = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_voo = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v171!\n");
      exit(1);
    }
    break;
  case ( v171_t4 ):
    if (True == False) {;}
    else if  (v171_v <= (30.0)) {
      v171_vx_u = v171_vx ;
      v171_vy_u = v171_vy ;
      v171_vz_u = v171_vz ;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v171_t1 ;
      force_init_update = False;
    }

    else if ( v171_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v171_vx_init = v171_vx ;
      slope =  (v171_vx * -33.2) ;
      v171_vx_u = (slope * d) + v171_vx ;
      if ((pstate != cstate) || force_init_update) v171_vy_init = v171_vy ;
      slope =  ((v171_vy * 20.0) * v171_ft) ;
      v171_vy_u = (slope * d) + v171_vy ;
      if ((pstate != cstate) || force_init_update) v171_vz_init = v171_vz ;
      slope =  ((v171_vz * 2.0) * v171_ft) ;
      v171_vz_u = (slope * d) + v171_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v171_t4 ;
      force_init_update = False;
      v171_g_u = ((((((((((((v171_v_i_0 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.21656448911)) + ((((v171_v_i_1 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.13899299522))) + ((((v171_v_i_2 + (- ((v171_vx + (- v171_vy)) + v171_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.87586236899))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v171_v_u = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_voo = ((v171_vx + (- v171_vy)) + v171_vz) ;
      v171_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v171!\n");
      exit(1);
    }
    break;
  }
  v171_vx = v171_vx_u;
  v171_vy = v171_vy_u;
  v171_vz = v171_vz_u;
  v171_g = v171_g_u;
  v171_v = v171_v_u;
  v171_ft = v171_ft_u;
  v171_theta = v171_theta_u;
  v171_v_O = v171_v_O_u;
  return cstate;
}