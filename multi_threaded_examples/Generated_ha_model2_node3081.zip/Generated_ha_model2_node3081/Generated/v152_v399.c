#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v152_v399_update_c1vd();
extern double v152_v399_update_c2vd();
extern double v152_v399_update_c1md();
extern double v152_v399_update_c2md();
extern double v152_v399_update_buffer_index(double,double,double,double);
extern double v152_v399_update_latch1(double,double);
extern double v152_v399_update_latch2(double,double);
extern double v152_v399_update_ocell1(double,double);
extern double v152_v399_update_ocell2(double,double);
double v152_v399_cell1_v;
double v152_v399_cell1_mode;
double v152_v399_cell2_v;
double v152_v399_cell2_mode;
double v152_v399_cell1_v_replay = 0.0;
double v152_v399_cell2_v_replay = 0.0;


static double  v152_v399_k  =  0.0 ,  v152_v399_cell1_mode_delayed  =  0.0 ,  v152_v399_cell2_mode_delayed  =  0.0 ,  v152_v399_from_cell  =  0.0 ,  v152_v399_cell1_replay_latch  =  0.0 ,  v152_v399_cell2_replay_latch  =  0.0 ,  v152_v399_cell1_v_delayed  =  0.0 ,  v152_v399_cell2_v_delayed  =  0.0 ,  v152_v399_wasted  =  0.0 ; //the continuous vars
static double  v152_v399_k_u , v152_v399_cell1_mode_delayed_u , v152_v399_cell2_mode_delayed_u , v152_v399_from_cell_u , v152_v399_cell1_replay_latch_u , v152_v399_cell2_replay_latch_u , v152_v399_cell1_v_delayed_u , v152_v399_cell2_v_delayed_u , v152_v399_wasted_u ; // and their updates
static double  v152_v399_k_init , v152_v399_cell1_mode_delayed_init , v152_v399_cell2_mode_delayed_init , v152_v399_from_cell_init , v152_v399_cell1_replay_latch_init , v152_v399_cell2_replay_latch_init , v152_v399_cell1_v_delayed_init , v152_v399_cell2_v_delayed_init , v152_v399_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v152_v399_idle , v152_v399_annhilate , v152_v399_previous_drection1 , v152_v399_previous_direction2 , v152_v399_wait_cell1 , v152_v399_replay_cell1 , v152_v399_replay_cell2 , v152_v399_wait_cell2 }; // state declarations

enum states v152_v399 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v152_v399_idle ):
    if (True == False) {;}
    else if  (v152_v399_cell2_mode == (2.0) && (v152_v399_cell1_mode != (2.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v152_v399_cell1_mode == (2.0) && (v152_v399_cell2_mode != (2.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v152_v399_cell1_mode == (2.0) && (v152_v399_cell2_mode == (2.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_idle ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_annhilate ):
    if (True == False) {;}
    else if  (v152_v399_cell1_mode != (2.0) && (v152_v399_cell2_mode != (2.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_from_cell_u = 0 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_previous_drection1 ):
    if (True == False) {;}
    else if  (v152_v399_from_cell == (1.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (0.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (2.0) && (v152_v399_cell2_mode_delayed == (0.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (2.0) && (v152_v399_cell2_mode_delayed != (0.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_previous_drection1 ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_previous_direction2 ):
    if (True == False) {;}
    else if  (v152_v399_from_cell == (1.0) && (v152_v399_cell1_mode_delayed != (0.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (2.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (0.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v152_v399_from_cell == (1.0) && (v152_v399_cell1_mode_delayed == (0.0))) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_previous_direction2 ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_wait_cell1 ):
    if (True == False) {;}
    else if  (v152_v399_cell2_mode == (2.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
    }
    else if  (v152_v399_k >= (85.8271172277)) {
      v152_v399_from_cell_u = 1 ;
      v152_v399_cell1_replay_latch_u = 1 ;
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_wait_cell1 ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_replay_cell1 ):
    if (True == False) {;}
    else if  (v152_v399_cell1_mode == (2.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_annhilate ;
      force_init_update = False;
    }
    else if  (v152_v399_k >= (85.8271172277)) {
      v152_v399_from_cell_u = 2 ;
      v152_v399_cell2_replay_latch_u = 1 ;
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_replay_cell1 ;
      force_init_update = False;
      v152_v399_cell1_replay_latch_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_replay_cell2 ):
    if (True == False) {;}
    else if  (v152_v399_k >= (10.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_replay_cell2 ;
      force_init_update = False;
      v152_v399_cell2_replay_latch_u = 1 ;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  case ( v152_v399_wait_cell2 ):
    if (True == False) {;}
    else if  (v152_v399_k >= (10.0)) {
      v152_v399_k_u = 1 ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
      cstate =  v152_v399_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v152_v399_k_init = v152_v399_k ;
      slope =  1 ;
      v152_v399_k_u = (slope * d) + v152_v399_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v152_v399_wait_cell2 ;
      force_init_update = False;
      v152_v399_cell1_v_delayed_u = v152_v399_update_c1vd () ;
      v152_v399_cell2_v_delayed_u = v152_v399_update_c2vd () ;
      v152_v399_cell1_mode_delayed_u = v152_v399_update_c1md () ;
      v152_v399_cell2_mode_delayed_u = v152_v399_update_c2md () ;
      v152_v399_wasted_u = v152_v399_update_buffer_index (v152_v399_cell1_v,v152_v399_cell2_v,v152_v399_cell1_mode,v152_v399_cell2_mode) ;
      v152_v399_cell1_replay_latch_u = v152_v399_update_latch1 (v152_v399_cell1_mode_delayed,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_replay_latch_u = v152_v399_update_latch2 (v152_v399_cell2_mode_delayed,v152_v399_cell2_replay_latch_u) ;
      v152_v399_cell1_v_replay = v152_v399_update_ocell1 (v152_v399_cell1_v_delayed_u,v152_v399_cell1_replay_latch_u) ;
      v152_v399_cell2_v_replay = v152_v399_update_ocell2 (v152_v399_cell2_v_delayed_u,v152_v399_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v152_v399!\n");
      exit(1);
    }
    break;
  }
  v152_v399_k = v152_v399_k_u;
  v152_v399_cell1_mode_delayed = v152_v399_cell1_mode_delayed_u;
  v152_v399_cell2_mode_delayed = v152_v399_cell2_mode_delayed_u;
  v152_v399_from_cell = v152_v399_from_cell_u;
  v152_v399_cell1_replay_latch = v152_v399_cell1_replay_latch_u;
  v152_v399_cell2_replay_latch = v152_v399_cell2_replay_latch_u;
  v152_v399_cell1_v_delayed = v152_v399_cell1_v_delayed_u;
  v152_v399_cell2_v_delayed = v152_v399_cell2_v_delayed_u;
  v152_v399_wasted = v152_v399_wasted_u;
  return cstate;
}