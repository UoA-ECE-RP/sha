#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v158_v159_update_c1vd();
extern double v158_v159_update_c2vd();
extern double v158_v159_update_c1md();
extern double v158_v159_update_c2md();
extern double v158_v159_update_buffer_index(double,double,double,double);
extern double v158_v159_update_latch1(double,double);
extern double v158_v159_update_latch2(double,double);
extern double v158_v159_update_ocell1(double,double);
extern double v158_v159_update_ocell2(double,double);
double v158_v159_cell1_v;
double v158_v159_cell1_mode;
double v158_v159_cell2_v;
double v158_v159_cell2_mode;
double v158_v159_cell1_v_replay = 0.0;
double v158_v159_cell2_v_replay = 0.0;


static double  v158_v159_k  =  0.0 ,  v158_v159_cell1_mode_delayed  =  0.0 ,  v158_v159_cell2_mode_delayed  =  0.0 ,  v158_v159_from_cell  =  0.0 ,  v158_v159_cell1_replay_latch  =  0.0 ,  v158_v159_cell2_replay_latch  =  0.0 ,  v158_v159_cell1_v_delayed  =  0.0 ,  v158_v159_cell2_v_delayed  =  0.0 ,  v158_v159_wasted  =  0.0 ; //the continuous vars
static double  v158_v159_k_u , v158_v159_cell1_mode_delayed_u , v158_v159_cell2_mode_delayed_u , v158_v159_from_cell_u , v158_v159_cell1_replay_latch_u , v158_v159_cell2_replay_latch_u , v158_v159_cell1_v_delayed_u , v158_v159_cell2_v_delayed_u , v158_v159_wasted_u ; // and their updates
static double  v158_v159_k_init , v158_v159_cell1_mode_delayed_init , v158_v159_cell2_mode_delayed_init , v158_v159_from_cell_init , v158_v159_cell1_replay_latch_init , v158_v159_cell2_replay_latch_init , v158_v159_cell1_v_delayed_init , v158_v159_cell2_v_delayed_init , v158_v159_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v158_v159_idle , v158_v159_annhilate , v158_v159_previous_drection1 , v158_v159_previous_direction2 , v158_v159_wait_cell1 , v158_v159_replay_cell1 , v158_v159_replay_cell2 , v158_v159_wait_cell2 }; // state declarations

enum states v158_v159 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v158_v159_idle ):
    if (True == False) {;}
    else if  (v158_v159_cell2_mode == (2.0) && (v158_v159_cell1_mode != (2.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v158_v159_cell1_mode == (2.0) && (v158_v159_cell2_mode != (2.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v158_v159_cell1_mode == (2.0) && (v158_v159_cell2_mode == (2.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_idle ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_annhilate ):
    if (True == False) {;}
    else if  (v158_v159_cell1_mode != (2.0) && (v158_v159_cell2_mode != (2.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_from_cell_u = 0 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_previous_drection1 ):
    if (True == False) {;}
    else if  (v158_v159_from_cell == (1.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (0.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (2.0) && (v158_v159_cell2_mode_delayed == (0.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (2.0) && (v158_v159_cell2_mode_delayed != (0.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_previous_drection1 ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_previous_direction2 ):
    if (True == False) {;}
    else if  (v158_v159_from_cell == (1.0) && (v158_v159_cell1_mode_delayed != (0.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (2.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (0.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v158_v159_from_cell == (1.0) && (v158_v159_cell1_mode_delayed == (0.0))) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_previous_direction2 ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_wait_cell1 ):
    if (True == False) {;}
    else if  (v158_v159_cell2_mode == (2.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v158_v159_k >= (79.2322030924)) {
      v158_v159_from_cell_u = 1 ;
      v158_v159_cell1_replay_latch_u = 1 ;
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_wait_cell1 ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_replay_cell1 ):
    if (True == False) {;}
    else if  (v158_v159_cell1_mode == (2.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_annhilate ;
      force_init_update = False;
    }
    else if  (v158_v159_k >= (79.2322030924)) {
      v158_v159_from_cell_u = 2 ;
      v158_v159_cell2_replay_latch_u = 1 ;
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_replay_cell1 ;
      force_init_update = False;
      v158_v159_cell1_replay_latch_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_replay_cell2 ):
    if (True == False) {;}
    else if  (v158_v159_k >= (10.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_replay_cell2 ;
      force_init_update = False;
      v158_v159_cell2_replay_latch_u = 1 ;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  case ( v158_v159_wait_cell2 ):
    if (True == False) {;}
    else if  (v158_v159_k >= (10.0)) {
      v158_v159_k_u = 1 ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
      cstate =  v158_v159_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v158_v159_k_init = v158_v159_k ;
      slope =  1 ;
      v158_v159_k_u = (slope * d) + v158_v159_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v158_v159_wait_cell2 ;
      force_init_update = False;
      v158_v159_cell1_v_delayed_u = v158_v159_update_c1vd () ;
      v158_v159_cell2_v_delayed_u = v158_v159_update_c2vd () ;
      v158_v159_cell1_mode_delayed_u = v158_v159_update_c1md () ;
      v158_v159_cell2_mode_delayed_u = v158_v159_update_c2md () ;
      v158_v159_wasted_u = v158_v159_update_buffer_index (v158_v159_cell1_v,v158_v159_cell2_v,v158_v159_cell1_mode,v158_v159_cell2_mode) ;
      v158_v159_cell1_replay_latch_u = v158_v159_update_latch1 (v158_v159_cell1_mode_delayed,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_replay_latch_u = v158_v159_update_latch2 (v158_v159_cell2_mode_delayed,v158_v159_cell2_replay_latch_u) ;
      v158_v159_cell1_v_replay = v158_v159_update_ocell1 (v158_v159_cell1_v_delayed_u,v158_v159_cell1_replay_latch_u) ;
      v158_v159_cell2_v_replay = v158_v159_update_ocell2 (v158_v159_cell2_v_delayed_u,v158_v159_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v158_v159!\n");
      exit(1);
    }
    break;
  }
  v158_v159_k = v158_v159_k_u;
  v158_v159_cell1_mode_delayed = v158_v159_cell1_mode_delayed_u;
  v158_v159_cell2_mode_delayed = v158_v159_cell2_mode_delayed_u;
  v158_v159_from_cell = v158_v159_from_cell_u;
  v158_v159_cell1_replay_latch = v158_v159_cell1_replay_latch_u;
  v158_v159_cell2_replay_latch = v158_v159_cell2_replay_latch_u;
  v158_v159_cell1_v_delayed = v158_v159_cell1_v_delayed_u;
  v158_v159_cell2_v_delayed = v158_v159_cell2_v_delayed_u;
  v158_v159_wasted = v158_v159_wasted_u;
  return cstate;
}