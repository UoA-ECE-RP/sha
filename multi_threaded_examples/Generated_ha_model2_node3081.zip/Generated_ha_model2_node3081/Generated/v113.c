#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v113_v_i_0;
double v113_v_i_1;
double v113_v_i_2;
double v113_v_i_3;
double v113_voo = 0.0;
double v113_state = 0.0;


static double  v113_vx  =  0 ,  v113_vy  =  0 ,  v113_vz  =  0 ,  v113_g  =  0 ,  v113_v  =  0 ,  v113_ft  =  0 ,  v113_theta  =  0 ,  v113_v_O  =  0 ; //the continuous vars
static double  v113_vx_u , v113_vy_u , v113_vz_u , v113_g_u , v113_v_u , v113_ft_u , v113_theta_u , v113_v_O_u ; // and their updates
static double  v113_vx_init , v113_vy_init , v113_vz_init , v113_g_init , v113_v_init , v113_ft_init , v113_theta_init , v113_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v113_t1 , v113_t2 , v113_t3 , v113_t4 }; // state declarations

enum states v113 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v113_t1 ):
    if (True == False) {;}
    else if  (v113_g > (44.5)) {
      v113_vx_u = (0.3 * v113_v) ;
      v113_vy_u = 0 ;
      v113_vz_u = (0.7 * v113_v) ;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v113_theta_u = (v113_v / 30.0) ;
      v113_v_O_u = (131.1 + (- (80.1 * pow ( ((v113_v / 30.0)) , (0.5) )))) ;
      v113_ft_u = f (v113_theta,4.0e-2) ;
      cstate =  v113_t2 ;
      force_init_update = False;
    }

    else if ( v113_v <= (44.5)
               && v113_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v113_vx_init = v113_vx ;
      slope =  (v113_vx * -8.7) ;
      v113_vx_u = (slope * d) + v113_vx ;
      if ((pstate != cstate) || force_init_update) v113_vy_init = v113_vy ;
      slope =  (v113_vy * -190.9) ;
      v113_vy_u = (slope * d) + v113_vy ;
      if ((pstate != cstate) || force_init_update) v113_vz_init = v113_vz ;
      slope =  (v113_vz * -190.4) ;
      v113_vz_u = (slope * d) + v113_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v113_t1 ;
      force_init_update = False;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v113_v_u = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_voo = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v113!\n");
      exit(1);
    }
    break;
  case ( v113_t2 ):
    if (True == False) {;}
    else if  (v113_v >= (44.5)) {
      v113_vx_u = v113_vx ;
      v113_vy_u = v113_vy ;
      v113_vz_u = v113_vz ;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v113_t3 ;
      force_init_update = False;
    }
    else if  (v113_g <= (44.5)
               && v113_v < (44.5)) {
      v113_vx_u = v113_vx ;
      v113_vy_u = v113_vy ;
      v113_vz_u = v113_vz ;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v113_t1 ;
      force_init_update = False;
    }

    else if ( v113_v < (44.5)
               && v113_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v113_vx_init = v113_vx ;
      slope =  ((v113_vx * -23.6) + (777200.0 * v113_g)) ;
      v113_vx_u = (slope * d) + v113_vx ;
      if ((pstate != cstate) || force_init_update) v113_vy_init = v113_vy ;
      slope =  ((v113_vy * -45.5) + (58900.0 * v113_g)) ;
      v113_vy_u = (slope * d) + v113_vy ;
      if ((pstate != cstate) || force_init_update) v113_vz_init = v113_vz ;
      slope =  ((v113_vz * -12.9) + (276600.0 * v113_g)) ;
      v113_vz_u = (slope * d) + v113_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v113_t2 ;
      force_init_update = False;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v113_v_u = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_voo = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v113!\n");
      exit(1);
    }
    break;
  case ( v113_t3 ):
    if (True == False) {;}
    else if  (v113_v >= (131.1)) {
      v113_vx_u = v113_vx ;
      v113_vy_u = v113_vy ;
      v113_vz_u = v113_vz ;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v113_t4 ;
      force_init_update = False;
    }

    else if ( v113_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v113_vx_init = v113_vx ;
      slope =  (v113_vx * -6.9) ;
      v113_vx_u = (slope * d) + v113_vx ;
      if ((pstate != cstate) || force_init_update) v113_vy_init = v113_vy ;
      slope =  (v113_vy * 75.9) ;
      v113_vy_u = (slope * d) + v113_vy ;
      if ((pstate != cstate) || force_init_update) v113_vz_init = v113_vz ;
      slope =  (v113_vz * 6826.5) ;
      v113_vz_u = (slope * d) + v113_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v113_t3 ;
      force_init_update = False;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v113_v_u = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_voo = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v113!\n");
      exit(1);
    }
    break;
  case ( v113_t4 ):
    if (True == False) {;}
    else if  (v113_v <= (30.0)) {
      v113_vx_u = v113_vx ;
      v113_vy_u = v113_vy ;
      v113_vz_u = v113_vz ;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v113_t1 ;
      force_init_update = False;
    }

    else if ( v113_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v113_vx_init = v113_vx ;
      slope =  (v113_vx * -33.2) ;
      v113_vx_u = (slope * d) + v113_vx ;
      if ((pstate != cstate) || force_init_update) v113_vy_init = v113_vy ;
      slope =  ((v113_vy * 20.0) * v113_ft) ;
      v113_vy_u = (slope * d) + v113_vy ;
      if ((pstate != cstate) || force_init_update) v113_vz_init = v113_vz ;
      slope =  ((v113_vz * 2.0) * v113_ft) ;
      v113_vz_u = (slope * d) + v113_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v113_t4 ;
      force_init_update = False;
      v113_g_u = ((((((((((((v113_v_i_0 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926)) + ((((v113_v_i_1 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v113_v_i_2 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719))) + ((((v113_v_i_3 + (- ((v113_vx + (- v113_vy)) + v113_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v113_v_u = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_voo = ((v113_vx + (- v113_vy)) + v113_vz) ;
      v113_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v113!\n");
      exit(1);
    }
    break;
  }
  v113_vx = v113_vx_u;
  v113_vy = v113_vy_u;
  v113_vz = v113_vz_u;
  v113_g = v113_g_u;
  v113_v = v113_v_u;
  v113_ft = v113_ft_u;
  v113_theta = v113_theta_u;
  v113_v_O = v113_v_O_u;
  return cstate;
}