#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v180_v_i_0;
double v180_v_i_1;
double v180_v_i_2;
double v180_v_i_3;
double v180_v_i_4;
double v180_voo = 0.0;
double v180_state = 0.0;


static double  v180_vx  =  0 ,  v180_vy  =  0 ,  v180_vz  =  0 ,  v180_g  =  0 ,  v180_v  =  0 ,  v180_ft  =  0 ,  v180_theta  =  0 ,  v180_v_O  =  0 ; //the continuous vars
static double  v180_vx_u , v180_vy_u , v180_vz_u , v180_g_u , v180_v_u , v180_ft_u , v180_theta_u , v180_v_O_u ; // and their updates
static double  v180_vx_init , v180_vy_init , v180_vz_init , v180_g_init , v180_v_init , v180_ft_init , v180_theta_init , v180_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v180_t1 , v180_t2 , v180_t3 , v180_t4 }; // state declarations

enum states v180 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v180_t1 ):
    if (True == False) {;}
    else if  (v180_g > (44.5)) {
      v180_vx_u = (0.3 * v180_v) ;
      v180_vy_u = 0 ;
      v180_vz_u = (0.7 * v180_v) ;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      v180_theta_u = (v180_v / 30.0) ;
      v180_v_O_u = (131.1 + (- (80.1 * pow ( ((v180_v / 30.0)) , (0.5) )))) ;
      v180_ft_u = f (v180_theta,4.0e-2) ;
      cstate =  v180_t2 ;
      force_init_update = False;
    }

    else if ( v180_v <= (44.5)
               && v180_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v180_vx_init = v180_vx ;
      slope =  (v180_vx * -8.7) ;
      v180_vx_u = (slope * d) + v180_vx ;
      if ((pstate != cstate) || force_init_update) v180_vy_init = v180_vy ;
      slope =  (v180_vy * -190.9) ;
      v180_vy_u = (slope * d) + v180_vy ;
      if ((pstate != cstate) || force_init_update) v180_vz_init = v180_vz ;
      slope =  (v180_vz * -190.4) ;
      v180_vz_u = (slope * d) + v180_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v180_t1 ;
      force_init_update = False;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      v180_v_u = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_voo = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v180!\n");
      exit(1);
    }
    break;
  case ( v180_t2 ):
    if (True == False) {;}
    else if  (v180_v >= (44.5)) {
      v180_vx_u = v180_vx ;
      v180_vy_u = v180_vy ;
      v180_vz_u = v180_vz ;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      cstate =  v180_t3 ;
      force_init_update = False;
    }
    else if  (v180_g <= (44.5)
               && v180_v < (44.5)) {
      v180_vx_u = v180_vx ;
      v180_vy_u = v180_vy ;
      v180_vz_u = v180_vz ;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      cstate =  v180_t1 ;
      force_init_update = False;
    }

    else if ( v180_v < (44.5)
               && v180_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v180_vx_init = v180_vx ;
      slope =  ((v180_vx * -23.6) + (777200.0 * v180_g)) ;
      v180_vx_u = (slope * d) + v180_vx ;
      if ((pstate != cstate) || force_init_update) v180_vy_init = v180_vy ;
      slope =  ((v180_vy * -45.5) + (58900.0 * v180_g)) ;
      v180_vy_u = (slope * d) + v180_vy ;
      if ((pstate != cstate) || force_init_update) v180_vz_init = v180_vz ;
      slope =  ((v180_vz * -12.9) + (276600.0 * v180_g)) ;
      v180_vz_u = (slope * d) + v180_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v180_t2 ;
      force_init_update = False;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      v180_v_u = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_voo = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v180!\n");
      exit(1);
    }
    break;
  case ( v180_t3 ):
    if (True == False) {;}
    else if  (v180_v >= (131.1)) {
      v180_vx_u = v180_vx ;
      v180_vy_u = v180_vy ;
      v180_vz_u = v180_vz ;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      cstate =  v180_t4 ;
      force_init_update = False;
    }

    else if ( v180_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v180_vx_init = v180_vx ;
      slope =  (v180_vx * -6.9) ;
      v180_vx_u = (slope * d) + v180_vx ;
      if ((pstate != cstate) || force_init_update) v180_vy_init = v180_vy ;
      slope =  (v180_vy * 75.9) ;
      v180_vy_u = (slope * d) + v180_vy ;
      if ((pstate != cstate) || force_init_update) v180_vz_init = v180_vz ;
      slope =  (v180_vz * 6826.5) ;
      v180_vz_u = (slope * d) + v180_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v180_t3 ;
      force_init_update = False;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      v180_v_u = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_voo = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v180!\n");
      exit(1);
    }
    break;
  case ( v180_t4 ):
    if (True == False) {;}
    else if  (v180_v <= (30.0)) {
      v180_vx_u = v180_vx ;
      v180_vy_u = v180_vy ;
      v180_vz_u = v180_vz ;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      cstate =  v180_t1 ;
      force_init_update = False;
    }

    else if ( v180_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v180_vx_init = v180_vx ;
      slope =  (v180_vx * -33.2) ;
      v180_vx_u = (slope * d) + v180_vx ;
      if ((pstate != cstate) || force_init_update) v180_vy_init = v180_vy ;
      slope =  ((v180_vy * 20.0) * v180_ft) ;
      v180_vy_u = (slope * d) + v180_vy ;
      if ((pstate != cstate) || force_init_update) v180_vz_init = v180_vz ;
      slope =  ((v180_vz * 2.0) * v180_ft) ;
      v180_vz_u = (slope * d) + v180_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v180_t4 ;
      force_init_update = False;
      v180_g_u = ((((((((((((v180_v_i_0 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v180_v_i_1 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v180_v_i_2 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.59724009218))) + ((((v180_v_i_3 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v180_v_i_4 + (- ((v180_vx + (- v180_vy)) + v180_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 5.08726613827))) + 0) + 0) + 0) + 0) ;
      v180_v_u = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_voo = ((v180_vx + (- v180_vy)) + v180_vz) ;
      v180_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v180!\n");
      exit(1);
    }
    break;
  }
  v180_vx = v180_vx_u;
  v180_vy = v180_vy_u;
  v180_vz = v180_vz_u;
  v180_g = v180_g_u;
  v180_v = v180_v_u;
  v180_ft = v180_ft_u;
  v180_theta = v180_theta_u;
  v180_v_O = v180_v_O_u;
  return cstate;
}