#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double SA_CT_update_c1vd();
extern double SA_CT_update_c2vd();
extern double SA_CT_update_c1md();
extern double SA_CT_update_c2md();
extern double SA_CT_update_buffer_index(double,double,double,double);
extern double SA_CT_update_latch1(double,double);
extern double SA_CT_update_latch2(double,double);
extern double SA_CT_update_ocell1(double,double);
extern double SA_CT_update_ocell2(double,double);
double SA_CT_cell1_v;
double SA_CT_cell1_mode;
double SA_CT_cell2_v;
double SA_CT_cell2_mode;
double SA_CT_cell1_v_replay = 0.0;
double SA_CT_cell2_v_replay = 0.0;


static double  SA_CT_k  =  0.0 ,  SA_CT_cell1_mode_delayed  =  0.0 ,  SA_CT_cell2_mode_delayed  =  0.0 ,  SA_CT_from_cell  =  0.0 ,  SA_CT_cell1_replay_latch  =  0.0 ,  SA_CT_cell2_replay_latch  =  0.0 ,  SA_CT_cell1_v_delayed  =  0.0 ,  SA_CT_cell2_v_delayed  =  0.0 ,  SA_CT_wasted  =  0.0 ; //the continuous vars
static double  SA_CT_k_u , SA_CT_cell1_mode_delayed_u , SA_CT_cell2_mode_delayed_u , SA_CT_from_cell_u , SA_CT_cell1_replay_latch_u , SA_CT_cell2_replay_latch_u , SA_CT_cell1_v_delayed_u , SA_CT_cell2_v_delayed_u , SA_CT_wasted_u ; // and their updates
static double  SA_CT_k_init , SA_CT_cell1_mode_delayed_init , SA_CT_cell2_mode_delayed_init , SA_CT_from_cell_init , SA_CT_cell1_replay_latch_init , SA_CT_cell2_replay_latch_init , SA_CT_cell1_v_delayed_init , SA_CT_cell2_v_delayed_init , SA_CT_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { SA_CT_idle , SA_CT_annhilate , SA_CT_previous_drection1 , SA_CT_previous_direction2 , SA_CT_wait_cell1 , SA_CT_replay_cell1 , SA_CT_replay_cell2 , SA_CT_wait_cell2 }; // state declarations

enum states SA_CT (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( SA_CT_idle ):
    if (True == False) {;}
    else if  (SA_CT_cell2_mode == (2.0) && (SA_CT_cell1_mode != (2.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_previous_direction2 ;
      force_init_update = False;
    }
    else if  (SA_CT_cell1_mode == (2.0) && (SA_CT_cell2_mode != (2.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_previous_drection1 ;
      force_init_update = False;
    }
    else if  (SA_CT_cell1_mode == (2.0) && (SA_CT_cell2_mode == (2.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_idle ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_annhilate ):
    if (True == False) {;}
    else if  (SA_CT_cell1_mode != (2.0) && (SA_CT_cell2_mode != (2.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_from_cell_u = 0 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_previous_drection1 ):
    if (True == False) {;}
    else if  (SA_CT_from_cell == (1.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_wait_cell1 ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (0.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_wait_cell1 ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (2.0) && (SA_CT_cell2_mode_delayed == (0.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_wait_cell1 ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (2.0) && (SA_CT_cell2_mode_delayed != (0.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_previous_drection1 ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_previous_direction2 ):
    if (True == False) {;}
    else if  (SA_CT_from_cell == (1.0) && (SA_CT_cell1_mode_delayed != (0.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (2.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_replay_cell1 ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (0.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_replay_cell1 ;
      force_init_update = False;
    }
    else if  (SA_CT_from_cell == (1.0) && (SA_CT_cell1_mode_delayed == (0.0))) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_previous_direction2 ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_wait_cell1 ):
    if (True == False) {;}
    else if  (SA_CT_cell2_mode == (2.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
    }
    else if  (SA_CT_k >= (20.0)) {
      SA_CT_from_cell_u = 1 ;
      SA_CT_cell1_replay_latch_u = 1 ;
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_wait_cell1 ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_replay_cell1 ):
    if (True == False) {;}
    else if  (SA_CT_cell1_mode == (2.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_annhilate ;
      force_init_update = False;
    }
    else if  (SA_CT_k >= (20.0)) {
      SA_CT_from_cell_u = 2 ;
      SA_CT_cell2_replay_latch_u = 1 ;
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_replay_cell1 ;
      force_init_update = False;
      SA_CT_cell1_replay_latch_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_replay_cell2 ):
    if (True == False) {;}
    else if  (SA_CT_k >= (10.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_replay_cell2 ;
      force_init_update = False;
      SA_CT_cell2_replay_latch_u = 1 ;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  case ( SA_CT_wait_cell2 ):
    if (True == False) {;}
    else if  (SA_CT_k >= (10.0)) {
      SA_CT_k_u = 1 ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
      cstate =  SA_CT_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) SA_CT_k_init = SA_CT_k ;
      slope =  1 ;
      SA_CT_k_u = (slope * d) + SA_CT_k ;
      /* Possible Saturation */
      
      
      
      cstate =  SA_CT_wait_cell2 ;
      force_init_update = False;
      SA_CT_cell1_v_delayed_u = SA_CT_update_c1vd () ;
      SA_CT_cell2_v_delayed_u = SA_CT_update_c2vd () ;
      SA_CT_cell1_mode_delayed_u = SA_CT_update_c1md () ;
      SA_CT_cell2_mode_delayed_u = SA_CT_update_c2md () ;
      SA_CT_wasted_u = SA_CT_update_buffer_index (SA_CT_cell1_v,SA_CT_cell2_v,SA_CT_cell1_mode,SA_CT_cell2_mode) ;
      SA_CT_cell1_replay_latch_u = SA_CT_update_latch1 (SA_CT_cell1_mode_delayed,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_replay_latch_u = SA_CT_update_latch2 (SA_CT_cell2_mode_delayed,SA_CT_cell2_replay_latch_u) ;
      SA_CT_cell1_v_replay = SA_CT_update_ocell1 (SA_CT_cell1_v_delayed_u,SA_CT_cell1_replay_latch_u) ;
      SA_CT_cell2_v_replay = SA_CT_update_ocell2 (SA_CT_cell2_v_delayed_u,SA_CT_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: SA_CT!\n");
      exit(1);
    }
    break;
  }
  SA_CT_k = SA_CT_k_u;
  SA_CT_cell1_mode_delayed = SA_CT_cell1_mode_delayed_u;
  SA_CT_cell2_mode_delayed = SA_CT_cell2_mode_delayed_u;
  SA_CT_from_cell = SA_CT_from_cell_u;
  SA_CT_cell1_replay_latch = SA_CT_cell1_replay_latch_u;
  SA_CT_cell2_replay_latch = SA_CT_cell2_replay_latch_u;
  SA_CT_cell1_v_delayed = SA_CT_cell1_v_delayed_u;
  SA_CT_cell2_v_delayed = SA_CT_cell2_v_delayed_u;
  SA_CT_wasted = SA_CT_wasted_u;
  return cstate;
}