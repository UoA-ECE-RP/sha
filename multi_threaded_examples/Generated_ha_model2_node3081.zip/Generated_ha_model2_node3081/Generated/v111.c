#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v111_v_i_0;
double v111_v_i_1;
double v111_v_i_2;
double v111_v_i_3;
double v111_voo = 0.0;
double v111_state = 0.0;


static double  v111_vx  =  0 ,  v111_vy  =  0 ,  v111_vz  =  0 ,  v111_g  =  0 ,  v111_v  =  0 ,  v111_ft  =  0 ,  v111_theta  =  0 ,  v111_v_O  =  0 ; //the continuous vars
static double  v111_vx_u , v111_vy_u , v111_vz_u , v111_g_u , v111_v_u , v111_ft_u , v111_theta_u , v111_v_O_u ; // and their updates
static double  v111_vx_init , v111_vy_init , v111_vz_init , v111_g_init , v111_v_init , v111_ft_init , v111_theta_init , v111_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v111_t1 , v111_t2 , v111_t3 , v111_t4 }; // state declarations

enum states v111 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v111_t1 ):
    if (True == False) {;}
    else if  (v111_g > (44.5)) {
      v111_vx_u = (0.3 * v111_v) ;
      v111_vy_u = 0 ;
      v111_vz_u = (0.7 * v111_v) ;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      v111_theta_u = (v111_v / 30.0) ;
      v111_v_O_u = (131.1 + (- (80.1 * pow ( ((v111_v / 30.0)) , (0.5) )))) ;
      v111_ft_u = f (v111_theta,4.0e-2) ;
      cstate =  v111_t2 ;
      force_init_update = False;
    }

    else if ( v111_v <= (44.5)
               && v111_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v111_vx_init = v111_vx ;
      slope =  (v111_vx * -8.7) ;
      v111_vx_u = (slope * d) + v111_vx ;
      if ((pstate != cstate) || force_init_update) v111_vy_init = v111_vy ;
      slope =  (v111_vy * -190.9) ;
      v111_vy_u = (slope * d) + v111_vy ;
      if ((pstate != cstate) || force_init_update) v111_vz_init = v111_vz ;
      slope =  (v111_vz * -190.4) ;
      v111_vz_u = (slope * d) + v111_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v111_t1 ;
      force_init_update = False;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      v111_v_u = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_voo = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v111!\n");
      exit(1);
    }
    break;
  case ( v111_t2 ):
    if (True == False) {;}
    else if  (v111_v >= (44.5)) {
      v111_vx_u = v111_vx ;
      v111_vy_u = v111_vy ;
      v111_vz_u = v111_vz ;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v111_t3 ;
      force_init_update = False;
    }
    else if  (v111_g <= (44.5)
               && v111_v < (44.5)) {
      v111_vx_u = v111_vx ;
      v111_vy_u = v111_vy ;
      v111_vz_u = v111_vz ;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v111_t1 ;
      force_init_update = False;
    }

    else if ( v111_v < (44.5)
               && v111_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v111_vx_init = v111_vx ;
      slope =  ((v111_vx * -23.6) + (777200.0 * v111_g)) ;
      v111_vx_u = (slope * d) + v111_vx ;
      if ((pstate != cstate) || force_init_update) v111_vy_init = v111_vy ;
      slope =  ((v111_vy * -45.5) + (58900.0 * v111_g)) ;
      v111_vy_u = (slope * d) + v111_vy ;
      if ((pstate != cstate) || force_init_update) v111_vz_init = v111_vz ;
      slope =  ((v111_vz * -12.9) + (276600.0 * v111_g)) ;
      v111_vz_u = (slope * d) + v111_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v111_t2 ;
      force_init_update = False;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      v111_v_u = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_voo = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v111!\n");
      exit(1);
    }
    break;
  case ( v111_t3 ):
    if (True == False) {;}
    else if  (v111_v >= (131.1)) {
      v111_vx_u = v111_vx ;
      v111_vy_u = v111_vy ;
      v111_vz_u = v111_vz ;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v111_t4 ;
      force_init_update = False;
    }

    else if ( v111_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v111_vx_init = v111_vx ;
      slope =  (v111_vx * -6.9) ;
      v111_vx_u = (slope * d) + v111_vx ;
      if ((pstate != cstate) || force_init_update) v111_vy_init = v111_vy ;
      slope =  (v111_vy * 75.9) ;
      v111_vy_u = (slope * d) + v111_vy ;
      if ((pstate != cstate) || force_init_update) v111_vz_init = v111_vz ;
      slope =  (v111_vz * 6826.5) ;
      v111_vz_u = (slope * d) + v111_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v111_t3 ;
      force_init_update = False;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      v111_v_u = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_voo = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v111!\n");
      exit(1);
    }
    break;
  case ( v111_t4 ):
    if (True == False) {;}
    else if  (v111_v <= (30.0)) {
      v111_vx_u = v111_vx ;
      v111_vy_u = v111_vy ;
      v111_vz_u = v111_vz ;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v111_t1 ;
      force_init_update = False;
    }

    else if ( v111_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v111_vx_init = v111_vx ;
      slope =  (v111_vx * -33.2) ;
      v111_vx_u = (slope * d) + v111_vx ;
      if ((pstate != cstate) || force_init_update) v111_vy_init = v111_vy ;
      slope =  ((v111_vy * 20.0) * v111_ft) ;
      v111_vy_u = (slope * d) + v111_vy ;
      if ((pstate != cstate) || force_init_update) v111_vz_init = v111_vz ;
      slope =  ((v111_vz * 2.0) * v111_ft) ;
      v111_vz_u = (slope * d) + v111_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v111_t4 ;
      force_init_update = False;
      v111_g_u = ((((((((((((v111_v_i_0 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v111_v_i_1 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.6347785522))) + ((((v111_v_i_2 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.311926))) + ((((v111_v_i_3 + (- ((v111_vx + (- v111_vy)) + v111_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.43947037718))) + 0) + 0) + 0) + 0) + 0) ;
      v111_v_u = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_voo = ((v111_vx + (- v111_vy)) + v111_vz) ;
      v111_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v111!\n");
      exit(1);
    }
    break;
  }
  v111_vx = v111_vx_u;
  v111_vy = v111_vy_u;
  v111_vz = v111_vz_u;
  v111_g = v111_g_u;
  v111_v = v111_v_u;
  v111_ft = v111_ft_u;
  v111_theta = v111_theta_u;
  v111_v_O = v111_v_O_u;
  return cstate;
}