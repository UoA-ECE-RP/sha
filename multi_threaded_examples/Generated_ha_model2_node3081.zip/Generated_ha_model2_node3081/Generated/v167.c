#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v167_v_i_0;
double v167_v_i_1;
double v167_v_i_2;
double v167_v_i_3;
double v167_voo = 0.0;
double v167_state = 0.0;


static double  v167_vx  =  0 ,  v167_vy  =  0 ,  v167_vz  =  0 ,  v167_g  =  0 ,  v167_v  =  0 ,  v167_ft  =  0 ,  v167_theta  =  0 ,  v167_v_O  =  0 ; //the continuous vars
static double  v167_vx_u , v167_vy_u , v167_vz_u , v167_g_u , v167_v_u , v167_ft_u , v167_theta_u , v167_v_O_u ; // and their updates
static double  v167_vx_init , v167_vy_init , v167_vz_init , v167_g_init , v167_v_init , v167_ft_init , v167_theta_init , v167_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v167_t1 , v167_t2 , v167_t3 , v167_t4 }; // state declarations

enum states v167 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v167_t1 ):
    if (True == False) {;}
    else if  (v167_g > (44.5)) {
      v167_vx_u = (0.3 * v167_v) ;
      v167_vy_u = 0 ;
      v167_vz_u = (0.7 * v167_v) ;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v167_theta_u = (v167_v / 30.0) ;
      v167_v_O_u = (131.1 + (- (80.1 * pow ( ((v167_v / 30.0)) , (0.5) )))) ;
      v167_ft_u = f (v167_theta,4.0e-2) ;
      cstate =  v167_t2 ;
      force_init_update = False;
    }

    else if ( v167_v <= (44.5)
               && v167_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v167_vx_init = v167_vx ;
      slope =  (v167_vx * -8.7) ;
      v167_vx_u = (slope * d) + v167_vx ;
      if ((pstate != cstate) || force_init_update) v167_vy_init = v167_vy ;
      slope =  (v167_vy * -190.9) ;
      v167_vy_u = (slope * d) + v167_vy ;
      if ((pstate != cstate) || force_init_update) v167_vz_init = v167_vz ;
      slope =  (v167_vz * -190.4) ;
      v167_vz_u = (slope * d) + v167_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v167_t1 ;
      force_init_update = False;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v167_v_u = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_voo = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167!\n");
      exit(1);
    }
    break;
  case ( v167_t2 ):
    if (True == False) {;}
    else if  (v167_v >= (44.5)) {
      v167_vx_u = v167_vx ;
      v167_vy_u = v167_vy ;
      v167_vz_u = v167_vz ;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v167_t3 ;
      force_init_update = False;
    }
    else if  (v167_g <= (44.5)
               && v167_v < (44.5)) {
      v167_vx_u = v167_vx ;
      v167_vy_u = v167_vy ;
      v167_vz_u = v167_vz ;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v167_t1 ;
      force_init_update = False;
    }

    else if ( v167_v < (44.5)
               && v167_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v167_vx_init = v167_vx ;
      slope =  ((v167_vx * -23.6) + (777200.0 * v167_g)) ;
      v167_vx_u = (slope * d) + v167_vx ;
      if ((pstate != cstate) || force_init_update) v167_vy_init = v167_vy ;
      slope =  ((v167_vy * -45.5) + (58900.0 * v167_g)) ;
      v167_vy_u = (slope * d) + v167_vy ;
      if ((pstate != cstate) || force_init_update) v167_vz_init = v167_vz ;
      slope =  ((v167_vz * -12.9) + (276600.0 * v167_g)) ;
      v167_vz_u = (slope * d) + v167_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v167_t2 ;
      force_init_update = False;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v167_v_u = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_voo = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167!\n");
      exit(1);
    }
    break;
  case ( v167_t3 ):
    if (True == False) {;}
    else if  (v167_v >= (131.1)) {
      v167_vx_u = v167_vx ;
      v167_vy_u = v167_vy ;
      v167_vz_u = v167_vz ;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v167_t4 ;
      force_init_update = False;
    }

    else if ( v167_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v167_vx_init = v167_vx ;
      slope =  (v167_vx * -6.9) ;
      v167_vx_u = (slope * d) + v167_vx ;
      if ((pstate != cstate) || force_init_update) v167_vy_init = v167_vy ;
      slope =  (v167_vy * 75.9) ;
      v167_vy_u = (slope * d) + v167_vy ;
      if ((pstate != cstate) || force_init_update) v167_vz_init = v167_vz ;
      slope =  (v167_vz * 6826.5) ;
      v167_vz_u = (slope * d) + v167_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v167_t3 ;
      force_init_update = False;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v167_v_u = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_voo = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167!\n");
      exit(1);
    }
    break;
  case ( v167_t4 ):
    if (True == False) {;}
    else if  (v167_v <= (30.0)) {
      v167_vx_u = v167_vx ;
      v167_vy_u = v167_vy ;
      v167_vz_u = v167_vz ;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v167_t1 ;
      force_init_update = False;
    }

    else if ( v167_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v167_vx_init = v167_vx ;
      slope =  (v167_vx * -33.2) ;
      v167_vx_u = (slope * d) + v167_vx ;
      if ((pstate != cstate) || force_init_update) v167_vy_init = v167_vy ;
      slope =  ((v167_vy * 20.0) * v167_ft) ;
      v167_vy_u = (slope * d) + v167_vy ;
      if ((pstate != cstate) || force_init_update) v167_vz_init = v167_vz ;
      slope =  ((v167_vz * 2.0) * v167_ft) ;
      v167_vz_u = (slope * d) + v167_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v167_t4 ;
      force_init_update = False;
      v167_g_u = ((((((((((((v167_v_i_0 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v167_v_i_1 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885))) + ((((v167_v_i_2 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + ((((v167_v_i_3 + (- ((v167_vx + (- v167_vy)) + v167_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.41051542655))) + 0) + 0) + 0) + 0) + 0) ;
      v167_v_u = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_voo = ((v167_vx + (- v167_vy)) + v167_vz) ;
      v167_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v167!\n");
      exit(1);
    }
    break;
  }
  v167_vx = v167_vx_u;
  v167_vy = v167_vy_u;
  v167_vz = v167_vz_u;
  v167_g = v167_g_u;
  v167_v = v167_v_u;
  v167_ft = v167_ft_u;
  v167_theta = v167_theta_u;
  v167_v_O = v167_v_O_u;
  return cstate;
}