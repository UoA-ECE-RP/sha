#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v116_v_i_0;
double v116_v_i_1;
double v116_v_i_2;
double v116_v_i_3;
double v116_voo = 0.0;
double v116_state = 0.0;


static double  v116_vx  =  0 ,  v116_vy  =  0 ,  v116_vz  =  0 ,  v116_g  =  0 ,  v116_v  =  0 ,  v116_ft  =  0 ,  v116_theta  =  0 ,  v116_v_O  =  0 ; //the continuous vars
static double  v116_vx_u , v116_vy_u , v116_vz_u , v116_g_u , v116_v_u , v116_ft_u , v116_theta_u , v116_v_O_u ; // and their updates
static double  v116_vx_init , v116_vy_init , v116_vz_init , v116_g_init , v116_v_init , v116_ft_init , v116_theta_init , v116_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v116_t1 , v116_t2 , v116_t3 , v116_t4 }; // state declarations

enum states v116 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v116_t1 ):
    if (True == False) {;}
    else if  (v116_g > (44.5)) {
      v116_vx_u = (0.3 * v116_v) ;
      v116_vy_u = 0 ;
      v116_vz_u = (0.7 * v116_v) ;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v116_theta_u = (v116_v / 30.0) ;
      v116_v_O_u = (131.1 + (- (80.1 * pow ( ((v116_v / 30.0)) , (0.5) )))) ;
      v116_ft_u = f (v116_theta,4.0e-2) ;
      cstate =  v116_t2 ;
      force_init_update = False;
    }

    else if ( v116_v <= (44.5)
               && v116_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v116_vx_init = v116_vx ;
      slope =  (v116_vx * -8.7) ;
      v116_vx_u = (slope * d) + v116_vx ;
      if ((pstate != cstate) || force_init_update) v116_vy_init = v116_vy ;
      slope =  (v116_vy * -190.9) ;
      v116_vy_u = (slope * d) + v116_vy ;
      if ((pstate != cstate) || force_init_update) v116_vz_init = v116_vz ;
      slope =  (v116_vz * -190.4) ;
      v116_vz_u = (slope * d) + v116_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v116_t1 ;
      force_init_update = False;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v116_v_u = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_voo = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v116!\n");
      exit(1);
    }
    break;
  case ( v116_t2 ):
    if (True == False) {;}
    else if  (v116_v >= (44.5)) {
      v116_vx_u = v116_vx ;
      v116_vy_u = v116_vy ;
      v116_vz_u = v116_vz ;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v116_t3 ;
      force_init_update = False;
    }
    else if  (v116_g <= (44.5)
               && v116_v < (44.5)) {
      v116_vx_u = v116_vx ;
      v116_vy_u = v116_vy ;
      v116_vz_u = v116_vz ;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v116_t1 ;
      force_init_update = False;
    }

    else if ( v116_v < (44.5)
               && v116_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v116_vx_init = v116_vx ;
      slope =  ((v116_vx * -23.6) + (777200.0 * v116_g)) ;
      v116_vx_u = (slope * d) + v116_vx ;
      if ((pstate != cstate) || force_init_update) v116_vy_init = v116_vy ;
      slope =  ((v116_vy * -45.5) + (58900.0 * v116_g)) ;
      v116_vy_u = (slope * d) + v116_vy ;
      if ((pstate != cstate) || force_init_update) v116_vz_init = v116_vz ;
      slope =  ((v116_vz * -12.9) + (276600.0 * v116_g)) ;
      v116_vz_u = (slope * d) + v116_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v116_t2 ;
      force_init_update = False;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v116_v_u = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_voo = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v116!\n");
      exit(1);
    }
    break;
  case ( v116_t3 ):
    if (True == False) {;}
    else if  (v116_v >= (131.1)) {
      v116_vx_u = v116_vx ;
      v116_vy_u = v116_vy ;
      v116_vz_u = v116_vz ;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v116_t4 ;
      force_init_update = False;
    }

    else if ( v116_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v116_vx_init = v116_vx ;
      slope =  (v116_vx * -6.9) ;
      v116_vx_u = (slope * d) + v116_vx ;
      if ((pstate != cstate) || force_init_update) v116_vy_init = v116_vy ;
      slope =  (v116_vy * 75.9) ;
      v116_vy_u = (slope * d) + v116_vy ;
      if ((pstate != cstate) || force_init_update) v116_vz_init = v116_vz ;
      slope =  (v116_vz * 6826.5) ;
      v116_vz_u = (slope * d) + v116_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v116_t3 ;
      force_init_update = False;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v116_v_u = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_voo = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v116!\n");
      exit(1);
    }
    break;
  case ( v116_t4 ):
    if (True == False) {;}
    else if  (v116_v <= (30.0)) {
      v116_vx_u = v116_vx ;
      v116_vy_u = v116_vy ;
      v116_vz_u = v116_vz ;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v116_t1 ;
      force_init_update = False;
    }

    else if ( v116_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v116_vx_init = v116_vx ;
      slope =  (v116_vx * -33.2) ;
      v116_vx_u = (slope * d) + v116_vx ;
      if ((pstate != cstate) || force_init_update) v116_vy_init = v116_vy ;
      slope =  ((v116_vy * 20.0) * v116_ft) ;
      v116_vy_u = (slope * d) + v116_vy ;
      if ((pstate != cstate) || force_init_update) v116_vz_init = v116_vz ;
      slope =  ((v116_vz * 2.0) * v116_ft) ;
      v116_vz_u = (slope * d) + v116_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v116_t4 ;
      force_init_update = False;
      v116_g_u = ((((((((((((v116_v_i_0 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603)) + ((((v116_v_i_1 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + ((((v116_v_i_2 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v116_v_i_3 + (- ((v116_vx + (- v116_vy)) + v116_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.40977135286))) + 0) + 0) + 0) + 0) + 0) ;
      v116_v_u = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_voo = ((v116_vx + (- v116_vy)) + v116_vz) ;
      v116_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v116!\n");
      exit(1);
    }
    break;
  }
  v116_vx = v116_vx_u;
  v116_vy = v116_vy_u;
  v116_vz = v116_vz_u;
  v116_g = v116_g_u;
  v116_v = v116_v_u;
  v116_ft = v116_ft_u;
  v116_theta = v116_theta_u;
  v116_v_O = v116_v_O_u;
  return cstate;
}