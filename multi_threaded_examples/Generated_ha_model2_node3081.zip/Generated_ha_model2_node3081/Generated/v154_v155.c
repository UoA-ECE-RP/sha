#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v154_v155_update_c1vd();
extern double v154_v155_update_c2vd();
extern double v154_v155_update_c1md();
extern double v154_v155_update_c2md();
extern double v154_v155_update_buffer_index(double,double,double,double);
extern double v154_v155_update_latch1(double,double);
extern double v154_v155_update_latch2(double,double);
extern double v154_v155_update_ocell1(double,double);
extern double v154_v155_update_ocell2(double,double);
double v154_v155_cell1_v;
double v154_v155_cell1_mode;
double v154_v155_cell2_v;
double v154_v155_cell2_mode;
double v154_v155_cell1_v_replay = 0.0;
double v154_v155_cell2_v_replay = 0.0;


static double  v154_v155_k  =  0.0 ,  v154_v155_cell1_mode_delayed  =  0.0 ,  v154_v155_cell2_mode_delayed  =  0.0 ,  v154_v155_from_cell  =  0.0 ,  v154_v155_cell1_replay_latch  =  0.0 ,  v154_v155_cell2_replay_latch  =  0.0 ,  v154_v155_cell1_v_delayed  =  0.0 ,  v154_v155_cell2_v_delayed  =  0.0 ,  v154_v155_wasted  =  0.0 ; //the continuous vars
static double  v154_v155_k_u , v154_v155_cell1_mode_delayed_u , v154_v155_cell2_mode_delayed_u , v154_v155_from_cell_u , v154_v155_cell1_replay_latch_u , v154_v155_cell2_replay_latch_u , v154_v155_cell1_v_delayed_u , v154_v155_cell2_v_delayed_u , v154_v155_wasted_u ; // and their updates
static double  v154_v155_k_init , v154_v155_cell1_mode_delayed_init , v154_v155_cell2_mode_delayed_init , v154_v155_from_cell_init , v154_v155_cell1_replay_latch_init , v154_v155_cell2_replay_latch_init , v154_v155_cell1_v_delayed_init , v154_v155_cell2_v_delayed_init , v154_v155_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v154_v155_idle , v154_v155_annhilate , v154_v155_previous_drection1 , v154_v155_previous_direction2 , v154_v155_wait_cell1 , v154_v155_replay_cell1 , v154_v155_replay_cell2 , v154_v155_wait_cell2 }; // state declarations

enum states v154_v155 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v154_v155_idle ):
    if (True == False) {;}
    else if  (v154_v155_cell2_mode == (2.0) && (v154_v155_cell1_mode != (2.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v154_v155_cell1_mode == (2.0) && (v154_v155_cell2_mode != (2.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v154_v155_cell1_mode == (2.0) && (v154_v155_cell2_mode == (2.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_idle ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_annhilate ):
    if (True == False) {;}
    else if  (v154_v155_cell1_mode != (2.0) && (v154_v155_cell2_mode != (2.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_from_cell_u = 0 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_previous_drection1 ):
    if (True == False) {;}
    else if  (v154_v155_from_cell == (1.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (0.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (2.0) && (v154_v155_cell2_mode_delayed == (0.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (2.0) && (v154_v155_cell2_mode_delayed != (0.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_previous_drection1 ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_previous_direction2 ):
    if (True == False) {;}
    else if  (v154_v155_from_cell == (1.0) && (v154_v155_cell1_mode_delayed != (0.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (2.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (0.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v154_v155_from_cell == (1.0) && (v154_v155_cell1_mode_delayed == (0.0))) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_previous_direction2 ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_wait_cell1 ):
    if (True == False) {;}
    else if  (v154_v155_cell2_mode == (2.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
    }
    else if  (v154_v155_k >= (68.25177585109999)) {
      v154_v155_from_cell_u = 1 ;
      v154_v155_cell1_replay_latch_u = 1 ;
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_wait_cell1 ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_replay_cell1 ):
    if (True == False) {;}
    else if  (v154_v155_cell1_mode == (2.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_annhilate ;
      force_init_update = False;
    }
    else if  (v154_v155_k >= (68.25177585109999)) {
      v154_v155_from_cell_u = 2 ;
      v154_v155_cell2_replay_latch_u = 1 ;
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_replay_cell1 ;
      force_init_update = False;
      v154_v155_cell1_replay_latch_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_replay_cell2 ):
    if (True == False) {;}
    else if  (v154_v155_k >= (10.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_replay_cell2 ;
      force_init_update = False;
      v154_v155_cell2_replay_latch_u = 1 ;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  case ( v154_v155_wait_cell2 ):
    if (True == False) {;}
    else if  (v154_v155_k >= (10.0)) {
      v154_v155_k_u = 1 ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
      cstate =  v154_v155_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v154_v155_k_init = v154_v155_k ;
      slope =  1 ;
      v154_v155_k_u = (slope * d) + v154_v155_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v154_v155_wait_cell2 ;
      force_init_update = False;
      v154_v155_cell1_v_delayed_u = v154_v155_update_c1vd () ;
      v154_v155_cell2_v_delayed_u = v154_v155_update_c2vd () ;
      v154_v155_cell1_mode_delayed_u = v154_v155_update_c1md () ;
      v154_v155_cell2_mode_delayed_u = v154_v155_update_c2md () ;
      v154_v155_wasted_u = v154_v155_update_buffer_index (v154_v155_cell1_v,v154_v155_cell2_v,v154_v155_cell1_mode,v154_v155_cell2_mode) ;
      v154_v155_cell1_replay_latch_u = v154_v155_update_latch1 (v154_v155_cell1_mode_delayed,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_replay_latch_u = v154_v155_update_latch2 (v154_v155_cell2_mode_delayed,v154_v155_cell2_replay_latch_u) ;
      v154_v155_cell1_v_replay = v154_v155_update_ocell1 (v154_v155_cell1_v_delayed_u,v154_v155_cell1_replay_latch_u) ;
      v154_v155_cell2_v_replay = v154_v155_update_ocell2 (v154_v155_cell2_v_delayed_u,v154_v155_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v154_v155!\n");
      exit(1);
    }
    break;
  }
  v154_v155_k = v154_v155_k_u;
  v154_v155_cell1_mode_delayed = v154_v155_cell1_mode_delayed_u;
  v154_v155_cell2_mode_delayed = v154_v155_cell2_mode_delayed_u;
  v154_v155_from_cell = v154_v155_from_cell_u;
  v154_v155_cell1_replay_latch = v154_v155_cell1_replay_latch_u;
  v154_v155_cell2_replay_latch = v154_v155_cell2_replay_latch_u;
  v154_v155_cell1_v_delayed = v154_v155_cell1_v_delayed_u;
  v154_v155_cell2_v_delayed = v154_v155_cell2_v_delayed_u;
  v154_v155_wasted = v154_v155_wasted_u;
  return cstate;
}