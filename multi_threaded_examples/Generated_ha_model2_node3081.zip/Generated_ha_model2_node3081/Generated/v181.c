#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v181_v_i_0;
double v181_v_i_1;
double v181_voo = 0.0;
double v181_state = 0.0;


static double  v181_vx  =  0 ,  v181_vy  =  0 ,  v181_vz  =  0 ,  v181_g  =  0 ,  v181_v  =  0 ,  v181_ft  =  0 ,  v181_theta  =  0 ,  v181_v_O  =  0 ; //the continuous vars
static double  v181_vx_u , v181_vy_u , v181_vz_u , v181_g_u , v181_v_u , v181_ft_u , v181_theta_u , v181_v_O_u ; // and their updates
static double  v181_vx_init , v181_vy_init , v181_vz_init , v181_g_init , v181_v_init , v181_ft_init , v181_theta_init , v181_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v181_t1 , v181_t2 , v181_t3 , v181_t4 }; // state declarations

enum states v181 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v181_t1 ):
    if (True == False) {;}
    else if  (v181_g > (44.5)) {
      v181_vx_u = (0.3 * v181_v) ;
      v181_vy_u = 0 ;
      v181_vz_u = (0.7 * v181_v) ;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v181_theta_u = (v181_v / 30.0) ;
      v181_v_O_u = (131.1 + (- (80.1 * pow ( ((v181_v / 30.0)) , (0.5) )))) ;
      v181_ft_u = f (v181_theta,4.0e-2) ;
      cstate =  v181_t2 ;
      force_init_update = False;
    }

    else if ( v181_v <= (44.5)
               && v181_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v181_vx_init = v181_vx ;
      slope =  (v181_vx * -8.7) ;
      v181_vx_u = (slope * d) + v181_vx ;
      if ((pstate != cstate) || force_init_update) v181_vy_init = v181_vy ;
      slope =  (v181_vy * -190.9) ;
      v181_vy_u = (slope * d) + v181_vy ;
      if ((pstate != cstate) || force_init_update) v181_vz_init = v181_vz ;
      slope =  (v181_vz * -190.4) ;
      v181_vz_u = (slope * d) + v181_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v181_t1 ;
      force_init_update = False;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v181_v_u = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_voo = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181!\n");
      exit(1);
    }
    break;
  case ( v181_t2 ):
    if (True == False) {;}
    else if  (v181_v >= (44.5)) {
      v181_vx_u = v181_vx ;
      v181_vy_u = v181_vy ;
      v181_vz_u = v181_vz ;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v181_t3 ;
      force_init_update = False;
    }
    else if  (v181_g <= (44.5)
               && v181_v < (44.5)) {
      v181_vx_u = v181_vx ;
      v181_vy_u = v181_vy ;
      v181_vz_u = v181_vz ;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v181_t1 ;
      force_init_update = False;
    }

    else if ( v181_v < (44.5)
               && v181_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v181_vx_init = v181_vx ;
      slope =  ((v181_vx * -23.6) + (777200.0 * v181_g)) ;
      v181_vx_u = (slope * d) + v181_vx ;
      if ((pstate != cstate) || force_init_update) v181_vy_init = v181_vy ;
      slope =  ((v181_vy * -45.5) + (58900.0 * v181_g)) ;
      v181_vy_u = (slope * d) + v181_vy ;
      if ((pstate != cstate) || force_init_update) v181_vz_init = v181_vz ;
      slope =  ((v181_vz * -12.9) + (276600.0 * v181_g)) ;
      v181_vz_u = (slope * d) + v181_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v181_t2 ;
      force_init_update = False;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v181_v_u = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_voo = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181!\n");
      exit(1);
    }
    break;
  case ( v181_t3 ):
    if (True == False) {;}
    else if  (v181_v >= (131.1)) {
      v181_vx_u = v181_vx ;
      v181_vy_u = v181_vy ;
      v181_vz_u = v181_vz ;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v181_t4 ;
      force_init_update = False;
    }

    else if ( v181_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v181_vx_init = v181_vx ;
      slope =  (v181_vx * -6.9) ;
      v181_vx_u = (slope * d) + v181_vx ;
      if ((pstate != cstate) || force_init_update) v181_vy_init = v181_vy ;
      slope =  (v181_vy * 75.9) ;
      v181_vy_u = (slope * d) + v181_vy ;
      if ((pstate != cstate) || force_init_update) v181_vz_init = v181_vz ;
      slope =  (v181_vz * 6826.5) ;
      v181_vz_u = (slope * d) + v181_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v181_t3 ;
      force_init_update = False;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v181_v_u = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_voo = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181!\n");
      exit(1);
    }
    break;
  case ( v181_t4 ):
    if (True == False) {;}
    else if  (v181_v <= (30.0)) {
      v181_vx_u = v181_vx ;
      v181_vy_u = v181_vy ;
      v181_vz_u = v181_vz ;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v181_t1 ;
      force_init_update = False;
    }

    else if ( v181_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v181_vx_init = v181_vx ;
      slope =  (v181_vx * -33.2) ;
      v181_vx_u = (slope * d) + v181_vx ;
      if ((pstate != cstate) || force_init_update) v181_vy_init = v181_vy ;
      slope =  ((v181_vy * 20.0) * v181_ft) ;
      v181_vy_u = (slope * d) + v181_vy ;
      if ((pstate != cstate) || force_init_update) v181_vz_init = v181_vz ;
      slope =  ((v181_vz * 2.0) * v181_ft) ;
      v181_vz_u = (slope * d) + v181_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v181_t4 ;
      force_init_update = False;
      v181_g_u = ((((((((((((v181_v_i_0 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v181_v_i_1 + (- ((v181_vx + (- v181_vy)) + v181_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v181_v_u = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_voo = ((v181_vx + (- v181_vy)) + v181_vz) ;
      v181_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181!\n");
      exit(1);
    }
    break;
  }
  v181_vx = v181_vx_u;
  v181_vy = v181_vy_u;
  v181_vz = v181_vz_u;
  v181_g = v181_g_u;
  v181_v = v181_v_u;
  v181_ft = v181_ft_u;
  v181_theta = v181_theta_u;
  v181_v_O = v181_v_O_u;
  return cstate;
}