#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v156_v157_update_c1vd();
extern double v156_v157_update_c2vd();
extern double v156_v157_update_c1md();
extern double v156_v157_update_c2md();
extern double v156_v157_update_buffer_index(double,double,double,double);
extern double v156_v157_update_latch1(double,double);
extern double v156_v157_update_latch2(double,double);
extern double v156_v157_update_ocell1(double,double);
extern double v156_v157_update_ocell2(double,double);
double v156_v157_cell1_v;
double v156_v157_cell1_mode;
double v156_v157_cell2_v;
double v156_v157_cell2_mode;
double v156_v157_cell1_v_replay = 0.0;
double v156_v157_cell2_v_replay = 0.0;


static double  v156_v157_k  =  0.0 ,  v156_v157_cell1_mode_delayed  =  0.0 ,  v156_v157_cell2_mode_delayed  =  0.0 ,  v156_v157_from_cell  =  0.0 ,  v156_v157_cell1_replay_latch  =  0.0 ,  v156_v157_cell2_replay_latch  =  0.0 ,  v156_v157_cell1_v_delayed  =  0.0 ,  v156_v157_cell2_v_delayed  =  0.0 ,  v156_v157_wasted  =  0.0 ; //the continuous vars
static double  v156_v157_k_u , v156_v157_cell1_mode_delayed_u , v156_v157_cell2_mode_delayed_u , v156_v157_from_cell_u , v156_v157_cell1_replay_latch_u , v156_v157_cell2_replay_latch_u , v156_v157_cell1_v_delayed_u , v156_v157_cell2_v_delayed_u , v156_v157_wasted_u ; // and their updates
static double  v156_v157_k_init , v156_v157_cell1_mode_delayed_init , v156_v157_cell2_mode_delayed_init , v156_v157_from_cell_init , v156_v157_cell1_replay_latch_init , v156_v157_cell2_replay_latch_init , v156_v157_cell1_v_delayed_init , v156_v157_cell2_v_delayed_init , v156_v157_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v156_v157_idle , v156_v157_annhilate , v156_v157_previous_drection1 , v156_v157_previous_direction2 , v156_v157_wait_cell1 , v156_v157_replay_cell1 , v156_v157_replay_cell2 , v156_v157_wait_cell2 }; // state declarations

enum states v156_v157 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v156_v157_idle ):
    if (True == False) {;}
    else if  (v156_v157_cell2_mode == (2.0) && (v156_v157_cell1_mode != (2.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v156_v157_cell1_mode == (2.0) && (v156_v157_cell2_mode != (2.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v156_v157_cell1_mode == (2.0) && (v156_v157_cell2_mode == (2.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_idle ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_annhilate ):
    if (True == False) {;}
    else if  (v156_v157_cell1_mode != (2.0) && (v156_v157_cell2_mode != (2.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_from_cell_u = 0 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_previous_drection1 ):
    if (True == False) {;}
    else if  (v156_v157_from_cell == (1.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (0.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (2.0) && (v156_v157_cell2_mode_delayed == (0.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (2.0) && (v156_v157_cell2_mode_delayed != (0.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_previous_drection1 ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_previous_direction2 ):
    if (True == False) {;}
    else if  (v156_v157_from_cell == (1.0) && (v156_v157_cell1_mode_delayed != (0.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (2.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (0.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v156_v157_from_cell == (1.0) && (v156_v157_cell1_mode_delayed == (0.0))) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_previous_direction2 ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_wait_cell1 ):
    if (True == False) {;}
    else if  (v156_v157_cell2_mode == (2.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
    }
    else if  (v156_v157_k >= (44.8904404214)) {
      v156_v157_from_cell_u = 1 ;
      v156_v157_cell1_replay_latch_u = 1 ;
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_wait_cell1 ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_replay_cell1 ):
    if (True == False) {;}
    else if  (v156_v157_cell1_mode == (2.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_annhilate ;
      force_init_update = False;
    }
    else if  (v156_v157_k >= (44.8904404214)) {
      v156_v157_from_cell_u = 2 ;
      v156_v157_cell2_replay_latch_u = 1 ;
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_replay_cell1 ;
      force_init_update = False;
      v156_v157_cell1_replay_latch_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_replay_cell2 ):
    if (True == False) {;}
    else if  (v156_v157_k >= (10.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_replay_cell2 ;
      force_init_update = False;
      v156_v157_cell2_replay_latch_u = 1 ;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  case ( v156_v157_wait_cell2 ):
    if (True == False) {;}
    else if  (v156_v157_k >= (10.0)) {
      v156_v157_k_u = 1 ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
      cstate =  v156_v157_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v156_v157_k_init = v156_v157_k ;
      slope =  1 ;
      v156_v157_k_u = (slope * d) + v156_v157_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v156_v157_wait_cell2 ;
      force_init_update = False;
      v156_v157_cell1_v_delayed_u = v156_v157_update_c1vd () ;
      v156_v157_cell2_v_delayed_u = v156_v157_update_c2vd () ;
      v156_v157_cell1_mode_delayed_u = v156_v157_update_c1md () ;
      v156_v157_cell2_mode_delayed_u = v156_v157_update_c2md () ;
      v156_v157_wasted_u = v156_v157_update_buffer_index (v156_v157_cell1_v,v156_v157_cell2_v,v156_v157_cell1_mode,v156_v157_cell2_mode) ;
      v156_v157_cell1_replay_latch_u = v156_v157_update_latch1 (v156_v157_cell1_mode_delayed,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_replay_latch_u = v156_v157_update_latch2 (v156_v157_cell2_mode_delayed,v156_v157_cell2_replay_latch_u) ;
      v156_v157_cell1_v_replay = v156_v157_update_ocell1 (v156_v157_cell1_v_delayed_u,v156_v157_cell1_replay_latch_u) ;
      v156_v157_cell2_v_replay = v156_v157_update_ocell2 (v156_v157_cell2_v_delayed_u,v156_v157_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v156_v157!\n");
      exit(1);
    }
    break;
  }
  v156_v157_k = v156_v157_k_u;
  v156_v157_cell1_mode_delayed = v156_v157_cell1_mode_delayed_u;
  v156_v157_cell2_mode_delayed = v156_v157_cell2_mode_delayed_u;
  v156_v157_from_cell = v156_v157_from_cell_u;
  v156_v157_cell1_replay_latch = v156_v157_cell1_replay_latch_u;
  v156_v157_cell2_replay_latch = v156_v157_cell2_replay_latch_u;
  v156_v157_cell1_v_delayed = v156_v157_cell1_v_delayed_u;
  v156_v157_cell2_v_delayed = v156_v157_cell2_v_delayed_u;
  v156_v157_wasted = v156_v157_wasted_u;
  return cstate;
}