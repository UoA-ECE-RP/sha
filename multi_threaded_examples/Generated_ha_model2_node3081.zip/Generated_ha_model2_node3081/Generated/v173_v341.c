#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v173_v341_update_c1vd();
extern double v173_v341_update_c2vd();
extern double v173_v341_update_c1md();
extern double v173_v341_update_c2md();
extern double v173_v341_update_buffer_index(double,double,double,double);
extern double v173_v341_update_latch1(double,double);
extern double v173_v341_update_latch2(double,double);
extern double v173_v341_update_ocell1(double,double);
extern double v173_v341_update_ocell2(double,double);
double v173_v341_cell1_v;
double v173_v341_cell1_mode;
double v173_v341_cell2_v;
double v173_v341_cell2_mode;
double v173_v341_cell1_v_replay = 0.0;
double v173_v341_cell2_v_replay = 0.0;


static double  v173_v341_k  =  0.0 ,  v173_v341_cell1_mode_delayed  =  0.0 ,  v173_v341_cell2_mode_delayed  =  0.0 ,  v173_v341_from_cell  =  0.0 ,  v173_v341_cell1_replay_latch  =  0.0 ,  v173_v341_cell2_replay_latch  =  0.0 ,  v173_v341_cell1_v_delayed  =  0.0 ,  v173_v341_cell2_v_delayed  =  0.0 ,  v173_v341_wasted  =  0.0 ; //the continuous vars
static double  v173_v341_k_u , v173_v341_cell1_mode_delayed_u , v173_v341_cell2_mode_delayed_u , v173_v341_from_cell_u , v173_v341_cell1_replay_latch_u , v173_v341_cell2_replay_latch_u , v173_v341_cell1_v_delayed_u , v173_v341_cell2_v_delayed_u , v173_v341_wasted_u ; // and their updates
static double  v173_v341_k_init , v173_v341_cell1_mode_delayed_init , v173_v341_cell2_mode_delayed_init , v173_v341_from_cell_init , v173_v341_cell1_replay_latch_init , v173_v341_cell2_replay_latch_init , v173_v341_cell1_v_delayed_init , v173_v341_cell2_v_delayed_init , v173_v341_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v173_v341_idle , v173_v341_annhilate , v173_v341_previous_drection1 , v173_v341_previous_direction2 , v173_v341_wait_cell1 , v173_v341_replay_cell1 , v173_v341_replay_cell2 , v173_v341_wait_cell2 }; // state declarations

enum states v173_v341 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v173_v341_idle ):
    if (True == False) {;}
    else if  (v173_v341_cell2_mode == (2.0) && (v173_v341_cell1_mode != (2.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v173_v341_cell1_mode == (2.0) && (v173_v341_cell2_mode != (2.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v173_v341_cell1_mode == (2.0) && (v173_v341_cell2_mode == (2.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_idle ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_annhilate ):
    if (True == False) {;}
    else if  (v173_v341_cell1_mode != (2.0) && (v173_v341_cell2_mode != (2.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_from_cell_u = 0 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_previous_drection1 ):
    if (True == False) {;}
    else if  (v173_v341_from_cell == (1.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (0.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (2.0) && (v173_v341_cell2_mode_delayed == (0.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (2.0) && (v173_v341_cell2_mode_delayed != (0.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_previous_drection1 ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_previous_direction2 ):
    if (True == False) {;}
    else if  (v173_v341_from_cell == (1.0) && (v173_v341_cell1_mode_delayed != (0.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (2.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (0.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v173_v341_from_cell == (1.0) && (v173_v341_cell1_mode_delayed == (0.0))) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_previous_direction2 ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_wait_cell1 ):
    if (True == False) {;}
    else if  (v173_v341_cell2_mode == (2.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
    }
    else if  (v173_v341_k >= (118.232724412)) {
      v173_v341_from_cell_u = 1 ;
      v173_v341_cell1_replay_latch_u = 1 ;
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_wait_cell1 ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_replay_cell1 ):
    if (True == False) {;}
    else if  (v173_v341_cell1_mode == (2.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_annhilate ;
      force_init_update = False;
    }
    else if  (v173_v341_k >= (118.232724412)) {
      v173_v341_from_cell_u = 2 ;
      v173_v341_cell2_replay_latch_u = 1 ;
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_replay_cell1 ;
      force_init_update = False;
      v173_v341_cell1_replay_latch_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_replay_cell2 ):
    if (True == False) {;}
    else if  (v173_v341_k >= (10.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_replay_cell2 ;
      force_init_update = False;
      v173_v341_cell2_replay_latch_u = 1 ;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  case ( v173_v341_wait_cell2 ):
    if (True == False) {;}
    else if  (v173_v341_k >= (10.0)) {
      v173_v341_k_u = 1 ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
      cstate =  v173_v341_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v173_v341_k_init = v173_v341_k ;
      slope =  1 ;
      v173_v341_k_u = (slope * d) + v173_v341_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v173_v341_wait_cell2 ;
      force_init_update = False;
      v173_v341_cell1_v_delayed_u = v173_v341_update_c1vd () ;
      v173_v341_cell2_v_delayed_u = v173_v341_update_c2vd () ;
      v173_v341_cell1_mode_delayed_u = v173_v341_update_c1md () ;
      v173_v341_cell2_mode_delayed_u = v173_v341_update_c2md () ;
      v173_v341_wasted_u = v173_v341_update_buffer_index (v173_v341_cell1_v,v173_v341_cell2_v,v173_v341_cell1_mode,v173_v341_cell2_mode) ;
      v173_v341_cell1_replay_latch_u = v173_v341_update_latch1 (v173_v341_cell1_mode_delayed,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_replay_latch_u = v173_v341_update_latch2 (v173_v341_cell2_mode_delayed,v173_v341_cell2_replay_latch_u) ;
      v173_v341_cell1_v_replay = v173_v341_update_ocell1 (v173_v341_cell1_v_delayed_u,v173_v341_cell1_replay_latch_u) ;
      v173_v341_cell2_v_replay = v173_v341_update_ocell2 (v173_v341_cell2_v_delayed_u,v173_v341_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v173_v341!\n");
      exit(1);
    }
    break;
  }
  v173_v341_k = v173_v341_k_u;
  v173_v341_cell1_mode_delayed = v173_v341_cell1_mode_delayed_u;
  v173_v341_cell2_mode_delayed = v173_v341_cell2_mode_delayed_u;
  v173_v341_from_cell = v173_v341_from_cell_u;
  v173_v341_cell1_replay_latch = v173_v341_cell1_replay_latch_u;
  v173_v341_cell2_replay_latch = v173_v341_cell2_replay_latch_u;
  v173_v341_cell1_v_delayed = v173_v341_cell1_v_delayed_u;
  v173_v341_cell2_v_delayed = v173_v341_cell2_v_delayed_u;
  v173_v341_wasted = v173_v341_wasted_u;
  return cstate;
}