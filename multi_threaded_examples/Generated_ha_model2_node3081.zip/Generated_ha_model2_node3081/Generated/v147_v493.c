#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v147_v493_update_c1vd();
extern double v147_v493_update_c2vd();
extern double v147_v493_update_c1md();
extern double v147_v493_update_c2md();
extern double v147_v493_update_buffer_index(double,double,double,double);
extern double v147_v493_update_latch1(double,double);
extern double v147_v493_update_latch2(double,double);
extern double v147_v493_update_ocell1(double,double);
extern double v147_v493_update_ocell2(double,double);
double v147_v493_cell1_v;
double v147_v493_cell1_mode;
double v147_v493_cell2_v;
double v147_v493_cell2_mode;
double v147_v493_cell1_v_replay = 0.0;
double v147_v493_cell2_v_replay = 0.0;


static double  v147_v493_k  =  0.0 ,  v147_v493_cell1_mode_delayed  =  0.0 ,  v147_v493_cell2_mode_delayed  =  0.0 ,  v147_v493_from_cell  =  0.0 ,  v147_v493_cell1_replay_latch  =  0.0 ,  v147_v493_cell2_replay_latch  =  0.0 ,  v147_v493_cell1_v_delayed  =  0.0 ,  v147_v493_cell2_v_delayed  =  0.0 ,  v147_v493_wasted  =  0.0 ; //the continuous vars
static double  v147_v493_k_u , v147_v493_cell1_mode_delayed_u , v147_v493_cell2_mode_delayed_u , v147_v493_from_cell_u , v147_v493_cell1_replay_latch_u , v147_v493_cell2_replay_latch_u , v147_v493_cell1_v_delayed_u , v147_v493_cell2_v_delayed_u , v147_v493_wasted_u ; // and their updates
static double  v147_v493_k_init , v147_v493_cell1_mode_delayed_init , v147_v493_cell2_mode_delayed_init , v147_v493_from_cell_init , v147_v493_cell1_replay_latch_init , v147_v493_cell2_replay_latch_init , v147_v493_cell1_v_delayed_init , v147_v493_cell2_v_delayed_init , v147_v493_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v147_v493_idle , v147_v493_annhilate , v147_v493_previous_drection1 , v147_v493_previous_direction2 , v147_v493_wait_cell1 , v147_v493_replay_cell1 , v147_v493_replay_cell2 , v147_v493_wait_cell2 }; // state declarations

enum states v147_v493 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v147_v493_idle ):
    if (True == False) {;}
    else if  (v147_v493_cell2_mode == (2.0) && (v147_v493_cell1_mode != (2.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v147_v493_cell1_mode == (2.0) && (v147_v493_cell2_mode != (2.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v147_v493_cell1_mode == (2.0) && (v147_v493_cell2_mode == (2.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_idle ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_annhilate ):
    if (True == False) {;}
    else if  (v147_v493_cell1_mode != (2.0) && (v147_v493_cell2_mode != (2.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_from_cell_u = 0 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_previous_drection1 ):
    if (True == False) {;}
    else if  (v147_v493_from_cell == (1.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (0.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (2.0) && (v147_v493_cell2_mode_delayed == (0.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (2.0) && (v147_v493_cell2_mode_delayed != (0.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_previous_drection1 ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_previous_direction2 ):
    if (True == False) {;}
    else if  (v147_v493_from_cell == (1.0) && (v147_v493_cell1_mode_delayed != (0.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (2.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (0.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v147_v493_from_cell == (1.0) && (v147_v493_cell1_mode_delayed == (0.0))) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_previous_direction2 ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_wait_cell1 ):
    if (True == False) {;}
    else if  (v147_v493_cell2_mode == (2.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
    }
    else if  (v147_v493_k >= (78.6309776833)) {
      v147_v493_from_cell_u = 1 ;
      v147_v493_cell1_replay_latch_u = 1 ;
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_wait_cell1 ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_replay_cell1 ):
    if (True == False) {;}
    else if  (v147_v493_cell1_mode == (2.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_annhilate ;
      force_init_update = False;
    }
    else if  (v147_v493_k >= (78.6309776833)) {
      v147_v493_from_cell_u = 2 ;
      v147_v493_cell2_replay_latch_u = 1 ;
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_replay_cell1 ;
      force_init_update = False;
      v147_v493_cell1_replay_latch_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_replay_cell2 ):
    if (True == False) {;}
    else if  (v147_v493_k >= (10.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_replay_cell2 ;
      force_init_update = False;
      v147_v493_cell2_replay_latch_u = 1 ;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  case ( v147_v493_wait_cell2 ):
    if (True == False) {;}
    else if  (v147_v493_k >= (10.0)) {
      v147_v493_k_u = 1 ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
      cstate =  v147_v493_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v147_v493_k_init = v147_v493_k ;
      slope =  1 ;
      v147_v493_k_u = (slope * d) + v147_v493_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v147_v493_wait_cell2 ;
      force_init_update = False;
      v147_v493_cell1_v_delayed_u = v147_v493_update_c1vd () ;
      v147_v493_cell2_v_delayed_u = v147_v493_update_c2vd () ;
      v147_v493_cell1_mode_delayed_u = v147_v493_update_c1md () ;
      v147_v493_cell2_mode_delayed_u = v147_v493_update_c2md () ;
      v147_v493_wasted_u = v147_v493_update_buffer_index (v147_v493_cell1_v,v147_v493_cell2_v,v147_v493_cell1_mode,v147_v493_cell2_mode) ;
      v147_v493_cell1_replay_latch_u = v147_v493_update_latch1 (v147_v493_cell1_mode_delayed,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_replay_latch_u = v147_v493_update_latch2 (v147_v493_cell2_mode_delayed,v147_v493_cell2_replay_latch_u) ;
      v147_v493_cell1_v_replay = v147_v493_update_ocell1 (v147_v493_cell1_v_delayed_u,v147_v493_cell1_replay_latch_u) ;
      v147_v493_cell2_v_replay = v147_v493_update_ocell2 (v147_v493_cell2_v_delayed_u,v147_v493_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147_v493!\n");
      exit(1);
    }
    break;
  }
  v147_v493_k = v147_v493_k_u;
  v147_v493_cell1_mode_delayed = v147_v493_cell1_mode_delayed_u;
  v147_v493_cell2_mode_delayed = v147_v493_cell2_mode_delayed_u;
  v147_v493_from_cell = v147_v493_from_cell_u;
  v147_v493_cell1_replay_latch = v147_v493_cell1_replay_latch_u;
  v147_v493_cell2_replay_latch = v147_v493_cell2_replay_latch_u;
  v147_v493_cell1_v_delayed = v147_v493_cell1_v_delayed_u;
  v147_v493_cell2_v_delayed = v147_v493_cell2_v_delayed_u;
  v147_v493_wasted = v147_v493_wasted_u;
  return cstate;
}