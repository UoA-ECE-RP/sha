#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v112_v111_update_c1vd();
extern double v112_v111_update_c2vd();
extern double v112_v111_update_c1md();
extern double v112_v111_update_c2md();
extern double v112_v111_update_buffer_index(double,double,double,double);
extern double v112_v111_update_latch1(double,double);
extern double v112_v111_update_latch2(double,double);
extern double v112_v111_update_ocell1(double,double);
extern double v112_v111_update_ocell2(double,double);
double v112_v111_cell1_v;
double v112_v111_cell1_mode;
double v112_v111_cell2_v;
double v112_v111_cell2_mode;
double v112_v111_cell1_v_replay = 0.0;
double v112_v111_cell2_v_replay = 0.0;


static double  v112_v111_k  =  0.0 ,  v112_v111_cell1_mode_delayed  =  0.0 ,  v112_v111_cell2_mode_delayed  =  0.0 ,  v112_v111_from_cell  =  0.0 ,  v112_v111_cell1_replay_latch  =  0.0 ,  v112_v111_cell2_replay_latch  =  0.0 ,  v112_v111_cell1_v_delayed  =  0.0 ,  v112_v111_cell2_v_delayed  =  0.0 ,  v112_v111_wasted  =  0.0 ; //the continuous vars
static double  v112_v111_k_u , v112_v111_cell1_mode_delayed_u , v112_v111_cell2_mode_delayed_u , v112_v111_from_cell_u , v112_v111_cell1_replay_latch_u , v112_v111_cell2_replay_latch_u , v112_v111_cell1_v_delayed_u , v112_v111_cell2_v_delayed_u , v112_v111_wasted_u ; // and their updates
static double  v112_v111_k_init , v112_v111_cell1_mode_delayed_init , v112_v111_cell2_mode_delayed_init , v112_v111_from_cell_init , v112_v111_cell1_replay_latch_init , v112_v111_cell2_replay_latch_init , v112_v111_cell1_v_delayed_init , v112_v111_cell2_v_delayed_init , v112_v111_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v112_v111_idle , v112_v111_annhilate , v112_v111_previous_drection1 , v112_v111_previous_direction2 , v112_v111_wait_cell1 , v112_v111_replay_cell1 , v112_v111_replay_cell2 , v112_v111_wait_cell2 }; // state declarations

enum states v112_v111 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v112_v111_idle ):
    if (True == False) {;}
    else if  (v112_v111_cell2_mode == (2.0) && (v112_v111_cell1_mode != (2.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v112_v111_cell1_mode == (2.0) && (v112_v111_cell2_mode != (2.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v112_v111_cell1_mode == (2.0) && (v112_v111_cell2_mode == (2.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_idle ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_annhilate ):
    if (True == False) {;}
    else if  (v112_v111_cell1_mode != (2.0) && (v112_v111_cell2_mode != (2.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_from_cell_u = 0 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_previous_drection1 ):
    if (True == False) {;}
    else if  (v112_v111_from_cell == (1.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (0.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (2.0) && (v112_v111_cell2_mode_delayed == (0.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (2.0) && (v112_v111_cell2_mode_delayed != (0.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_previous_drection1 ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_previous_direction2 ):
    if (True == False) {;}
    else if  (v112_v111_from_cell == (1.0) && (v112_v111_cell1_mode_delayed != (0.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (2.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (0.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v112_v111_from_cell == (1.0) && (v112_v111_cell1_mode_delayed == (0.0))) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_previous_direction2 ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_wait_cell1 ):
    if (True == False) {;}
    else if  (v112_v111_cell2_mode == (2.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
    }
    else if  (v112_v111_k >= (62.2801027376)) {
      v112_v111_from_cell_u = 1 ;
      v112_v111_cell1_replay_latch_u = 1 ;
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_wait_cell1 ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_replay_cell1 ):
    if (True == False) {;}
    else if  (v112_v111_cell1_mode == (2.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_annhilate ;
      force_init_update = False;
    }
    else if  (v112_v111_k >= (62.2801027376)) {
      v112_v111_from_cell_u = 2 ;
      v112_v111_cell2_replay_latch_u = 1 ;
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_replay_cell1 ;
      force_init_update = False;
      v112_v111_cell1_replay_latch_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_replay_cell2 ):
    if (True == False) {;}
    else if  (v112_v111_k >= (10.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_replay_cell2 ;
      force_init_update = False;
      v112_v111_cell2_replay_latch_u = 1 ;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  case ( v112_v111_wait_cell2 ):
    if (True == False) {;}
    else if  (v112_v111_k >= (10.0)) {
      v112_v111_k_u = 1 ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
      cstate =  v112_v111_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v112_v111_k_init = v112_v111_k ;
      slope =  1 ;
      v112_v111_k_u = (slope * d) + v112_v111_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v112_v111_wait_cell2 ;
      force_init_update = False;
      v112_v111_cell1_v_delayed_u = v112_v111_update_c1vd () ;
      v112_v111_cell2_v_delayed_u = v112_v111_update_c2vd () ;
      v112_v111_cell1_mode_delayed_u = v112_v111_update_c1md () ;
      v112_v111_cell2_mode_delayed_u = v112_v111_update_c2md () ;
      v112_v111_wasted_u = v112_v111_update_buffer_index (v112_v111_cell1_v,v112_v111_cell2_v,v112_v111_cell1_mode,v112_v111_cell2_mode) ;
      v112_v111_cell1_replay_latch_u = v112_v111_update_latch1 (v112_v111_cell1_mode_delayed,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_replay_latch_u = v112_v111_update_latch2 (v112_v111_cell2_mode_delayed,v112_v111_cell2_replay_latch_u) ;
      v112_v111_cell1_v_replay = v112_v111_update_ocell1 (v112_v111_cell1_v_delayed_u,v112_v111_cell1_replay_latch_u) ;
      v112_v111_cell2_v_replay = v112_v111_update_ocell2 (v112_v111_cell2_v_delayed_u,v112_v111_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v112_v111!\n");
      exit(1);
    }
    break;
  }
  v112_v111_k = v112_v111_k_u;
  v112_v111_cell1_mode_delayed = v112_v111_cell1_mode_delayed_u;
  v112_v111_cell2_mode_delayed = v112_v111_cell2_mode_delayed_u;
  v112_v111_from_cell = v112_v111_from_cell_u;
  v112_v111_cell1_replay_latch = v112_v111_cell1_replay_latch_u;
  v112_v111_cell2_replay_latch = v112_v111_cell2_replay_latch_u;
  v112_v111_cell1_v_delayed = v112_v111_cell1_v_delayed_u;
  v112_v111_cell2_v_delayed = v112_v111_cell2_v_delayed_u;
  v112_v111_wasted = v112_v111_wasted_u;
  return cstate;
}