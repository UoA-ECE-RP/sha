#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v147_v_i_0;
double v147_v_i_1;
double v147_v_i_2;
double v147_voo = 0.0;
double v147_state = 0.0;


static double  v147_vx  =  0 ,  v147_vy  =  0 ,  v147_vz  =  0 ,  v147_g  =  0 ,  v147_v  =  0 ,  v147_ft  =  0 ,  v147_theta  =  0 ,  v147_v_O  =  0 ; //the continuous vars
static double  v147_vx_u , v147_vy_u , v147_vz_u , v147_g_u , v147_v_u , v147_ft_u , v147_theta_u , v147_v_O_u ; // and their updates
static double  v147_vx_init , v147_vy_init , v147_vz_init , v147_g_init , v147_v_init , v147_ft_init , v147_theta_init , v147_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v147_t1 , v147_t2 , v147_t3 , v147_t4 }; // state declarations

enum states v147 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v147_t1 ):
    if (True == False) {;}
    else if  (v147_g > (44.5)) {
      v147_vx_u = (0.3 * v147_v) ;
      v147_vy_u = 0 ;
      v147_vz_u = (0.7 * v147_v) ;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v147_theta_u = (v147_v / 30.0) ;
      v147_v_O_u = (131.1 + (- (80.1 * pow ( ((v147_v / 30.0)) , (0.5) )))) ;
      v147_ft_u = f (v147_theta,4.0e-2) ;
      cstate =  v147_t2 ;
      force_init_update = False;
    }

    else if ( v147_v <= (44.5)
               && v147_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v147_vx_init = v147_vx ;
      slope =  (v147_vx * -8.7) ;
      v147_vx_u = (slope * d) + v147_vx ;
      if ((pstate != cstate) || force_init_update) v147_vy_init = v147_vy ;
      slope =  (v147_vy * -190.9) ;
      v147_vy_u = (slope * d) + v147_vy ;
      if ((pstate != cstate) || force_init_update) v147_vz_init = v147_vz ;
      slope =  (v147_vz * -190.4) ;
      v147_vz_u = (slope * d) + v147_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v147_t1 ;
      force_init_update = False;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v147_v_u = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_voo = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147!\n");
      exit(1);
    }
    break;
  case ( v147_t2 ):
    if (True == False) {;}
    else if  (v147_v >= (44.5)) {
      v147_vx_u = v147_vx ;
      v147_vy_u = v147_vy ;
      v147_vz_u = v147_vz ;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v147_t3 ;
      force_init_update = False;
    }
    else if  (v147_g <= (44.5)
               && v147_v < (44.5)) {
      v147_vx_u = v147_vx ;
      v147_vy_u = v147_vy ;
      v147_vz_u = v147_vz ;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v147_t1 ;
      force_init_update = False;
    }

    else if ( v147_v < (44.5)
               && v147_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v147_vx_init = v147_vx ;
      slope =  ((v147_vx * -23.6) + (777200.0 * v147_g)) ;
      v147_vx_u = (slope * d) + v147_vx ;
      if ((pstate != cstate) || force_init_update) v147_vy_init = v147_vy ;
      slope =  ((v147_vy * -45.5) + (58900.0 * v147_g)) ;
      v147_vy_u = (slope * d) + v147_vy ;
      if ((pstate != cstate) || force_init_update) v147_vz_init = v147_vz ;
      slope =  ((v147_vz * -12.9) + (276600.0 * v147_g)) ;
      v147_vz_u = (slope * d) + v147_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v147_t2 ;
      force_init_update = False;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v147_v_u = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_voo = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147!\n");
      exit(1);
    }
    break;
  case ( v147_t3 ):
    if (True == False) {;}
    else if  (v147_v >= (131.1)) {
      v147_vx_u = v147_vx ;
      v147_vy_u = v147_vy ;
      v147_vz_u = v147_vz ;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v147_t4 ;
      force_init_update = False;
    }

    else if ( v147_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v147_vx_init = v147_vx ;
      slope =  (v147_vx * -6.9) ;
      v147_vx_u = (slope * d) + v147_vx ;
      if ((pstate != cstate) || force_init_update) v147_vy_init = v147_vy ;
      slope =  (v147_vy * 75.9) ;
      v147_vy_u = (slope * d) + v147_vy ;
      if ((pstate != cstate) || force_init_update) v147_vz_init = v147_vz ;
      slope =  (v147_vz * 6826.5) ;
      v147_vz_u = (slope * d) + v147_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v147_t3 ;
      force_init_update = False;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v147_v_u = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_voo = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147!\n");
      exit(1);
    }
    break;
  case ( v147_t4 ):
    if (True == False) {;}
    else if  (v147_v <= (30.0)) {
      v147_vx_u = v147_vx ;
      v147_vy_u = v147_vy ;
      v147_vz_u = v147_vz ;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v147_t1 ;
      force_init_update = False;
    }

    else if ( v147_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v147_vx_init = v147_vx ;
      slope =  (v147_vx * -33.2) ;
      v147_vx_u = (slope * d) + v147_vx ;
      if ((pstate != cstate) || force_init_update) v147_vy_init = v147_vy ;
      slope =  ((v147_vy * 20.0) * v147_ft) ;
      v147_vy_u = (slope * d) + v147_vy ;
      if ((pstate != cstate) || force_init_update) v147_vz_init = v147_vz ;
      slope =  ((v147_vz * 2.0) * v147_ft) ;
      v147_vz_u = (slope * d) + v147_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v147_t4 ;
      force_init_update = False;
      v147_g_u = ((((((((((((v147_v_i_0 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v147_v_i_1 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v147_v_i_2 + (- ((v147_vx + (- v147_vy)) + v147_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.06396955376))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v147_v_u = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_voo = ((v147_vx + (- v147_vy)) + v147_vz) ;
      v147_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v147!\n");
      exit(1);
    }
    break;
  }
  v147_vx = v147_vx_u;
  v147_vy = v147_vy_u;
  v147_vz = v147_vz_u;
  v147_g = v147_g_u;
  v147_v = v147_v_u;
  v147_ft = v147_ft_u;
  v147_theta = v147_theta_u;
  v147_v_O = v147_v_O_u;
  return cstate;
}