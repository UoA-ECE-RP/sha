#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v127_v_i_0;
double v127_v_i_1;
double v127_v_i_2;
double v127_v_i_3;
double v127_voo = 0.0;
double v127_state = 0.0;


static double  v127_vx  =  0 ,  v127_vy  =  0 ,  v127_vz  =  0 ,  v127_g  =  0 ,  v127_v  =  0 ,  v127_ft  =  0 ,  v127_theta  =  0 ,  v127_v_O  =  0 ; //the continuous vars
static double  v127_vx_u , v127_vy_u , v127_vz_u , v127_g_u , v127_v_u , v127_ft_u , v127_theta_u , v127_v_O_u ; // and their updates
static double  v127_vx_init , v127_vy_init , v127_vz_init , v127_g_init , v127_v_init , v127_ft_init , v127_theta_init , v127_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v127_t1 , v127_t2 , v127_t3 , v127_t4 }; // state declarations

enum states v127 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v127_t1 ):
    if (True == False) {;}
    else if  (v127_g > (44.5)) {
      v127_vx_u = (0.3 * v127_v) ;
      v127_vy_u = 0 ;
      v127_vz_u = (0.7 * v127_v) ;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      v127_theta_u = (v127_v / 30.0) ;
      v127_v_O_u = (131.1 + (- (80.1 * pow ( ((v127_v / 30.0)) , (0.5) )))) ;
      v127_ft_u = f (v127_theta,4.0e-2) ;
      cstate =  v127_t2 ;
      force_init_update = False;
    }

    else if ( v127_v <= (44.5)
               && v127_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v127_vx_init = v127_vx ;
      slope =  (v127_vx * -8.7) ;
      v127_vx_u = (slope * d) + v127_vx ;
      if ((pstate != cstate) || force_init_update) v127_vy_init = v127_vy ;
      slope =  (v127_vy * -190.9) ;
      v127_vy_u = (slope * d) + v127_vy ;
      if ((pstate != cstate) || force_init_update) v127_vz_init = v127_vz ;
      slope =  (v127_vz * -190.4) ;
      v127_vz_u = (slope * d) + v127_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v127_t1 ;
      force_init_update = False;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      v127_v_u = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_voo = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127!\n");
      exit(1);
    }
    break;
  case ( v127_t2 ):
    if (True == False) {;}
    else if  (v127_v >= (44.5)) {
      v127_vx_u = v127_vx ;
      v127_vy_u = v127_vy ;
      v127_vz_u = v127_vz ;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v127_t3 ;
      force_init_update = False;
    }
    else if  (v127_g <= (44.5)
               && v127_v < (44.5)) {
      v127_vx_u = v127_vx ;
      v127_vy_u = v127_vy ;
      v127_vz_u = v127_vz ;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v127_t1 ;
      force_init_update = False;
    }

    else if ( v127_v < (44.5)
               && v127_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v127_vx_init = v127_vx ;
      slope =  ((v127_vx * -23.6) + (777200.0 * v127_g)) ;
      v127_vx_u = (slope * d) + v127_vx ;
      if ((pstate != cstate) || force_init_update) v127_vy_init = v127_vy ;
      slope =  ((v127_vy * -45.5) + (58900.0 * v127_g)) ;
      v127_vy_u = (slope * d) + v127_vy ;
      if ((pstate != cstate) || force_init_update) v127_vz_init = v127_vz ;
      slope =  ((v127_vz * -12.9) + (276600.0 * v127_g)) ;
      v127_vz_u = (slope * d) + v127_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v127_t2 ;
      force_init_update = False;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      v127_v_u = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_voo = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127!\n");
      exit(1);
    }
    break;
  case ( v127_t3 ):
    if (True == False) {;}
    else if  (v127_v >= (131.1)) {
      v127_vx_u = v127_vx ;
      v127_vy_u = v127_vy ;
      v127_vz_u = v127_vz ;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v127_t4 ;
      force_init_update = False;
    }

    else if ( v127_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v127_vx_init = v127_vx ;
      slope =  (v127_vx * -6.9) ;
      v127_vx_u = (slope * d) + v127_vx ;
      if ((pstate != cstate) || force_init_update) v127_vy_init = v127_vy ;
      slope =  (v127_vy * 75.9) ;
      v127_vy_u = (slope * d) + v127_vy ;
      if ((pstate != cstate) || force_init_update) v127_vz_init = v127_vz ;
      slope =  (v127_vz * 6826.5) ;
      v127_vz_u = (slope * d) + v127_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v127_t3 ;
      force_init_update = False;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      v127_v_u = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_voo = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127!\n");
      exit(1);
    }
    break;
  case ( v127_t4 ):
    if (True == False) {;}
    else if  (v127_v <= (30.0)) {
      v127_vx_u = v127_vx ;
      v127_vy_u = v127_vy ;
      v127_vz_u = v127_vz ;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v127_t1 ;
      force_init_update = False;
    }

    else if ( v127_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v127_vx_init = v127_vx ;
      slope =  (v127_vx * -33.2) ;
      v127_vx_u = (slope * d) + v127_vx ;
      if ((pstate != cstate) || force_init_update) v127_vy_init = v127_vy ;
      slope =  ((v127_vy * 20.0) * v127_ft) ;
      v127_vy_u = (slope * d) + v127_vy ;
      if ((pstate != cstate) || force_init_update) v127_vz_init = v127_vz ;
      slope =  ((v127_vz * 2.0) * v127_ft) ;
      v127_vz_u = (slope * d) + v127_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v127_t4 ;
      force_init_update = False;
      v127_g_u = ((((((((((((v127_v_i_0 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.171037419)) + ((((v127_v_i_1 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000631242))) + ((((v127_v_i_2 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.93618207881))) + ((((v127_v_i_3 + (- ((v127_vx + (- v127_vy)) + v127_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.11627172427))) + 0) + 0) + 0) + 0) + 0) ;
      v127_v_u = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_voo = ((v127_vx + (- v127_vy)) + v127_vz) ;
      v127_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127!\n");
      exit(1);
    }
    break;
  }
  v127_vx = v127_vx_u;
  v127_vy = v127_vy_u;
  v127_vz = v127_vz_u;
  v127_g = v127_g_u;
  v127_v = v127_v_u;
  v127_ft = v127_ft_u;
  v127_theta = v127_theta_u;
  v127_v_O = v127_v_O_u;
  return cstate;
}