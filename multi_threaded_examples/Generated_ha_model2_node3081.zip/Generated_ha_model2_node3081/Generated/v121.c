#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v121_v_i_0;
double v121_v_i_1;
double v121_v_i_2;
double v121_v_i_3;
double v121_voo = 0.0;
double v121_state = 0.0;


static double  v121_vx  =  0 ,  v121_vy  =  0 ,  v121_vz  =  0 ,  v121_g  =  0 ,  v121_v  =  0 ,  v121_ft  =  0 ,  v121_theta  =  0 ,  v121_v_O  =  0 ; //the continuous vars
static double  v121_vx_u , v121_vy_u , v121_vz_u , v121_g_u , v121_v_u , v121_ft_u , v121_theta_u , v121_v_O_u ; // and their updates
static double  v121_vx_init , v121_vy_init , v121_vz_init , v121_g_init , v121_v_init , v121_ft_init , v121_theta_init , v121_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v121_t1 , v121_t2 , v121_t3 , v121_t4 }; // state declarations

enum states v121 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v121_t1 ):
    if (True == False) {;}
    else if  (v121_g > (44.5)) {
      v121_vx_u = (0.3 * v121_v) ;
      v121_vy_u = 0 ;
      v121_vz_u = (0.7 * v121_v) ;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      v121_theta_u = (v121_v / 30.0) ;
      v121_v_O_u = (131.1 + (- (80.1 * pow ( ((v121_v / 30.0)) , (0.5) )))) ;
      v121_ft_u = f (v121_theta,4.0e-2) ;
      cstate =  v121_t2 ;
      force_init_update = False;
    }

    else if ( v121_v <= (44.5)
               && v121_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v121_vx_init = v121_vx ;
      slope =  (v121_vx * -8.7) ;
      v121_vx_u = (slope * d) + v121_vx ;
      if ((pstate != cstate) || force_init_update) v121_vy_init = v121_vy ;
      slope =  (v121_vy * -190.9) ;
      v121_vy_u = (slope * d) + v121_vy ;
      if ((pstate != cstate) || force_init_update) v121_vz_init = v121_vz ;
      slope =  (v121_vz * -190.4) ;
      v121_vz_u = (slope * d) + v121_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v121_t1 ;
      force_init_update = False;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      v121_v_u = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_voo = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v121!\n");
      exit(1);
    }
    break;
  case ( v121_t2 ):
    if (True == False) {;}
    else if  (v121_v >= (44.5)) {
      v121_vx_u = v121_vx ;
      v121_vy_u = v121_vy ;
      v121_vz_u = v121_vz ;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v121_t3 ;
      force_init_update = False;
    }
    else if  (v121_g <= (44.5)
               && v121_v < (44.5)) {
      v121_vx_u = v121_vx ;
      v121_vy_u = v121_vy ;
      v121_vz_u = v121_vz ;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v121_t1 ;
      force_init_update = False;
    }

    else if ( v121_v < (44.5)
               && v121_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v121_vx_init = v121_vx ;
      slope =  ((v121_vx * -23.6) + (777200.0 * v121_g)) ;
      v121_vx_u = (slope * d) + v121_vx ;
      if ((pstate != cstate) || force_init_update) v121_vy_init = v121_vy ;
      slope =  ((v121_vy * -45.5) + (58900.0 * v121_g)) ;
      v121_vy_u = (slope * d) + v121_vy ;
      if ((pstate != cstate) || force_init_update) v121_vz_init = v121_vz ;
      slope =  ((v121_vz * -12.9) + (276600.0 * v121_g)) ;
      v121_vz_u = (slope * d) + v121_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v121_t2 ;
      force_init_update = False;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      v121_v_u = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_voo = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v121!\n");
      exit(1);
    }
    break;
  case ( v121_t3 ):
    if (True == False) {;}
    else if  (v121_v >= (131.1)) {
      v121_vx_u = v121_vx ;
      v121_vy_u = v121_vy ;
      v121_vz_u = v121_vz ;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v121_t4 ;
      force_init_update = False;
    }

    else if ( v121_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v121_vx_init = v121_vx ;
      slope =  (v121_vx * -6.9) ;
      v121_vx_u = (slope * d) + v121_vx ;
      if ((pstate != cstate) || force_init_update) v121_vy_init = v121_vy ;
      slope =  (v121_vy * 75.9) ;
      v121_vy_u = (slope * d) + v121_vy ;
      if ((pstate != cstate) || force_init_update) v121_vz_init = v121_vz ;
      slope =  (v121_vz * 6826.5) ;
      v121_vz_u = (slope * d) + v121_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v121_t3 ;
      force_init_update = False;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      v121_v_u = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_voo = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v121!\n");
      exit(1);
    }
    break;
  case ( v121_t4 ):
    if (True == False) {;}
    else if  (v121_v <= (30.0)) {
      v121_vx_u = v121_vx ;
      v121_vy_u = v121_vy ;
      v121_vz_u = v121_vz ;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v121_t1 ;
      force_init_update = False;
    }

    else if ( v121_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v121_vx_init = v121_vx ;
      slope =  (v121_vx * -33.2) ;
      v121_vx_u = (slope * d) + v121_vx ;
      if ((pstate != cstate) || force_init_update) v121_vy_init = v121_vy ;
      slope =  ((v121_vy * 20.0) * v121_ft) ;
      v121_vy_u = (slope * d) + v121_vy ;
      if ((pstate != cstate) || force_init_update) v121_vz_init = v121_vz ;
      slope =  ((v121_vz * 2.0) * v121_ft) ;
      v121_vz_u = (slope * d) + v121_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v121_t4 ;
      force_init_update = False;
      v121_g_u = ((((((((((((v121_v_i_0 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10818703084)) + ((((v121_v_i_1 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768))) + ((((v121_v_i_2 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.34395819985))) + ((((v121_v_i_3 + (- ((v121_vx + (- v121_vy)) + v121_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21889517064))) + 0) + 0) + 0) + 0) + 0) ;
      v121_v_u = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_voo = ((v121_vx + (- v121_vy)) + v121_vz) ;
      v121_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v121!\n");
      exit(1);
    }
    break;
  }
  v121_vx = v121_vx_u;
  v121_vy = v121_vy_u;
  v121_vz = v121_vz_u;
  v121_g = v121_g_u;
  v121_v = v121_v_u;
  v121_ft = v121_ft_u;
  v121_theta = v121_theta_u;
  v121_v_O = v121_v_O_u;
  return cstate;
}