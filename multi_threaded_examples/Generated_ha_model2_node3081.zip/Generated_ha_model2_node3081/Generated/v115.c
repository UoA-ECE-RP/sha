#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v115_v_i_0;
double v115_v_i_1;
double v115_voo = 0.0;
double v115_state = 0.0;


static double  v115_vx  =  0 ,  v115_vy  =  0 ,  v115_vz  =  0 ,  v115_g  =  0 ,  v115_v  =  0 ,  v115_ft  =  0 ,  v115_theta  =  0 ,  v115_v_O  =  0 ; //the continuous vars
static double  v115_vx_u , v115_vy_u , v115_vz_u , v115_g_u , v115_v_u , v115_ft_u , v115_theta_u , v115_v_O_u ; // and their updates
static double  v115_vx_init , v115_vy_init , v115_vz_init , v115_g_init , v115_v_init , v115_ft_init , v115_theta_init , v115_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v115_t1 , v115_t2 , v115_t3 , v115_t4 }; // state declarations

enum states v115 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v115_t1 ):
    if (True == False) {;}
    else if  (v115_g > (44.5)) {
      v115_vx_u = (0.3 * v115_v) ;
      v115_vy_u = 0 ;
      v115_vz_u = (0.7 * v115_v) ;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v115_theta_u = (v115_v / 30.0) ;
      v115_v_O_u = (131.1 + (- (80.1 * pow ( ((v115_v / 30.0)) , (0.5) )))) ;
      v115_ft_u = f (v115_theta,4.0e-2) ;
      cstate =  v115_t2 ;
      force_init_update = False;
    }

    else if ( v115_v <= (44.5)
               && v115_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v115_vx_init = v115_vx ;
      slope =  (v115_vx * -8.7) ;
      v115_vx_u = (slope * d) + v115_vx ;
      if ((pstate != cstate) || force_init_update) v115_vy_init = v115_vy ;
      slope =  (v115_vy * -190.9) ;
      v115_vy_u = (slope * d) + v115_vy ;
      if ((pstate != cstate) || force_init_update) v115_vz_init = v115_vz ;
      slope =  (v115_vz * -190.4) ;
      v115_vz_u = (slope * d) + v115_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v115_t1 ;
      force_init_update = False;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v115_v_u = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_voo = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115!\n");
      exit(1);
    }
    break;
  case ( v115_t2 ):
    if (True == False) {;}
    else if  (v115_v >= (44.5)) {
      v115_vx_u = v115_vx ;
      v115_vy_u = v115_vy ;
      v115_vz_u = v115_vz ;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v115_t3 ;
      force_init_update = False;
    }
    else if  (v115_g <= (44.5)
               && v115_v < (44.5)) {
      v115_vx_u = v115_vx ;
      v115_vy_u = v115_vy ;
      v115_vz_u = v115_vz ;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v115_t1 ;
      force_init_update = False;
    }

    else if ( v115_v < (44.5)
               && v115_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v115_vx_init = v115_vx ;
      slope =  ((v115_vx * -23.6) + (777200.0 * v115_g)) ;
      v115_vx_u = (slope * d) + v115_vx ;
      if ((pstate != cstate) || force_init_update) v115_vy_init = v115_vy ;
      slope =  ((v115_vy * -45.5) + (58900.0 * v115_g)) ;
      v115_vy_u = (slope * d) + v115_vy ;
      if ((pstate != cstate) || force_init_update) v115_vz_init = v115_vz ;
      slope =  ((v115_vz * -12.9) + (276600.0 * v115_g)) ;
      v115_vz_u = (slope * d) + v115_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v115_t2 ;
      force_init_update = False;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v115_v_u = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_voo = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115!\n");
      exit(1);
    }
    break;
  case ( v115_t3 ):
    if (True == False) {;}
    else if  (v115_v >= (131.1)) {
      v115_vx_u = v115_vx ;
      v115_vy_u = v115_vy ;
      v115_vz_u = v115_vz ;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v115_t4 ;
      force_init_update = False;
    }

    else if ( v115_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v115_vx_init = v115_vx ;
      slope =  (v115_vx * -6.9) ;
      v115_vx_u = (slope * d) + v115_vx ;
      if ((pstate != cstate) || force_init_update) v115_vy_init = v115_vy ;
      slope =  (v115_vy * 75.9) ;
      v115_vy_u = (slope * d) + v115_vy ;
      if ((pstate != cstate) || force_init_update) v115_vz_init = v115_vz ;
      slope =  (v115_vz * 6826.5) ;
      v115_vz_u = (slope * d) + v115_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v115_t3 ;
      force_init_update = False;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v115_v_u = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_voo = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115!\n");
      exit(1);
    }
    break;
  case ( v115_t4 ):
    if (True == False) {;}
    else if  (v115_v <= (30.0)) {
      v115_vx_u = v115_vx ;
      v115_vy_u = v115_vy ;
      v115_vz_u = v115_vz ;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v115_t1 ;
      force_init_update = False;
    }

    else if ( v115_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v115_vx_init = v115_vx ;
      slope =  (v115_vx * -33.2) ;
      v115_vx_u = (slope * d) + v115_vx ;
      if ((pstate != cstate) || force_init_update) v115_vy_init = v115_vy ;
      slope =  ((v115_vy * 20.0) * v115_ft) ;
      v115_vy_u = (slope * d) + v115_vy ;
      if ((pstate != cstate) || force_init_update) v115_vz_init = v115_vz ;
      slope =  ((v115_vz * 2.0) * v115_ft) ;
      v115_vz_u = (slope * d) + v115_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v115_t4 ;
      force_init_update = False;
      v115_g_u = ((((((((((((v115_v_i_0 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v115_v_i_1 + (- ((v115_vx + (- v115_vy)) + v115_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152856924))) + 0) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v115_v_u = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_voo = ((v115_vx + (- v115_vy)) + v115_vz) ;
      v115_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v115!\n");
      exit(1);
    }
    break;
  }
  v115_vx = v115_vx_u;
  v115_vy = v115_vy_u;
  v115_vz = v115_vz_u;
  v115_g = v115_g_u;
  v115_v = v115_v_u;
  v115_ft = v115_ft_u;
  v115_theta = v115_theta_u;
  v115_v_O = v115_v_O_u;
  return cstate;
}