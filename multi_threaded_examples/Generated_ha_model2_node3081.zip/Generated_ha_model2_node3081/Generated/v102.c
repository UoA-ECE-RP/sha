#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v102_v_i_0;
double v102_v_i_1;
double v102_v_i_2;
double v102_v_i_3;
double v102_voo = 0.0;
double v102_state = 0.0;


static double  v102_vx  =  0 ,  v102_vy  =  0 ,  v102_vz  =  0 ,  v102_g  =  0 ,  v102_v  =  0 ,  v102_ft  =  0 ,  v102_theta  =  0 ,  v102_v_O  =  0 ; //the continuous vars
static double  v102_vx_u , v102_vy_u , v102_vz_u , v102_g_u , v102_v_u , v102_ft_u , v102_theta_u , v102_v_O_u ; // and their updates
static double  v102_vx_init , v102_vy_init , v102_vz_init , v102_g_init , v102_v_init , v102_ft_init , v102_theta_init , v102_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v102_t1 , v102_t2 , v102_t3 , v102_t4 }; // state declarations

enum states v102 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v102_t1 ):
    if (True == False) {;}
    else if  (v102_g > (44.5)) {
      v102_vx_u = (0.3 * v102_v) ;
      v102_vy_u = 0 ;
      v102_vz_u = (0.7 * v102_v) ;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      v102_theta_u = (v102_v / 30.0) ;
      v102_v_O_u = (131.1 + (- (80.1 * pow ( ((v102_v / 30.0)) , (0.5) )))) ;
      v102_ft_u = f (v102_theta,4.0e-2) ;
      cstate =  v102_t2 ;
      force_init_update = False;
    }

    else if ( v102_v <= (44.5)
               && v102_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v102_vx_init = v102_vx ;
      slope =  (v102_vx * -8.7) ;
      v102_vx_u = (slope * d) + v102_vx ;
      if ((pstate != cstate) || force_init_update) v102_vy_init = v102_vy ;
      slope =  (v102_vy * -190.9) ;
      v102_vy_u = (slope * d) + v102_vy ;
      if ((pstate != cstate) || force_init_update) v102_vz_init = v102_vz ;
      slope =  (v102_vz * -190.4) ;
      v102_vz_u = (slope * d) + v102_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v102_t1 ;
      force_init_update = False;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      v102_v_u = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_voo = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v102!\n");
      exit(1);
    }
    break;
  case ( v102_t2 ):
    if (True == False) {;}
    else if  (v102_v >= (44.5)) {
      v102_vx_u = v102_vx ;
      v102_vy_u = v102_vy ;
      v102_vz_u = v102_vz ;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v102_t3 ;
      force_init_update = False;
    }
    else if  (v102_g <= (44.5)
               && v102_v < (44.5)) {
      v102_vx_u = v102_vx ;
      v102_vy_u = v102_vy ;
      v102_vz_u = v102_vz ;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v102_t1 ;
      force_init_update = False;
    }

    else if ( v102_v < (44.5)
               && v102_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v102_vx_init = v102_vx ;
      slope =  ((v102_vx * -23.6) + (777200.0 * v102_g)) ;
      v102_vx_u = (slope * d) + v102_vx ;
      if ((pstate != cstate) || force_init_update) v102_vy_init = v102_vy ;
      slope =  ((v102_vy * -45.5) + (58900.0 * v102_g)) ;
      v102_vy_u = (slope * d) + v102_vy ;
      if ((pstate != cstate) || force_init_update) v102_vz_init = v102_vz ;
      slope =  ((v102_vz * -12.9) + (276600.0 * v102_g)) ;
      v102_vz_u = (slope * d) + v102_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v102_t2 ;
      force_init_update = False;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      v102_v_u = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_voo = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v102!\n");
      exit(1);
    }
    break;
  case ( v102_t3 ):
    if (True == False) {;}
    else if  (v102_v >= (131.1)) {
      v102_vx_u = v102_vx ;
      v102_vy_u = v102_vy ;
      v102_vz_u = v102_vz ;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v102_t4 ;
      force_init_update = False;
    }

    else if ( v102_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v102_vx_init = v102_vx ;
      slope =  (v102_vx * -6.9) ;
      v102_vx_u = (slope * d) + v102_vx ;
      if ((pstate != cstate) || force_init_update) v102_vy_init = v102_vy ;
      slope =  (v102_vy * 75.9) ;
      v102_vy_u = (slope * d) + v102_vy ;
      if ((pstate != cstate) || force_init_update) v102_vz_init = v102_vz ;
      slope =  (v102_vz * 6826.5) ;
      v102_vz_u = (slope * d) + v102_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v102_t3 ;
      force_init_update = False;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      v102_v_u = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_voo = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v102!\n");
      exit(1);
    }
    break;
  case ( v102_t4 ):
    if (True == False) {;}
    else if  (v102_v <= (30.0)) {
      v102_vx_u = v102_vx ;
      v102_vy_u = v102_vy ;
      v102_vz_u = v102_vz ;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v102_t1 ;
      force_init_update = False;
    }

    else if ( v102_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v102_vx_init = v102_vx ;
      slope =  (v102_vx * -33.2) ;
      v102_vx_u = (slope * d) + v102_vx ;
      if ((pstate != cstate) || force_init_update) v102_vy_init = v102_vy ;
      slope =  ((v102_vy * 20.0) * v102_ft) ;
      v102_vy_u = (slope * d) + v102_vy ;
      if ((pstate != cstate) || force_init_update) v102_vz_init = v102_vz ;
      slope =  ((v102_vz * 2.0) * v102_ft) ;
      v102_vz_u = (slope * d) + v102_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v102_t4 ;
      force_init_update = False;
      v102_g_u = ((((((((((((v102_v_i_0 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v102_v_i_1 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v102_v_i_2 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.17178048426))) + ((((v102_v_i_3 + (- ((v102_vx + (- v102_vy)) + v102_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.28618271575))) + 0) + 0) + 0) + 0) + 0) ;
      v102_v_u = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_voo = ((v102_vx + (- v102_vy)) + v102_vz) ;
      v102_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v102!\n");
      exit(1);
    }
    break;
  }
  v102_vx = v102_vx_u;
  v102_vy = v102_vy_u;
  v102_vz = v102_vz_u;
  v102_g = v102_g_u;
  v102_v = v102_v_u;
  v102_ft = v102_ft_u;
  v102_theta = v102_theta_u;
  v102_v_O = v102_v_O_u;
  return cstate;
}