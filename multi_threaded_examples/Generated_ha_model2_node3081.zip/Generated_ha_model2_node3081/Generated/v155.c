#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v155_v_i_0;
double v155_v_i_1;
double v155_v_i_2;
double v155_voo = 0.0;
double v155_state = 0.0;


static double  v155_vx  =  0 ,  v155_vy  =  0 ,  v155_vz  =  0 ,  v155_g  =  0 ,  v155_v  =  0 ,  v155_ft  =  0 ,  v155_theta  =  0 ,  v155_v_O  =  0 ; //the continuous vars
static double  v155_vx_u , v155_vy_u , v155_vz_u , v155_g_u , v155_v_u , v155_ft_u , v155_theta_u , v155_v_O_u ; // and their updates
static double  v155_vx_init , v155_vy_init , v155_vz_init , v155_g_init , v155_v_init , v155_ft_init , v155_theta_init , v155_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v155_t1 , v155_t2 , v155_t3 , v155_t4 }; // state declarations

enum states v155 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v155_t1 ):
    if (True == False) {;}
    else if  (v155_g > (44.5)) {
      v155_vx_u = (0.3 * v155_v) ;
      v155_vy_u = 0 ;
      v155_vz_u = (0.7 * v155_v) ;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v155_theta_u = (v155_v / 30.0) ;
      v155_v_O_u = (131.1 + (- (80.1 * pow ( ((v155_v / 30.0)) , (0.5) )))) ;
      v155_ft_u = f (v155_theta,4.0e-2) ;
      cstate =  v155_t2 ;
      force_init_update = False;
    }

    else if ( v155_v <= (44.5)
               && v155_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v155_vx_init = v155_vx ;
      slope =  (v155_vx * -8.7) ;
      v155_vx_u = (slope * d) + v155_vx ;
      if ((pstate != cstate) || force_init_update) v155_vy_init = v155_vy ;
      slope =  (v155_vy * -190.9) ;
      v155_vy_u = (slope * d) + v155_vy ;
      if ((pstate != cstate) || force_init_update) v155_vz_init = v155_vz ;
      slope =  (v155_vz * -190.4) ;
      v155_vz_u = (slope * d) + v155_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v155_t1 ;
      force_init_update = False;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v155_v_u = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_voo = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v155!\n");
      exit(1);
    }
    break;
  case ( v155_t2 ):
    if (True == False) {;}
    else if  (v155_v >= (44.5)) {
      v155_vx_u = v155_vx ;
      v155_vy_u = v155_vy ;
      v155_vz_u = v155_vz ;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v155_t3 ;
      force_init_update = False;
    }
    else if  (v155_g <= (44.5)
               && v155_v < (44.5)) {
      v155_vx_u = v155_vx ;
      v155_vy_u = v155_vy ;
      v155_vz_u = v155_vz ;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v155_t1 ;
      force_init_update = False;
    }

    else if ( v155_v < (44.5)
               && v155_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v155_vx_init = v155_vx ;
      slope =  ((v155_vx * -23.6) + (777200.0 * v155_g)) ;
      v155_vx_u = (slope * d) + v155_vx ;
      if ((pstate != cstate) || force_init_update) v155_vy_init = v155_vy ;
      slope =  ((v155_vy * -45.5) + (58900.0 * v155_g)) ;
      v155_vy_u = (slope * d) + v155_vy ;
      if ((pstate != cstate) || force_init_update) v155_vz_init = v155_vz ;
      slope =  ((v155_vz * -12.9) + (276600.0 * v155_g)) ;
      v155_vz_u = (slope * d) + v155_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v155_t2 ;
      force_init_update = False;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v155_v_u = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_voo = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v155!\n");
      exit(1);
    }
    break;
  case ( v155_t3 ):
    if (True == False) {;}
    else if  (v155_v >= (131.1)) {
      v155_vx_u = v155_vx ;
      v155_vy_u = v155_vy ;
      v155_vz_u = v155_vz ;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v155_t4 ;
      force_init_update = False;
    }

    else if ( v155_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v155_vx_init = v155_vx ;
      slope =  (v155_vx * -6.9) ;
      v155_vx_u = (slope * d) + v155_vx ;
      if ((pstate != cstate) || force_init_update) v155_vy_init = v155_vy ;
      slope =  (v155_vy * 75.9) ;
      v155_vy_u = (slope * d) + v155_vy ;
      if ((pstate != cstate) || force_init_update) v155_vz_init = v155_vz ;
      slope =  (v155_vz * 6826.5) ;
      v155_vz_u = (slope * d) + v155_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v155_t3 ;
      force_init_update = False;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v155_v_u = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_voo = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v155!\n");
      exit(1);
    }
    break;
  case ( v155_t4 ):
    if (True == False) {;}
    else if  (v155_v <= (30.0)) {
      v155_vx_u = v155_vx ;
      v155_vy_u = v155_vy ;
      v155_vz_u = v155_vz ;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v155_t1 ;
      force_init_update = False;
    }

    else if ( v155_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v155_vx_init = v155_vx ;
      slope =  (v155_vx * -33.2) ;
      v155_vx_u = (slope * d) + v155_vx ;
      if ((pstate != cstate) || force_init_update) v155_vy_init = v155_vy ;
      slope =  ((v155_vy * 20.0) * v155_ft) ;
      v155_vy_u = (slope * d) + v155_vy ;
      if ((pstate != cstate) || force_init_update) v155_vz_init = v155_vz ;
      slope =  ((v155_vz * 2.0) * v155_ft) ;
      v155_vz_u = (slope * d) + v155_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v155_t4 ;
      force_init_update = False;
      v155_g_u = ((((((((((((v155_v_i_0 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213)) + ((((v155_v_i_1 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v155_v_i_2 + (- ((v155_vx + (- v155_vy)) + v155_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.3987924809))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v155_v_u = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_voo = ((v155_vx + (- v155_vy)) + v155_vz) ;
      v155_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v155!\n");
      exit(1);
    }
    break;
  }
  v155_vx = v155_vx_u;
  v155_vy = v155_vy_u;
  v155_vz = v155_vz_u;
  v155_g = v155_g_u;
  v155_v = v155_v_u;
  v155_ft = v155_ft_u;
  v155_theta = v155_theta_u;
  v155_v_O = v155_v_O_u;
  return cstate;
}