#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v159_v_i_0;
double v159_v_i_1;
double v159_v_i_2;
double v159_v_i_3;
double v159_voo = 0.0;
double v159_state = 0.0;


static double  v159_vx  =  0 ,  v159_vy  =  0 ,  v159_vz  =  0 ,  v159_g  =  0 ,  v159_v  =  0 ,  v159_ft  =  0 ,  v159_theta  =  0 ,  v159_v_O  =  0 ; //the continuous vars
static double  v159_vx_u , v159_vy_u , v159_vz_u , v159_g_u , v159_v_u , v159_ft_u , v159_theta_u , v159_v_O_u ; // and their updates
static double  v159_vx_init , v159_vy_init , v159_vz_init , v159_g_init , v159_v_init , v159_ft_init , v159_theta_init , v159_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v159_t1 , v159_t2 , v159_t3 , v159_t4 }; // state declarations

enum states v159 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v159_t1 ):
    if (True == False) {;}
    else if  (v159_g > (44.5)) {
      v159_vx_u = (0.3 * v159_v) ;
      v159_vy_u = 0 ;
      v159_vz_u = (0.7 * v159_v) ;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      v159_theta_u = (v159_v / 30.0) ;
      v159_v_O_u = (131.1 + (- (80.1 * pow ( ((v159_v / 30.0)) , (0.5) )))) ;
      v159_ft_u = f (v159_theta,4.0e-2) ;
      cstate =  v159_t2 ;
      force_init_update = False;
    }

    else if ( v159_v <= (44.5)
               && v159_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v159_vx_init = v159_vx ;
      slope =  (v159_vx * -8.7) ;
      v159_vx_u = (slope * d) + v159_vx ;
      if ((pstate != cstate) || force_init_update) v159_vy_init = v159_vy ;
      slope =  (v159_vy * -190.9) ;
      v159_vy_u = (slope * d) + v159_vy ;
      if ((pstate != cstate) || force_init_update) v159_vz_init = v159_vz ;
      slope =  (v159_vz * -190.4) ;
      v159_vz_u = (slope * d) + v159_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v159_t1 ;
      force_init_update = False;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      v159_v_u = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_voo = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v159!\n");
      exit(1);
    }
    break;
  case ( v159_t2 ):
    if (True == False) {;}
    else if  (v159_v >= (44.5)) {
      v159_vx_u = v159_vx ;
      v159_vy_u = v159_vy ;
      v159_vz_u = v159_vz ;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v159_t3 ;
      force_init_update = False;
    }
    else if  (v159_g <= (44.5)
               && v159_v < (44.5)) {
      v159_vx_u = v159_vx ;
      v159_vy_u = v159_vy ;
      v159_vz_u = v159_vz ;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v159_t1 ;
      force_init_update = False;
    }

    else if ( v159_v < (44.5)
               && v159_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v159_vx_init = v159_vx ;
      slope =  ((v159_vx * -23.6) + (777200.0 * v159_g)) ;
      v159_vx_u = (slope * d) + v159_vx ;
      if ((pstate != cstate) || force_init_update) v159_vy_init = v159_vy ;
      slope =  ((v159_vy * -45.5) + (58900.0 * v159_g)) ;
      v159_vy_u = (slope * d) + v159_vy ;
      if ((pstate != cstate) || force_init_update) v159_vz_init = v159_vz ;
      slope =  ((v159_vz * -12.9) + (276600.0 * v159_g)) ;
      v159_vz_u = (slope * d) + v159_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v159_t2 ;
      force_init_update = False;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      v159_v_u = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_voo = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v159!\n");
      exit(1);
    }
    break;
  case ( v159_t3 ):
    if (True == False) {;}
    else if  (v159_v >= (131.1)) {
      v159_vx_u = v159_vx ;
      v159_vy_u = v159_vy ;
      v159_vz_u = v159_vz ;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v159_t4 ;
      force_init_update = False;
    }

    else if ( v159_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v159_vx_init = v159_vx ;
      slope =  (v159_vx * -6.9) ;
      v159_vx_u = (slope * d) + v159_vx ;
      if ((pstate != cstate) || force_init_update) v159_vy_init = v159_vy ;
      slope =  (v159_vy * 75.9) ;
      v159_vy_u = (slope * d) + v159_vy ;
      if ((pstate != cstate) || force_init_update) v159_vz_init = v159_vz ;
      slope =  (v159_vz * 6826.5) ;
      v159_vz_u = (slope * d) + v159_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v159_t3 ;
      force_init_update = False;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      v159_v_u = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_voo = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v159!\n");
      exit(1);
    }
    break;
  case ( v159_t4 ):
    if (True == False) {;}
    else if  (v159_v <= (30.0)) {
      v159_vx_u = v159_vx ;
      v159_vy_u = v159_vy ;
      v159_vz_u = v159_vz ;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v159_t1 ;
      force_init_update = False;
    }

    else if ( v159_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v159_vx_init = v159_vx ;
      slope =  (v159_vx * -33.2) ;
      v159_vx_u = (slope * d) + v159_vx ;
      if ((pstate != cstate) || force_init_update) v159_vy_init = v159_vy ;
      slope =  ((v159_vy * 20.0) * v159_ft) ;
      v159_vy_u = (slope * d) + v159_vy ;
      if ((pstate != cstate) || force_init_update) v159_vz_init = v159_vz ;
      slope =  ((v159_vz * 2.0) * v159_ft) ;
      v159_vz_u = (slope * d) + v159_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v159_t4 ;
      force_init_update = False;
      v159_g_u = ((((((((((((v159_v_i_0 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.07975100499)) + ((((v159_v_i_1 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.274985341922))) + ((((v159_v_i_2 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.753423484777))) + ((((v159_v_i_3 + (- ((v159_vx + (- v159_vy)) + v159_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.50713356958))) + 0) + 0) + 0) + 0) + 0) ;
      v159_v_u = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_voo = ((v159_vx + (- v159_vy)) + v159_vz) ;
      v159_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v159!\n");
      exit(1);
    }
    break;
  }
  v159_vx = v159_vx_u;
  v159_vy = v159_vy_u;
  v159_vz = v159_vz_u;
  v159_g = v159_g_u;
  v159_v = v159_v_u;
  v159_ft = v159_ft_u;
  v159_theta = v159_theta_u;
  v159_v_O = v159_v_O_u;
  return cstate;
}