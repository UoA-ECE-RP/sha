#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v149_v491_update_c1vd();
extern double v149_v491_update_c2vd();
extern double v149_v491_update_c1md();
extern double v149_v491_update_c2md();
extern double v149_v491_update_buffer_index(double,double,double,double);
extern double v149_v491_update_latch1(double,double);
extern double v149_v491_update_latch2(double,double);
extern double v149_v491_update_ocell1(double,double);
extern double v149_v491_update_ocell2(double,double);
double v149_v491_cell1_v;
double v149_v491_cell1_mode;
double v149_v491_cell2_v;
double v149_v491_cell2_mode;
double v149_v491_cell1_v_replay = 0.0;
double v149_v491_cell2_v_replay = 0.0;


static double  v149_v491_k  =  0.0 ,  v149_v491_cell1_mode_delayed  =  0.0 ,  v149_v491_cell2_mode_delayed  =  0.0 ,  v149_v491_from_cell  =  0.0 ,  v149_v491_cell1_replay_latch  =  0.0 ,  v149_v491_cell2_replay_latch  =  0.0 ,  v149_v491_cell1_v_delayed  =  0.0 ,  v149_v491_cell2_v_delayed  =  0.0 ,  v149_v491_wasted  =  0.0 ; //the continuous vars
static double  v149_v491_k_u , v149_v491_cell1_mode_delayed_u , v149_v491_cell2_mode_delayed_u , v149_v491_from_cell_u , v149_v491_cell1_replay_latch_u , v149_v491_cell2_replay_latch_u , v149_v491_cell1_v_delayed_u , v149_v491_cell2_v_delayed_u , v149_v491_wasted_u ; // and their updates
static double  v149_v491_k_init , v149_v491_cell1_mode_delayed_init , v149_v491_cell2_mode_delayed_init , v149_v491_from_cell_init , v149_v491_cell1_replay_latch_init , v149_v491_cell2_replay_latch_init , v149_v491_cell1_v_delayed_init , v149_v491_cell2_v_delayed_init , v149_v491_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v149_v491_idle , v149_v491_annhilate , v149_v491_previous_drection1 , v149_v491_previous_direction2 , v149_v491_wait_cell1 , v149_v491_replay_cell1 , v149_v491_replay_cell2 , v149_v491_wait_cell2 }; // state declarations

enum states v149_v491 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v149_v491_idle ):
    if (True == False) {;}
    else if  (v149_v491_cell2_mode == (2.0) && (v149_v491_cell1_mode != (2.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v149_v491_cell1_mode == (2.0) && (v149_v491_cell2_mode != (2.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v149_v491_cell1_mode == (2.0) && (v149_v491_cell2_mode == (2.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_idle ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_annhilate ):
    if (True == False) {;}
    else if  (v149_v491_cell1_mode != (2.0) && (v149_v491_cell2_mode != (2.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_from_cell_u = 0 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_previous_drection1 ):
    if (True == False) {;}
    else if  (v149_v491_from_cell == (1.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (0.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (2.0) && (v149_v491_cell2_mode_delayed == (0.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (2.0) && (v149_v491_cell2_mode_delayed != (0.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_previous_drection1 ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_previous_direction2 ):
    if (True == False) {;}
    else if  (v149_v491_from_cell == (1.0) && (v149_v491_cell1_mode_delayed != (0.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (2.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (0.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v149_v491_from_cell == (1.0) && (v149_v491_cell1_mode_delayed == (0.0))) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_previous_direction2 ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_wait_cell1 ):
    if (True == False) {;}
    else if  (v149_v491_cell2_mode == (2.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
    }
    else if  (v149_v491_k >= (110.03578469600001)) {
      v149_v491_from_cell_u = 1 ;
      v149_v491_cell1_replay_latch_u = 1 ;
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_wait_cell1 ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_replay_cell1 ):
    if (True == False) {;}
    else if  (v149_v491_cell1_mode == (2.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_annhilate ;
      force_init_update = False;
    }
    else if  (v149_v491_k >= (110.03578469600001)) {
      v149_v491_from_cell_u = 2 ;
      v149_v491_cell2_replay_latch_u = 1 ;
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_replay_cell1 ;
      force_init_update = False;
      v149_v491_cell1_replay_latch_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_replay_cell2 ):
    if (True == False) {;}
    else if  (v149_v491_k >= (10.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_replay_cell2 ;
      force_init_update = False;
      v149_v491_cell2_replay_latch_u = 1 ;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  case ( v149_v491_wait_cell2 ):
    if (True == False) {;}
    else if  (v149_v491_k >= (10.0)) {
      v149_v491_k_u = 1 ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
      cstate =  v149_v491_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v149_v491_k_init = v149_v491_k ;
      slope =  1 ;
      v149_v491_k_u = (slope * d) + v149_v491_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v149_v491_wait_cell2 ;
      force_init_update = False;
      v149_v491_cell1_v_delayed_u = v149_v491_update_c1vd () ;
      v149_v491_cell2_v_delayed_u = v149_v491_update_c2vd () ;
      v149_v491_cell1_mode_delayed_u = v149_v491_update_c1md () ;
      v149_v491_cell2_mode_delayed_u = v149_v491_update_c2md () ;
      v149_v491_wasted_u = v149_v491_update_buffer_index (v149_v491_cell1_v,v149_v491_cell2_v,v149_v491_cell1_mode,v149_v491_cell2_mode) ;
      v149_v491_cell1_replay_latch_u = v149_v491_update_latch1 (v149_v491_cell1_mode_delayed,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_replay_latch_u = v149_v491_update_latch2 (v149_v491_cell2_mode_delayed,v149_v491_cell2_replay_latch_u) ;
      v149_v491_cell1_v_replay = v149_v491_update_ocell1 (v149_v491_cell1_v_delayed_u,v149_v491_cell1_replay_latch_u) ;
      v149_v491_cell2_v_replay = v149_v491_update_ocell2 (v149_v491_cell2_v_delayed_u,v149_v491_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v149_v491!\n");
      exit(1);
    }
    break;
  }
  v149_v491_k = v149_v491_k_u;
  v149_v491_cell1_mode_delayed = v149_v491_cell1_mode_delayed_u;
  v149_v491_cell2_mode_delayed = v149_v491_cell2_mode_delayed_u;
  v149_v491_from_cell = v149_v491_from_cell_u;
  v149_v491_cell1_replay_latch = v149_v491_cell1_replay_latch_u;
  v149_v491_cell2_replay_latch = v149_v491_cell2_replay_latch_u;
  v149_v491_cell1_v_delayed = v149_v491_cell1_v_delayed_u;
  v149_v491_cell2_v_delayed = v149_v491_cell2_v_delayed_u;
  v149_v491_wasted = v149_v491_wasted_u;
  return cstate;
}