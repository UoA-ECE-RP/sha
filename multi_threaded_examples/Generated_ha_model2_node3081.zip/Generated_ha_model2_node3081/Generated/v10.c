#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v10_v_i_0;
double v10_v_i_1;
double v10_v_i_2;
double v10_v_i_3;
double v10_voo = 0.0;
double v10_state = 0.0;


static double  v10_vx  =  0 ,  v10_vy  =  0 ,  v10_vz  =  0 ,  v10_g  =  0 ,  v10_v  =  0 ,  v10_ft  =  0 ,  v10_theta  =  0 ,  v10_v_O  =  0 ; //the continuous vars
static double  v10_vx_u , v10_vy_u , v10_vz_u , v10_g_u , v10_v_u , v10_ft_u , v10_theta_u , v10_v_O_u ; // and their updates
static double  v10_vx_init , v10_vy_init , v10_vz_init , v10_g_init , v10_v_init , v10_ft_init , v10_theta_init , v10_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v10_t1 , v10_t2 , v10_t3 , v10_t4 }; // state declarations

enum states v10 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v10_t1 ):
    if (True == False) {;}
    else if  (v10_g > (44.5)) {
      v10_vx_u = (0.3 * v10_v) ;
      v10_vy_u = 0 ;
      v10_vz_u = (0.7 * v10_v) ;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      v10_theta_u = (v10_v / 30.0) ;
      v10_v_O_u = (131.1 + (- (80.1 * pow ( ((v10_v / 30.0)) , (0.5) )))) ;
      v10_ft_u = f (v10_theta,4.0e-2) ;
      cstate =  v10_t2 ;
      force_init_update = False;
    }

    else if ( v10_v <= (44.5)
               && v10_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v10_vx_init = v10_vx ;
      slope =  (v10_vx * -8.7) ;
      v10_vx_u = (slope * d) + v10_vx ;
      if ((pstate != cstate) || force_init_update) v10_vy_init = v10_vy ;
      slope =  (v10_vy * -190.9) ;
      v10_vy_u = (slope * d) + v10_vy ;
      if ((pstate != cstate) || force_init_update) v10_vz_init = v10_vz ;
      slope =  (v10_vz * -190.4) ;
      v10_vz_u = (slope * d) + v10_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v10_t1 ;
      force_init_update = False;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      v10_v_u = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_voo = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v10!\n");
      exit(1);
    }
    break;
  case ( v10_t2 ):
    if (True == False) {;}
    else if  (v10_v >= (44.5)) {
      v10_vx_u = v10_vx ;
      v10_vy_u = v10_vy ;
      v10_vz_u = v10_vz ;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v10_t3 ;
      force_init_update = False;
    }
    else if  (v10_g <= (44.5)
               && v10_v < (44.5)) {
      v10_vx_u = v10_vx ;
      v10_vy_u = v10_vy ;
      v10_vz_u = v10_vz ;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v10_t1 ;
      force_init_update = False;
    }

    else if ( v10_v < (44.5) && 
              v10_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v10_vx_init = v10_vx ;
      slope =  ((v10_vx * -23.6) + (777200.0 * v10_g)) ;
      v10_vx_u = (slope * d) + v10_vx ;
      if ((pstate != cstate) || force_init_update) v10_vy_init = v10_vy ;
      slope =  ((v10_vy * -45.5) + (58900.0 * v10_g)) ;
      v10_vy_u = (slope * d) + v10_vy ;
      if ((pstate != cstate) || force_init_update) v10_vz_init = v10_vz ;
      slope =  ((v10_vz * -12.9) + (276600.0 * v10_g)) ;
      v10_vz_u = (slope * d) + v10_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v10_t2 ;
      force_init_update = False;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      v10_v_u = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_voo = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v10!\n");
      exit(1);
    }
    break;
  case ( v10_t3 ):
    if (True == False) {;}
    else if  (v10_v >= (131.1)) {
      v10_vx_u = v10_vx ;
      v10_vy_u = v10_vy ;
      v10_vz_u = v10_vz ;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v10_t4 ;
      force_init_update = False;
    }

    else if ( v10_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v10_vx_init = v10_vx ;
      slope =  (v10_vx * -6.9) ;
      v10_vx_u = (slope * d) + v10_vx ;
      if ((pstate != cstate) || force_init_update) v10_vy_init = v10_vy ;
      slope =  (v10_vy * 75.9) ;
      v10_vy_u = (slope * d) + v10_vy ;
      if ((pstate != cstate) || force_init_update) v10_vz_init = v10_vz ;
      slope =  (v10_vz * 6826.5) ;
      v10_vz_u = (slope * d) + v10_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v10_t3 ;
      force_init_update = False;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      v10_v_u = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_voo = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v10!\n");
      exit(1);
    }
    break;
  case ( v10_t4 ):
    if (True == False) {;}
    else if  (v10_v <= (30.0)) {
      v10_vx_u = v10_vx ;
      v10_vy_u = v10_vy ;
      v10_vz_u = v10_vz ;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v10_t1 ;
      force_init_update = False;
    }

    else if ( v10_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v10_vx_init = v10_vx ;
      slope =  (v10_vx * -33.2) ;
      v10_vx_u = (slope * d) + v10_vx ;
      if ((pstate != cstate) || force_init_update) v10_vy_init = v10_vy ;
      slope =  ((v10_vy * 20.0) * v10_ft) ;
      v10_vy_u = (slope * d) + v10_vy ;
      if ((pstate != cstate) || force_init_update) v10_vz_init = v10_vz ;
      slope =  ((v10_vz * 2.0) * v10_ft) ;
      v10_vz_u = (slope * d) + v10_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v10_t4 ;
      force_init_update = False;
      v10_g_u = ((((((((((((v10_v_i_0 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.1807173114)) + ((((v10_v_i_1 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.10667997233))) + ((((v10_v_i_2 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42217424681))) + ((((v10_v_i_3 + (- ((v10_vx + (- v10_vy)) + v10_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + 0) + 0) + 0) + 0) + 0) ;
      v10_v_u = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_voo = ((v10_vx + (- v10_vy)) + v10_vz) ;
      v10_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v10!\n");
      exit(1);
    }
    break;
  }
  v10_vx = v10_vx_u;
  v10_vy = v10_vy_u;
  v10_vz = v10_vz_u;
  v10_g = v10_g_u;
  v10_v = v10_v_u;
  v10_ft = v10_ft_u;
  v10_theta = v10_theta_u;
  v10_v_O = v10_v_O_u;
  return cstate;
}