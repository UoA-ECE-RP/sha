#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v17_v_i_0;
double v17_v_i_1;
double v17_v_i_2;
double v17_v_i_3;
double v17_v_i_4;
double v17_voo = 0.0;
double v17_state = 0.0;


static double  v17_vx  =  0 ,  v17_vy  =  0 ,  v17_vz  =  0 ,  v17_g  =  0 ,  v17_v  =  0 ,  v17_ft  =  0 ,  v17_theta  =  0 ,  v17_v_O  =  0 ; //the continuous vars
static double  v17_vx_u , v17_vy_u , v17_vz_u , v17_g_u , v17_v_u , v17_ft_u , v17_theta_u , v17_v_O_u ; // and their updates
static double  v17_vx_init , v17_vy_init , v17_vz_init , v17_g_init , v17_v_init , v17_ft_init , v17_theta_init , v17_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v17_t1 , v17_t2 , v17_t3 , v17_t4 }; // state declarations

enum states v17 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v17_t1 ):
    if (True == False) {;}
    else if  (v17_g > (44.5)) {
      v17_vx_u = (0.3 * v17_v) ;
      v17_vy_u = 0 ;
      v17_vz_u = (0.7 * v17_v) ;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      v17_theta_u = (v17_v / 30.0) ;
      v17_v_O_u = (131.1 + (- (80.1 * pow ( ((v17_v / 30.0)) , (0.5) )))) ;
      v17_ft_u = f (v17_theta,4.0e-2) ;
      cstate =  v17_t2 ;
      force_init_update = False;
    }

    else if ( v17_v <= (44.5)
               && v17_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v17_vx_init = v17_vx ;
      slope =  (v17_vx * -8.7) ;
      v17_vx_u = (slope * d) + v17_vx ;
      if ((pstate != cstate) || force_init_update) v17_vy_init = v17_vy ;
      slope =  (v17_vy * -190.9) ;
      v17_vy_u = (slope * d) + v17_vy ;
      if ((pstate != cstate) || force_init_update) v17_vz_init = v17_vz ;
      slope =  (v17_vz * -190.4) ;
      v17_vz_u = (slope * d) + v17_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v17_t1 ;
      force_init_update = False;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      v17_v_u = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_voo = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v17!\n");
      exit(1);
    }
    break;
  case ( v17_t2 ):
    if (True == False) {;}
    else if  (v17_v >= (44.5)) {
      v17_vx_u = v17_vx ;
      v17_vy_u = v17_vy ;
      v17_vz_u = v17_vz ;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      cstate =  v17_t3 ;
      force_init_update = False;
    }
    else if  (v17_g <= (44.5)
               && v17_v < (44.5)) {
      v17_vx_u = v17_vx ;
      v17_vy_u = v17_vy ;
      v17_vz_u = v17_vz ;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      cstate =  v17_t1 ;
      force_init_update = False;
    }

    else if ( v17_v < (44.5) && 
              v17_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v17_vx_init = v17_vx ;
      slope =  ((v17_vx * -23.6) + (777200.0 * v17_g)) ;
      v17_vx_u = (slope * d) + v17_vx ;
      if ((pstate != cstate) || force_init_update) v17_vy_init = v17_vy ;
      slope =  ((v17_vy * -45.5) + (58900.0 * v17_g)) ;
      v17_vy_u = (slope * d) + v17_vy ;
      if ((pstate != cstate) || force_init_update) v17_vz_init = v17_vz ;
      slope =  ((v17_vz * -12.9) + (276600.0 * v17_g)) ;
      v17_vz_u = (slope * d) + v17_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v17_t2 ;
      force_init_update = False;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      v17_v_u = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_voo = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v17!\n");
      exit(1);
    }
    break;
  case ( v17_t3 ):
    if (True == False) {;}
    else if  (v17_v >= (131.1)) {
      v17_vx_u = v17_vx ;
      v17_vy_u = v17_vy ;
      v17_vz_u = v17_vz ;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      cstate =  v17_t4 ;
      force_init_update = False;
    }

    else if ( v17_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v17_vx_init = v17_vx ;
      slope =  (v17_vx * -6.9) ;
      v17_vx_u = (slope * d) + v17_vx ;
      if ((pstate != cstate) || force_init_update) v17_vy_init = v17_vy ;
      slope =  (v17_vy * 75.9) ;
      v17_vy_u = (slope * d) + v17_vy ;
      if ((pstate != cstate) || force_init_update) v17_vz_init = v17_vz ;
      slope =  (v17_vz * 6826.5) ;
      v17_vz_u = (slope * d) + v17_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v17_t3 ;
      force_init_update = False;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      v17_v_u = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_voo = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v17!\n");
      exit(1);
    }
    break;
  case ( v17_t4 ):
    if (True == False) {;}
    else if  (v17_v <= (30.0)) {
      v17_vx_u = v17_vx ;
      v17_vy_u = v17_vy ;
      v17_vz_u = v17_vz ;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      cstate =  v17_t1 ;
      force_init_update = False;
    }

    else if ( v17_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v17_vx_init = v17_vx ;
      slope =  (v17_vx * -33.2) ;
      v17_vx_u = (slope * d) + v17_vx ;
      if ((pstate != cstate) || force_init_update) v17_vy_init = v17_vy ;
      slope =  ((v17_vy * 20.0) * v17_ft) ;
      v17_vy_u = (slope * d) + v17_vy ;
      if ((pstate != cstate) || force_init_update) v17_vz_init = v17_vz ;
      slope =  ((v17_vz * 2.0) * v17_ft) ;
      v17_vz_u = (slope * d) + v17_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v17_t4 ;
      force_init_update = False;
      v17_g_u = ((((((((((((v17_v_i_0 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v17_v_i_1 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174))) + ((((v17_v_i_2 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.42533705779))) + ((((v17_v_i_3 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v17_v_i_4 + (- ((v17_vx + (- v17_vy)) + v17_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.67576121397))) + 0) + 0) + 0) + 0) ;
      v17_v_u = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_voo = ((v17_vx + (- v17_vy)) + v17_vz) ;
      v17_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v17!\n");
      exit(1);
    }
    break;
  }
  v17_vx = v17_vx_u;
  v17_vy = v17_vy_u;
  v17_vz = v17_vz_u;
  v17_g = v17_g_u;
  v17_v = v17_v_u;
  v17_ft = v17_ft_u;
  v17_theta = v17_theta_u;
  v17_v_O = v17_v_O_u;
  return cstate;
}