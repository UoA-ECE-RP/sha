#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v168_v_i_0;
double v168_v_i_1;
double v168_v_i_2;
double v168_voo = 0.0;
double v168_state = 0.0;


static double  v168_vx  =  0 ,  v168_vy  =  0 ,  v168_vz  =  0 ,  v168_g  =  0 ,  v168_v  =  0 ,  v168_ft  =  0 ,  v168_theta  =  0 ,  v168_v_O  =  0 ; //the continuous vars
static double  v168_vx_u , v168_vy_u , v168_vz_u , v168_g_u , v168_v_u , v168_ft_u , v168_theta_u , v168_v_O_u ; // and their updates
static double  v168_vx_init , v168_vy_init , v168_vz_init , v168_g_init , v168_v_init , v168_ft_init , v168_theta_init , v168_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v168_t1 , v168_t2 , v168_t3 , v168_t4 }; // state declarations

enum states v168 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v168_t1 ):
    if (True == False) {;}
    else if  (v168_g > (44.5)) {
      v168_vx_u = (0.3 * v168_v) ;
      v168_vy_u = 0 ;
      v168_vz_u = (0.7 * v168_v) ;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v168_theta_u = (v168_v / 30.0) ;
      v168_v_O_u = (131.1 + (- (80.1 * pow ( ((v168_v / 30.0)) , (0.5) )))) ;
      v168_ft_u = f (v168_theta,4.0e-2) ;
      cstate =  v168_t2 ;
      force_init_update = False;
    }

    else if ( v168_v <= (44.5)
               && v168_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v168_vx_init = v168_vx ;
      slope =  (v168_vx * -8.7) ;
      v168_vx_u = (slope * d) + v168_vx ;
      if ((pstate != cstate) || force_init_update) v168_vy_init = v168_vy ;
      slope =  (v168_vy * -190.9) ;
      v168_vy_u = (slope * d) + v168_vy ;
      if ((pstate != cstate) || force_init_update) v168_vz_init = v168_vz ;
      slope =  (v168_vz * -190.4) ;
      v168_vz_u = (slope * d) + v168_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v168_t1 ;
      force_init_update = False;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v168_v_u = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_voo = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v168!\n");
      exit(1);
    }
    break;
  case ( v168_t2 ):
    if (True == False) {;}
    else if  (v168_v >= (44.5)) {
      v168_vx_u = v168_vx ;
      v168_vy_u = v168_vy ;
      v168_vz_u = v168_vz ;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v168_t3 ;
      force_init_update = False;
    }
    else if  (v168_g <= (44.5)
               && v168_v < (44.5)) {
      v168_vx_u = v168_vx ;
      v168_vy_u = v168_vy ;
      v168_vz_u = v168_vz ;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v168_t1 ;
      force_init_update = False;
    }

    else if ( v168_v < (44.5)
               && v168_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v168_vx_init = v168_vx ;
      slope =  ((v168_vx * -23.6) + (777200.0 * v168_g)) ;
      v168_vx_u = (slope * d) + v168_vx ;
      if ((pstate != cstate) || force_init_update) v168_vy_init = v168_vy ;
      slope =  ((v168_vy * -45.5) + (58900.0 * v168_g)) ;
      v168_vy_u = (slope * d) + v168_vy ;
      if ((pstate != cstate) || force_init_update) v168_vz_init = v168_vz ;
      slope =  ((v168_vz * -12.9) + (276600.0 * v168_g)) ;
      v168_vz_u = (slope * d) + v168_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v168_t2 ;
      force_init_update = False;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v168_v_u = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_voo = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v168!\n");
      exit(1);
    }
    break;
  case ( v168_t3 ):
    if (True == False) {;}
    else if  (v168_v >= (131.1)) {
      v168_vx_u = v168_vx ;
      v168_vy_u = v168_vy ;
      v168_vz_u = v168_vz ;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v168_t4 ;
      force_init_update = False;
    }

    else if ( v168_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v168_vx_init = v168_vx ;
      slope =  (v168_vx * -6.9) ;
      v168_vx_u = (slope * d) + v168_vx ;
      if ((pstate != cstate) || force_init_update) v168_vy_init = v168_vy ;
      slope =  (v168_vy * 75.9) ;
      v168_vy_u = (slope * d) + v168_vy ;
      if ((pstate != cstate) || force_init_update) v168_vz_init = v168_vz ;
      slope =  (v168_vz * 6826.5) ;
      v168_vz_u = (slope * d) + v168_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v168_t3 ;
      force_init_update = False;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v168_v_u = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_voo = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v168!\n");
      exit(1);
    }
    break;
  case ( v168_t4 ):
    if (True == False) {;}
    else if  (v168_v <= (30.0)) {
      v168_vx_u = v168_vx ;
      v168_vy_u = v168_vy ;
      v168_vz_u = v168_vz ;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v168_t1 ;
      force_init_update = False;
    }

    else if ( v168_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v168_vx_init = v168_vx ;
      slope =  (v168_vx * -33.2) ;
      v168_vx_u = (slope * d) + v168_vx ;
      if ((pstate != cstate) || force_init_update) v168_vy_init = v168_vy ;
      slope =  ((v168_vy * 20.0) * v168_ft) ;
      v168_vy_u = (slope * d) + v168_vy ;
      if ((pstate != cstate) || force_init_update) v168_vz_init = v168_vz ;
      slope =  ((v168_vz * 2.0) * v168_ft) ;
      v168_vz_u = (slope * d) + v168_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v168_t4 ;
      force_init_update = False;
      v168_g_u = ((((((((((((v168_v_i_0 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17832061885)) + ((((v168_v_i_1 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v168_v_i_2 + (- ((v168_vx + (- v168_vy)) + v168_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844272583))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v168_v_u = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_voo = ((v168_vx + (- v168_vy)) + v168_vz) ;
      v168_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v168!\n");
      exit(1);
    }
    break;
  }
  v168_vx = v168_vx_u;
  v168_vy = v168_vy_u;
  v168_vz = v168_vz_u;
  v168_g = v168_g_u;
  v168_v = v168_v_u;
  v168_ft = v168_ft_u;
  v168_theta = v168_theta_u;
  v168_v_O = v168_v_O_u;
  return cstate;
}