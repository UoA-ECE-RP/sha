#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v14_v15_update_c1vd();
extern double v14_v15_update_c2vd();
extern double v14_v15_update_c1md();
extern double v14_v15_update_c2md();
extern double v14_v15_update_buffer_index(double,double,double,double);
extern double v14_v15_update_latch1(double,double);
extern double v14_v15_update_latch2(double,double);
extern double v14_v15_update_ocell1(double,double);
extern double v14_v15_update_ocell2(double,double);
double v14_v15_cell1_v;
double v14_v15_cell1_mode;
double v14_v15_cell2_v;
double v14_v15_cell2_mode;
double v14_v15_cell1_v_replay = 0.0;
double v14_v15_cell2_v_replay = 0.0;


static double  v14_v15_k  =  0.0 ,  v14_v15_cell1_mode_delayed  =  0.0 ,  v14_v15_cell2_mode_delayed  =  0.0 ,  v14_v15_from_cell  =  0.0 ,  v14_v15_cell1_replay_latch  =  0.0 ,  v14_v15_cell2_replay_latch  =  0.0 ,  v14_v15_cell1_v_delayed  =  0.0 ,  v14_v15_cell2_v_delayed  =  0.0 ,  v14_v15_wasted  =  0.0 ; //the continuous vars
static double  v14_v15_k_u , v14_v15_cell1_mode_delayed_u , v14_v15_cell2_mode_delayed_u , v14_v15_from_cell_u , v14_v15_cell1_replay_latch_u , v14_v15_cell2_replay_latch_u , v14_v15_cell1_v_delayed_u , v14_v15_cell2_v_delayed_u , v14_v15_wasted_u ; // and their updates
static double  v14_v15_k_init , v14_v15_cell1_mode_delayed_init , v14_v15_cell2_mode_delayed_init , v14_v15_from_cell_init , v14_v15_cell1_replay_latch_init , v14_v15_cell2_replay_latch_init , v14_v15_cell1_v_delayed_init , v14_v15_cell2_v_delayed_init , v14_v15_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v14_v15_idle , v14_v15_annhilate , v14_v15_previous_drection1 , v14_v15_previous_direction2 , v14_v15_wait_cell1 , v14_v15_replay_cell1 , v14_v15_replay_cell2 , v14_v15_wait_cell2 }; // state declarations

enum states v14_v15 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v14_v15_idle ):
    if (True == False) {;}
    else if  (v14_v15_cell2_mode == (2.0) && (v14_v15_cell1_mode != (2.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v14_v15_cell1_mode == (2.0) && (v14_v15_cell2_mode != (2.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v14_v15_cell1_mode == (2.0) && (v14_v15_cell2_mode == (2.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_idle ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_annhilate ):
    if (True == False) {;}
    else if  (v14_v15_cell1_mode != (2.0) && (v14_v15_cell2_mode != (2.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_from_cell_u = 0 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_previous_drection1 ):
    if (True == False) {;}
    else if  (v14_v15_from_cell == (1.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (0.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (2.0) && (v14_v15_cell2_mode_delayed == (0.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (2.0) && (v14_v15_cell2_mode_delayed != (0.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_previous_drection1 ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_previous_direction2 ):
    if (True == False) {;}
    else if  (v14_v15_from_cell == (1.0) && (v14_v15_cell1_mode_delayed != (0.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (2.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (0.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v14_v15_from_cell == (1.0) && (v14_v15_cell1_mode_delayed == (0.0))) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_previous_direction2 ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_wait_cell1 ):
    if (True == False) {;}
    else if  (v14_v15_cell2_mode == (2.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v15_k >= (2.2330502085)) {
      v14_v15_from_cell_u = 1 ;
      v14_v15_cell1_replay_latch_u = 1 ;
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_wait_cell1 ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_replay_cell1 ):
    if (True == False) {;}
    else if  (v14_v15_cell1_mode == (2.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_annhilate ;
      force_init_update = False;
    }
    else if  (v14_v15_k >= (2.2330502085)) {
      v14_v15_from_cell_u = 2 ;
      v14_v15_cell2_replay_latch_u = 1 ;
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_replay_cell1 ;
      force_init_update = False;
      v14_v15_cell1_replay_latch_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_replay_cell2 ):
    if (True == False) {;}
    else if  (v14_v15_k >= (10.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_replay_cell2 ;
      force_init_update = False;
      v14_v15_cell2_replay_latch_u = 1 ;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  case ( v14_v15_wait_cell2 ):
    if (True == False) {;}
    else if  (v14_v15_k >= (10.0)) {
      v14_v15_k_u = 1 ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
      cstate =  v14_v15_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v14_v15_k_init = v14_v15_k ;
      slope =  1 ;
      v14_v15_k_u = (slope * d) + v14_v15_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v14_v15_wait_cell2 ;
      force_init_update = False;
      v14_v15_cell1_v_delayed_u = v14_v15_update_c1vd () ;
      v14_v15_cell2_v_delayed_u = v14_v15_update_c2vd () ;
      v14_v15_cell1_mode_delayed_u = v14_v15_update_c1md () ;
      v14_v15_cell2_mode_delayed_u = v14_v15_update_c2md () ;
      v14_v15_wasted_u = v14_v15_update_buffer_index (v14_v15_cell1_v,v14_v15_cell2_v,v14_v15_cell1_mode,v14_v15_cell2_mode) ;
      v14_v15_cell1_replay_latch_u = v14_v15_update_latch1 (v14_v15_cell1_mode_delayed,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_replay_latch_u = v14_v15_update_latch2 (v14_v15_cell2_mode_delayed,v14_v15_cell2_replay_latch_u) ;
      v14_v15_cell1_v_replay = v14_v15_update_ocell1 (v14_v15_cell1_v_delayed_u,v14_v15_cell1_replay_latch_u) ;
      v14_v15_cell2_v_replay = v14_v15_update_ocell2 (v14_v15_cell2_v_delayed_u,v14_v15_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v14_v15!\n");
      exit(1);
    }
    break;
  }
  v14_v15_k = v14_v15_k_u;
  v14_v15_cell1_mode_delayed = v14_v15_cell1_mode_delayed_u;
  v14_v15_cell2_mode_delayed = v14_v15_cell2_mode_delayed_u;
  v14_v15_from_cell = v14_v15_from_cell_u;
  v14_v15_cell1_replay_latch = v14_v15_cell1_replay_latch_u;
  v14_v15_cell2_replay_latch = v14_v15_cell2_replay_latch_u;
  v14_v15_cell1_v_delayed = v14_v15_cell1_v_delayed_u;
  v14_v15_cell2_v_delayed = v14_v15_cell2_v_delayed_u;
  v14_v15_wasted = v14_v15_wasted_u;
  return cstate;
}