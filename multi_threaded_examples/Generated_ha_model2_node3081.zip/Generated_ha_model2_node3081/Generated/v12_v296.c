#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v12_v296_update_c1vd();
extern double v12_v296_update_c2vd();
extern double v12_v296_update_c1md();
extern double v12_v296_update_c2md();
extern double v12_v296_update_buffer_index(double,double,double,double);
extern double v12_v296_update_latch1(double,double);
extern double v12_v296_update_latch2(double,double);
extern double v12_v296_update_ocell1(double,double);
extern double v12_v296_update_ocell2(double,double);
double v12_v296_cell1_v;
double v12_v296_cell1_mode;
double v12_v296_cell2_v;
double v12_v296_cell2_mode;
double v12_v296_cell1_v_replay = 0.0;
double v12_v296_cell2_v_replay = 0.0;


static double  v12_v296_k  =  0.0 ,  v12_v296_cell1_mode_delayed  =  0.0 ,  v12_v296_cell2_mode_delayed  =  0.0 ,  v12_v296_from_cell  =  0.0 ,  v12_v296_cell1_replay_latch  =  0.0 ,  v12_v296_cell2_replay_latch  =  0.0 ,  v12_v296_cell1_v_delayed  =  0.0 ,  v12_v296_cell2_v_delayed  =  0.0 ,  v12_v296_wasted  =  0.0 ; //the continuous vars
static double  v12_v296_k_u , v12_v296_cell1_mode_delayed_u , v12_v296_cell2_mode_delayed_u , v12_v296_from_cell_u , v12_v296_cell1_replay_latch_u , v12_v296_cell2_replay_latch_u , v12_v296_cell1_v_delayed_u , v12_v296_cell2_v_delayed_u , v12_v296_wasted_u ; // and their updates
static double  v12_v296_k_init , v12_v296_cell1_mode_delayed_init , v12_v296_cell2_mode_delayed_init , v12_v296_from_cell_init , v12_v296_cell1_replay_latch_init , v12_v296_cell2_replay_latch_init , v12_v296_cell1_v_delayed_init , v12_v296_cell2_v_delayed_init , v12_v296_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v12_v296_idle , v12_v296_annhilate , v12_v296_previous_drection1 , v12_v296_previous_direction2 , v12_v296_wait_cell1 , v12_v296_replay_cell1 , v12_v296_replay_cell2 , v12_v296_wait_cell2 }; // state declarations

enum states v12_v296 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v12_v296_idle ):
    if (True == False) {;}
    else if  (v12_v296_cell2_mode == (2.0) && (v12_v296_cell1_mode != (2.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v12_v296_cell1_mode == (2.0) && (v12_v296_cell2_mode != (2.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v12_v296_cell1_mode == (2.0) && (v12_v296_cell2_mode == (2.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_idle ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_annhilate ):
    if (True == False) {;}
    else if  (v12_v296_cell1_mode != (2.0) && (v12_v296_cell2_mode != (2.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_from_cell_u = 0 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_previous_drection1 ):
    if (True == False) {;}
    else if  (v12_v296_from_cell == (1.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (0.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (2.0) && (v12_v296_cell2_mode_delayed == (0.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (2.0) && (v12_v296_cell2_mode_delayed != (0.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_previous_drection1 ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_previous_direction2 ):
    if (True == False) {;}
    else if  (v12_v296_from_cell == (1.0) && (v12_v296_cell1_mode_delayed != (0.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (2.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (0.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v12_v296_from_cell == (1.0) && (v12_v296_cell1_mode_delayed == (0.0))) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_previous_direction2 ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_wait_cell1 ):
    if (True == False) {;}
    else if  (v12_v296_cell2_mode == (2.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
    }
    else if  (v12_v296_k >= (147.429019418)) {
      v12_v296_from_cell_u = 1 ;
      v12_v296_cell1_replay_latch_u = 1 ;
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_wait_cell1 ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_replay_cell1 ):
    if (True == False) {;}
    else if  (v12_v296_cell1_mode == (2.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_annhilate ;
      force_init_update = False;
    }
    else if  (v12_v296_k >= (147.429019418)) {
      v12_v296_from_cell_u = 2 ;
      v12_v296_cell2_replay_latch_u = 1 ;
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_replay_cell1 ;
      force_init_update = False;
      v12_v296_cell1_replay_latch_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_replay_cell2 ):
    if (True == False) {;}
    else if  (v12_v296_k >= (10.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_replay_cell2 ;
      force_init_update = False;
      v12_v296_cell2_replay_latch_u = 1 ;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  case ( v12_v296_wait_cell2 ):
    if (True == False) {;}
    else if  (v12_v296_k >= (10.0)) {
      v12_v296_k_u = 1 ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
      cstate =  v12_v296_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v12_v296_k_init = v12_v296_k ;
      slope =  1 ;
      v12_v296_k_u = (slope * d) + v12_v296_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v12_v296_wait_cell2 ;
      force_init_update = False;
      v12_v296_cell1_v_delayed_u = v12_v296_update_c1vd () ;
      v12_v296_cell2_v_delayed_u = v12_v296_update_c2vd () ;
      v12_v296_cell1_mode_delayed_u = v12_v296_update_c1md () ;
      v12_v296_cell2_mode_delayed_u = v12_v296_update_c2md () ;
      v12_v296_wasted_u = v12_v296_update_buffer_index (v12_v296_cell1_v,v12_v296_cell2_v,v12_v296_cell1_mode,v12_v296_cell2_mode) ;
      v12_v296_cell1_replay_latch_u = v12_v296_update_latch1 (v12_v296_cell1_mode_delayed,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_replay_latch_u = v12_v296_update_latch2 (v12_v296_cell2_mode_delayed,v12_v296_cell2_replay_latch_u) ;
      v12_v296_cell1_v_replay = v12_v296_update_ocell1 (v12_v296_cell1_v_delayed_u,v12_v296_cell1_replay_latch_u) ;
      v12_v296_cell2_v_replay = v12_v296_update_ocell2 (v12_v296_cell2_v_delayed_u,v12_v296_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12_v296!\n");
      exit(1);
    }
    break;
  }
  v12_v296_k = v12_v296_k_u;
  v12_v296_cell1_mode_delayed = v12_v296_cell1_mode_delayed_u;
  v12_v296_cell2_mode_delayed = v12_v296_cell2_mode_delayed_u;
  v12_v296_from_cell = v12_v296_from_cell_u;
  v12_v296_cell1_replay_latch = v12_v296_cell1_replay_latch_u;
  v12_v296_cell2_replay_latch = v12_v296_cell2_replay_latch_u;
  v12_v296_cell1_v_delayed = v12_v296_cell1_v_delayed_u;
  v12_v296_cell2_v_delayed = v12_v296_cell2_v_delayed_u;
  v12_v296_wasted = v12_v296_wasted_u;
  return cstate;
}