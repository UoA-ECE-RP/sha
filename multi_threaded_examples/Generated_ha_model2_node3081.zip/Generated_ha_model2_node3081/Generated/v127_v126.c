#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v127_v126_update_c1vd();
extern double v127_v126_update_c2vd();
extern double v127_v126_update_c1md();
extern double v127_v126_update_c2md();
extern double v127_v126_update_buffer_index(double,double,double,double);
extern double v127_v126_update_latch1(double,double);
extern double v127_v126_update_latch2(double,double);
extern double v127_v126_update_ocell1(double,double);
extern double v127_v126_update_ocell2(double,double);
double v127_v126_cell1_v;
double v127_v126_cell1_mode;
double v127_v126_cell2_v;
double v127_v126_cell2_mode;
double v127_v126_cell1_v_replay = 0.0;
double v127_v126_cell2_v_replay = 0.0;


static double  v127_v126_k  =  0.0 ,  v127_v126_cell1_mode_delayed  =  0.0 ,  v127_v126_cell2_mode_delayed  =  0.0 ,  v127_v126_from_cell  =  0.0 ,  v127_v126_cell1_replay_latch  =  0.0 ,  v127_v126_cell2_replay_latch  =  0.0 ,  v127_v126_cell1_v_delayed  =  0.0 ,  v127_v126_cell2_v_delayed  =  0.0 ,  v127_v126_wasted  =  0.0 ; //the continuous vars
static double  v127_v126_k_u , v127_v126_cell1_mode_delayed_u , v127_v126_cell2_mode_delayed_u , v127_v126_from_cell_u , v127_v126_cell1_replay_latch_u , v127_v126_cell2_replay_latch_u , v127_v126_cell1_v_delayed_u , v127_v126_cell2_v_delayed_u , v127_v126_wasted_u ; // and their updates
static double  v127_v126_k_init , v127_v126_cell1_mode_delayed_init , v127_v126_cell2_mode_delayed_init , v127_v126_from_cell_init , v127_v126_cell1_replay_latch_init , v127_v126_cell2_replay_latch_init , v127_v126_cell1_v_delayed_init , v127_v126_cell2_v_delayed_init , v127_v126_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v127_v126_idle , v127_v126_annhilate , v127_v126_previous_drection1 , v127_v126_previous_direction2 , v127_v126_wait_cell1 , v127_v126_replay_cell1 , v127_v126_replay_cell2 , v127_v126_wait_cell2 }; // state declarations

enum states v127_v126 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v127_v126_idle ):
    if (True == False) {;}
    else if  (v127_v126_cell2_mode == (2.0) && (v127_v126_cell1_mode != (2.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v127_v126_cell1_mode == (2.0) && (v127_v126_cell2_mode != (2.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v127_v126_cell1_mode == (2.0) && (v127_v126_cell2_mode == (2.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_idle ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_annhilate ):
    if (True == False) {;}
    else if  (v127_v126_cell1_mode != (2.0) && (v127_v126_cell2_mode != (2.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_from_cell_u = 0 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_previous_drection1 ):
    if (True == False) {;}
    else if  (v127_v126_from_cell == (1.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (0.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (2.0) && (v127_v126_cell2_mode_delayed == (0.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (2.0) && (v127_v126_cell2_mode_delayed != (0.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_previous_drection1 ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_previous_direction2 ):
    if (True == False) {;}
    else if  (v127_v126_from_cell == (1.0) && (v127_v126_cell1_mode_delayed != (0.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (2.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (0.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v127_v126_from_cell == (1.0) && (v127_v126_cell1_mode_delayed == (0.0))) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_previous_direction2 ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_wait_cell1 ):
    if (True == False) {;}
    else if  (v127_v126_cell2_mode == (2.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
    }
    else if  (v127_v126_k >= (44.612972605299994)) {
      v127_v126_from_cell_u = 1 ;
      v127_v126_cell1_replay_latch_u = 1 ;
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_wait_cell1 ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_replay_cell1 ):
    if (True == False) {;}
    else if  (v127_v126_cell1_mode == (2.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_annhilate ;
      force_init_update = False;
    }
    else if  (v127_v126_k >= (44.612972605299994)) {
      v127_v126_from_cell_u = 2 ;
      v127_v126_cell2_replay_latch_u = 1 ;
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_replay_cell1 ;
      force_init_update = False;
      v127_v126_cell1_replay_latch_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_replay_cell2 ):
    if (True == False) {;}
    else if  (v127_v126_k >= (10.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_replay_cell2 ;
      force_init_update = False;
      v127_v126_cell2_replay_latch_u = 1 ;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  case ( v127_v126_wait_cell2 ):
    if (True == False) {;}
    else if  (v127_v126_k >= (10.0)) {
      v127_v126_k_u = 1 ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
      cstate =  v127_v126_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v127_v126_k_init = v127_v126_k ;
      slope =  1 ;
      v127_v126_k_u = (slope * d) + v127_v126_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v127_v126_wait_cell2 ;
      force_init_update = False;
      v127_v126_cell1_v_delayed_u = v127_v126_update_c1vd () ;
      v127_v126_cell2_v_delayed_u = v127_v126_update_c2vd () ;
      v127_v126_cell1_mode_delayed_u = v127_v126_update_c1md () ;
      v127_v126_cell2_mode_delayed_u = v127_v126_update_c2md () ;
      v127_v126_wasted_u = v127_v126_update_buffer_index (v127_v126_cell1_v,v127_v126_cell2_v,v127_v126_cell1_mode,v127_v126_cell2_mode) ;
      v127_v126_cell1_replay_latch_u = v127_v126_update_latch1 (v127_v126_cell1_mode_delayed,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_replay_latch_u = v127_v126_update_latch2 (v127_v126_cell2_mode_delayed,v127_v126_cell2_replay_latch_u) ;
      v127_v126_cell1_v_replay = v127_v126_update_ocell1 (v127_v126_cell1_v_delayed_u,v127_v126_cell1_replay_latch_u) ;
      v127_v126_cell2_v_replay = v127_v126_update_ocell2 (v127_v126_cell2_v_delayed_u,v127_v126_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v127_v126!\n");
      exit(1);
    }
    break;
  }
  v127_v126_k = v127_v126_k_u;
  v127_v126_cell1_mode_delayed = v127_v126_cell1_mode_delayed_u;
  v127_v126_cell2_mode_delayed = v127_v126_cell2_mode_delayed_u;
  v127_v126_from_cell = v127_v126_from_cell_u;
  v127_v126_cell1_replay_latch = v127_v126_cell1_replay_latch_u;
  v127_v126_cell2_replay_latch = v127_v126_cell2_replay_latch_u;
  v127_v126_cell1_v_delayed = v127_v126_cell1_v_delayed_u;
  v127_v126_cell2_v_delayed = v127_v126_cell2_v_delayed_u;
  v127_v126_wasted = v127_v126_wasted_u;
  return cstate;
}