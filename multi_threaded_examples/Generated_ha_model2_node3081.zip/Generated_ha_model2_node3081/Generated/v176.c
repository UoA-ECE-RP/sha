#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v176_v_i_0;
double v176_v_i_1;
double v176_v_i_2;
double v176_v_i_3;
double v176_voo = 0.0;
double v176_state = 0.0;


static double  v176_vx  =  0 ,  v176_vy  =  0 ,  v176_vz  =  0 ,  v176_g  =  0 ,  v176_v  =  0 ,  v176_ft  =  0 ,  v176_theta  =  0 ,  v176_v_O  =  0 ; //the continuous vars
static double  v176_vx_u , v176_vy_u , v176_vz_u , v176_g_u , v176_v_u , v176_ft_u , v176_theta_u , v176_v_O_u ; // and their updates
static double  v176_vx_init , v176_vy_init , v176_vz_init , v176_g_init , v176_v_init , v176_ft_init , v176_theta_init , v176_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v176_t1 , v176_t2 , v176_t3 , v176_t4 }; // state declarations

enum states v176 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v176_t1 ):
    if (True == False) {;}
    else if  (v176_g > (44.5)) {
      v176_vx_u = (0.3 * v176_v) ;
      v176_vy_u = 0 ;
      v176_vz_u = (0.7 * v176_v) ;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      v176_theta_u = (v176_v / 30.0) ;
      v176_v_O_u = (131.1 + (- (80.1 * pow ( ((v176_v / 30.0)) , (0.5) )))) ;
      v176_ft_u = f (v176_theta,4.0e-2) ;
      cstate =  v176_t2 ;
      force_init_update = False;
    }

    else if ( v176_v <= (44.5)
               && v176_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v176_vx_init = v176_vx ;
      slope =  (v176_vx * -8.7) ;
      v176_vx_u = (slope * d) + v176_vx ;
      if ((pstate != cstate) || force_init_update) v176_vy_init = v176_vy ;
      slope =  (v176_vy * -190.9) ;
      v176_vy_u = (slope * d) + v176_vy ;
      if ((pstate != cstate) || force_init_update) v176_vz_init = v176_vz ;
      slope =  (v176_vz * -190.4) ;
      v176_vz_u = (slope * d) + v176_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v176_t1 ;
      force_init_update = False;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      v176_v_u = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_voo = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v176!\n");
      exit(1);
    }
    break;
  case ( v176_t2 ):
    if (True == False) {;}
    else if  (v176_v >= (44.5)) {
      v176_vx_u = v176_vx ;
      v176_vy_u = v176_vy ;
      v176_vz_u = v176_vz ;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v176_t3 ;
      force_init_update = False;
    }
    else if  (v176_g <= (44.5)
               && v176_v < (44.5)) {
      v176_vx_u = v176_vx ;
      v176_vy_u = v176_vy ;
      v176_vz_u = v176_vz ;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v176_t1 ;
      force_init_update = False;
    }

    else if ( v176_v < (44.5)
               && v176_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v176_vx_init = v176_vx ;
      slope =  ((v176_vx * -23.6) + (777200.0 * v176_g)) ;
      v176_vx_u = (slope * d) + v176_vx ;
      if ((pstate != cstate) || force_init_update) v176_vy_init = v176_vy ;
      slope =  ((v176_vy * -45.5) + (58900.0 * v176_g)) ;
      v176_vy_u = (slope * d) + v176_vy ;
      if ((pstate != cstate) || force_init_update) v176_vz_init = v176_vz ;
      slope =  ((v176_vz * -12.9) + (276600.0 * v176_g)) ;
      v176_vz_u = (slope * d) + v176_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v176_t2 ;
      force_init_update = False;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      v176_v_u = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_voo = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v176!\n");
      exit(1);
    }
    break;
  case ( v176_t3 ):
    if (True == False) {;}
    else if  (v176_v >= (131.1)) {
      v176_vx_u = v176_vx ;
      v176_vy_u = v176_vy ;
      v176_vz_u = v176_vz ;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v176_t4 ;
      force_init_update = False;
    }

    else if ( v176_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v176_vx_init = v176_vx ;
      slope =  (v176_vx * -6.9) ;
      v176_vx_u = (slope * d) + v176_vx ;
      if ((pstate != cstate) || force_init_update) v176_vy_init = v176_vy ;
      slope =  (v176_vy * 75.9) ;
      v176_vy_u = (slope * d) + v176_vy ;
      if ((pstate != cstate) || force_init_update) v176_vz_init = v176_vz ;
      slope =  (v176_vz * 6826.5) ;
      v176_vz_u = (slope * d) + v176_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v176_t3 ;
      force_init_update = False;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      v176_v_u = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_voo = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v176!\n");
      exit(1);
    }
    break;
  case ( v176_t4 ):
    if (True == False) {;}
    else if  (v176_v <= (30.0)) {
      v176_vx_u = v176_vx ;
      v176_vy_u = v176_vy ;
      v176_vz_u = v176_vz ;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v176_t1 ;
      force_init_update = False;
    }

    else if ( v176_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v176_vx_init = v176_vx ;
      slope =  (v176_vx * -33.2) ;
      v176_vx_u = (slope * d) + v176_vx ;
      if ((pstate != cstate) || force_init_update) v176_vy_init = v176_vy ;
      slope =  ((v176_vy * 20.0) * v176_ft) ;
      v176_vy_u = (slope * d) + v176_vy ;
      if ((pstate != cstate) || force_init_update) v176_vz_init = v176_vz ;
      slope =  ((v176_vz * 2.0) * v176_ft) ;
      v176_vz_u = (slope * d) + v176_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v176_t4 ;
      force_init_update = False;
      v176_g_u = ((((((((((((v176_v_i_0 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v176_v_i_1 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v176_v_i_2 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.99787218932))) + ((((v176_v_i_3 + (- ((v176_vx + (- v176_vy)) + v176_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.95990725314))) + 0) + 0) + 0) + 0) + 0) ;
      v176_v_u = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_voo = ((v176_vx + (- v176_vy)) + v176_vz) ;
      v176_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v176!\n");
      exit(1);
    }
    break;
  }
  v176_vx = v176_vx_u;
  v176_vy = v176_vy_u;
  v176_vz = v176_vz_u;
  v176_g = v176_g_u;
  v176_v = v176_v_u;
  v176_ft = v176_ft_u;
  v176_theta = v176_theta_u;
  v176_v_O = v176_v_O_u;
  return cstate;
}