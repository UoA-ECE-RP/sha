#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v109_v_i_0;
double v109_v_i_1;
double v109_v_i_2;
double v109_voo = 0.0;
double v109_state = 0.0;


static double  v109_vx  =  0 ,  v109_vy  =  0 ,  v109_vz  =  0 ,  v109_g  =  0 ,  v109_v  =  0 ,  v109_ft  =  0 ,  v109_theta  =  0 ,  v109_v_O  =  0 ; //the continuous vars
static double  v109_vx_u , v109_vy_u , v109_vz_u , v109_g_u , v109_v_u , v109_ft_u , v109_theta_u , v109_v_O_u ; // and their updates
static double  v109_vx_init , v109_vy_init , v109_vz_init , v109_g_init , v109_v_init , v109_ft_init , v109_theta_init , v109_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v109_t1 , v109_t2 , v109_t3 , v109_t4 }; // state declarations

enum states v109 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v109_t1 ):
    if (True == False) {;}
    else if  (v109_g > (44.5)) {
      v109_vx_u = (0.3 * v109_v) ;
      v109_vy_u = 0 ;
      v109_vz_u = (0.7 * v109_v) ;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v109_theta_u = (v109_v / 30.0) ;
      v109_v_O_u = (131.1 + (- (80.1 * pow ( ((v109_v / 30.0)) , (0.5) )))) ;
      v109_ft_u = f (v109_theta,4.0e-2) ;
      cstate =  v109_t2 ;
      force_init_update = False;
    }

    else if ( v109_v <= (44.5)
               && v109_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v109_vx_init = v109_vx ;
      slope =  (v109_vx * -8.7) ;
      v109_vx_u = (slope * d) + v109_vx ;
      if ((pstate != cstate) || force_init_update) v109_vy_init = v109_vy ;
      slope =  (v109_vy * -190.9) ;
      v109_vy_u = (slope * d) + v109_vy ;
      if ((pstate != cstate) || force_init_update) v109_vz_init = v109_vz ;
      slope =  (v109_vz * -190.4) ;
      v109_vz_u = (slope * d) + v109_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v109_t1 ;
      force_init_update = False;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v109_v_u = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_voo = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v109!\n");
      exit(1);
    }
    break;
  case ( v109_t2 ):
    if (True == False) {;}
    else if  (v109_v >= (44.5)) {
      v109_vx_u = v109_vx ;
      v109_vy_u = v109_vy ;
      v109_vz_u = v109_vz ;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v109_t3 ;
      force_init_update = False;
    }
    else if  (v109_g <= (44.5)
               && v109_v < (44.5)) {
      v109_vx_u = v109_vx ;
      v109_vy_u = v109_vy ;
      v109_vz_u = v109_vz ;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v109_t1 ;
      force_init_update = False;
    }

    else if ( v109_v < (44.5)
               && v109_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v109_vx_init = v109_vx ;
      slope =  ((v109_vx * -23.6) + (777200.0 * v109_g)) ;
      v109_vx_u = (slope * d) + v109_vx ;
      if ((pstate != cstate) || force_init_update) v109_vy_init = v109_vy ;
      slope =  ((v109_vy * -45.5) + (58900.0 * v109_g)) ;
      v109_vy_u = (slope * d) + v109_vy ;
      if ((pstate != cstate) || force_init_update) v109_vz_init = v109_vz ;
      slope =  ((v109_vz * -12.9) + (276600.0 * v109_g)) ;
      v109_vz_u = (slope * d) + v109_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v109_t2 ;
      force_init_update = False;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v109_v_u = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_voo = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v109!\n");
      exit(1);
    }
    break;
  case ( v109_t3 ):
    if (True == False) {;}
    else if  (v109_v >= (131.1)) {
      v109_vx_u = v109_vx ;
      v109_vy_u = v109_vy ;
      v109_vz_u = v109_vz ;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v109_t4 ;
      force_init_update = False;
    }

    else if ( v109_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v109_vx_init = v109_vx ;
      slope =  (v109_vx * -6.9) ;
      v109_vx_u = (slope * d) + v109_vx ;
      if ((pstate != cstate) || force_init_update) v109_vy_init = v109_vy ;
      slope =  (v109_vy * 75.9) ;
      v109_vy_u = (slope * d) + v109_vy ;
      if ((pstate != cstate) || force_init_update) v109_vz_init = v109_vz ;
      slope =  (v109_vz * 6826.5) ;
      v109_vz_u = (slope * d) + v109_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v109_t3 ;
      force_init_update = False;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v109_v_u = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_voo = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v109!\n");
      exit(1);
    }
    break;
  case ( v109_t4 ):
    if (True == False) {;}
    else if  (v109_v <= (30.0)) {
      v109_vx_u = v109_vx ;
      v109_vy_u = v109_vy ;
      v109_vz_u = v109_vz ;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v109_t1 ;
      force_init_update = False;
    }

    else if ( v109_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v109_vx_init = v109_vx ;
      slope =  (v109_vx * -33.2) ;
      v109_vx_u = (slope * d) + v109_vx ;
      if ((pstate != cstate) || force_init_update) v109_vy_init = v109_vy ;
      slope =  ((v109_vy * 20.0) * v109_ft) ;
      v109_vy_u = (slope * d) + v109_vy ;
      if ((pstate != cstate) || force_init_update) v109_vz_init = v109_vz ;
      slope =  ((v109_vz * 2.0) * v109_ft) ;
      v109_vz_u = (slope * d) + v109_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v109_t4 ;
      force_init_update = False;
      v109_g_u = ((((((((((((v109_v_i_0 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v109_v_i_1 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v109_v_i_2 + (- ((v109_vx + (- v109_vy)) + v109_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.21566392641))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v109_v_u = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_voo = ((v109_vx + (- v109_vy)) + v109_vz) ;
      v109_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v109!\n");
      exit(1);
    }
    break;
  }
  v109_vx = v109_vx_u;
  v109_vy = v109_vy_u;
  v109_vz = v109_vz_u;
  v109_g = v109_g_u;
  v109_v = v109_v_u;
  v109_ft = v109_ft_u;
  v109_theta = v109_theta_u;
  v109_v_O = v109_v_O_u;
  return cstate;
}