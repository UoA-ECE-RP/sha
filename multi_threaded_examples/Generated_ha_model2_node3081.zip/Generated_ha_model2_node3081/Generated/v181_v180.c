#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double v181_v180_update_c1vd();
extern double v181_v180_update_c2vd();
extern double v181_v180_update_c1md();
extern double v181_v180_update_c2md();
extern double v181_v180_update_buffer_index(double,double,double,double);
extern double v181_v180_update_latch1(double,double);
extern double v181_v180_update_latch2(double,double);
extern double v181_v180_update_ocell1(double,double);
extern double v181_v180_update_ocell2(double,double);
double v181_v180_cell1_v;
double v181_v180_cell1_mode;
double v181_v180_cell2_v;
double v181_v180_cell2_mode;
double v181_v180_cell1_v_replay = 0.0;
double v181_v180_cell2_v_replay = 0.0;


static double  v181_v180_k  =  0.0 ,  v181_v180_cell1_mode_delayed  =  0.0 ,  v181_v180_cell2_mode_delayed  =  0.0 ,  v181_v180_from_cell  =  0.0 ,  v181_v180_cell1_replay_latch  =  0.0 ,  v181_v180_cell2_replay_latch  =  0.0 ,  v181_v180_cell1_v_delayed  =  0.0 ,  v181_v180_cell2_v_delayed  =  0.0 ,  v181_v180_wasted  =  0.0 ; //the continuous vars
static double  v181_v180_k_u , v181_v180_cell1_mode_delayed_u , v181_v180_cell2_mode_delayed_u , v181_v180_from_cell_u , v181_v180_cell1_replay_latch_u , v181_v180_cell2_replay_latch_u , v181_v180_cell1_v_delayed_u , v181_v180_cell2_v_delayed_u , v181_v180_wasted_u ; // and their updates
static double  v181_v180_k_init , v181_v180_cell1_mode_delayed_init , v181_v180_cell2_mode_delayed_init , v181_v180_from_cell_init , v181_v180_cell1_replay_latch_init , v181_v180_cell2_replay_latch_init , v181_v180_cell1_v_delayed_init , v181_v180_cell2_v_delayed_init , v181_v180_wasted_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v181_v180_idle , v181_v180_annhilate , v181_v180_previous_drection1 , v181_v180_previous_direction2 , v181_v180_wait_cell1 , v181_v180_replay_cell1 , v181_v180_replay_cell2 , v181_v180_wait_cell2 }; // state declarations

enum states v181_v180 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v181_v180_idle ):
    if (True == False) {;}
    else if  (v181_v180_cell2_mode == (2.0) && (v181_v180_cell1_mode != (2.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_previous_direction2 ;
      force_init_update = False;
    }
    else if  (v181_v180_cell1_mode == (2.0) && (v181_v180_cell2_mode != (2.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_previous_drection1 ;
      force_init_update = False;
    }
    else if  (v181_v180_cell1_mode == (2.0) && (v181_v180_cell2_mode == (2.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_idle ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_annhilate ):
    if (True == False) {;}
    else if  (v181_v180_cell1_mode != (2.0) && (v181_v180_cell2_mode != (2.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_from_cell_u = 0 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_previous_drection1 ):
    if (True == False) {;}
    else if  (v181_v180_from_cell == (1.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (0.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (2.0) && (v181_v180_cell2_mode_delayed == (0.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_wait_cell1 ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (2.0) && (v181_v180_cell2_mode_delayed != (0.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_previous_drection1 ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_previous_direction2 ):
    if (True == False) {;}
    else if  (v181_v180_from_cell == (1.0) && (v181_v180_cell1_mode_delayed != (0.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (2.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (0.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_replay_cell1 ;
      force_init_update = False;
    }
    else if  (v181_v180_from_cell == (1.0) && (v181_v180_cell1_mode_delayed == (0.0))) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_replay_cell1 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_previous_direction2 ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_wait_cell1 ):
    if (True == False) {;}
    else if  (v181_v180_cell2_mode == (2.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
    }
    else if  (v181_v180_k >= (68.25177585109999)) {
      v181_v180_from_cell_u = 1 ;
      v181_v180_cell1_replay_latch_u = 1 ;
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_replay_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_wait_cell1 ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_replay_cell1 ):
    if (True == False) {;}
    else if  (v181_v180_cell1_mode == (2.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_annhilate ;
      force_init_update = False;
    }
    else if  (v181_v180_k >= (68.25177585109999)) {
      v181_v180_from_cell_u = 2 ;
      v181_v180_cell2_replay_latch_u = 1 ;
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_wait_cell2 ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_replay_cell1 ;
      force_init_update = False;
      v181_v180_cell1_replay_latch_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_replay_cell2 ):
    if (True == False) {;}
    else if  (v181_v180_k >= (10.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_replay_cell2 ;
      force_init_update = False;
      v181_v180_cell2_replay_latch_u = 1 ;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  case ( v181_v180_wait_cell2 ):
    if (True == False) {;}
    else if  (v181_v180_k >= (10.0)) {
      v181_v180_k_u = 1 ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
      cstate =  v181_v180_idle ;
      force_init_update = False;
    }

    else if ( True     ) {
      if ((pstate != cstate) || force_init_update) v181_v180_k_init = v181_v180_k ;
      slope =  1 ;
      v181_v180_k_u = (slope * d) + v181_v180_k ;
      /* Possible Saturation */
      
      
      
      cstate =  v181_v180_wait_cell2 ;
      force_init_update = False;
      v181_v180_cell1_v_delayed_u = v181_v180_update_c1vd () ;
      v181_v180_cell2_v_delayed_u = v181_v180_update_c2vd () ;
      v181_v180_cell1_mode_delayed_u = v181_v180_update_c1md () ;
      v181_v180_cell2_mode_delayed_u = v181_v180_update_c2md () ;
      v181_v180_wasted_u = v181_v180_update_buffer_index (v181_v180_cell1_v,v181_v180_cell2_v,v181_v180_cell1_mode,v181_v180_cell2_mode) ;
      v181_v180_cell1_replay_latch_u = v181_v180_update_latch1 (v181_v180_cell1_mode_delayed,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_replay_latch_u = v181_v180_update_latch2 (v181_v180_cell2_mode_delayed,v181_v180_cell2_replay_latch_u) ;
      v181_v180_cell1_v_replay = v181_v180_update_ocell1 (v181_v180_cell1_v_delayed_u,v181_v180_cell1_replay_latch_u) ;
      v181_v180_cell2_v_replay = v181_v180_update_ocell2 (v181_v180_cell2_v_delayed_u,v181_v180_cell2_replay_latch_u) ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v181_v180!\n");
      exit(1);
    }
    break;
  }
  v181_v180_k = v181_v180_k_u;
  v181_v180_cell1_mode_delayed = v181_v180_cell1_mode_delayed_u;
  v181_v180_cell2_mode_delayed = v181_v180_cell2_mode_delayed_u;
  v181_v180_from_cell = v181_v180_from_cell_u;
  v181_v180_cell1_replay_latch = v181_v180_cell1_replay_latch_u;
  v181_v180_cell2_replay_latch = v181_v180_cell2_replay_latch_u;
  v181_v180_cell1_v_delayed = v181_v180_cell1_v_delayed_u;
  v181_v180_cell2_v_delayed = v181_v180_cell2_v_delayed_u;
  v181_v180_wasted = v181_v180_wasted_u;
  return cstate;
}