#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v141_v_i_0;
double v141_v_i_1;
double v141_v_i_2;
double v141_v_i_3;
double v141_voo = 0.0;
double v141_state = 0.0;


static double  v141_vx  =  0 ,  v141_vy  =  0 ,  v141_vz  =  0 ,  v141_g  =  0 ,  v141_v  =  0 ,  v141_ft  =  0 ,  v141_theta  =  0 ,  v141_v_O  =  0 ; //the continuous vars
static double  v141_vx_u , v141_vy_u , v141_vz_u , v141_g_u , v141_v_u , v141_ft_u , v141_theta_u , v141_v_O_u ; // and their updates
static double  v141_vx_init , v141_vy_init , v141_vz_init , v141_g_init , v141_v_init , v141_ft_init , v141_theta_init , v141_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v141_t1 , v141_t2 , v141_t3 , v141_t4 }; // state declarations

enum states v141 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v141_t1 ):
    if (True == False) {;}
    else if  (v141_g > (44.5)) {
      v141_vx_u = (0.3 * v141_v) ;
      v141_vy_u = 0 ;
      v141_vz_u = (0.7 * v141_v) ;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      v141_theta_u = (v141_v / 30.0) ;
      v141_v_O_u = (131.1 + (- (80.1 * pow ( ((v141_v / 30.0)) , (0.5) )))) ;
      v141_ft_u = f (v141_theta,4.0e-2) ;
      cstate =  v141_t2 ;
      force_init_update = False;
    }

    else if ( v141_v <= (44.5)
               && v141_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v141_vx_init = v141_vx ;
      slope =  (v141_vx * -8.7) ;
      v141_vx_u = (slope * d) + v141_vx ;
      if ((pstate != cstate) || force_init_update) v141_vy_init = v141_vy ;
      slope =  (v141_vy * -190.9) ;
      v141_vy_u = (slope * d) + v141_vy ;
      if ((pstate != cstate) || force_init_update) v141_vz_init = v141_vz ;
      slope =  (v141_vz * -190.4) ;
      v141_vz_u = (slope * d) + v141_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v141_t1 ;
      force_init_update = False;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      v141_v_u = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_voo = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v141!\n");
      exit(1);
    }
    break;
  case ( v141_t2 ):
    if (True == False) {;}
    else if  (v141_v >= (44.5)) {
      v141_vx_u = v141_vx ;
      v141_vy_u = v141_vy ;
      v141_vz_u = v141_vz ;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v141_t3 ;
      force_init_update = False;
    }
    else if  (v141_g <= (44.5)
               && v141_v < (44.5)) {
      v141_vx_u = v141_vx ;
      v141_vy_u = v141_vy ;
      v141_vz_u = v141_vz ;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v141_t1 ;
      force_init_update = False;
    }

    else if ( v141_v < (44.5)
               && v141_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v141_vx_init = v141_vx ;
      slope =  ((v141_vx * -23.6) + (777200.0 * v141_g)) ;
      v141_vx_u = (slope * d) + v141_vx ;
      if ((pstate != cstate) || force_init_update) v141_vy_init = v141_vy ;
      slope =  ((v141_vy * -45.5) + (58900.0 * v141_g)) ;
      v141_vy_u = (slope * d) + v141_vy ;
      if ((pstate != cstate) || force_init_update) v141_vz_init = v141_vz ;
      slope =  ((v141_vz * -12.9) + (276600.0 * v141_g)) ;
      v141_vz_u = (slope * d) + v141_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v141_t2 ;
      force_init_update = False;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      v141_v_u = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_voo = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v141!\n");
      exit(1);
    }
    break;
  case ( v141_t3 ):
    if (True == False) {;}
    else if  (v141_v >= (131.1)) {
      v141_vx_u = v141_vx ;
      v141_vy_u = v141_vy ;
      v141_vz_u = v141_vz ;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v141_t4 ;
      force_init_update = False;
    }

    else if ( v141_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v141_vx_init = v141_vx ;
      slope =  (v141_vx * -6.9) ;
      v141_vx_u = (slope * d) + v141_vx ;
      if ((pstate != cstate) || force_init_update) v141_vy_init = v141_vy ;
      slope =  (v141_vy * 75.9) ;
      v141_vy_u = (slope * d) + v141_vy ;
      if ((pstate != cstate) || force_init_update) v141_vz_init = v141_vz ;
      slope =  (v141_vz * 6826.5) ;
      v141_vz_u = (slope * d) + v141_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v141_t3 ;
      force_init_update = False;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      v141_v_u = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_voo = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v141!\n");
      exit(1);
    }
    break;
  case ( v141_t4 ):
    if (True == False) {;}
    else if  (v141_v <= (30.0)) {
      v141_vx_u = v141_vx ;
      v141_vy_u = v141_vy ;
      v141_vz_u = v141_vz ;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v141_t1 ;
      force_init_update = False;
    }

    else if ( v141_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v141_vx_init = v141_vx ;
      slope =  (v141_vx * -33.2) ;
      v141_vx_u = (slope * d) + v141_vx ;
      if ((pstate != cstate) || force_init_update) v141_vy_init = v141_vy ;
      slope =  ((v141_vy * 20.0) * v141_ft) ;
      v141_vy_u = (slope * d) + v141_vy ;
      if ((pstate != cstate) || force_init_update) v141_vz_init = v141_vz ;
      slope =  ((v141_vz * 2.0) * v141_ft) ;
      v141_vz_u = (slope * d) + v141_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v141_t4 ;
      force_init_update = False;
      v141_g_u = ((((((((((((v141_v_i_0 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.17831991174)) + ((((v141_v_i_1 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v141_v_i_2 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.22844078845))) + ((((v141_v_i_3 + (- ((v141_vx + (- v141_vy)) + v141_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10239842435))) + 0) + 0) + 0) + 0) + 0) ;
      v141_v_u = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_voo = ((v141_vx + (- v141_vy)) + v141_vz) ;
      v141_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v141!\n");
      exit(1);
    }
    break;
  }
  v141_vx = v141_vx_u;
  v141_vy = v141_vy_u;
  v141_vz = v141_vz_u;
  v141_g = v141_g_u;
  v141_v = v141_v_u;
  v141_ft = v141_ft_u;
  v141_theta = v141_theta_u;
  v141_v_O = v141_v_O_u;
  return cstate;
}