#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v134_v_i_0;
double v134_v_i_1;
double v134_v_i_2;
double v134_voo = 0.0;
double v134_state = 0.0;


static double  v134_vx  =  0 ,  v134_vy  =  0 ,  v134_vz  =  0 ,  v134_g  =  0 ,  v134_v  =  0 ,  v134_ft  =  0 ,  v134_theta  =  0 ,  v134_v_O  =  0 ; //the continuous vars
static double  v134_vx_u , v134_vy_u , v134_vz_u , v134_g_u , v134_v_u , v134_ft_u , v134_theta_u , v134_v_O_u ; // and their updates
static double  v134_vx_init , v134_vy_init , v134_vz_init , v134_g_init , v134_v_init , v134_ft_init , v134_theta_init , v134_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v134_t1 , v134_t2 , v134_t3 , v134_t4 }; // state declarations

enum states v134 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v134_t1 ):
    if (True == False) {;}
    else if  (v134_g > (44.5)) {
      v134_vx_u = (0.3 * v134_v) ;
      v134_vy_u = 0 ;
      v134_vz_u = (0.7 * v134_v) ;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v134_theta_u = (v134_v / 30.0) ;
      v134_v_O_u = (131.1 + (- (80.1 * pow ( ((v134_v / 30.0)) , (0.5) )))) ;
      v134_ft_u = f (v134_theta,4.0e-2) ;
      cstate =  v134_t2 ;
      force_init_update = False;
    }

    else if ( v134_v <= (44.5)
               && v134_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v134_vx_init = v134_vx ;
      slope =  (v134_vx * -8.7) ;
      v134_vx_u = (slope * d) + v134_vx ;
      if ((pstate != cstate) || force_init_update) v134_vy_init = v134_vy ;
      slope =  (v134_vy * -190.9) ;
      v134_vy_u = (slope * d) + v134_vy ;
      if ((pstate != cstate) || force_init_update) v134_vz_init = v134_vz ;
      slope =  (v134_vz * -190.4) ;
      v134_vz_u = (slope * d) + v134_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v134_t1 ;
      force_init_update = False;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v134_v_u = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_voo = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v134!\n");
      exit(1);
    }
    break;
  case ( v134_t2 ):
    if (True == False) {;}
    else if  (v134_v >= (44.5)) {
      v134_vx_u = v134_vx ;
      v134_vy_u = v134_vy ;
      v134_vz_u = v134_vz ;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v134_t3 ;
      force_init_update = False;
    }
    else if  (v134_g <= (44.5)
               && v134_v < (44.5)) {
      v134_vx_u = v134_vx ;
      v134_vy_u = v134_vy ;
      v134_vz_u = v134_vz ;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v134_t1 ;
      force_init_update = False;
    }

    else if ( v134_v < (44.5)
               && v134_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v134_vx_init = v134_vx ;
      slope =  ((v134_vx * -23.6) + (777200.0 * v134_g)) ;
      v134_vx_u = (slope * d) + v134_vx ;
      if ((pstate != cstate) || force_init_update) v134_vy_init = v134_vy ;
      slope =  ((v134_vy * -45.5) + (58900.0 * v134_g)) ;
      v134_vy_u = (slope * d) + v134_vy ;
      if ((pstate != cstate) || force_init_update) v134_vz_init = v134_vz ;
      slope =  ((v134_vz * -12.9) + (276600.0 * v134_g)) ;
      v134_vz_u = (slope * d) + v134_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v134_t2 ;
      force_init_update = False;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v134_v_u = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_voo = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v134!\n");
      exit(1);
    }
    break;
  case ( v134_t3 ):
    if (True == False) {;}
    else if  (v134_v >= (131.1)) {
      v134_vx_u = v134_vx ;
      v134_vy_u = v134_vy ;
      v134_vz_u = v134_vz ;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v134_t4 ;
      force_init_update = False;
    }

    else if ( v134_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v134_vx_init = v134_vx ;
      slope =  (v134_vx * -6.9) ;
      v134_vx_u = (slope * d) + v134_vx ;
      if ((pstate != cstate) || force_init_update) v134_vy_init = v134_vy ;
      slope =  (v134_vy * 75.9) ;
      v134_vy_u = (slope * d) + v134_vy ;
      if ((pstate != cstate) || force_init_update) v134_vz_init = v134_vz ;
      slope =  (v134_vz * 6826.5) ;
      v134_vz_u = (slope * d) + v134_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v134_t3 ;
      force_init_update = False;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v134_v_u = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_voo = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v134!\n");
      exit(1);
    }
    break;
  case ( v134_t4 ):
    if (True == False) {;}
    else if  (v134_v <= (30.0)) {
      v134_vx_u = v134_vx ;
      v134_vy_u = v134_vy ;
      v134_vz_u = v134_vz ;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v134_t1 ;
      force_init_update = False;
    }

    else if ( v134_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v134_vx_init = v134_vx ;
      slope =  (v134_vx * -33.2) ;
      v134_vx_u = (slope * d) + v134_vx ;
      if ((pstate != cstate) || force_init_update) v134_vy_init = v134_vy ;
      slope =  ((v134_vy * 20.0) * v134_ft) ;
      v134_vy_u = (slope * d) + v134_vy ;
      if ((pstate != cstate) || force_init_update) v134_vz_init = v134_vz ;
      slope =  ((v134_vz * 2.0) * v134_ft) ;
      v134_vz_u = (slope * d) + v134_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v134_t4 ;
      force_init_update = False;
      v134_g_u = ((((((((((((v134_v_i_0 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.85035074487)) + ((((v134_v_i_1 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.06248874992))) + ((((v134_v_i_2 + (- ((v134_vx + (- v134_vy)) + v134_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.33803268967))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v134_v_u = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_voo = ((v134_vx + (- v134_vy)) + v134_vz) ;
      v134_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v134!\n");
      exit(1);
    }
    break;
  }
  v134_vx = v134_vx_u;
  v134_vy = v134_vy_u;
  v134_vz = v134_vz_u;
  v134_g = v134_g_u;
  v134_v = v134_v_u;
  v134_ft = v134_ft_u;
  v134_theta = v134_theta_u;
  v134_v_O = v134_v_O_u;
  return cstate;
}