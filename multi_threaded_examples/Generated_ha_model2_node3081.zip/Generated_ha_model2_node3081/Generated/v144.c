#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v144_v_i_0;
double v144_v_i_1;
double v144_v_i_2;
double v144_v_i_3;
double v144_voo = 0.0;
double v144_state = 0.0;


static double  v144_vx  =  0 ,  v144_vy  =  0 ,  v144_vz  =  0 ,  v144_g  =  0 ,  v144_v  =  0 ,  v144_ft  =  0 ,  v144_theta  =  0 ,  v144_v_O  =  0 ; //the continuous vars
static double  v144_vx_u , v144_vy_u , v144_vz_u , v144_g_u , v144_v_u , v144_ft_u , v144_theta_u , v144_v_O_u ; // and their updates
static double  v144_vx_init , v144_vy_init , v144_vz_init , v144_g_init , v144_v_init , v144_ft_init , v144_theta_init , v144_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v144_t1 , v144_t2 , v144_t3 , v144_t4 }; // state declarations

enum states v144 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v144_t1 ):
    if (True == False) {;}
    else if  (v144_g > (44.5)) {
      v144_vx_u = (0.3 * v144_v) ;
      v144_vy_u = 0 ;
      v144_vz_u = (0.7 * v144_v) ;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      v144_theta_u = (v144_v / 30.0) ;
      v144_v_O_u = (131.1 + (- (80.1 * pow ( ((v144_v / 30.0)) , (0.5) )))) ;
      v144_ft_u = f (v144_theta,4.0e-2) ;
      cstate =  v144_t2 ;
      force_init_update = False;
    }

    else if ( v144_v <= (44.5)
               && v144_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v144_vx_init = v144_vx ;
      slope =  (v144_vx * -8.7) ;
      v144_vx_u = (slope * d) + v144_vx ;
      if ((pstate != cstate) || force_init_update) v144_vy_init = v144_vy ;
      slope =  (v144_vy * -190.9) ;
      v144_vy_u = (slope * d) + v144_vy ;
      if ((pstate != cstate) || force_init_update) v144_vz_init = v144_vz ;
      slope =  (v144_vz * -190.4) ;
      v144_vz_u = (slope * d) + v144_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v144_t1 ;
      force_init_update = False;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      v144_v_u = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_voo = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v144!\n");
      exit(1);
    }
    break;
  case ( v144_t2 ):
    if (True == False) {;}
    else if  (v144_v >= (44.5)) {
      v144_vx_u = v144_vx ;
      v144_vy_u = v144_vy ;
      v144_vz_u = v144_vz ;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v144_t3 ;
      force_init_update = False;
    }
    else if  (v144_g <= (44.5)
               && v144_v < (44.5)) {
      v144_vx_u = v144_vx ;
      v144_vy_u = v144_vy ;
      v144_vz_u = v144_vz ;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v144_t1 ;
      force_init_update = False;
    }

    else if ( v144_v < (44.5)
               && v144_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v144_vx_init = v144_vx ;
      slope =  ((v144_vx * -23.6) + (777200.0 * v144_g)) ;
      v144_vx_u = (slope * d) + v144_vx ;
      if ((pstate != cstate) || force_init_update) v144_vy_init = v144_vy ;
      slope =  ((v144_vy * -45.5) + (58900.0 * v144_g)) ;
      v144_vy_u = (slope * d) + v144_vy ;
      if ((pstate != cstate) || force_init_update) v144_vz_init = v144_vz ;
      slope =  ((v144_vz * -12.9) + (276600.0 * v144_g)) ;
      v144_vz_u = (slope * d) + v144_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v144_t2 ;
      force_init_update = False;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      v144_v_u = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_voo = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v144!\n");
      exit(1);
    }
    break;
  case ( v144_t3 ):
    if (True == False) {;}
    else if  (v144_v >= (131.1)) {
      v144_vx_u = v144_vx ;
      v144_vy_u = v144_vy ;
      v144_vz_u = v144_vz ;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v144_t4 ;
      force_init_update = False;
    }

    else if ( v144_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v144_vx_init = v144_vx ;
      slope =  (v144_vx * -6.9) ;
      v144_vx_u = (slope * d) + v144_vx ;
      if ((pstate != cstate) || force_init_update) v144_vy_init = v144_vy ;
      slope =  (v144_vy * 75.9) ;
      v144_vy_u = (slope * d) + v144_vy ;
      if ((pstate != cstate) || force_init_update) v144_vz_init = v144_vz ;
      slope =  (v144_vz * 6826.5) ;
      v144_vz_u = (slope * d) + v144_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v144_t3 ;
      force_init_update = False;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      v144_v_u = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_voo = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v144!\n");
      exit(1);
    }
    break;
  case ( v144_t4 ):
    if (True == False) {;}
    else if  (v144_v <= (30.0)) {
      v144_vx_u = v144_vx ;
      v144_vy_u = v144_vy ;
      v144_vz_u = v144_vz ;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v144_t1 ;
      force_init_update = False;
    }

    else if ( v144_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v144_vx_init = v144_vx ;
      slope =  (v144_vx * -33.2) ;
      v144_vx_u = (slope * d) + v144_vx ;
      if ((pstate != cstate) || force_init_update) v144_vy_init = v144_vy ;
      slope =  ((v144_vy * 20.0) * v144_ft) ;
      v144_vy_u = (slope * d) + v144_vy ;
      if ((pstate != cstate) || force_init_update) v144_vz_init = v144_vz ;
      slope =  ((v144_vz * 2.0) * v144_ft) ;
      v144_vz_u = (slope * d) + v144_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v144_t4 ;
      force_init_update = False;
      v144_g_u = ((((((((((((v144_v_i_0 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.68203803392)) + ((((v144_v_i_1 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.23427949443))) + ((((v144_v_i_2 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.90610648799))) + ((((v144_v_i_3 + (- ((v144_vx + (- v144_vy)) + v144_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.77454314938))) + 0) + 0) + 0) + 0) + 0) ;
      v144_v_u = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_voo = ((v144_vx + (- v144_vy)) + v144_vz) ;
      v144_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v144!\n");
      exit(1);
    }
    break;
  }
  v144_vx = v144_vx_u;
  v144_vy = v144_vy_u;
  v144_vz = v144_vz_u;
  v144_g = v144_g_u;
  v144_v = v144_v_u;
  v144_ft = v144_ft_u;
  v144_theta = v144_theta_u;
  v144_v_O = v144_v_O_u;
  return cstate;
}