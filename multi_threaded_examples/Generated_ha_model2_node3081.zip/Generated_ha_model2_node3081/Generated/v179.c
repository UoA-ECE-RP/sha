#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v179_v_i_0;
double v179_v_i_1;
double v179_v_i_2;
double v179_v_i_3;
double v179_voo = 0.0;
double v179_state = 0.0;


static double  v179_vx  =  0 ,  v179_vy  =  0 ,  v179_vz  =  0 ,  v179_g  =  0 ,  v179_v  =  0 ,  v179_ft  =  0 ,  v179_theta  =  0 ,  v179_v_O  =  0 ; //the continuous vars
static double  v179_vx_u , v179_vy_u , v179_vz_u , v179_g_u , v179_v_u , v179_ft_u , v179_theta_u , v179_v_O_u ; // and their updates
static double  v179_vx_init , v179_vy_init , v179_vz_init , v179_g_init , v179_v_init , v179_ft_init , v179_theta_init , v179_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v179_t1 , v179_t2 , v179_t3 , v179_t4 }; // state declarations

enum states v179 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v179_t1 ):
    if (True == False) {;}
    else if  (v179_g > (44.5)) {
      v179_vx_u = (0.3 * v179_v) ;
      v179_vy_u = 0 ;
      v179_vz_u = (0.7 * v179_v) ;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      v179_theta_u = (v179_v / 30.0) ;
      v179_v_O_u = (131.1 + (- (80.1 * pow ( ((v179_v / 30.0)) , (0.5) )))) ;
      v179_ft_u = f (v179_theta,4.0e-2) ;
      cstate =  v179_t2 ;
      force_init_update = False;
    }

    else if ( v179_v <= (44.5)
               && v179_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v179_vx_init = v179_vx ;
      slope =  (v179_vx * -8.7) ;
      v179_vx_u = (slope * d) + v179_vx ;
      if ((pstate != cstate) || force_init_update) v179_vy_init = v179_vy ;
      slope =  (v179_vy * -190.9) ;
      v179_vy_u = (slope * d) + v179_vy ;
      if ((pstate != cstate) || force_init_update) v179_vz_init = v179_vz ;
      slope =  (v179_vz * -190.4) ;
      v179_vz_u = (slope * d) + v179_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v179_t1 ;
      force_init_update = False;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      v179_v_u = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_voo = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179!\n");
      exit(1);
    }
    break;
  case ( v179_t2 ):
    if (True == False) {;}
    else if  (v179_v >= (44.5)) {
      v179_vx_u = v179_vx ;
      v179_vy_u = v179_vy ;
      v179_vz_u = v179_vz ;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v179_t3 ;
      force_init_update = False;
    }
    else if  (v179_g <= (44.5)
               && v179_v < (44.5)) {
      v179_vx_u = v179_vx ;
      v179_vy_u = v179_vy ;
      v179_vz_u = v179_vz ;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v179_t1 ;
      force_init_update = False;
    }

    else if ( v179_v < (44.5)
               && v179_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v179_vx_init = v179_vx ;
      slope =  ((v179_vx * -23.6) + (777200.0 * v179_g)) ;
      v179_vx_u = (slope * d) + v179_vx ;
      if ((pstate != cstate) || force_init_update) v179_vy_init = v179_vy ;
      slope =  ((v179_vy * -45.5) + (58900.0 * v179_g)) ;
      v179_vy_u = (slope * d) + v179_vy ;
      if ((pstate != cstate) || force_init_update) v179_vz_init = v179_vz ;
      slope =  ((v179_vz * -12.9) + (276600.0 * v179_g)) ;
      v179_vz_u = (slope * d) + v179_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v179_t2 ;
      force_init_update = False;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      v179_v_u = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_voo = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179!\n");
      exit(1);
    }
    break;
  case ( v179_t3 ):
    if (True == False) {;}
    else if  (v179_v >= (131.1)) {
      v179_vx_u = v179_vx ;
      v179_vy_u = v179_vy ;
      v179_vz_u = v179_vz ;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v179_t4 ;
      force_init_update = False;
    }

    else if ( v179_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v179_vx_init = v179_vx ;
      slope =  (v179_vx * -6.9) ;
      v179_vx_u = (slope * d) + v179_vx ;
      if ((pstate != cstate) || force_init_update) v179_vy_init = v179_vy ;
      slope =  (v179_vy * 75.9) ;
      v179_vy_u = (slope * d) + v179_vy ;
      if ((pstate != cstate) || force_init_update) v179_vz_init = v179_vz ;
      slope =  (v179_vz * 6826.5) ;
      v179_vz_u = (slope * d) + v179_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v179_t3 ;
      force_init_update = False;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      v179_v_u = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_voo = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179!\n");
      exit(1);
    }
    break;
  case ( v179_t4 ):
    if (True == False) {;}
    else if  (v179_v <= (30.0)) {
      v179_vx_u = v179_vx ;
      v179_vy_u = v179_vy ;
      v179_vz_u = v179_vz ;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v179_t1 ;
      force_init_update = False;
    }

    else if ( v179_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v179_vx_init = v179_vx ;
      slope =  (v179_vx * -33.2) ;
      v179_vx_u = (slope * d) + v179_vx ;
      if ((pstate != cstate) || force_init_update) v179_vy_init = v179_vy ;
      slope =  ((v179_vy * 20.0) * v179_ft) ;
      v179_vy_u = (slope * d) + v179_vy ;
      if ((pstate != cstate) || force_init_update) v179_vz_init = v179_vz ;
      slope =  ((v179_vz * 2.0) * v179_ft) ;
      v179_vz_u = (slope * d) + v179_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v179_t4 ;
      force_init_update = False;
      v179_g_u = ((((((((((((v179_v_i_0 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1)) + ((((v179_v_i_1 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.1))) + ((((v179_v_i_2 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 4.633603))) + ((((v179_v_i_3 + (- ((v179_vx + (- v179_vy)) + v179_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.15438865185))) + 0) + 0) + 0) + 0) + 0) ;
      v179_v_u = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_voo = ((v179_vx + (- v179_vy)) + v179_vz) ;
      v179_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v179!\n");
      exit(1);
    }
    break;
  }
  v179_vx = v179_vx_u;
  v179_vy = v179_vy_u;
  v179_vz = v179_vz_u;
  v179_g = v179_g_u;
  v179_v = v179_v_u;
  v179_ft = v179_ft_u;
  v179_theta = v179_theta_u;
  v179_v_O = v179_v_O_u;
  return cstate;
}