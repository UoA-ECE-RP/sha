#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v122_v_i_0;
double v122_v_i_1;
double v122_v_i_2;
double v122_v_i_3;
double v122_voo = 0.0;
double v122_state = 0.0;


static double  v122_vx  =  0 ,  v122_vy  =  0 ,  v122_vz  =  0 ,  v122_g  =  0 ,  v122_v  =  0 ,  v122_ft  =  0 ,  v122_theta  =  0 ,  v122_v_O  =  0 ; //the continuous vars
static double  v122_vx_u , v122_vy_u , v122_vz_u , v122_g_u , v122_v_u , v122_ft_u , v122_theta_u , v122_v_O_u ; // and their updates
static double  v122_vx_init , v122_vy_init , v122_vz_init , v122_g_init , v122_v_init , v122_ft_init , v122_theta_init , v122_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v122_t1 , v122_t2 , v122_t3 , v122_t4 }; // state declarations

enum states v122 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v122_t1 ):
    if (True == False) {;}
    else if  (v122_g > (44.5)) {
      v122_vx_u = (0.3 * v122_v) ;
      v122_vy_u = 0 ;
      v122_vz_u = (0.7 * v122_v) ;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      v122_theta_u = (v122_v / 30.0) ;
      v122_v_O_u = (131.1 + (- (80.1 * pow ( ((v122_v / 30.0)) , (0.5) )))) ;
      v122_ft_u = f (v122_theta,4.0e-2) ;
      cstate =  v122_t2 ;
      force_init_update = False;
    }

    else if ( v122_v <= (44.5)
               && v122_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v122_vx_init = v122_vx ;
      slope =  (v122_vx * -8.7) ;
      v122_vx_u = (slope * d) + v122_vx ;
      if ((pstate != cstate) || force_init_update) v122_vy_init = v122_vy ;
      slope =  (v122_vy * -190.9) ;
      v122_vy_u = (slope * d) + v122_vy ;
      if ((pstate != cstate) || force_init_update) v122_vz_init = v122_vz ;
      slope =  (v122_vz * -190.4) ;
      v122_vz_u = (slope * d) + v122_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v122_t1 ;
      force_init_update = False;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      v122_v_u = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_voo = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v122!\n");
      exit(1);
    }
    break;
  case ( v122_t2 ):
    if (True == False) {;}
    else if  (v122_v >= (44.5)) {
      v122_vx_u = v122_vx ;
      v122_vy_u = v122_vy ;
      v122_vz_u = v122_vz ;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v122_t3 ;
      force_init_update = False;
    }
    else if  (v122_g <= (44.5)
               && v122_v < (44.5)) {
      v122_vx_u = v122_vx ;
      v122_vy_u = v122_vy ;
      v122_vz_u = v122_vz ;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v122_t1 ;
      force_init_update = False;
    }

    else if ( v122_v < (44.5)
               && v122_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v122_vx_init = v122_vx ;
      slope =  ((v122_vx * -23.6) + (777200.0 * v122_g)) ;
      v122_vx_u = (slope * d) + v122_vx ;
      if ((pstate != cstate) || force_init_update) v122_vy_init = v122_vy ;
      slope =  ((v122_vy * -45.5) + (58900.0 * v122_g)) ;
      v122_vy_u = (slope * d) + v122_vy ;
      if ((pstate != cstate) || force_init_update) v122_vz_init = v122_vz ;
      slope =  ((v122_vz * -12.9) + (276600.0 * v122_g)) ;
      v122_vz_u = (slope * d) + v122_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v122_t2 ;
      force_init_update = False;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      v122_v_u = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_voo = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v122!\n");
      exit(1);
    }
    break;
  case ( v122_t3 ):
    if (True == False) {;}
    else if  (v122_v >= (131.1)) {
      v122_vx_u = v122_vx ;
      v122_vy_u = v122_vy ;
      v122_vz_u = v122_vz ;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v122_t4 ;
      force_init_update = False;
    }

    else if ( v122_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v122_vx_init = v122_vx ;
      slope =  (v122_vx * -6.9) ;
      v122_vx_u = (slope * d) + v122_vx ;
      if ((pstate != cstate) || force_init_update) v122_vy_init = v122_vy ;
      slope =  (v122_vy * 75.9) ;
      v122_vy_u = (slope * d) + v122_vy ;
      if ((pstate != cstate) || force_init_update) v122_vz_init = v122_vz ;
      slope =  (v122_vz * 6826.5) ;
      v122_vz_u = (slope * d) + v122_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v122_t3 ;
      force_init_update = False;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      v122_v_u = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_voo = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v122!\n");
      exit(1);
    }
    break;
  case ( v122_t4 ):
    if (True == False) {;}
    else if  (v122_v <= (30.0)) {
      v122_vx_u = v122_vx ;
      v122_vy_u = v122_vy ;
      v122_vz_u = v122_vz ;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v122_t1 ;
      force_init_update = False;
    }

    else if ( v122_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v122_vx_init = v122_vx ;
      slope =  (v122_vx * -33.2) ;
      v122_vx_u = (slope * d) + v122_vx ;
      if ((pstate != cstate) || force_init_update) v122_vy_init = v122_vy ;
      slope =  ((v122_vy * 20.0) * v122_ft) ;
      v122_vy_u = (slope * d) + v122_vy ;
      if ((pstate != cstate) || force_init_update) v122_vz_init = v122_vz ;
      slope =  ((v122_vz * 2.0) * v122_ft) ;
      v122_vz_u = (slope * d) + v122_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v122_t4 ;
      force_init_update = False;
      v122_g_u = ((((((((((((v122_v_i_0 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10442100768)) + ((((v122_v_i_1 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 0.985510277289))) + ((((v122_v_i_2 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.7001678788))) + ((((v122_v_i_3 + (- ((v122_vx + (- v122_vy)) + v122_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.08167579066))) + 0) + 0) + 0) + 0) + 0) ;
      v122_v_u = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_voo = ((v122_vx + (- v122_vy)) + v122_vz) ;
      v122_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v122!\n");
      exit(1);
    }
    break;
  }
  v122_vx = v122_vx_u;
  v122_vy = v122_vy_u;
  v122_vz = v122_vz_u;
  v122_g = v122_g_u;
  v122_v = v122_v_u;
  v122_ft = v122_ft_u;
  v122_theta = v122_theta_u;
  v122_v_O = v122_v_O_u;
  return cstate;
}