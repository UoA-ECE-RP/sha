#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v114_v_i_0;
double v114_v_i_1;
double v114_v_i_2;
double v114_v_i_3;
double v114_voo = 0.0;
double v114_state = 0.0;


static double  v114_vx  =  0 ,  v114_vy  =  0 ,  v114_vz  =  0 ,  v114_g  =  0 ,  v114_v  =  0 ,  v114_ft  =  0 ,  v114_theta  =  0 ,  v114_v_O  =  0 ; //the continuous vars
static double  v114_vx_u , v114_vy_u , v114_vz_u , v114_g_u , v114_v_u , v114_ft_u , v114_theta_u , v114_v_O_u ; // and their updates
static double  v114_vx_init , v114_vy_init , v114_vz_init , v114_g_init , v114_v_init , v114_ft_init , v114_theta_init , v114_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v114_t1 , v114_t2 , v114_t3 , v114_t4 }; // state declarations

enum states v114 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v114_t1 ):
    if (True == False) {;}
    else if  (v114_g > (44.5)) {
      v114_vx_u = (0.3 * v114_v) ;
      v114_vy_u = 0 ;
      v114_vz_u = (0.7 * v114_v) ;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      v114_theta_u = (v114_v / 30.0) ;
      v114_v_O_u = (131.1 + (- (80.1 * pow ( ((v114_v / 30.0)) , (0.5) )))) ;
      v114_ft_u = f (v114_theta,4.0e-2) ;
      cstate =  v114_t2 ;
      force_init_update = False;
    }

    else if ( v114_v <= (44.5)
               && v114_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v114_vx_init = v114_vx ;
      slope =  (v114_vx * -8.7) ;
      v114_vx_u = (slope * d) + v114_vx ;
      if ((pstate != cstate) || force_init_update) v114_vy_init = v114_vy ;
      slope =  (v114_vy * -190.9) ;
      v114_vy_u = (slope * d) + v114_vy ;
      if ((pstate != cstate) || force_init_update) v114_vz_init = v114_vz ;
      slope =  (v114_vz * -190.4) ;
      v114_vz_u = (slope * d) + v114_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v114_t1 ;
      force_init_update = False;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      v114_v_u = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_voo = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v114!\n");
      exit(1);
    }
    break;
  case ( v114_t2 ):
    if (True == False) {;}
    else if  (v114_v >= (44.5)) {
      v114_vx_u = v114_vx ;
      v114_vy_u = v114_vy ;
      v114_vz_u = v114_vz ;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v114_t3 ;
      force_init_update = False;
    }
    else if  (v114_g <= (44.5)
               && v114_v < (44.5)) {
      v114_vx_u = v114_vx ;
      v114_vy_u = v114_vy ;
      v114_vz_u = v114_vz ;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v114_t1 ;
      force_init_update = False;
    }

    else if ( v114_v < (44.5)
               && v114_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v114_vx_init = v114_vx ;
      slope =  ((v114_vx * -23.6) + (777200.0 * v114_g)) ;
      v114_vx_u = (slope * d) + v114_vx ;
      if ((pstate != cstate) || force_init_update) v114_vy_init = v114_vy ;
      slope =  ((v114_vy * -45.5) + (58900.0 * v114_g)) ;
      v114_vy_u = (slope * d) + v114_vy ;
      if ((pstate != cstate) || force_init_update) v114_vz_init = v114_vz ;
      slope =  ((v114_vz * -12.9) + (276600.0 * v114_g)) ;
      v114_vz_u = (slope * d) + v114_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v114_t2 ;
      force_init_update = False;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      v114_v_u = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_voo = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v114!\n");
      exit(1);
    }
    break;
  case ( v114_t3 ):
    if (True == False) {;}
    else if  (v114_v >= (131.1)) {
      v114_vx_u = v114_vx ;
      v114_vy_u = v114_vy ;
      v114_vz_u = v114_vz ;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v114_t4 ;
      force_init_update = False;
    }

    else if ( v114_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v114_vx_init = v114_vx ;
      slope =  (v114_vx * -6.9) ;
      v114_vx_u = (slope * d) + v114_vx ;
      if ((pstate != cstate) || force_init_update) v114_vy_init = v114_vy ;
      slope =  (v114_vy * 75.9) ;
      v114_vy_u = (slope * d) + v114_vy ;
      if ((pstate != cstate) || force_init_update) v114_vz_init = v114_vz ;
      slope =  (v114_vz * 6826.5) ;
      v114_vz_u = (slope * d) + v114_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v114_t3 ;
      force_init_update = False;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      v114_v_u = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_voo = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v114!\n");
      exit(1);
    }
    break;
  case ( v114_t4 ):
    if (True == False) {;}
    else if  (v114_v <= (30.0)) {
      v114_vx_u = v114_vx ;
      v114_vy_u = v114_vy ;
      v114_vz_u = v114_vz ;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v114_t1 ;
      force_init_update = False;
    }

    else if ( v114_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v114_vx_init = v114_vx ;
      slope =  (v114_vx * -33.2) ;
      v114_vx_u = (slope * d) + v114_vx ;
      if ((pstate != cstate) || force_init_update) v114_vy_init = v114_vy ;
      slope =  ((v114_vy * 20.0) * v114_ft) ;
      v114_vy_u = (slope * d) + v114_vy ;
      if ((pstate != cstate) || force_init_update) v114_vz_init = v114_vz ;
      slope =  ((v114_vz * 2.0) * v114_ft) ;
      v114_vz_u = (slope * d) + v114_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v114_t4 ;
      force_init_update = False;
      v114_g_u = ((((((((((((v114_v_i_0 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.25913717719)) + ((((v114_v_i_1 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.79152786213))) + ((((v114_v_i_2 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.533603))) + ((((v114_v_i_3 + (- ((v114_vx + (- v114_vy)) + v114_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.44229854915))) + 0) + 0) + 0) + 0) + 0) ;
      v114_v_u = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_voo = ((v114_vx + (- v114_vy)) + v114_vz) ;
      v114_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v114!\n");
      exit(1);
    }
    break;
  }
  v114_vx = v114_vx_u;
  v114_vy = v114_vy_u;
  v114_vz = v114_vz_u;
  v114_g = v114_g_u;
  v114_v = v114_v_u;
  v114_ft = v114_ft_u;
  v114_theta = v114_theta_u;
  v114_v_O = v114_v_O_u;
  return cstate;
}