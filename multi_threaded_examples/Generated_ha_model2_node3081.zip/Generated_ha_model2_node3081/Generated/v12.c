#include<stdint.h>
#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#define True 1
#define False 0

extern double f(double,double);
double v12_v_i_0;
double v12_v_i_1;
double v12_v_i_2;
double v12_voo = 0.0;
double v12_state = 0.0;


static double  v12_vx  =  0 ,  v12_vy  =  0 ,  v12_vz  =  0 ,  v12_g  =  0 ,  v12_v  =  0 ,  v12_ft  =  0 ,  v12_theta  =  0 ,  v12_v_O  =  0 ; //the continuous vars
static double  v12_vx_u , v12_vy_u , v12_vz_u , v12_g_u , v12_v_u , v12_ft_u , v12_theta_u , v12_v_O_u ; // and their updates
static double  v12_vx_init , v12_vy_init , v12_vz_init , v12_g_init , v12_v_init , v12_ft_init , v12_theta_init , v12_v_O_init ; // and their inits
static unsigned char force_init_update;
extern double d; // the time step
static double slope; // the slope
enum states { v12_t1 , v12_t2 , v12_t3 , v12_t4 }; // state declarations

enum states v12 (enum states cstate, enum states pstate){
  switch (cstate) {
  case ( v12_t1 ):
    if (True == False) {;}
    else if  (v12_g > (44.5)) {
      v12_vx_u = (0.3 * v12_v) ;
      v12_vy_u = 0 ;
      v12_vz_u = (0.7 * v12_v) ;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v12_theta_u = (v12_v / 30.0) ;
      v12_v_O_u = (131.1 + (- (80.1 * pow ( ((v12_v / 30.0)) , (0.5) )))) ;
      v12_ft_u = f (v12_theta,4.0e-2) ;
      cstate =  v12_t2 ;
      force_init_update = False;
    }

    else if ( v12_v <= (44.5)
               && v12_g <= (44.5)     ) {
      if ((pstate != cstate) || force_init_update) v12_vx_init = v12_vx ;
      slope =  (v12_vx * -8.7) ;
      v12_vx_u = (slope * d) + v12_vx ;
      if ((pstate != cstate) || force_init_update) v12_vy_init = v12_vy ;
      slope =  (v12_vy * -190.9) ;
      v12_vy_u = (slope * d) + v12_vy ;
      if ((pstate != cstate) || force_init_update) v12_vz_init = v12_vz ;
      slope =  (v12_vz * -190.4) ;
      v12_vz_u = (slope * d) + v12_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v12_t1 ;
      force_init_update = False;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v12_v_u = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_voo = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_state = 0 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12!\n");
      exit(1);
    }
    break;
  case ( v12_t2 ):
    if (True == False) {;}
    else if  (v12_v >= (44.5)) {
      v12_vx_u = v12_vx ;
      v12_vy_u = v12_vy ;
      v12_vz_u = v12_vz ;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v12_t3 ;
      force_init_update = False;
    }
    else if  (v12_g <= (44.5)
               && v12_v < (44.5)) {
      v12_vx_u = v12_vx ;
      v12_vy_u = v12_vy ;
      v12_vz_u = v12_vz ;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v12_t1 ;
      force_init_update = False;
    }

    else if ( v12_v < (44.5) && 
              v12_g > (0.0)     ) {
      if ((pstate != cstate) || force_init_update) v12_vx_init = v12_vx ;
      slope =  ((v12_vx * -23.6) + (777200.0 * v12_g)) ;
      v12_vx_u = (slope * d) + v12_vx ;
      if ((pstate != cstate) || force_init_update) v12_vy_init = v12_vy ;
      slope =  ((v12_vy * -45.5) + (58900.0 * v12_g)) ;
      v12_vy_u = (slope * d) + v12_vy ;
      if ((pstate != cstate) || force_init_update) v12_vz_init = v12_vz ;
      slope =  ((v12_vz * -12.9) + (276600.0 * v12_g)) ;
      v12_vz_u = (slope * d) + v12_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v12_t2 ;
      force_init_update = False;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v12_v_u = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_voo = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_state = 1 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12!\n");
      exit(1);
    }
    break;
  case ( v12_t3 ):
    if (True == False) {;}
    else if  (v12_v >= (131.1)) {
      v12_vx_u = v12_vx ;
      v12_vy_u = v12_vy ;
      v12_vz_u = v12_vz ;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v12_t4 ;
      force_init_update = False;
    }

    else if ( v12_v < (131.1)     ) {
      if ((pstate != cstate) || force_init_update) v12_vx_init = v12_vx ;
      slope =  (v12_vx * -6.9) ;
      v12_vx_u = (slope * d) + v12_vx ;
      if ((pstate != cstate) || force_init_update) v12_vy_init = v12_vy ;
      slope =  (v12_vy * 75.9) ;
      v12_vy_u = (slope * d) + v12_vy ;
      if ((pstate != cstate) || force_init_update) v12_vz_init = v12_vz ;
      slope =  (v12_vz * 6826.5) ;
      v12_vz_u = (slope * d) + v12_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v12_t3 ;
      force_init_update = False;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v12_v_u = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_voo = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_state = 2 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12!\n");
      exit(1);
    }
    break;
  case ( v12_t4 ):
    if (True == False) {;}
    else if  (v12_v <= (30.0)) {
      v12_vx_u = v12_vx ;
      v12_vy_u = v12_vy ;
      v12_vz_u = v12_vz ;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      cstate =  v12_t1 ;
      force_init_update = False;
    }

    else if ( v12_v > (30.0)     ) {
      if ((pstate != cstate) || force_init_update) v12_vx_init = v12_vx ;
      slope =  (v12_vx * -33.2) ;
      v12_vx_u = (slope * d) + v12_vx ;
      if ((pstate != cstate) || force_init_update) v12_vy_init = v12_vy ;
      slope =  ((v12_vy * 20.0) * v12_ft) ;
      v12_vy_u = (slope * d) + v12_vy ;
      if ((pstate != cstate) || force_init_update) v12_vz_init = v12_vz ;
      slope =  ((v12_vz * 2.0) * v12_ft) ;
      v12_vz_u = (slope * d) + v12_vz ;
      /* Possible Saturation */
      
      
      
      
      
      cstate =  v12_t4 ;
      force_init_update = False;
      v12_g_u = ((((((((((((v12_v_i_0 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 1.78673862791)) + ((((v12_v_i_1 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 2.10000273137))) + ((((v12_v_i_2 + (- ((v12_vx + (- v12_vy)) + v12_vz))) * 100.0) * 0.1) / ((100.0 * 1.0e-2) * 3.86983624499))) + 0) + 0) + 0) + 0) + 0) + 0) ;
      v12_v_u = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_voo = ((v12_vx + (- v12_vy)) + v12_vz) ;
      v12_state = 3 ;
    }
    else {
      fprintf(stderr, "Unreachable state in: v12!\n");
      exit(1);
    }
    break;
  }
  v12_vx = v12_vx_u;
  v12_vy = v12_vy_u;
  v12_vz = v12_vz_u;
  v12_g = v12_g_u;
  v12_v = v12_v_u;
  v12_ft = v12_ft_u;
  v12_theta = v12_theta_u;
  v12_v_O = v12_v_O_u;
  return cstate;
}