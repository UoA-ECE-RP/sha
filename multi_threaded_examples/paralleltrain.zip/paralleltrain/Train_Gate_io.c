#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<string.h>
#include<assert.h>
#include"BigMain.h"

/* The files are in csv format */
//#define OFILE "train_gate.csv"

#define TRUE 1
#define FALSE 0


/* The step size */
double d = 0.2;


void readInput(IO* io, Train*t, Gate* g) {

  if (t->train_signal != io->signal_pre){
    if (t->train_signal == 1){

      g->DOWN=1;
      g->UP=0;
    }
    else{

      g->DOWN=0;
      g->UP=1;
    }

    io->signal_pre = t->train_signal;
  }
  else {
    g->DOWN=0;
    g->UP=0;
  }
}


/* Write output x to file */
void writeOutput(IO* io){

  (io->tick)++;
  if (io->tick==5000) {

    return;
  }

}


