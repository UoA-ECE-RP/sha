#include <stdio.h>
#include <cilk/cilk.h>
// #include <omp.h>
#include <BigMain.h>
#include <stdlib.h>
#include <time.h>

int maintg(Train*, Gate*, IO*);
extern void writeOutput(IO*);

int main(int argc, char const *argv[])
{

	time_t start,end;  
	start = time(&start);  
	/* code */
	int i = 0;

	// cilk_for (i=0;i<67;i++){
	// #pragma omp parallel for
	cilk_for (i=0;i<=3080;i++){

		IO* io = (IO*)(calloc(1,sizeof(struct iot)));
		Train *t = (Train*)(calloc(1, sizeof(struct train)));
		Gate *g = (Gate*)(calloc(1, sizeof(struct gate)));
		g->cstate = 0;
		g->pstate = -1;
		g->gate_x=10.0;

		// Train 
		t->cstate = 0;
		t->pstate = -1;
		t->train_y = 0.0;

		maintg(t, g, io);

		writeOutput(io);
	}

	end =time(&end);  
	printf("time=%f\n",difftime(end,start));
	return 0;
}