#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#include "BigMain.h"

#define True 1

#define False 0


//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2};

//Previous state variable

#include "t1.h"
#include <math.h>
double gate_t1_ode_1(double d, double gate_x) {
   double gate_t1_ode_1_result;
   gate_t1_ode_1_result = d*(-1.0L/2.0L*gate_x + 11.0L/2.0L) + gate_x;
   return gate_t1_ode_1_result;
}
double gate_t1_init_1(double x) {
   double gate_t1_init_1_result;
   gate_t1_init_1_result = x;
   return gate_t1_init_1_result;
}


#include "t2.h"
#include <math.h>
double gate_t2_ode_1(double d, double gate_x) {
   double gate_t2_ode_1_result;
   gate_t2_ode_1_result = -1.0L/2.0L*d*gate_x + gate_x;
   return gate_t2_ode_1_result;
}
double gate_t2_init_1(double x) {
   double gate_t2_init_1_result;
   gate_t2_init_1_result = x;
   return gate_t2_init_1_result;
}


enum states gate(Gate* GATE) {
  switch (GATE->cstate) {
  case (t1):
    if(GATE->gate_x >= 1 && GATE->gate_x <= 10 && !GATE->DOWN && !GATE->UP){
      if ((GATE->pstate != GATE->cstate) || True){
        GATE->gate_x = gate_t1_init_1(GATE->gate_x);
        GATE->gate_x_init = GATE->gate_x;
      }
      GATE->gate_x_u = gate_t1_ode_1(d, GATE->gate_x);
      if(GATE->gate_x_u > 10 && GATE->gate_x_init <= 10)
        GATE->gate_x_u = 10;
      ++k;
      GATE->cstate = t1;
       
    }
    else if(GATE->DOWN && True) {
      k=1;
      GATE->cstate=t2;
      GATE->gate_x_u = GATE->gate_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(GATE->gate_x >= 1 && GATE->gate_x <= 10 && !GATE->DOWN && !GATE->UP){
      if ((GATE->pstate != GATE->cstate) || True){
        GATE->gate_x = gate_t2_init_1(GATE->gate_x);
        GATE->gate_x_init = GATE->gate_x;
      }
      GATE->gate_x_u = gate_t2_ode_1(d, GATE->gate_x);
      if(GATE->gate_x_u < 1 && GATE->gate_x_init >= 1)
        GATE->gate_x_u = 1;
      ++k;
      GATE->cstate = t2;
      
    }
    else if(GATE->UP && True) {
      k=1;
      GATE->cstate=t1;
      GATE->gate_x_u = GATE->gate_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  GATE->gate_x = GATE->gate_x_u;
  return GATE->cstate;
}
