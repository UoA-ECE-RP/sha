#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>
#include<cilk/cilk.h>
#include<time.h>

#include<math.h>
#include"BigMain.h"

#define True 1

#define False 0

//Events

extern void readInput(IO*, Train*, Gate*);

extern void writeOutput(IO*);

extern int train(Train*);

extern int gate(Gate*);

int maintg(Train *t, Gate *g, IO* io) {

  while(True) {

    readInput(io, t, g);

    int otcstate = t->cstate;
    train (t);
    t->pstate = otcstate;

    int ogcstate = g->cstate;
    gate (g);
    t->pstate = ogcstate;


    writeOutput(io);
   
    if( io->tick == 1000000) {
         /* terminate the loop using break statement */
         break;
    }
  }


  return 0;

}
