
-----------------------------------------------------
1. Example description

This is a Train&Gate control example that models the behavior of a gate at a rail road.

-----------------------------------------------------
2. Files

This folder contains:
BigMain.c: The main file for executing multiple trains&gates (e.g.3080).
BigMain.h: Defining structures.
maintg.c: The file for executing one train and gate.
gateforcilk.c: The generated C code for the HIOA of gate.
trainforcilk.c: The generated C code for the HIOA of train.
Train_Gate_io.c: The controller that is used to control the movement of the gate.

(currently, in "BigMain.c", Cilk is used for parallelization; the code can be adjusted to implement parallelization with OpenMP or for sequential execution).

"model" is the executable that generated after compile all the C files.


-----------------------------------------------------
3. How to compile and execute the C files (for sequentical execution)

Using a C compiler like GCC and Clang to compile the generated C file and output an executable - "model":

Clang:
clang -O0 trainforcilk.c gateforcilk.c maintg.c BigMain.c Train_Gate_io.c -o model

gcc:
/usr/local/bin/gcc-6 -O0 trainforcilk.c gateforcilk.c maintg.c BigMain.c Train_Gate_io.c -o model


After compile the generated C files into the executable, to run the executable:

./model 

		
-----------------------------------------------------
4. How to compile and execute the generated C code when implementing parallelization with Cilk.

The language extensions of Cilk need to be installed on the C compiler that is used to compile the code. When using Clang as the compiler to compile the C ocde into binary: (more detail of installing and using Cilk in the Clang see https://cilkplus.github.io/) 

export PATH=/install/prefix/bin:$PATH
export C_INCLUDE_PATH=/install/prefix/include:$C_INCLUDE_PATH
export CPLUS_INCLUDE_PATH=/install/prefix/include:$CPLUS_INCLUDE_PATH
export LIBRARY_PATH=/install/prefix/lib:$LIBRARY_PATH
export LD_LIBRARY_PATH=/install/prefix/lib:$LD_LIBRARY_PATH

clang -O0 -fcilkplus -I"/install/prefix/lib/" trainforcilk.c gateforcilk.c maintg.c BigMain.c Train_Gate_io.c -o model
	
To run:	 

CILK_NWORKERS=(number of threads expected to be used to execute the code) ./model


-----------------------------------------------------
5. How to compile the generated C code when implementing parallelization with OpenMP.

When using GCC as the compiler to compile the C ocde into binary: 

/usr/local/bin/gcc-6 -O0 -fopenmp trainforcilk.c gateforcilk.c maintg.c BigMain.c Train_Gate_io.c -o model

To run: 

OMP_NUM_THREADS=(number of threads expected to be used to execute the code) ./model 
or
./model (if already set how many threads expected to be used to execute the code, in "BigMain.c")

		

