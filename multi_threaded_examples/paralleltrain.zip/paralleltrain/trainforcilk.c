#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#include "BigMain.h"

#define True 1

#define False 0


//Step-size constant d

extern double d;

//Nstep constant k

//double k;

//States
enum states {t1 , t2 , t3};

//Previous state variable

#include "t1.h"
#include <math.h>
double train_t1_ode_1(double d, double train_y) {
   double train_t1_ode_1_result;
   train_t1_ode_1_result = d + train_y;
   return train_t1_ode_1_result;
}
double train_t1_init_1(double y) {
   double train_t1_init_1_result;
   train_t1_init_1_result = y;
   return train_t1_init_1_result;
}


#include "t2.h"
#include <math.h>
double train_t2_ode_1(double d, double train_y) {
   double train_t2_ode_1_result;
   train_t2_ode_1_result = d + train_y;
   return train_t2_ode_1_result;
}
double train_t2_init_1(double y) {
   double train_t2_init_1_result;
   train_t2_init_1_result = y;
   return train_t2_init_1_result;
}


#include "t3.h"
#include <math.h>
double train_t3_ode_1(double d, double train_y) {
   double train_t3_ode_1_result;
   train_t3_ode_1_result = d + train_y;
   return train_t3_ode_1_result;
}
double train_t3_init_1(double y) {
   double train_t3_init_1_result;
   train_t3_init_1_result = y;
   return train_t3_init_1_result;
}


enum states train(Train *TRAIN) {
  
  switch (TRAIN->cstate) {
  case (t1):
    if(TRAIN->train_y < 5){
      if ((TRAIN->pstate != TRAIN->cstate) || True){
        TRAIN->train_y = train_t1_init_1(TRAIN->train_y);
        TRAIN->train_y_init = TRAIN->train_y;
      }
      TRAIN->train_y_u = train_t1_ode_1(d, TRAIN->train_y);
      if(TRAIN->train_y_u > 5 && TRAIN->train_y_init <= 5)
        TRAIN->train_y_u = 5;
      //++k;
      TRAIN->cstate = t1;
      //False = False;
    }
    else if(True && TRAIN->train_y >= 5 && TRAIN->train_y <= 5) {
      //k=1;
      TRAIN->cstate=t2;
      TRAIN->train_y_u = TRAIN->train_y;
      TRAIN->train_signal = 1;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(TRAIN->train_y >= 5 && TRAIN->train_y < 15){
      if ((TRAIN->pstate != TRAIN->cstate)){
        TRAIN->train_y = train_t2_init_1(TRAIN->train_y);
        TRAIN->train_y_init = TRAIN->train_y;
      }
      TRAIN->train_y_u = train_t2_ode_1(d, TRAIN->train_y);
      if(TRAIN->train_y_u > 15 && TRAIN->train_y_init <= 15)
        TRAIN->train_y_u = 15;
      //++k;
      TRAIN->cstate = t2;
      //False = False;
    }
    else if(True && TRAIN->train_y >= 15 && TRAIN->train_y <= 15) {
      // k=1;
      TRAIN->cstate=t3;
      TRAIN->train_y_u = TRAIN->train_y;
      TRAIN->train_signal = 0;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t3):
    if(TRAIN->train_y >= 15 && TRAIN->train_y < 25){
      if ((TRAIN->pstate != TRAIN->cstate)){
        TRAIN->train_y = train_t3_init_1(TRAIN->train_y);
        TRAIN->train_y_init = TRAIN->train_y;
      }
      TRAIN->train_y_u = train_t3_ode_1(d, TRAIN->train_y);
      if(TRAIN->train_y_u > 25 && TRAIN->train_y_init <= 25)
        TRAIN->train_y_u = 25;
      //++k;
      TRAIN->cstate = t3;
      // False = False;
    }
    else if(True && TRAIN->train_y >= 25 && TRAIN->train_y <= 25) {
      //k=1;
      TRAIN->cstate=t1;
      TRAIN->train_y = 0;
      TRAIN->train_y_u = TRAIN->train_y;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  TRAIN->train_y = TRAIN->train_y_u;
  return TRAIN->cstate;
}
