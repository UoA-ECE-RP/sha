typedef struct iot {
	size_t tick;
	int signal_pre;
}IO;
typedef struct  train {
	double train_y, train_y_u, train_y_init;
	int cstate, pstate;
	int train_signal;
}Train;
typedef struct  gate {
	double gate_x, gate_x_u, gate_x_init;
	int cstate, pstate;
	int UP, DOWN;
}Gate;