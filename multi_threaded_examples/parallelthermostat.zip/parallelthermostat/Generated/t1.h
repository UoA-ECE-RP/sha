#ifndef PROJECT__T1__H
#define PROJECT__T1__H
double th3080_t1_ode_1(double d, double th3080_x);
double th3080_t1_init_1(double x);
#endif
