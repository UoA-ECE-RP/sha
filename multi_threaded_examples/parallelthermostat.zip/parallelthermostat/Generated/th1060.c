#include<stdint.h>

#include<stdlib.h>

#include<stdio.h>

#define True 1

#define False 0

// Global variables from outside this HA

// Global variables in this HA

//Events

extern void readInput();

extern void writeOutput();

//Continous variables

double th1060_x=22.78;

//Continous variable update

static double th1060_x_u;

//Continous variable init

static double th1060_x_init;

//External variables and events

//Step-size constant d

extern double d;

//Nstep constant k

double k;

//States

enum states {t1 , t2};

//Previous state variable

#include "t1.h"
#include <math.h>
double th1060_t1_ode_1(double d, double th1060_x) {
   double th1060_t1_ode_1_result;
   th1060_t1_ode_1_result = d*(-th1060_x + 10) + th1060_x;
   return th1060_t1_ode_1_result;
}
double th1060_t1_init_1(double x) {
   double th1060_t1_init_1_result;
   th1060_t1_init_1_result = x;
   return th1060_t1_init_1_result;
}


#include "t2.h"
#include <math.h>
double th1060_t2_ode_1(double d, double th1060_x) {
   double th1060_t2_ode_1_result;
   th1060_t2_ode_1_result = d*(-th1060_x + 37.78) + th1060_x;
   return th1060_t2_ode_1_result;
}
double th1060_t2_init_1(double x) {
   double th1060_t2_init_1_result;
   th1060_t2_init_1_result = x;
   return th1060_t2_init_1_result;
}


enum states th1060(enum states cstate, enum states pstate) {
  static double fk;
  static unsigned char force_init_update;
  switch (cstate) {
  case (t1):
    if(th1060_x > 22.78){
      if ((pstate != cstate) || force_init_update){
        th1060_x = th1060_t1_init_1(th1060_x);
        th1060_x_init = th1060_x;
      }
      th1060_x_u = th1060_t1_ode_1(d, th1060_x);
      if(th1060_x_u < 22.7800000000000 && th1060_x_init >= 22.7800000000000)
        th1060_x_u = 22.7800000000000;
      ++k;
      cstate = t1;
      force_init_update = False;
    }
    else if(True && th1060_x <= 22.78) {
      k=1;
      cstate=t2;
      th1060_x_u = th1060_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  case (t2):
    if(th1060_x < 25){
      if ((pstate != cstate) || force_init_update){
        th1060_x = th1060_t2_init_1(th1060_x);
        th1060_x_init = th1060_x;
      }
      th1060_x_u = th1060_t2_ode_1(d, th1060_x);
      if(th1060_x_u > 25 && th1060_x_init <= 25)
        th1060_x_u = 25;
      ++k;
      cstate = t2;
      force_init_update = False;
    }
    else if(True && th1060_x >= 25) {
      k=1;
      cstate=t1;
      th1060_x_u = th1060_x;
    }
    else {
      fprintf(stderr,"Unreachable state!");
      exit(1);
    }
    break;
  default: exit(1);
  }
  th1060_x = th1060_x_u;
  return cstate;
}