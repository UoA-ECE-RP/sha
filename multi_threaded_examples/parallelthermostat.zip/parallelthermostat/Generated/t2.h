#ifndef PROJECT__T2__H
#define PROJECT__T2__H
double th3080_t2_ode_1(double d, double th3080_x);
double th3080_t2_init_1(double x);
#endif
